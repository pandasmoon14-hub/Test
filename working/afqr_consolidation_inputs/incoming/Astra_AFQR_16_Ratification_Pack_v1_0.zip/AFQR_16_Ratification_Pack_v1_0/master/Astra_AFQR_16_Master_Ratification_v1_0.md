# Astra AFQR-16 Master Ratification v1.0

## Part I — Executive decision

**Selected architecture:** Registered Federated Embodiment–Integrity Architecture with Typed Component–Function–Dependency Graphs, Staged Exposure–Transfer–Effect Pipelines, Profile-Scoped Injury–Condition–Death Families, and Bitemporal Recovery–Transformation Continuity  
**Abbreviation:** `RFEIA-CFDG-SETE-ICD-BRTC`  
**Confidence:** High  
**Resolution:** Ratification candidate.

> **Central law:** No body, structure, component, anatomy label, hit-point value, damage number, injury label, condition, death flag, treatment text, repair result, transformation description, donor rule, or model narration possesses mutation authority by itself. Every authoritative embodiment result is a purpose-scoped, version-pinned, bitemporal determination over frozen identity, embodiment, topology, substrate, function, dependency, redundancy, protection, exposure, quantity, epistemic, agency, consent, behavioral, social, communication, governed-relation, and institutional bases. Contact, transfer, penetration, uptake, effect, injury, condition, impairment, death or destruction, recoverability, treatment, repair, replacement, and transformation remain separate. Only owner-prepared AFQR-01 transitions mutate state; later diagnosis, reinterpretation, recovery, and continuity determinations append records rather than rewriting history; unresolved and source-local outcomes remain lawful.

This is a federated embodiment and integrity architecture for biological, synthetic, mechanical, digital, spiritual, distributed, platform, and source-local systems. It is not a replacement hit-point system, universal anatomy, universal damage taxonomy, universal death doctrine, universal medical model, or final combat engine.

No second broad research pass is required. Narrow implementation research remains mandatory for every adopted harm family, substrate, clinical or technical evaluator, death profile, source-local metaphysics, environmental interface, and high-fidelity simulation tier.

## Part II — Repository-grounded diagnosis

The verified `main` head is `928bb79ce00a2de749d127dcc5cb8299de788a15`, the merge of PR #325 / RT-002F.

The runtime doctrine names injury, condition, damage, and recovery as future backend-owned state and requires typed versioned records, component ownership, validation before mutation, append-only events, deterministic replay, and narration after commitment. Those are accepted doctrine, not generalized implementation.

Batch B treats health/injury/recovery, hazards/exposure, repair, vehicles, and implants as conversion and procedural pressure. Batch C provides candidate creature, platform, hazard, implant, repair, resistance, and exposure references but explicitly forbids live injury and runtime-state leakage. Its creature/platform composition rule prevents platform state from becoming creature biology.

RT-002A–F remains a narrow object/lever fixture: one actor, one target/NPC, a hazard clock, a visible condition string, a hidden fact, legality/preview, event/delta, and replay/audit envelopes. It implements no body, anatomy, damage, injury, condition progression, impairment, diagnosis, consciousness, death, healing, repair, or transformation service.

The complete 50-question determination follows.

| question_number | question | implemented_status | answer |
| --- | --- | --- | --- |
| 1 | Are bodies represented authoritatively? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 2 | Are bodies distinct from actors and identities? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 3 | Are nonbiological structures represented through the same or separate schemas? | conversion_schema_only | Conversion schemas or pressure records describe this family, but they do not own campaign state or runtime mutation. |
| 4 | Are body or structure components represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 5 | Are topology and dependency explicit? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 6 | Are functional subsystems represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 7 | Is redundancy represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 8 | Are protective layers represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 9 | Is damage represented? | accepted_doctrine_not_implemented | The doctrine recognizes this state family or future owner, but no generalized service or committed state model exists. |
| 10 | Is damage distinct from injury? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 11 | Are harmful exposures represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 12 | Are contact, transfer, penetration, and uptake separated? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 13 | Are dose and duration represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 14 | Are damage families registered or freeform? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 15 | Are resistances separated from immunity and armor? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 16 | Can protection itself be damaged? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 17 | Are injuries represented? | accepted_doctrine_not_implemented | The doctrine recognizes this state family or future owner, but no generalized service or committed state model exists. |
| 18 | Are conditions represented? | accepted_doctrine_not_implemented | The doctrine recognizes this state family or future owner, but no generalized service or committed state model exists. |
| 19 | Are injuries separated from conditions and symptoms? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 20 | Are condition progression and timing represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 21 | Is impairment represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 22 | Is impairment separated from incapacity and agency? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 23 | Are accommodations or assistive systems represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 24 | Are pain and sensation represented separately from damage? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 25 | Is diagnosis represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 26 | Can misdiagnosis exist? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 27 | Is consciousness represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 28 | Are unconsciousness and incapacitation separated? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 29 | Is death represented? | accepted_doctrine_not_implemented | The doctrine recognizes this state family or future owner, but no generalized service or committed state model exists. |
| 30 | Are body death and identity continuity separated? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 31 | Are destruction and irrecoverability separated? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 32 | Are remains or corpses represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 33 | Are stabilization and treatment represented? | accepted_doctrine_not_implemented | The doctrine recognizes this state family or future owner, but no generalized service or committed state model exists. |
| 34 | Are healing, regeneration, repair, and replacement separated? | accepted_doctrine_not_implemented | The doctrine recognizes this state family or future owner, but no generalized service or committed state model exists. |
| 35 | Are treatment resources and time represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 36 | Are complications represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 37 | Are implants and prosthetics represented? | conversion_schema_only | Conversion schemas or pressure records describe this family, but they do not own campaign state or runtime mutation. |
| 38 | Are transformations represented? | accepted_doctrine_not_implemented | The doctrine recognizes this state family or future owner, but no generalized service or committed state model exists. |
| 39 | Can injury continuity across forms be disputed? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 40 | Are vehicle and structure component failures represented? | conversion_schema_only | Conversion schemas or pressure records describe this family, but they do not own campaign state or runtime mutation. |
| 41 | Are cascading failures represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 42 | Are distributed bodies supported? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 43 | Can a swarm lose components without whole-subject death? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 44 | Can a copy inherit none, some, or disputed conditions? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 45 | Can a resurrected body differ from the prior body? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 46 | Can hidden injuries remain invisible to the model? | accepted_AFQR_architecture_only | AFQR-08–16 provides the separation or continuity rule; repository implementation is absent. |
| 47 | Which health or damage fields are conversion-only? | conversion_schema_only | Conversion schemas or pressure records describe this family, but they do not own campaign state or runtime mutation. |
| 48 | Which are fixture-only? | fixture_only | RT-002A–F has only generic actor/target refs, one visible condition label, object/lever mutation, visibility, event, and replay envelopes. |
| 49 | Which are narrative-only? | narrative_only | Combat descriptions, health prose, injury text, dead/broken labels, treatment descriptions, and model narration are non-authoritative surfaces. |
| 50 | What implementation remains blocked? | blocked | Embodiment, topology, exposure, protection, injury, condition, function, diagnosis, consciousness, death, recovery, repair, replacement, and transformation execution remain blocked. |

## Part III — External research synthesis


### Trauma Medicine Injury Classification

**Actual mechanism.** Injury classification separates external cause and mechanism, anatomical site and nature, physiological state, severity, triage, stabilization, and complications. Blunt, penetrating, burn, fracture, hemorrhage, and shock are not one variable.

**Architectural lesson.** Use mechanism, exposure, localization, component state, physiological or functional effect, severity profile, triage, and stabilization as separate records.

**Limitation.** Human clinical categories and thresholds cannot define all species, machines, spirits, or source-local embodiments.

**Astra disposition.** `adapt_structural_separations`.


### Physiology Systems Biology

**Actual mechanism.** Homeostatic systems use feedback, reserves, compensation, thresholds, adaptation, and interdependent organ or subsystem functions. Functional collapse can lag behind injury and compensation can preserve performance.

**Architectural lesson.** Represent function providers, dependencies, reserve, redundancy, feedback, compensation, thresholds, and cascading failure.

**Limitation.** Human physiology is one embodiment profile, not universal substrate law.

**Astra disposition.** `adapt_dependency_and_reserve_grammar`.


### Pathology Disease Progression

**Actual mechanism.** Conditions may be latent, incubating, acute, chronic, remitting, recurrent, progressive, complicated, or resolved; symptoms and contagiousness can differ across stages.

**Architectural lesson.** Use condition definitions, stage machines, onset/progression schedules, suppression, remission, recurrence, complications, and sequelae.

**Limitation.** Disease-specific staging and mechanisms remain profile- and source-local.

**Astra disposition.** `adapt_condition_lifecycle`.


### Toxicology Dose Response

**Actual mechanism.** Effect depends on agent, route, administered and absorbed dose, concentration, duration, target tissue, kinetics, accumulation, interactions, susceptibility, and uncertainty; dose-response can be nonlinear.

**Architectural lesson.** Separate exposure, route, uptake, target dose, timing, metabolism or conversion, accumulation, delayed effects, interaction, and uncertainty.

**Limitation.** No universal linear dose-response curve or shared toxicity scale.

**Astra disposition.** `adapt_quantity_valid_pipeline`.


### Biomechanics Fracture Mechanics

**Actual mechanism.** Loads create stress and strain through geometry, rate, direction, material anisotropy, flaws, fatigue, and load paths; fracture and deformation are distinct failure modes.

**Architectural lesson.** Represent load paths, material profiles, impact/transfer, stressor history, crack initiation and propagation, deformation, fatigue, and arrest.

**Limitation.** Direct physics simulation is expensive and calibrated only for declared substrates.

**Astra disposition.** `adapt_profiled_mechanics_not_universal_physics`.


### Materials Science Degradation

**Actual mechanism.** Hardness, toughness, brittleness, elasticity, plasticity, wear, corrosion, thermal/radiation degradation, composites, coatings, and repairability describe different properties.

**Architectural lesson.** Use source-scoped substrate property sets and stage-specific protection/degradation interactions.

**Limitation.** No universal material property list or cross-genre unit system is sufficient.

**Astra disposition.** `adapt_extensible_substrate_profiles`.


### Reliability Safety Engineering

**Actual mechanism.** FMEA, fault trees, redundancy, common-cause failure, graceful degradation, fail-safe states, inspection, maintenance, and reliability growth distinguish local failures from system effects.

**Architectural lesson.** Use bounded component-function-dependency graphs, failure propagation profiles, common-cause groups, emergency modes, maintenance history, and recursion limits.

**Limitation.** Engineering analyses do not determine biological injury or metaphysical continuity.

**Astra disposition.** `adopt_graph_and_failure_safety_patterns`.


### Robotics Vehicles Ships Machinery

**Actual mechanism.** Complex platforms separate structure, power, control, sensing, propulsion, environment, occupants, cargo, mission capability, repair, inspection, and catastrophic loss.

**Architectural lesson.** Platform damage, crew injury, cargo state, AI process state, environmental exposure, and mission capability require different owners.

**Limitation.** Vehicle families differ substantially and cannot share one component list or destruction threshold.

**Astra disposition.** `adapt_platform_composition`.


### Electrical Thermal Radiation Pressure

**Actual mechanism.** Outcome depends on current or energy path, waveform, contact, temperature, exposure time, absorbed dose, dose rate, shielding, tissue/material sensitivity, pressure gradient, and delayed effects.

**Architectural lesson.** Register route- and substrate-specific exposure profiles with delayed progression and stage-specific protection.

**Limitation.** These physical models do not automatically apply to magical, digital, or incorporeal targets.

**Astra disposition.** `adapt_as_harm_family_profiles`.


### Infectious Disease Immunology

**Actual mechanism.** Exposure, uptake, colonization or infection, incubation, immune or defensive response, infectiousness, symptoms, recovery, persistence, and sequelae are distinct.

**Architectural lesson.** AFQR-16 owns host exposure and condition state; later environment/population doctrine owns transmission networks and epidemiology.

**Limitation.** No universal pathogen, immunity, or contagion model is adopted.

**Astra disposition.** `adapt_host_state_defer_population_spread`.


### Functional Assessment Disability Rehabilitation

**Actual mechanism.** Functioning is contextual and includes body function, activity, participation, environment, assistance, adaptation, rehabilitation, and assistive technology.

**Architectural lesson.** Separate impairment from task limitation, participation, agency, and personhood; allow accommodations and assisted function to restore practical performance.

**Limitation.** Human disability classifications must not become a universal normality standard for all embodiments.

**Astra disposition.** `adopt_contextual_function_principle`.


### Pain Symptom Representation

**Actual mechanism.** Pain is a subjective sensory and emotional experience influenced by biological, psychological, and social factors; pain can occur without visible injury and injury without pain, and inability to communicate does not negate pain.

**Architectural lesson.** Separate nociception, pain experience, symptom report, observable sign, injury truth, behavioral effects, and credibility.

**Limitation.** Astra must not infer subjective pain universally or reduce it to a numeric damage proxy.

**Astra disposition.** `adopt_separation_and_private_experience`.


### Consciousness Capacity

**Actual mechanism.** Wakefulness, awareness, responsiveness, orientation, motor output, communication access, and task-specific capacity can dissociate.

**Architectural lesson.** Use orthogonal consciousness and capacity dimensions; incapacity remains purpose-specific and routes to AFQR-11.

**Limitation.** Human neurological categories are not universal consciousness metaphysics.

**Astra disposition.** `adapt_orthogonal_state_dimensions`.


### Death Determination Forensics

**Actual mechanism.** Death determination depends on a defined criterion, prerequisites, evidence, examination, timing, and purpose; circulatory and neurological criteria differ, and legal certification is a separate institutional record.

**Architectural lesson.** Use profile-scoped death, destruction, recoverability, and remains determinations, then route person continuity to AFQR-08 and legal death to AFQR-15.

**Limitation.** No universal definition of life, death, soul separation, or irreversibility is adopted.

**Astra disposition.** `adapt_evidence_based_profile_architecture`.


### Regeneration Transplantation Prosthetics Replacement

**Actual mechanism.** Restoration can involve healing, regeneration, transplant, implant, prosthetic support, integration, rejection, maintenance, rehabilitation, complications, and changed dependencies.

**Architectural lesson.** Separate replacement identity, compatibility, procedure, integration, rejection, maintenance dependency, capability, and continuity.

**Limitation.** Human clinical ethics and biology do not settle all synthetic or source-local replacements.

**Astra disposition.** `adapt_replacement_integration_pipeline`.


### Veterinary Botanical Fungal Nonhuman

**Actual mechanism.** Nonhuman life includes modular, colonial, distributed, regenerative, plant, fungal, and other topologies in which local loss and whole-organism failure differ.

**Architectural lesson.** Avoid humanoid anatomy; support modularity, distributed functions, mutable topology, and node-level continuity.

**Limitation.** No single nonhuman source represents the full donor range.

**Astra disposition.** `adapt_anatomical_neutrality`.


### Digital Informational Integrity

**Actual mechanism.** Digital resilience separates corruption, detection, protection, versioning, checkpoints, last-known-good state, backups, failover, process restart, restoration, consistency, and malicious modification.

**Architectural lesson.** Digital harm needs data/process/node/topology semantics; backup existence does not decide identity continuity.

**Limitation.** Digital states do not map directly to biological injury or death.

**Astra disposition.** `adopt_parallel_integrity_family`.


### Games Simulation Systems

**Actual mechanism.** Games variously use hit points, wounds, stress, consequences, harm levels, dying tracks, structure/stress, morph durability, component loss, and recovery clocks.

**Architectural lesson.** These are pressure families that may map to aggregate integrity, injuries, conditions, function loss, or source-local adapters.

**Limitation.** Game abstractions often collapse stages and cannot become universal Astra law.

**Astra disposition.** `contain_as_donor_pressure`.


### Ttrpg Systems

**Actual mechanism.** TTRPG donors encode armor, soak, resistance, damage types, hit locations, disease, poison, corruption, fatigue, death saves, healing, resurrection, vehicle damage, and conceptual harm incompatibly.

**Architectural lesson.** Extract semantics and route each construct through direct, normalized, source-local, quarantine, or escalation outcomes.

**Limitation.** No donor’s anatomy, HP, death, healing, or metaphysics is universal.

**Astra disposition.** `normalize_or_retain_source_locally`.


## Part IV — Canonical terminology


### Embodiment

- **embodiment:** A purpose-scoped relation by which one or more identities are manifested, hosted, represented, or enabled through one or more body or structure instances.

- **body:** An embodiment-oriented organized substrate or component system; not automatically a person, actor, owner, controller, or legal subject.

- **structure:** An organized material, synthetic, digital, energetic, or source-local component system evaluated for integrity and function.

- **vessel:** A body or structure capable of hosting, carrying, or supporting an identity, occupant, process, or controlled manifestation under a named profile.

- **form:** A versioned topology, appearance, substrate, or manifestation state of an embodiment.

- **manifestation:** A source- and profile-scoped appearance or operational presence of an identity that may or may not be a persistent body.

- **body instance:** A particular identity-bearing body record at a recorded interval.

- **structural instance:** A particular structure record with versioned topology, components, functions, and state.

- **component:** A typed part, node, tissue, organ, module, layer, or process with its own identity, interfaces, state, and relations where relevant.

- **subcomponent:** A component whose part-of relation is scoped beneath another component without implying inheritance of all properties.

- **tissue:** A biological or source-local substrate organization with profile-defined properties and functions.

- **organ:** A functionally organized body component; its semantics are embodiment-profile specific rather than universally biological.

- **module:** A replaceable, detachable, or logically bounded component with declared interfaces and dependencies.

- **subsystem:** A coordinated component set providing one or more functions.

- **layer:** A topological or functional stratum that may affect contact, transfer, containment, protection, or propagation.

- **surface:** A registered contact boundary; it may be spatial, network, energetic, informational, or source-local.

- **interface:** A registered boundary through which matter, energy, signal, load, control, support, or source-local effects may pass.

- **topology:** A versioned graph of component, attachment, containment, interface, reachability, and support relations.

- **material:** A source-scoped substrate category with named property sets rather than a universal physics list.

- **biological substrate:** A living or once-living substrate governed by a biological or source-local profile.

- **synthetic substrate:** An engineered nonbiological or hybrid substrate.

- **distributed body:** An embodiment whose functions or continuity are spread across multiple nodes without requiring a privileged central component.

- **incorporeal body:** A source-local embodiment lacking ordinary physical substrate while retaining declared interfaces, topology, and integrity semantics.

### Function

- **function:** A purpose-scoped contribution or operation provided by one or more components, substrates, processes, supports, or environments.

- **functional domain:** A named class of function such as mobility, sensing, regulation, processing, protection, transport, communication, or source-local operation.

- **capacity:** A typed upper bound, current ability, or task-specific performance measure under a named profile.

- **reserve:** Available capacity beyond current ordinary demand that can support compensation, peak use, or degradation.

- **redundancy:** Multiple providers or pathways capable of sustaining a function under a registered failover or aggregation profile.

- **dependency:** A typed relation stating that a function, component, process, or state relies on another subject, component, interface, resource, or environment.

- **support relation:** A dependency-family relation providing enabling, stabilizing, load-bearing, regulatory, or maintenance support.

- **baseline function:** The reference functional state for a profile and interval, not a universal normality standard.

- **available function:** The currently usable function after dependencies, impairment, reserve, environment, support, and accommodations are evaluated.

- **assisted function:** Function made usable through an aid, replacement, external support, interface, person, or environmental modification.

- **degraded function:** Function that remains available with reduced capacity, reliability, precision, duration, safety, or scope.

- **lost function:** Function unavailable under the evaluated context; it does not imply universal incapacity.

- **impairment:** A context- and purpose-scoped alteration or limitation of function; not loss of agency, personhood, or universal inability.

- **limitation:** A task- or environment-specific restriction in performance or access.

- **accommodation:** A change to tools, environment, procedure, assistance, or interface that improves practical function without requiring removal of the underlying impairment.

- **adaptation:** A persistent or learned change that alters function, tolerance, compensation, or interaction with the environment.

### Harm Exposure

- **harmful event:** A committed event capable of producing adverse embodiment or structural effects under one or more registered profiles.

- **harm agent:** A typed source, carrier, process, substance, load, signal, or source-local effect capable of harmful exposure.

- **damage family:** A registered interoperability and effect-routing family; not a universal list of damage types or severity scale.

- **exposure:** A relation in which a target boundary is presented to a harm agent through a route for an interval.

- **contact:** A profile-scoped determination that source or carrier reached a target surface or interface.

- **impact:** A contact event involving a registered load, momentum, energy, pressure, or source-local transfer profile.

- **transfer:** A determined movement of typed quantity or effect potential across an interface.

- **penetration:** A determination that exposure crosses a layer or boundary under a named profile.

- **uptake:** Absorption, entry, ingestion, inhalation, injection, infection, reception, or other acquisition by a target subsystem.

- **propagation:** Movement or reproduction of an exposure, fault, load, condition, or effect through a registered path.

- **load:** A typed demand, force, stressor, flow, computation, or source-local burden applied to a component or structure.

- **dose:** A typed exposure quantity qualified by route, target, time, concentration, distribution, and measurement basis.

- **intensity:** A typed magnitude or rate associated with an exposure or load.

- **duration:** The logical-time extent of an exposure, state, or process.

- **attenuation:** A profile-governed reduction or transformation of an exposure before it reaches a later stage.

- **absorption:** Acquisition or storage of exposure quantity by a protection, substrate, or target, with capacity and byproducts explicit.

- **reflection:** Redirection toward a defined outgoing path without assuming identity or quantity preservation.

- **redirection:** Transfer of all or part of an exposure to another path, target, or sink under a registered manifest.

- **byproduct:** An output generated by transfer, conversion, protection, damage, treatment, or repair in addition to intended outputs.

- **secondary exposure:** A new exposure produced by an earlier event, conversion, byproduct, propagation, or component failure.

### Protection

- **protection:** A registered mechanism affecting a specific stage of targeting, contact, transfer, uptake, propagation, effect, progression, or recovery.

- **armor:** A protective body or structure component with coverage, interfaces, capacity, condition, and damage semantics.

- **shield:** An active, passive, energetic, informational, or source-local protection with defined coverage and capacity.

- **barrier:** A boundary intended to block, filter, contain, redirect, or attenuate specified interactions.

- **cover:** An external spatial or interface obstruction affecting targeting, contact, or transfer.

- **resistance:** A profile-scoped reduction, delay, or altered response to a harm family or stage.

- **tolerance:** A profile-scoped range or threshold within which exposure produces limited or no specified adverse effect.

- **immunity:** A qualified claim that a specified effect cannot occur under exact route, threshold, source, state, and profile conditions; never an unqualified universal boolean.

- **vulnerability:** A qualified interaction property increasing likelihood, transfer, severity, progression, or consequence for a specified target and harm family.

- **insulation:** Protection that limits transfer through a declared interface or route.

- **containment:** Protection limiting escape, spread, contact, or propagation.

- **filtering:** Selective passage, removal, transformation, or rejection of exposure components.

- **damping:** Reduction of oscillation, shock, vibration, signal, or other dynamic response.

- **ablative protection:** Protection designed to consume, shed, erode, or sacrifice capacity or material while attenuating exposure.

- **active defense:** A protection requiring sensing, power, control, timing, action, or resource expenditure.

### Injury Condition

- **damage:** A qualified embodiment or structural state change produced by a committed effect; prohibited as an unqualified numeric currency.

- **injury:** A typed adverse alteration to a body component, tissue, organ, function-support system, or source-local embodiment.

- **wound:** An injury family involving localized physical or source-local disruption under a named profile.

- **lesion:** A localized structural or functional abnormality represented under a diagnostic or injury profile.

- **defect:** A structural, material, software, informational, or component deviation that may affect function.

- **malfunction:** Failure or abnormal operation of a function or subsystem without requiring physical damage.

- **degradation:** A progressive or accumulated decline in material, component, system, data, or functional condition.

- **condition:** A versioned state family with origin, stage, triggers, progression, suppression, remission, recurrence, and resolution semantics.

- **disease:** A biological or source-local condition family; no universal human disease ontology is assumed.

- **infection:** A condition involving establishment or proliferation of an infectious agent after exposure and uptake.

- **poison:** A harmful substance or source-local agent identified by route, dose, kinetics, and effect profiles.

- **toxin:** A harmful agent produced biologically or source-locally; it remains distinct from the condition it may cause.

- **contamination:** Presence or distribution of an unwanted agent, substance, signal, or corrupting influence on or within a target.

- **corruption:** A source-local, informational, spiritual, magical, or systemic degradation family requiring explicit interfaces and semantics.

- **chronic condition:** A condition with long-duration or persistent management semantics under a named profile.

- **latent condition:** A condition present without active effects, visible signs, or current detectability under the evaluated profile.

- **progressive condition:** A condition whose state can worsen or spread over scheduled or triggered transitions.

- **complication:** A new or worsened condition, injury, impairment, or treatment consequence arising from another state or intervention.

- **sequela:** A persistent or later consequence of a prior injury, condition, or treatment after the initiating state has changed or resolved.

- **symptom:** A subject-experienced or subject-reported phenomenon; not condition truth.

- **sign:** An observer- or instrument-detectable phenomenon; not automatically diagnosis.

- **pain:** A subjective sensory and emotional experience represented separately from nociception, injury, function, and report credibility.

- **diagnosis:** An epistemic or institutional determination selecting or preserving condition candidates from evidence under a versioned profile.

- **prognosis:** A bounded forecast candidate about future state or function under stated assumptions and uncertainty.

### State

- **stable:** A profile-scoped state in which specified adverse transitions are not currently expected without new triggers.

- **unstable:** A profile-scoped state with material risk of near-term adverse transition or insufficient control.

- **critical:** A profile-scoped state requiring urgent attention under a defined purpose; not a universal severity label.

- **incapacitated:** Unable to perform one or more specified actions or task families under an incapacity profile; not automatically unconscious or without agency.

- **unconscious:** A state determined under a consciousness profile; it does not by itself decide personhood, consent history, or all task capacities.

- **dying:** A source- and profile-scoped state of active transition toward a death criterion; not universal or irreversible.

- **dead:** A qualified death determination for a specified body, function, process, legal purpose, or source-local profile.

- **destroyed:** A qualified structural or process determination that specified integrity or function criteria are met.

- **dormant:** Inactive but potentially recoverable or resumable under a profile.

- **shut down:** A process or system is inactive through controlled, protective, failed, or unknown cause.

- **recoverable:** A determination that a registered restoration pathway remains feasible under stated assumptions and resources.

- **irrecoverable:** A purpose-scoped determination that no registered recovery pathway satisfies the profile and evidence basis.

- **remains:** A post-death or post-destruction body, component, material, data, or source-local record retaining identity and provenance where relevant.

- **corpse:** A source- and profile-scoped biological remains classification.

- **wreck:** A damaged or destroyed structure retained as a distinct salvage or remains state.

- **salvage state:** A determination of recoverable components, materials, data, or functions after damage or destruction.

### Recovery

- **stabilization:** An intervention or transition that limits immediate deterioration without necessarily healing or resolving the cause.

- **treatment:** A registered intervention intended to alter injury, condition, symptom, progression, or function.

- **healing:** Biological or source-local restoration process affecting injuries or conditions under a named profile.

- **recovery:** A broader transition toward restored or adapted function, state, participation, or capacity.

- **regeneration:** Restoration or regrowth of substrate, component, topology, or function through a registered process.

- **repair:** A technical, material, digital, magical, or hybrid intervention restoring specified structure or function.

- **maintenance:** Preventive, corrective, or condition-based work intended to preserve or improve reliability and function.

- **replacement:** Substitution of a component, body, process, data set, or function provider with a distinct identity or instance.

- **rehabilitation:** Interventions optimizing function and participation through recovery, adaptation, training, environment, and assistive support.

- **reconstruction:** Rebuilding a body or structure from components, records, templates, remains, or source-local processes.

- **restoration:** A general return toward a specified state or function without assuming historical identity or exact configuration.

- **resurrection:** A source-local process attempting to restore a dead body, embodiment, identity relation, or living state; person continuity routes to AFQR-08.

- **reincarnation:** A source-local continuity claim involving embodiment through a new body or form.

- **body transfer:** A process changing which body or structure embodies, hosts, or is controlled by an identity.

### Transformation

- **mutation:** A persistent topology, substrate, property, or function change arising through a registered mechanism.

- **metamorphosis:** A staged transformation between embodiment profiles.

- **shapeshifting:** A reversible or recurring change of form or topology under an embodiment profile.

- **augmentation:** Addition or enhancement of components, functions, interfaces, or capacities.

- **implantation:** Installation of a component within or onto an embodiment through a registered procedure.

- **transplantation:** Transfer and integration of biological or source-local material or organs between bodies or origins.

- **purification:** A source-local process removing or transforming specified corruption, contamination, or condition layers.

- **possession:** A control or occupancy transition in which a distinct subject operates or inhabits a body without automatically changing body identity.

- **fusion:** An n-ary transformation combining bodies, structures, components, identities, or functions under explicit continuity manifests.

- **fission:** An n-ary transformation dividing one body or structure into several successors with explicit state allocation.

- **transformation:** A staged, versioned alteration of embodiment profile, topology, substrate, function, or manifestation.

- **continuity:** A purpose-scoped determination of what identity, body, component, injury, condition, function, or relation persists across transition.

- **replacement body:** A distinct body instance intended to host or embody an identity after or alongside another body.

### Cross Domain

- **nociception:** Neural or source-local processing of harmful stimuli; distinct from pain experience.

- **functional reserve:** Capacity available to compensate for increased demand or loss of ordinary providers.

- **mission capability:** A purpose-scoped assessment of whether a platform can perform a specified mission; not whole-structure integrity or survival.

- **catastrophic failure:** A profile-scoped transition causing specified high-level losses; not universal destruction or identity extinction.

- **recoverability profile:** A registered method for evaluating restoration pathways, resources, evidence, time, and uncertainty.

- **body death:** A death determination scoped to a body instance, not identity continuity.

- **legal death:** An AFQR-15 institutional determination, not body truth or identity extinction.

- **social death claim:** An AFQR-13 audience-relative status or recognition claim, not biological death.

- **condition truth:** The authoritative condition state owned by the embodiment or condition owner; distinct from diagnosis and records.

- **historical configuration:** A versioned topology, component, software, material, or embodiment state used as a restoration reference.

- **source-local integrity ontology:** A namespaced harm, embodiment, condition, death, or restoration system that is not universalized.

- **lawful unresolved outcome:** A typed result preserving missing, conflicting, incomparable, unsupported, or source-local bases without inventing certainty.


### Runtime qualification prohibition

`health`, `HP`, `damage`, `injury`, `condition`, `dead`, `destroyed`, `healed`, `repaired`, `disabled`, `impaired`, `unconscious`, `critical`, `stable`, `immunity`, `resistance`, `vulnerability`, `body`, `person`, `diagnosis`, `prognosis`, `recoverable`, `irrecoverable`, `normal anatomy`, `model medical conclusion`

Each requires a semantic family, body/structure/component, owner, profile, source namespace, purpose, time, evidence, status, and visibility. The anti-collapse laws in the question are ratified unchanged.

## Part V — Embodiment, structure, and ownership

An embodiment is a typed relation among identities and body or structure instances. A body is not a person, actor, agent, owner, controller, occupant, or legal subject. Each relation is represented separately:

```text
identity embodied
body or structure identity
owner
controller
occupant
possessor
operator
maintainer
legal custodian
```

One identity may use several bodies. One body may host several subjects or processes. Possession can change control without replacing the body. A structure can contain living components without becoming one biological body. AFQR-08 owns person and identity continuity; AFQR-11 owns control, agency, and consent; AFQR-15 owns legal status and custody. AFQR-16 owns embodiment and physical or structural state only.

## Part VI — Components, topology, function, and dependencies

Bodies and structures use versioned component–function–dependency graphs. Components may be nested, detachable, temporary, distributed, spatial, or source-local and nonspatial. Part-of, attachment, containment, interface, support, load path, and network reachability are different relations.

Functions are not components. A function may have several providers, consumers, dependencies, reserves, compensatory paths, external supports, and accommodations. Component loss produces a `FunctionLossCandidate`; the dependency and redundancy profiles decide whether function is lost, degraded, assisted, preserved, or unresolved. Recursive propagation is bounded, versioned, and fails closed when dependency data is incomplete.

## Part VII — Substrates and materials

Substrate profiles are extensible rather than universal. Biological tissue, engineered materials, composites, digital processes, energetic or spiritual substrates, and source-local conceptual structures can expose different property families. A profile declares only the properties needed for certified interactions: load response, transport, permeability, conductivity, heat transfer, corrosion, repairability, integration, data integrity, or source-local equivalents.

Shared words such as hardness, resistance, tissue, armor, or spirit do not prove cross-profile compatibility. Unknown substrate interaction returns unresolved or escalation.

## Part VIII — Harm agents, exposure, contact, and transfer

Harm resolution is a staged causal pipeline:

```text
source/event
→ targeting and actual target
→ contact
→ exposure
→ transfer
→ penetration or uptake
→ attenuation/absorption/redirection/conversion
→ propagation and secondary exposure
→ component-specific effect
→ injury/condition/function candidates
```

Every stage may fail independently. A donor numeric damage value cannot skip the stages. Quantities, units, precision, dose, duration, rates, loss, storage, conversion, and byproducts use AFQR-07. Source-local psychic, spiritual, conceptual, or magical harm requires AFQR-05 interfaces and a complete conversion manifest.

## Part IX — Protection, resistance, immunity, and vulnerability

Protection declares the stage it affects. Avoidance and cover affect targeting or contact. Armor, barriers, and shields may affect contact, transfer, penetration, uptake, or propagation. Resistance or tolerance may affect effect magnitude, condition onset, or progression. Recovery is not protection.

Coverage, orientation, current state, capacity, depletion, power, routing, active control, and protection damage are explicit. Multiple layers use a registered order. Immunity is a claim and determination qualified by target, source, route, threshold, state, and profile; unqualified `immune` is conversion pressure, not runtime semantics. Species or ancestry labels never establish vulnerability.

## Part X — Injury, defect, and condition state

Damage is not a universal numeric currency. A committed effect may create a localized injury, distributed injury, defect, malfunction, degradation, condition origin, no effect, or unresolved result.

Injury definitions and condition definitions are separate. Conditions have origin, stages, onset, triggers, progression, suppression, remission, recurrence, resolution, complications, and sequelae. Severity and localization are profile-scoped and may be absent where inappropriate. Disease, poison, contamination, software corruption, structural crack, curse, psychic wound, and spiritual injury share lifecycle interfaces but not one evaluator.

## Part XI — Function, impairment, and accommodation

Function is assessed for a specified task, environment, time, and support context. The architecture distinguishes baseline, intrinsic, available, degraded, assisted, reserve, and lost function. Impairment is a qualified alteration of function; it is not universal inability, incapacity, lack of agency, or lack of personhood.

Accommodations, prostheses, assistive devices, environmental changes, support actors, alternate interfaces, learned adaptations, and redundant providers may restore practical function. Capability and action-gateway changes are handoffs, not direct ability deletion.

## Part XII — Symptoms, signs, pain, diagnosis, and prognosis

Condition truth, subjective symptom, pain experience, sensation, self-report, observable sign, test result, diagnosis, prognosis, public record, and model portrayal are different records.

Pain is subjective and may exist without visible injury; injury may exist without pain. The absence of communication does not establish absence of pain. Diagnosis freezes evidence and visibility, applies a versioned profile, and may produce a differential, selected candidate, misdiagnosis, or unresolved result. Diagnosis changes epistemic or institutional state, not the underlying condition. Prognosis is a bounded forecast under explicit assumptions.

## Part XIII — Consciousness and incapacitation

The architecture does not use one `conscious` boolean. It tracks wakefulness, awareness, responsiveness, orientation, motor control, communication access, and task-specific decision or action capacity under named profiles.

Unconsciousness, coma, shutdown, dormancy, restraint, paralysis, sedation, altered awareness, and incapacitation remain distinct. AFQR-11 determines agency, consent, and capacity consequences. Communication aids or alternate interfaces may restore access without changing awareness.

## Part XIV — Death, destruction, remains, and recoverability

Death and destruction are profile-scoped determinations with explicit criteria, evidence closure, scope, purpose, and time. A body may be dead while some organs remain viable. A process may stop while a backup exists. A structure may be destroyed but salvageable. A distributed entity may lose nodes without whole-identity termination.

```text
body death
≠ identity extinction
≠ legal death
≠ social recognition
≠ structure destruction
≠ irrecoverability
```

Recoverability and irrecoverability are separate determinations over registered restoration paths, resources, evidence, time, and uncertainty. Remains retain identity and provenance. AFQR-08 owns person continuity; AFQR-15 owns legal death; AFQR-13 owns social recognition.

## Part XV — Stabilization, treatment, healing, and recovery

Stabilization limits immediate deterioration without necessarily resolving injury. Treatment is a registered intervention with target verification, practitioner, authority, consent, eligibility, tools, facility, resources, contraindications, attempt state, outcomes, and complications. Healing, regeneration, recovery, rehabilitation, and residual change remain separate.

Recovery is deterministic through versioned milestones, logical time, environment, support, resources, interruptions, and recurrence. A successful procedure may improve one condition and worsen another. A failed attempt remains a committed attempt rather than disappearing.

## Part XVI — Repair, maintenance, replacement, and integration

Mechanical, digital, synthetic, magical, and hybrid repair uses historical configuration, repairability, access, tools, parts, skill, facilities, resources, inspection, and verification. Repair may restore, substitute, patch, degrade, destabilize, or fail; it does not automatically restore an exact historical state.

Maintenance is preventive, corrective, or condition-based. Replacement introduces a distinct component or body identity. Integration, rejection, calibration, compatibility, ownership, prior provenance, maintenance dependency, changed capability, and changed vulnerability are explicit. Biological healing and machine repair require a bridge before they interact.

## Part XVII — Transformation and continuity

Transformation is a staged topology, substrate, function, or manifestation transition. It includes mutation, metamorphosis, shapeshifting, augmentation, implantation, purification, corruption, possession, fusion, fission, body transfer, reincarnation, resurrection, ascension, and source-local families.

A transformation continuity manifest states what bodies, components, functions, injuries, conditions, protections, memories, controls, dependencies, and relations persist, transfer, split, combine, resolve, or remain disputed. AFQR-16 determines body-state facts; AFQR-08 determines identity continuity. Shapeshifting does not heal all injuries unless the exact profile says so.

## Part XVIII — Vehicles, structures, and distributed bodies

Vehicles and structures have components, load paths, power, control, sensing, communications, propulsion, containment, life support, armor, compartments, occupants, cargo, AI processes, critical subsystems, redundancy, emergency modes, and mission profiles. Platform integrity, mission capability, crew injury, cargo damage, AI corruption, and environmental hazards are separate owners.

Distributed embodiments define nodes, contribution profiles, shared and local functions, threshold or aggregation rules, network interfaces, node loss, fault propagation, and collective continuity. Reachability does not create shared injury automatically.

## Part XIX — Hidden embodiment state and model projection

Private receipts protect hidden injuries, latent conditions, internal component state, private pain, secret implants, concealed vulnerabilities, reserves, covert repairs, false death, sealed diagnoses, and classified defects.

Audience projections use opaque audience tokens and projection-specific keyed digests. They must not expose private identifiers, candidate counts, simulation depth, timing, topology depth, hidden node count, diagnosis alternatives, or stable cross-audience hashes. The model receives a grounding manifest, permitted claim-kind registry, and evidence bindings. Unsupported injury, diagnosis, prognosis, vulnerability, impairment, unconsciousness, death, healing, repair, or continuity claims are rejected.

## Part XX — Typed contracts

The normative catalog contains **238** typed contracts. Each defines required, optional, hidden, derived, and prohibited fields; authoritative owner; record-specific temporal semantics; identity, embodiment, component, controller and occupant bindings; topology/function/profile bases; security commitments; and AFQR-01–15 references.

| contract_name | schema_family | authoritative_owner | purpose |
| --- | --- | --- | --- |
| EmbodimentDefinition | embodiment | embodiment_identity_owner | Typed AFQR-16 contract for embodiment definition. |
| EmbodimentInstance | embodiment | embodiment_identity_owner | Typed AFQR-16 contract for embodiment instance. |
| EmbodimentSubjectBinding | embodiment | embodiment_identity_owner | Typed AFQR-16 contract for embodiment subject binding. |
| EmbodimentControlBinding | embodiment | embodiment_identity_owner | Typed AFQR-16 contract for embodiment control binding. |
| EmbodimentOccupancyBinding | embodiment | embodiment_identity_owner | Typed AFQR-16 contract for embodiment occupancy binding. |
| EmbodimentProfile | embodiment | embodiment_identity_owner | Typed AFQR-16 contract for embodiment profile. |
| EmbodimentContinuityProfile | embodiment | embodiment_identity_owner | Typed AFQR-16 contract for embodiment continuity profile. |
| EmbodimentContinuityDetermination | embodiment | embodiment_identity_owner | Typed AFQR-16 contract for embodiment continuity determination. |
| StructureDefinition | structure | structure_state_owner | Typed AFQR-16 contract for structure definition. |
| StructureInstance | structure | structure_state_owner | Typed AFQR-16 contract for structure instance. |
| StructureProfile | structure | structure_state_owner | Typed AFQR-16 contract for structure profile. |
| ComponentDefinition | topology | topology_component_owner | Typed AFQR-16 contract for component definition. |
| ComponentInstance | topology | topology_component_owner | Typed AFQR-16 contract for component instance. |
| ComponentPartOfRelation | topology | topology_component_owner | Typed AFQR-16 contract for component part of relation. |
| ComponentAttachmentRelation | topology | topology_component_owner | Typed AFQR-16 contract for component attachment relation. |
| ComponentContainmentRelation | topology | topology_component_owner | Typed AFQR-16 contract for component containment relation. |
| ComponentInterfaceDefinition | topology | topology_component_owner | Typed AFQR-16 contract for component interface definition. |
| TopologyDefinition | topology | topology_component_owner | Typed AFQR-16 contract for topology definition. |
| TopologySnapshot | topology | topology_component_owner | Typed AFQR-16 contract for topology snapshot. |
| TopologyTransitionCandidate | topology | topology_component_owner | Typed AFQR-16 contract for topology transition candidate. |
| TopologyTransitionReceipt | topology | topology_component_owner | Typed AFQR-16 contract for topology transition receipt. |
| FunctionDefinition | function | function_capacity_owner | Typed AFQR-16 contract for function definition. |
| FunctionProviderBinding | function | function_capacity_owner | Typed AFQR-16 contract for function provider binding. |
| FunctionConsumerBinding | function | function_capacity_owner | Typed AFQR-16 contract for function consumer binding. |
| FunctionDependencyRelation | function | function_capacity_owner | Typed AFQR-16 contract for function dependency relation. |
| FunctionalRedundancyProfile | function | function_capacity_owner | Typed AFQR-16 contract for functional redundancy profile. |
| FunctionalReserveState | function | function_capacity_owner | Typed AFQR-16 contract for functional reserve state. |
| FunctionalCapacityState | function | function_capacity_owner | Typed AFQR-16 contract for functional capacity state. |
| FunctionAvailabilityDetermination | function | function_capacity_owner | Typed AFQR-16 contract for function availability determination. |
| FunctionLossCandidate | function | function_capacity_owner | Typed AFQR-16 contract for function loss candidate. |
| FunctionRestorationCandidate | function | function_capacity_owner | Typed AFQR-16 contract for function restoration candidate. |
| SubstrateDefinition | substrate | substrate_state_owner | Typed AFQR-16 contract for substrate definition. |
| MaterialProfile | substrate | substrate_state_owner | Typed AFQR-16 contract for material profile. |
| TissueProfile | substrate | substrate_state_owner | Typed AFQR-16 contract for tissue profile. |
| SyntheticSubstrateProfile | substrate | substrate_state_owner | Typed AFQR-16 contract for synthetic substrate profile. |
| DigitalSubstrateProfile | substrate | substrate_state_owner | Typed AFQR-16 contract for digital substrate profile. |
| MetaphysicalSubstrateProfile | substrate | substrate_state_owner | Typed AFQR-16 contract for metaphysical substrate profile. |
| SubstratePropertySet | substrate | substrate_state_owner | Typed AFQR-16 contract for substrate property set. |
| SubstrateState | substrate | substrate_state_owner | Typed AFQR-16 contract for substrate state. |
| HarmAgentDefinition | exposure | exposure_event_owner | Typed AFQR-16 contract for harm agent definition. |
| HarmFamilyDefinition | exposure | exposure_event_owner | Typed AFQR-16 contract for harm family definition. |
| ExposureDefinition | exposure | exposure_event_owner | Typed AFQR-16 contract for exposure definition. |
| ExposureEvent | exposure | exposure_event_owner | Typed AFQR-16 contract for exposure event. |
| ExposureCarrierBinding | exposure | exposure_event_owner | Typed AFQR-16 contract for exposure carrier binding. |
| ExposureRouteDefinition | exposure | exposure_event_owner | Typed AFQR-16 contract for exposure route definition. |
| ExposureTargetBinding | exposure | exposure_event_owner | Typed AFQR-16 contract for exposure target binding. |
| ExposureQuantityManifest | exposure | exposure_event_owner | Typed AFQR-16 contract for exposure quantity manifest. |
| ExposureTemporalProfile | exposure | exposure_event_owner | Typed AFQR-16 contract for exposure temporal profile. |
| ContactCandidate | transfer | transfer_propagation_owner | Typed AFQR-16 contract for contact candidate. |
| ContactDetermination | transfer | transfer_propagation_owner | Typed AFQR-16 contract for contact determination. |
| TransferInterfaceBinding | transfer | transfer_propagation_owner | Typed AFQR-16 contract for transfer interface binding. |
| TransferManifest | transfer | transfer_propagation_owner | Typed AFQR-16 contract for transfer manifest. |
| PenetrationCandidate | transfer | transfer_propagation_owner | Typed AFQR-16 contract for penetration candidate. |
| PenetrationDetermination | transfer | transfer_propagation_owner | Typed AFQR-16 contract for penetration determination. |
| AttenuationManifest | transfer | transfer_propagation_owner | Typed AFQR-16 contract for attenuation manifest. |
| AbsorptionManifest | transfer | transfer_propagation_owner | Typed AFQR-16 contract for absorption manifest. |
| PropagationPath | transfer | transfer_propagation_owner | Typed AFQR-16 contract for propagation path. |
| PropagationReceipt | transfer | transfer_propagation_owner | Typed AFQR-16 contract for propagation receipt. |
| SecondaryExposureManifest | transfer | transfer_propagation_owner | Typed AFQR-16 contract for secondary exposure manifest. |
| ProtectionDefinition | protection | protection_state_owner | Typed AFQR-16 contract for protection definition. |
| ProtectionInstance | protection | protection_state_owner | Typed AFQR-16 contract for protection instance. |
| ProtectionCoverageProfile | protection | protection_state_owner | Typed AFQR-16 contract for protection coverage profile. |
| ProtectionApplicabilityDetermination | protection | protection_state_owner | Typed AFQR-16 contract for protection applicability determination. |
| ProtectionCapacityState | protection | protection_state_owner | Typed AFQR-16 contract for protection capacity state. |
| ProtectionAttenuationProfile | protection | protection_state_owner | Typed AFQR-16 contract for protection attenuation profile. |
| ProtectionDepletionCandidate | protection | protection_state_owner | Typed AFQR-16 contract for protection depletion candidate. |
| ProtectionDamageCandidate | protection | protection_state_owner | Typed AFQR-16 contract for protection damage candidate. |
| ProtectionFailureRecord | protection | protection_state_owner | Typed AFQR-16 contract for protection failure record. |
| VulnerabilityDefinition | vulnerability | interaction_profile_owner | Typed AFQR-16 contract for vulnerability definition. |
| SusceptibilityProfile | vulnerability | interaction_profile_owner | Typed AFQR-16 contract for susceptibility profile. |
| ToleranceProfile | vulnerability | interaction_profile_owner | Typed AFQR-16 contract for tolerance profile. |
| ImmunityClaim | vulnerability | interaction_profile_owner | Typed AFQR-16 contract for immunity claim. |
| ImmunityDetermination | vulnerability | interaction_profile_owner | Typed AFQR-16 contract for immunity determination. |
| InteractionModifierProfile | vulnerability | interaction_profile_owner | Typed AFQR-16 contract for interaction modifier profile. |
| AdaptiveResponseProfile | vulnerability | interaction_profile_owner | Typed AFQR-16 contract for adaptive response profile. |
| HarmEffectProfile | effect_injury | injury_effect_owner | Typed AFQR-16 contract for harm effect profile. |
| HarmEffectCandidate | effect_injury | injury_effect_owner | Typed AFQR-16 contract for harm effect candidate. |
| EffectTargetComponentBinding | effect_injury | injury_effect_owner | Typed AFQR-16 contract for effect target component binding. |
| EffectEvidenceClosure | effect_injury | injury_effect_owner | Typed AFQR-16 contract for effect evidence closure. |
| InjuryDefinition | effect_injury | injury_effect_owner | Typed AFQR-16 contract for injury definition. |
| InjuryInstance | effect_injury | injury_effect_owner | Typed AFQR-16 contract for injury instance. |
| InjurySeverityProfile | effect_injury | injury_effect_owner | Typed AFQR-16 contract for injury severity profile. |
| InjuryLocalization | effect_injury | injury_effect_owner | Typed AFQR-16 contract for injury localization. |
| InjuryProgressionProfile | effect_injury | injury_effect_owner | Typed AFQR-16 contract for injury progression profile. |
| InjuryTransitionCandidate | effect_injury | injury_effect_owner | Typed AFQR-16 contract for injury transition candidate. |
| InjuryTransitionReceipt | effect_injury | injury_effect_owner | Typed AFQR-16 contract for injury transition receipt. |
| ConditionDefinition | condition | condition_state_owner | Typed AFQR-16 contract for condition definition. |
| ConditionInstance | condition | condition_state_owner | Typed AFQR-16 contract for condition instance. |
| ConditionOriginBinding | condition | condition_state_owner | Typed AFQR-16 contract for condition origin binding. |
| ConditionStageDefinition | condition | condition_state_owner | Typed AFQR-16 contract for condition stage definition. |
| ConditionProgressionProfile | condition | condition_state_owner | Typed AFQR-16 contract for condition progression profile. |
| ConditionTrigger | condition | condition_state_owner | Typed AFQR-16 contract for condition trigger. |
| ConditionSuppressionRecord | condition | condition_state_owner | Typed AFQR-16 contract for condition suppression record. |
| ConditionRemissionRecord | condition | condition_state_owner | Typed AFQR-16 contract for condition remission record. |
| ConditionResolutionCandidate | condition | condition_state_owner | Typed AFQR-16 contract for condition resolution candidate. |
| ConditionComplicationCandidate | condition | condition_state_owner | Typed AFQR-16 contract for condition complication candidate. |
| ConditionRecurrenceRecord | condition | condition_state_owner | Typed AFQR-16 contract for condition recurrence record. |
| FunctionalAssessmentProfile | impairment | functional_assessment_owner | Typed AFQR-16 contract for functional assessment profile. |
| FunctionalCapacityAssessment | impairment | functional_assessment_owner | Typed AFQR-16 contract for functional capacity assessment. |
| ImpairmentDefinition | impairment | functional_assessment_owner | Typed AFQR-16 contract for impairment definition. |
| ImpairmentInstance | impairment | functional_assessment_owner | Typed AFQR-16 contract for impairment instance. |
| ImpairmentContextBinding | impairment | functional_assessment_owner | Typed AFQR-16 contract for impairment context binding. |
| ImpairmentEffectManifest | impairment | functional_assessment_owner | Typed AFQR-16 contract for impairment effect manifest. |
| AccommodationDefinition | impairment | functional_assessment_owner | Typed AFQR-16 contract for accommodation definition. |
| AccommodationBinding | impairment | functional_assessment_owner | Typed AFQR-16 contract for accommodation binding. |
| AssistedFunctionState | impairment | functional_assessment_owner | Typed AFQR-16 contract for assisted function state. |
| FunctionalOutcomeDetermination | impairment | functional_assessment_owner | Typed AFQR-16 contract for functional outcome determination. |
| SymptomDefinition | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for symptom definition. |
| SubjectiveSymptomRecord | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for subjective symptom record. |
| ObservableSignRecord | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for observable sign record. |
| SensationRecord | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for sensation record. |
| PainExperienceRecord | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for pain experience record. |
| DiagnosticObservation | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for diagnostic observation. |
| DiagnosticTestDefinition | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for diagnostic test definition. |
| DiagnosticTestResult | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for diagnostic test result. |
| DiagnosisCandidate | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for diagnosis candidate. |
| DiagnosisDetermination | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for diagnosis determination. |
| DifferentialDiagnosisSet | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for differential diagnosis set. |
| PrognosisCandidate | diagnosis | epistemic_diagnostic_owner | Typed AFQR-16 contract for prognosis candidate. |
| ConsciousnessProfileDefinition | consciousness | consciousness_capacity_owner | Typed AFQR-16 contract for consciousness profile definition. |
| WakefulnessState | consciousness | consciousness_capacity_owner | Typed AFQR-16 contract for wakefulness state. |
| AwarenessState | consciousness | consciousness_capacity_owner | Typed AFQR-16 contract for awareness state. |
| ResponsivenessState | consciousness | consciousness_capacity_owner | Typed AFQR-16 contract for responsiveness state. |
| OrientationState | consciousness | consciousness_capacity_owner | Typed AFQR-16 contract for orientation state. |
| MotorControlState | consciousness | consciousness_capacity_owner | Typed AFQR-16 contract for motor control state. |
| CommunicationAccessState | consciousness | consciousness_capacity_owner | Typed AFQR-16 contract for communication access state. |
| IncapacitationProfile | consciousness | consciousness_capacity_owner | Typed AFQR-16 contract for incapacitation profile. |
| IncapacitationDetermination | consciousness | consciousness_capacity_owner | Typed AFQR-16 contract for incapacitation determination. |
| DeathProfileDefinition | death | death_destruction_owner | Typed AFQR-16 contract for death profile definition. |
| DeathCriterionDefinition | death | death_destruction_owner | Typed AFQR-16 contract for death criterion definition. |
| DeathEvidenceClosure | death | death_destruction_owner | Typed AFQR-16 contract for death evidence closure. |
| DeathCandidate | death | death_destruction_owner | Typed AFQR-16 contract for death candidate. |
| DeathDetermination | death | death_destruction_owner | Typed AFQR-16 contract for death determination. |
| DestructionProfileDefinition | death | death_destruction_owner | Typed AFQR-16 contract for destruction profile definition. |
| DestructionCandidate | death | death_destruction_owner | Typed AFQR-16 contract for destruction candidate. |
| DestructionDetermination | death | death_destruction_owner | Typed AFQR-16 contract for destruction determination. |
| RecoverabilityProfile | death | death_destruction_owner | Typed AFQR-16 contract for recoverability profile. |
| RecoverabilityDetermination | death | death_destruction_owner | Typed AFQR-16 contract for recoverability determination. |
| IrrecoverabilityDetermination | death | death_destruction_owner | Typed AFQR-16 contract for irrecoverability determination. |
| RemainsRecord | death | death_destruction_owner | Typed AFQR-16 contract for remains record. |
| StabilizationProcedureDefinition | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for stabilization procedure definition. |
| TreatmentDefinition | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for treatment definition. |
| TreatmentEligibilityDetermination | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for treatment eligibility determination. |
| TreatmentPlan | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for treatment plan. |
| TreatmentConsentReference | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for treatment consent reference. |
| TreatmentResourceManifest | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for treatment resource manifest. |
| TreatmentAttempt | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for treatment attempt. |
| TreatmentOutcomeCandidate | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for treatment outcome candidate. |
| TreatmentOutcomeDetermination | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for treatment outcome determination. |
| TreatmentComplicationCandidate | treatment | treatment_stabilization_owner | Typed AFQR-16 contract for treatment complication candidate. |
| HealingProfile | healing | recovery_healing_owner | Typed AFQR-16 contract for healing profile. |
| RecoveryProfile | healing | recovery_healing_owner | Typed AFQR-16 contract for recovery profile. |
| RegenerationProfile | healing | recovery_healing_owner | Typed AFQR-16 contract for regeneration profile. |
| HealingProgressState | healing | recovery_healing_owner | Typed AFQR-16 contract for healing progress state. |
| RecoveryMilestone | healing | recovery_healing_owner | Typed AFQR-16 contract for recovery milestone. |
| RegenerationCandidate | healing | recovery_healing_owner | Typed AFQR-16 contract for regeneration candidate. |
| RecoverySchedule | healing | recovery_healing_owner | Typed AFQR-16 contract for recovery schedule. |
| RecoveryInterruptionRecord | healing | recovery_healing_owner | Typed AFQR-16 contract for recovery interruption record. |
| ResidualEffectRecord | healing | recovery_healing_owner | Typed AFQR-16 contract for residual effect record. |
| ScarOrPersistentChangeCandidate | healing | recovery_healing_owner | Typed AFQR-16 contract for scar or persistent change candidate. |
| RepairDefinition | repair | repair_maintenance_owner | Typed AFQR-16 contract for repair definition. |
| MaintenanceDefinition | repair | repair_maintenance_owner | Typed AFQR-16 contract for maintenance definition. |
| RepairEligibilityDetermination | repair | repair_maintenance_owner | Typed AFQR-16 contract for repair eligibility determination. |
| RepairPlan | repair | repair_maintenance_owner | Typed AFQR-16 contract for repair plan. |
| RepairResourceManifest | repair | repair_maintenance_owner | Typed AFQR-16 contract for repair resource manifest. |
| RepairAttempt | repair | repair_maintenance_owner | Typed AFQR-16 contract for repair attempt. |
| RepairOutcomeCandidate | repair | repair_maintenance_owner | Typed AFQR-16 contract for repair outcome candidate. |
| RepairOutcomeDetermination | repair | repair_maintenance_owner | Typed AFQR-16 contract for repair outcome determination. |
| MaintenanceSchedule | repair | repair_maintenance_owner | Typed AFQR-16 contract for maintenance schedule. |
| RepairComplicationCandidate | repair | repair_maintenance_owner | Typed AFQR-16 contract for repair complication candidate. |
| ReplacementComponentDefinition | replacement | replacement_integration_owner | Typed AFQR-16 contract for replacement component definition. |
| ReplacementEligibilityDetermination | replacement | replacement_integration_owner | Typed AFQR-16 contract for replacement eligibility determination. |
| ReplacementProcedure | replacement | replacement_integration_owner | Typed AFQR-16 contract for replacement procedure. |
| IntegrationProfile | replacement | replacement_integration_owner | Typed AFQR-16 contract for integration profile. |
| IntegrationCandidate | replacement | replacement_integration_owner | Typed AFQR-16 contract for integration candidate. |
| IntegrationDetermination | replacement | replacement_integration_owner | Typed AFQR-16 contract for integration determination. |
| RejectionOrIncompatibilityCandidate | replacement | replacement_integration_owner | Typed AFQR-16 contract for rejection or incompatibility candidate. |
| MaintenanceDependencyRecord | replacement | replacement_integration_owner | Typed AFQR-16 contract for maintenance dependency record. |
| ReplacementContinuityReceipt | replacement | replacement_integration_owner | Typed AFQR-16 contract for replacement continuity receipt. |
| TransformationDefinition | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation definition. |
| TransformationProfile | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation profile. |
| TransformationTrigger | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation trigger. |
| TransformationEligibilityDetermination | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation eligibility determination. |
| TransformationStage | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation stage. |
| TransformationAttempt | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation attempt. |
| TransformationOutcomeCandidate | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation outcome candidate. |
| TransformationContinuityManifest | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation continuity manifest. |
| TransformationComplicationCandidate | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation complication candidate. |
| TransformationCompletionDetermination | transformation | transformation_state_owner | Typed AFQR-16 contract for transformation completion determination. |
| StructuralLoadPath | platform | platform_integrity_owner | Typed AFQR-16 contract for structural load path. |
| StructuralIntegrityState | platform | platform_integrity_owner | Typed AFQR-16 contract for structural integrity state. |
| SubsystemState | platform | platform_integrity_owner | Typed AFQR-16 contract for subsystem state. |
| CriticalSubsystemProfile | platform | platform_integrity_owner | Typed AFQR-16 contract for critical subsystem profile. |
| CascadingFailureProfile | platform | platform_integrity_owner | Typed AFQR-16 contract for cascading failure profile. |
| FailurePropagationCandidate | platform | platform_integrity_owner | Typed AFQR-16 contract for failure propagation candidate. |
| FailurePropagationReceipt | platform | platform_integrity_owner | Typed AFQR-16 contract for failure propagation receipt. |
| EmergencyModeDefinition | platform | platform_integrity_owner | Typed AFQR-16 contract for emergency mode definition. |
| MissionCapabilityAssessment | platform | platform_integrity_owner | Typed AFQR-16 contract for mission capability assessment. |
| CatastrophicFailureCandidate | platform | platform_integrity_owner | Typed AFQR-16 contract for catastrophic failure candidate. |
| DistributedEmbodimentProfile | distributed | distributed_embodiment_owner | Typed AFQR-16 contract for distributed embodiment profile. |
| EmbodimentNode | distributed | distributed_embodiment_owner | Typed AFQR-16 contract for embodiment node. |
| NodeContributionProfile | distributed | distributed_embodiment_owner | Typed AFQR-16 contract for node contribution profile. |
| NodeLossCandidate | distributed | distributed_embodiment_owner | Typed AFQR-16 contract for node loss candidate. |
| DistributedFunctionState | distributed | distributed_embodiment_owner | Typed AFQR-16 contract for distributed function state. |
| DistributedIntegrityAssessment | distributed | distributed_embodiment_owner | Typed AFQR-16 contract for distributed integrity assessment. |
| CollectiveBodyContinuityCandidate | distributed | distributed_embodiment_owner | Typed AFQR-16 contract for collective body continuity candidate. |
| EmbodimentSimulationTierDefinition | simulation | embodiment_simulation_owner | Typed AFQR-16 contract for embodiment simulation tier definition. |
| EmbodimentMaterializationPolicy | simulation | embodiment_simulation_owner | Typed AFQR-16 contract for embodiment materialization policy. |
| EmbodimentPromotionInputClosure | simulation | embodiment_simulation_owner | Typed AFQR-16 contract for embodiment promotion input closure. |
| EmbodimentPromotionReceipt | simulation | embodiment_simulation_owner | Typed AFQR-16 contract for embodiment promotion receipt. |
| EmbodimentDemotionRetentionManifest | simulation | embodiment_simulation_owner | Typed AFQR-16 contract for embodiment demotion retention manifest. |
| EmbodimentDemotionReceipt | simulation | embodiment_simulation_owner | Typed AFQR-16 contract for embodiment demotion receipt. |
| HistoricalEmbodimentApproximationRecord | simulation | embodiment_simulation_owner | Typed AFQR-16 contract for historical embodiment approximation record. |
| PrivateEmbodimentReceipt | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for private embodiment receipt. |
| PrivateInjuryReceipt | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for private injury receipt. |
| PrivateConditionReceipt | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for private condition receipt. |
| PrivateDiagnosisReceipt | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for private diagnosis receipt. |
| PrivateDeathReceipt | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for private death receipt. |
| PrivateTransformationReceipt | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for private transformation receipt. |
| ActorVisibleEmbodimentProjection | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for actor visible embodiment projection. |
| ObserverVisibleEmbodimentProjection | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for observer visible embodiment projection. |
| PlayerVisibleEmbodimentProjection | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for player visible embodiment projection. |
| ModelVisibleEmbodimentProjection | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for model visible embodiment projection. |
| PublicEmbodimentProjection | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for public embodiment projection. |
| ModelEmbodimentGroundingManifest | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for model embodiment grounding manifest. |
| PermittedEmbodimentClaimKindRegistry | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for permitted embodiment claim kind registry. |
| ModelEmbodimentEvidenceBinding | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for model embodiment evidence binding. |
| ModelEmbodimentOutputValidator | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for model embodiment output validator. |
| GeneratedInjuryClaimBinding | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for generated injury claim binding. |
| GeneratedDiagnosisClaimBinding | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for generated diagnosis claim binding. |
| GeneratedDeathClaimBinding | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for generated death claim binding. |
| CrossPacketEmbodimentIsolationReceipt | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for cross packet embodiment isolation receipt. |
| EmbodimentProjectionNoninterferenceReceipt | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for embodiment projection noninterference receipt. |
| AudienceScopedEmbodimentToken | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for audience scoped embodiment token. |
| PrivateEmbodimentIntegrityCommitment | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for private embodiment integrity commitment. |
| ProjectionSpecificEmbodimentDigest | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for projection specific embodiment digest. |
| CrossAudienceEmbodimentLinkabilityTest | projection | embodiment_projection_security_owner | Typed AFQR-16 contract for cross audience embodiment linkability test. |
| AFQR16Handoff | handoff | AFQR16_handoff_router | Typed AFQR-16 contract for a f q r16 handoff. |

## Part XXI — Determination pipelines

### Harm resolution

```text
committed action or environmental event
→ source/carrier/intended and actual target
→ frozen identity/topology/substrate/protection/state
→ contact
→ transfer/penetration/uptake/propagation
→ attenuation/absorption/redirection/conversion/byproducts
→ component effects
→ injury/defect/condition candidates
→ function/dependency consequences
→ owner fragments and AFQR-01 commit
→ scheduling and projections
```

### Protection

```text
incoming exposure
→ applicable layers and coverage
→ capacity/orientation/state/route/interface
→ registered order
→ attenuation/redirection/absorption/depletion/protection damage
→ complete quantity manifest
```

### Injury and condition

```text
committed component effect
→ definitions/susceptibility/evidence/thresholds
→ injury/defect/condition/no-effect candidate
→ localization/stage/severity/onset
→ complications and progression schedule
→ function/symptom/diagnosis/behavior/social handoffs
```

### Functional impact

```text
injury/condition/component loss/transformation
→ providers
→ dependencies/redundancy/reserve/compensation/accommodation
→ available function
→ capability/action-gateway handoff
```

### Diagnosis

```text
observations/symptoms/tests/scans/records/testimony
→ frozen evidence and visibility
→ diagnostic profile
→ differential candidates
→ selected/mistaken/unresolved diagnosis
→ epistemic or institutional commit only
```

### Death or destruction

```text
body/structure state
→ applicable death/destruction/shutdown/recoverability profiles
→ frozen component/function/evidence
→ separate criteria
→ scope/purpose result
→ body or structure determination
→ identity/social/legal/remains/salvage/restoration handoffs
```

### Stabilization and treatment

```text
command
→ target/practitioner/authority/consent/tools/facility/resources
→ eligibility/contraindications
→ reservations
→ procedure attempt
→ outcome and complication candidates
→ atomic body/resource commit where required
→ recovery or deterioration schedule
```

### Healing and recovery

```text
eligible injury/condition
→ healing/recovery/regeneration profile
→ resources/environment/support/time/interruptions
→ deterministic milestones
→ resolution/residual/recurrence/scar/complication candidates
```

### Repair and maintenance

```text
damaged structure/component
→ repair definition and historical configuration
→ access/tools/parts/skills/facility/resources
→ repairability
→ attempt
→ restored/degraded/substituted/unstable/failed outcome
→ dependency and inspection updates
```

### Replacement and integration

```text
replacement candidate
→ target and replacement identity
→ compatibility/authority/consent/ownership/resources
→ installation/transplant/restoration
→ integration/rejection/calibration/maintenance
→ identity/capability/social/legal handoffs
```

### Transformation

```text
trigger/action
→ subject/body/source/authority/consent/profile
→ frozen identity/topology/injury/condition/dependencies
→ staged transformation
→ component/function/injury/condition continuity
→ complications/source-local effects
→ owner commits and identity handoff
```

## Part XXII — Operation grammar

All **90** required operations have a typed owner boundary and lawful unresolved result.

| operation_number | operation | operation_family | authoritative_owner | authoritative_result |
| --- | --- | --- | --- | --- |
| 1 | minor impact | contact_impact | exposure_event_owner | Determine contact and typed load/exposure only; no automatic transfer, injury, or impairment. |
| 2 | major impact | contact_impact | exposure_event_owner | Determine contact and typed load/exposure only; no automatic transfer, injury, or impairment. |
| 3 | glancing contact | contact_impact | exposure_event_owner | Determine contact and typed load/exposure only; no automatic transfer, injury, or impairment. |
| 4 | failed contact | contact_impact | exposure_event_owner | Determine contact and typed load/exposure only; no automatic transfer, injury, or impairment. |
| 5 | armor intercepts exposure | protection_transfer | protection_state_owner | Apply coverage, orientation, state, capacity, and registered order; record attenuation, redirection, depletion, and protection damage separately. |
| 6 | shield absorbs exposure | protection_transfer | protection_state_owner | Apply coverage, orientation, state, capacity, and registered order; record attenuation, redirection, depletion, and protection damage separately. |
| 7 | shield overloads | protection_transfer | protection_state_owner | Apply coverage, orientation, state, capacity, and registered order; record attenuation, redirection, depletion, and protection damage separately. |
| 8 | armor is penetrated | protection_transfer | protection_state_owner | Apply coverage, orientation, state, capacity, and registered order; record attenuation, redirection, depletion, and protection damage separately. |
| 9 | armor is damaged | protection_transfer | protection_state_owner | Apply coverage, orientation, state, capacity, and registered order; record attenuation, redirection, depletion, and protection damage separately. |
| 10 | exposure is redirected | protection_transfer | protection_state_owner | Apply coverage, orientation, state, capacity, and registered order; record attenuation, redirection, depletion, and protection damage separately. |
| 11 | exposure is reflected | protection_transfer | protection_state_owner | Apply coverage, orientation, state, capacity, and registered order; record attenuation, redirection, depletion, and protection damage separately. |
| 12 | heat is transferred | exposure_transfer | exposure_event_owner | Record route, quantity, duration, uptake or propagation, target substrate, delayed effects, and uncertainty under AFQR-07. |
| 13 | cold exposure accumulates | exposure_transfer | exposure_event_owner | Record route, quantity, duration, uptake or propagation, target substrate, delayed effects, and uncertainty under AFQR-07. |
| 14 | electrical current follows a path | exposure_transfer | exposure_event_owner | Record route, quantity, duration, uptake or propagation, target substrate, delayed effects, and uncertainty under AFQR-07. |
| 15 | radiation dose accumulates | exposure_transfer | exposure_event_owner | Record route, quantity, duration, uptake or propagation, target substrate, delayed effects, and uncertainty under AFQR-07. |
| 16 | toxin is inhaled | exposure_transfer | exposure_event_owner | Record route, quantity, duration, uptake or propagation, target substrate, delayed effects, and uncertainty under AFQR-07. |
| 17 | poison is injected | exposure_transfer | exposure_event_owner | Record route, quantity, duration, uptake or propagation, target substrate, delayed effects, and uncertainty under AFQR-07. |
| 18 | disease exposure occurs | exposure_transfer | exposure_event_owner | Record route, quantity, duration, uptake or propagation, target substrate, delayed effects, and uncertainty under AFQR-07. |
| 19 | infection is established | condition_progression | condition_state_owner | Apply the versioned condition stage and schedule; preserve latency, suppression, remission, recurrence, and complications. |
| 20 | contamination spreads internally | exposure_transfer | exposure_event_owner | Record route, quantity, duration, uptake or propagation, target substrate, delayed effects, and uncertainty under AFQR-07. |
| 21 | laceration occurs | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 22 | fracture occurs | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 23 | hemorrhage begins | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 24 | burn occurs | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 25 | internal injury occurs | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 26 | nerve function is impaired | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 27 | organ or subsystem function degrades | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 28 | component is severed | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 29 | component is destroyed | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 30 | redundant component compensates | function_dependency | function_capacity_owner | Evaluate providers, dependencies, redundancy, reserve, assistance, and context before changing available function. |
| 31 | reserve capacity is consumed | function_dependency | function_capacity_owner | Evaluate providers, dependencies, redundancy, reserve, assistance, and context before changing available function. |
| 32 | cascading failure begins | platform_failure | platform_integrity_owner | Evaluate bounded load paths and dependency graph; platform, occupants, cargo, environment, and AI remain separate owners. |
| 33 | failure propagation stops | platform_failure | platform_integrity_owner | Evaluate bounded load paths and dependency graph; platform, occupants, cargo, environment, and AI remain separate owners. |
| 34 | structure deforms | platform_failure | platform_integrity_owner | Evaluate bounded load paths and dependency graph; platform, occupants, cargo, environment, and AI remain separate owners. |
| 35 | structural crack grows | platform_failure | platform_integrity_owner | Evaluate bounded load paths and dependency graph; platform, occupants, cargo, environment, and AI remain separate owners. |
| 36 | vehicle loses propulsion | platform_failure | platform_integrity_owner | Evaluate bounded load paths and dependency graph; platform, occupants, cargo, environment, and AI remain separate owners. |
| 37 | vehicle loses sensors | platform_failure | platform_integrity_owner | Evaluate bounded load paths and dependency graph; platform, occupants, cargo, environment, and AI remain separate owners. |
| 38 | life-support subsystem fails | platform_failure | platform_integrity_owner | Evaluate bounded load paths and dependency graph; platform, occupants, cargo, environment, and AI remain separate owners. |
| 39 | digital process is corrupted | platform_failure | platform_integrity_owner | Evaluate bounded load paths and dependency graph; platform, occupants, cargo, environment, and AI remain separate owners. |
| 40 | backup node assumes function | function_dependency | function_capacity_owner | Evaluate providers, dependencies, redundancy, reserve, assistance, and context before changing available function. |
| 41 | pain occurs without visible injury | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 42 | injury occurs without pain | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 43 | subject reports a symptom | symptom_diagnosis | epistemic_diagnostic_owner | Record subjective experience, report, observation, evidence, differential, or diagnosis without changing condition truth. |
| 44 | observer notices a sign | symptom_diagnosis | epistemic_diagnostic_owner | Record subjective experience, report, observation, evidence, differential, or diagnosis without changing condition truth. |
| 45 | diagnosis is correct | symptom_diagnosis | epistemic_diagnostic_owner | Record subjective experience, report, observation, evidence, differential, or diagnosis without changing condition truth. |
| 46 | diagnosis is mistaken | symptom_diagnosis | epistemic_diagnostic_owner | Record subjective experience, report, observation, evidence, differential, or diagnosis without changing condition truth. |
| 47 | condition is latent | condition_progression | condition_state_owner | Apply the versioned condition stage and schedule; preserve latency, suppression, remission, recurrence, and complications. |
| 48 | condition becomes active | condition_progression | condition_state_owner | Apply the versioned condition stage and schedule; preserve latency, suppression, remission, recurrence, and complications. |
| 49 | condition progresses | condition_progression | condition_state_owner | Apply the versioned condition stage and schedule; preserve latency, suppression, remission, recurrence, and complications. |
| 50 | condition is suppressed | condition_progression | condition_state_owner | Apply the versioned condition stage and schedule; preserve latency, suppression, remission, recurrence, and complications. |
| 51 | condition enters remission | condition_progression | condition_state_owner | Apply the versioned condition stage and schedule; preserve latency, suppression, remission, recurrence, and complications. |
| 52 | condition recurs | condition_progression | condition_state_owner | Apply the versioned condition stage and schedule; preserve latency, suppression, remission, recurrence, and complications. |
| 53 | complication develops | condition_progression | condition_state_owner | Apply the versioned condition stage and schedule; preserve latency, suppression, remission, recurrence, and complications. |
| 54 | function is impaired | function_dependency | function_capacity_owner | Evaluate providers, dependencies, redundancy, reserve, assistance, and context before changing available function. |
| 55 | accommodation restores practical function | function_dependency | function_capacity_owner | Evaluate providers, dependencies, redundancy, reserve, assistance, and context before changing available function. |
| 56 | subject becomes unconscious | consciousness_incapacity | consciousness_capacity_owner | Update only qualified wakefulness, awareness, responsiveness, control, communication, or task-capacity dimensions. |
| 57 | subject is responsive but incapacitated | consciousness_incapacity | consciousness_capacity_owner | Update only qualified wakefulness, awareness, responsiveness, control, communication, or task-capacity dimensions. |
| 58 | structure enters emergency mode | platform_failure | platform_integrity_owner | Evaluate bounded load paths and dependency graph; platform, occupants, cargo, environment, and AI remain separate owners. |
| 59 | stabilization succeeds | treatment_stabilization | treatment_stabilization_owner | Validate identity, consent, authority, eligibility, resources, tools, facilities, contraindications, and complication profile before any owner mutation. |
| 60 | stabilization fails | treatment_stabilization | treatment_stabilization_owner | Validate identity, consent, authority, eligibility, resources, tools, facilities, contraindications, and complication profile before any owner mutation. |
| 61 | first aid is attempted | treatment_stabilization | treatment_stabilization_owner | Validate identity, consent, authority, eligibility, resources, tools, facilities, contraindications, and complication profile before any owner mutation. |
| 62 | surgery is attempted | treatment_stabilization | treatment_stabilization_owner | Validate identity, consent, authority, eligibility, resources, tools, facilities, contraindications, and complication profile before any owner mutation. |
| 63 | antidote is administered | treatment_stabilization | treatment_stabilization_owner | Validate identity, consent, authority, eligibility, resources, tools, facilities, contraindications, and complication profile before any owner mutation. |
| 64 | decontamination occurs | exposure_transfer | exposure_event_owner | Record route, quantity, duration, uptake or propagation, target substrate, delayed effects, and uncertainty under AFQR-07. |
| 65 | natural healing advances | healing_recovery | recovery_healing_owner | Advance a versioned recovery milestone or residual-effect candidate; no universal healing rate or full restoration. |
| 66 | regeneration occurs | healing_recovery | recovery_healing_owner | Advance a versioned recovery milestone or residual-effect candidate; no universal healing rate or full restoration. |
| 67 | recovery is interrupted | healing_recovery | recovery_healing_owner | Advance a versioned recovery milestone or residual-effect candidate; no universal healing rate or full restoration. |
| 68 | persistent scar or change remains | healing_recovery | recovery_healing_owner | Advance a versioned recovery milestone or residual-effect candidate; no universal healing rate or full restoration. |
| 69 | mechanical repair is attempted | repair_replacement | repair_maintenance_owner | Separate repairability, historical configuration, parts, integration, ownership, degraded outcome, and maintenance dependency. |
| 70 | field repair creates degraded function | function_dependency | function_capacity_owner | Evaluate providers, dependencies, redundancy, reserve, assistance, and context before changing available function. |
| 71 | component is replaced | repair_replacement | repair_maintenance_owner | Separate repairability, historical configuration, parts, integration, ownership, degraded outcome, and maintenance dependency. |
| 72 | transplant or implant integrates | repair_replacement | repair_maintenance_owner | Separate repairability, historical configuration, parts, integration, ownership, degraded outcome, and maintenance dependency. |
| 73 | replacement is rejected | repair_replacement | repair_maintenance_owner | Separate repairability, historical configuration, parts, integration, ownership, degraded outcome, and maintenance dependency. |
| 74 | maintenance is overdue | repair_replacement | repair_maintenance_owner | Separate repairability, historical configuration, parts, integration, ownership, degraded outcome, and maintenance dependency. |
| 75 | body death is determined | death_recoverability | death_destruction_owner | Apply scope- and purpose-specific death, destruction, and recoverability profiles; route person continuity to AFQR-08. |
| 76 | structure destruction is determined | death_recoverability | death_destruction_owner | Apply scope- and purpose-specific death, destruction, and recoverability profiles; route person continuity to AFQR-08. |
| 77 | recoverability remains possible | death_recoverability | death_destruction_owner | Apply scope- and purpose-specific death, destruction, and recoverability profiles; route person continuity to AFQR-08. |
| 78 | irrecoverability is determined | death_recoverability | death_destruction_owner | Apply scope- and purpose-specific death, destruction, and recoverability profiles; route person continuity to AFQR-08. |
| 79 | remains are created | death_recoverability | death_destruction_owner | Apply scope- and purpose-specific death, destruction, and recoverability profiles; route person continuity to AFQR-08. |
| 80 | resurrection is attempted | death_recoverability | death_destruction_owner | Apply scope- and purpose-specific death, destruction, and recoverability profiles; route person continuity to AFQR-08. |
| 81 | replacement body is activated | repair_replacement | repair_maintenance_owner | Separate repairability, historical configuration, parts, integration, ownership, degraded outcome, and maintenance dependency. |
| 82 | shapeshifting occurs while injured | transformation_continuity | transformation_state_owner | Create staged topology and continuity candidates; identity, control, injuries, conditions, and functions transfer only by explicit manifest. |
| 83 | mutation alters topology | transformation_continuity | transformation_state_owner | Create staged topology and continuity candidates; identity, control, injuries, conditions, and functions transfer only by explicit manifest. |
| 84 | possession changes controller | transformation_continuity | transformation_state_owner | Create staged topology and continuity candidates; identity, control, injuries, conditions, and functions transfer only by explicit manifest. |
| 85 | fusion combines bodies | transformation_continuity | transformation_state_owner | Create staged topology and continuity candidates; identity, control, injuries, conditions, and functions transfer only by explicit manifest. |
| 86 | fission divides one body | transformation_continuity | transformation_state_owner | Create staged topology and continuity candidates; identity, control, injuries, conditions, and functions transfer only by explicit manifest. |
| 87 | distributed body loses nodes | distributed_embodiment | distributed_embodiment_owner | Evaluate node contribution, shared functions, thresholds, and continuity; node loss is not whole-subject death by default. |
| 88 | model narrates an unsupported injury | injury_component_effect | injury_effect_owner | Create a component-specific effect or injury candidate; localization, severity, condition, and function consequences remain separate determinations. |
| 89 | model declares death without authority | death_recoverability | death_destruction_owner | Apply scope- and purpose-specific death, destruction, and recoverability profiles; route person continuity to AFQR-08. |
| 90 | no lawful harm or embodiment determination exists | lawful_unresolved | AFQR16_handoff_router | Return unresolved, quarantined, or doctrine escalation; do not invent anatomy, interaction, injury, or death. |

## Part XXIII — Central stress cases

### Hybrid Ascendant under layered harm

The event branches into kinetic, thermal, electrical, psychic, shield, armor, implant, biological, delayed-condition, and spiritual-reserve pipelines. Protection ordering and quantities are branch-specific. Organic injury, cybernetic defect, armor damage, shield depletion, implant malfunction, psychic condition, and reserve expenditure belong to separate owners. Redundancy may preserve action. Shapeshifting uses continuity manifests. Treatment and regeneration remain distinct interventions. No universal damage total exists.

### Autonomous familiar with linked derivative bodies

Every derivative has a distinct body and identity binding. Shared function uses distributed contribution profiles. Harm propagation and voluntary redirection require explicit network interfaces, quantity manifests, capacity, and consent. One body can be destroyed while the derivative identity remains unresolved or continuing. A contract may create maintenance relations but not body ownership, control, or treatment consent automatically.

### Ship, crew, and cascading structural failure

Hull, compartments, power, sensors, life support, AI, crew, cargo, and atmosphere are separate owners. Hull breach creates secondary decompression exposure. Fire, toxic release, power loss, sensor faults, AI corruption, and isolation propagate through bounded graphs. The ship may be mission-incapable but recoverable while some crew and compartments remain functional.

### Death, replacement body, and contested continuity

AFQR-16 determines original-body death, organ viability, remains, structural recoverability, backup and replacement-body technical state, clone state, and resurrection body outcomes. AFQR-08 decides person continuity; AFQR-10 memory evidence; AFQR-15 legal death and offices; AFQR-13 social recognition. Several physically viable continuations may coexist while identity remains disputed.

## Part XXIV — Candidate comparison

Candidate H is selected. Universal HP is simple but semantically destructive. Wound tracks improve narrative clarity but remain too coarse. Hit-location systems overfit anatomy. Component graphs provide the core but need aggregate tiers, staged exposure, condition and continuity profiles. Tags alone under-specify objective function and quantities. Universal physics/physiology is too costly and donor-shaped. Unbounded source-local adapters prevent coherent mixed-system interaction.

| candidate | score_out_of_100 | donor_neutrality | anatomical_neutrality | component_damage | distributed_bodies | death_recoverability | simulation_tier_feasibility | corpus_scalability |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A_universal_hit_point_pool | 45.7 | 2 | 1 | 1 | 1 | 4 | 9 | 2 |
| B_wound_condition_track | 63.6 | 5 | 5 | 4 | 3 | 7 | 8 | 5 |
| C_hit_location_anatomy | 63.2 | 4 | 2 | 10 | 2 | 7 | 4 | 3 |
| D_component_dependency_graph | 95.0 | 10 | 10 | 10 | 10 | 9 | 10 | 10 |
| E_tag_consequence | 72.9 | 8 | 9 | 4 | 6 | 6 | 9 | 8 |
| F_physics_physiology_simulation | 69.3 | 3 | 2 | 10 | 4 | 9 | 2 | 2 |
| G_source_local_damage_adapters | 80.0 | 9 | 10 | 8 | 8 | 8 | 7 | 4 |
| H_registered_hybrid_integrity | 97.1 | 10 | 10 | 10 | 10 | 10 | 10 | 10 |

## Part XXV — Adversarial evaluation

Every scenario `DMG-001` through `DMG-200` receives a distinct disposition.

| scenario_id | title | category | candidate_status | authoritative_owners | final_lawful_disposition |
| --- | --- | --- | --- | --- | --- |
| DMG-001 | One identity has one biological body. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-002 | One identity controls two bodies. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-003 | Two identities share one body. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-004 | Body is possessed by another controller. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-005 | Body has detachable components. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-006 | Body topology changes temporarily. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-007 | Body topology changes permanently. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-008 | Structure contains living components. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-009 | Biological body contains synthetic subsystems. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-010 | Digital entity lacks physical anatomy. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-011 | Spirit has source-local embodiment. | embodiment_topology_function | source_local_containment | embodiment_identity_and_topology_owners | Retain under a source-local integrity ontology and explicit bridge; quarantine universal effect or continuity claims. |
| DMG-012 | Swarm has no privileged central node. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-013 | Colony has shared and local functions. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-014 | Component identity is disputed. | embodiment_topology_function | conflict_or_incomparability | embodiment_identity_and_topology_owners | Create a typed conflict or incomparability set; apply no implicit priority or averaging. |
| DMG-015 | Component ownership differs from body ownership. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-016 | Redundant subsystem is hidden. | embodiment_topology_function | hidden_state_security | embodiment_identity_and_topology_owners | Keep private state authoritative but remove hidden content, identifiers, counts, and linkable metadata from unauthorized projections. |
| DMG-017 | Function exists only with external support. | embodiment_topology_function | profile_scoped_candidate | embodiment_identity_and_topology_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-018 | No registered topology represents the body. | embodiment_topology_function | lawful_unresolved_or_escalated | embodiment_identity_and_topology_owners | Return unresolved, absent, quarantine, or doctrine escalation; do not invent anatomy, semantics, bridge, criterion, or outcome. |
| DMG-019 | Model assumes humanoid anatomy. | embodiment_topology_function | model_authority_or_projection_violation | embodiment_identity_and_topology_owners | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-020 | Embodiment classification remains unresolved. | embodiment_topology_function | death_destruction_profile | embodiment_identity_and_topology_owners | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-021 | Harmful action misses. | exposure_contact_transfer | staged_noncollapse | exposure_and_transfer_owners | Record the completed stage and explicit no-effect at later stages; do not infer downstream injury, symptom, or impairment. |
| DMG-022 | Contact occurs without transfer. | exposure_contact_transfer | staged_noncollapse | exposure_and_transfer_owners | Record the completed stage and explicit no-effect at later stages; do not infer downstream injury, symptom, or impairment. |
| DMG-023 | Transfer occurs without penetration. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-024 | Penetration occurs without injury. | exposure_contact_transfer | staged_noncollapse | exposure_and_transfer_owners | Record the completed stage and explicit no-effect at later stages; do not infer downstream injury, symptom, or impairment. |
| DMG-025 | Exposure reaches only outer layer. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-026 | Exposure reaches an internal component. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-027 | Impact affects several components. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-028 | Area exposure affects several bodies. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-029 | Dose accumulates over time. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-030 | Delayed effect follows brief exposure. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-031 | Exposure route is unknown. | exposure_contact_transfer | lawful_unresolved_or_escalated | exposure_and_transfer_owners | Return unresolved, absent, quarantine, or doctrine escalation; do not invent anatomy, semantics, bridge, criterion, or outcome. |
| DMG-032 | Quantity units are incompatible. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-033 | Attenuation profile is absent. | exposure_contact_transfer | lawful_unresolved_or_escalated | exposure_and_transfer_owners | Return unresolved, absent, quarantine, or doctrine escalation; do not invent anatomy, semantics, bridge, criterion, or outcome. |
| DMG-034 | Harm converts into another exposure family. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-035 | Secondary harmful byproduct is produced. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-036 | Exposure propagates through a network. | exposure_contact_transfer | profile_scoped_candidate | exposure_and_transfer_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-037 | Propagation path is hidden. | exposure_contact_transfer | hidden_state_security | exposure_and_transfer_owners | Keep private state authoritative but remove hidden content, identifiers, counts, and linkable metadata from unauthorized projections. |
| DMG-038 | Source-local harm lacks a bridge. | exposure_contact_transfer | source_local_containment | exposure_and_transfer_owners | Retain under a source-local integrity ontology and explicit bridge; quarantine universal effect or continuity claims. |
| DMG-039 | Model infers penetration from dramatic prose. | exposure_contact_transfer | model_authority_or_projection_violation | exposure_and_transfer_owners | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-040 | Transfer remains unresolved. | exposure_contact_transfer | death_destruction_profile | exposure_and_transfer_owners | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-041 | Armor fully blocks contact. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-042 | Armor attenuates transfer. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-043 | Armor is penetrated. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-044 | Armor is damaged but body is not. | protection_resistance_vulnerability | staged_noncollapse | protection_and_interaction_owners | Record the completed stage and explicit no-effect at later stages; do not infer downstream injury, symptom, or impairment. |
| DMG-045 | Shield absorbs exposure. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-046 | Shield capacity is exhausted. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-047 | Protection redirects exposure to another target. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-048 | Protection reflects exposure. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-049 | Insulation helps one route but worsens another. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-050 | Conditional immunity applies. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-051 | Claimed immunity is false. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-052 | Resistance reduces progression, not initial effect. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-053 | Vulnerability applies to one substrate only. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-054 | Adaptive defense changes after exposure. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-055 | Ablative layer is consumed. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-056 | Protection coverage is partial. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-057 | Protection orientation is wrong. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-058 | Several protections conflict. | protection_resistance_vulnerability | conflict_or_incomparability | protection_and_interaction_owners | Create a typed conflict or incomparability set; apply no implicit priority or averaging. |
| DMG-059 | Donor says “immune” without semantics. | protection_resistance_vulnerability | profile_scoped_candidate | protection_and_interaction_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-060 | Protection applicability remains unresolved. | protection_resistance_vulnerability | death_destruction_profile | protection_and_interaction_owners | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-061 | Minor localized injury occurs. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-062 | Severe localized injury occurs. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-063 | Internal injury has no visible sign. | injury_condition_symptom_impairment | staged_noncollapse | injury_condition_function_and_epistemic_owners | Record the completed stage and explicit no-effect at later stages; do not infer downstream injury, symptom, or impairment. |
| DMG-064 | Visible sign has no serious injury. | injury_condition_symptom_impairment | staged_noncollapse | injury_condition_function_and_epistemic_owners | Record the completed stage and explicit no-effect at later stages; do not infer downstream injury, symptom, or impairment. |
| DMG-065 | Pain occurs without tissue damage. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-066 | Tissue damage occurs without pain. | injury_condition_symptom_impairment | staged_noncollapse | injury_condition_function_and_epistemic_owners | Record the completed stage and explicit no-effect at later stages; do not infer downstream injury, symptom, or impairment. |
| DMG-067 | Hemorrhage progresses. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-068 | Fracture impairs one function. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-069 | Redundancy preserves function. | injury_condition_symptom_impairment | function_dependency_result | injury_condition_function_and_epistemic_owners | Evaluate providers, redundancy, reserve, accommodations, common-cause groups, and mission context; whole-subject destruction is not inferred. |
| DMG-070 | Accommodation restores task performance. | injury_condition_symptom_impairment | function_dependency_result | injury_condition_function_and_epistemic_owners | Evaluate providers, redundancy, reserve, accommodations, common-cause groups, and mission context; whole-subject destruction is not inferred. |
| DMG-071 | Infection is latent. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-072 | Infection becomes active. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-073 | Chronic condition enters remission. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-074 | Condition recurs. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-075 | Poison has delayed onset. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-076 | Two conditions interact. | injury_condition_symptom_impairment | conflict_or_incomparability | injury_condition_function_and_epistemic_owners | Create a typed conflict or incomparability set; apply no implicit priority or averaging. |
| DMG-077 | Diagnosis is correct. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-078 | Diagnosis is mistaken. | injury_condition_symptom_impairment | profile_scoped_candidate | injury_condition_function_and_epistemic_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-079 | Model invents a diagnosis. | injury_condition_symptom_impairment | model_authority_or_projection_violation | injury_condition_function_and_epistemic_owners | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-080 | Condition classification remains unresolved. | injury_condition_symptom_impairment | death_destruction_profile | injury_condition_function_and_epistemic_owners | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-081 | Noncritical component is lost. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-082 | Critical component is degraded. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-083 | Critical component is destroyed. | components_systems_cascade | death_destruction_profile | platform_integrity_and_dependency_owners | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-084 | Backup assumes function. | components_systems_cascade | function_dependency_result | platform_integrity_and_dependency_owners | Evaluate providers, redundancy, reserve, accommodations, common-cause groups, and mission context; whole-subject destruction is not inferred. |
| DMG-085 | Backup fails due to common cause. | components_systems_cascade | function_dependency_result | platform_integrity_and_dependency_owners | Evaluate providers, redundancy, reserve, accommodations, common-cause groups, and mission context; whole-subject destruction is not inferred. |
| DMG-086 | Power loss disables several systems. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-087 | Control system fails. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-088 | Sensor system gives false data. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-089 | Structural crack propagates. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-090 | Propagation is arrested. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-091 | Compartment breach affects occupants. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-092 | Life support fails locally. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-093 | Vehicle is mission-incapable but recoverable. | components_systems_cascade | death_destruction_profile | platform_integrity_and_dependency_owners | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-094 | Structure is usable in degraded mode. | components_systems_cascade | function_dependency_result | platform_integrity_and_dependency_owners | Evaluate providers, redundancy, reserve, accommodations, common-cause groups, and mission context; whole-subject destruction is not inferred. |
| DMG-095 | Digital subsystem is corrupted. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-096 | Corrupted backup propagates fault. | components_systems_cascade | function_dependency_result | platform_integrity_and_dependency_owners | Evaluate providers, redundancy, reserve, accommodations, common-cause groups, and mission context; whole-subject destruction is not inferred. |
| DMG-097 | Cascading profile exceeds recursion bound. | components_systems_cascade | profile_scoped_candidate | platform_integrity_and_dependency_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-098 | Component dependency data is incomplete. | components_systems_cascade | lawful_unresolved_or_escalated | platform_integrity_and_dependency_owners | Return unresolved, absent, quarantine, or doctrine escalation; do not invent anatomy, semantics, bridge, criterion, or outcome. |
| DMG-099 | Model equates component loss with destruction. | components_systems_cascade | model_authority_or_projection_violation | platform_integrity_and_dependency_owners | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-100 | System outcome remains unresolved. | components_systems_cascade | death_destruction_profile | platform_integrity_and_dependency_owners | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-101 | Stabilization succeeds. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-102 | Stabilization delays deterioration. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-103 | Stabilization fails. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-104 | Treatment lacks consent. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-105 | Emergency treatment authority is disputed. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-106 | Treatment target identity is mistaken. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-107 | Treatment resources are insufficient. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-108 | Treatment improves one condition and worsens another. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-109 | Treatment complication develops. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-110 | Natural healing advances. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-111 | Healing is interrupted. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-112 | Regeneration restores tissue but not memory. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-113 | Regeneration preserves a persistent condition. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-114 | Repair restores function with reduced capacity. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-115 | Repair uses incompatible parts. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-116 | Field repair is temporary. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-117 | Maintenance prevents failure. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-118 | Maintenance record is falsified. | treatment_healing_repair | intervention_candidate | treatment_recovery_repair_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-119 | Model narrates recovery before commitment. | treatment_healing_repair | model_authority_or_projection_violation | treatment_recovery_repair_owners | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-120 | Treatment or repair outcome remains unresolved. | treatment_healing_repair | death_destruction_profile | treatment_recovery_repair_owners | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-121 | Biological death criteria are met. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-122 | One organ is dead while body remains alive. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-123 | Circulatory arrest is reversible. | death_destruction_recoverability | profile_scoped_candidate | death_destruction_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-124 | Death evidence is incomplete. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-125 | Legal death is declared incorrectly. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-126 | Body is dead but identity continuity is unresolved. | death_destruction_recoverability | continuity_handoff | death_destruction_owner | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-127 | Structure is destroyed but salvageable. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-128 | Structure is irrecoverable. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-129 | Digital process stops but backup exists. | death_destruction_recoverability | function_dependency_result | death_destruction_owner | Evaluate providers, redundancy, reserve, accommodations, common-cause groups, and mission context; whole-subject destruction is not inferred. |
| DMG-130 | Distributed entity loses a majority of nodes. | death_destruction_recoverability | profile_scoped_candidate | death_destruction_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-131 | No death profile applies. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-132 | Source-local soul separation occurs. | death_destruction_recoverability | source_local_containment | death_destruction_owner | Retain under a source-local integrity ontology and explicit bridge; quarantine universal effect or continuity claims. |
| DMG-133 | Undead transition begins. | death_destruction_recoverability | source_local_containment | death_destruction_owner | Retain under a source-local integrity ontology and explicit bridge; quarantine universal effect or continuity claims. |
| DMG-134 | Remains are misidentified. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-135 | False death is staged. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-136 | Resurrection eligibility is disputed. | death_destruction_recoverability | continuity_handoff | death_destruction_owner | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-137 | Destruction and death determinations conflict. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-138 | Model announces death prematurely. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-139 | Historical death evaluator is unavailable. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-140 | Death or destruction remains unresolved. | death_destruction_recoverability | death_destruction_profile | death_destruction_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-141 | Prosthetic restores function. | replacement_transformation_continuity | profile_scoped_candidate | replacement_transformation_and_identity_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-142 | Implant creates maintenance dependency. | replacement_transformation_continuity | intervention_candidate | replacement_transformation_and_identity_owners | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-143 | Transplant is rejected. | replacement_transformation_continuity | profile_scoped_candidate | replacement_transformation_and_identity_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-144 | Replacement component has prior ownership. | replacement_transformation_continuity | profile_scoped_candidate | replacement_transformation_and_identity_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-145 | Replacement changes capability. | replacement_transformation_continuity | profile_scoped_candidate | replacement_transformation_and_identity_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-146 | Replacement changes vulnerability. | replacement_transformation_continuity | profile_scoped_candidate | replacement_transformation_and_identity_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-147 | Shapeshifting retains injury. | replacement_transformation_continuity | continuity_handoff | replacement_transformation_and_identity_owners | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-148 | Shapeshifting removes manifestation-specific injury. | replacement_transformation_continuity | continuity_handoff | replacement_transformation_and_identity_owners | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-149 | Transformation creates new topology. | replacement_transformation_continuity | profile_scoped_candidate | replacement_transformation_and_identity_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-150 | Transformation is interrupted. | replacement_transformation_continuity | profile_scoped_candidate | replacement_transformation_and_identity_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-151 | Mutation is harmful and beneficial. | replacement_transformation_continuity | profile_scoped_candidate | replacement_transformation_and_identity_owners | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-152 | Purification removes one corruption layer. | replacement_transformation_continuity | source_local_containment | replacement_transformation_and_identity_owners | Retain under a source-local integrity ontology and explicit bridge; quarantine universal effect or continuity claims. |
| DMG-153 | Possession changes controller but not body. | replacement_transformation_continuity | continuity_handoff | replacement_transformation_and_identity_owners | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-154 | Body transfer leaves original body alive. | replacement_transformation_continuity | continuity_handoff | replacement_transformation_and_identity_owners | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-155 | Fusion combines incompatible injuries. | replacement_transformation_continuity | continuity_handoff | replacement_transformation_and_identity_owners | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-156 | Fission allocates one chronic condition. | replacement_transformation_continuity | continuity_handoff | replacement_transformation_and_identity_owners | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-157 | Clone begins without predecessor injury. | replacement_transformation_continuity | continuity_handoff | replacement_transformation_and_identity_owners | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-158 | Resurrection restores body with persistent scar. | replacement_transformation_continuity | continuity_handoff | replacement_transformation_and_identity_owners | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-159 | Model decides identity continuity. | replacement_transformation_continuity | continuity_handoff | replacement_transformation_and_identity_owners | Determine body/topology/condition facts only and route identity, memory, relation, legal, and social continuity to their owners. |
| DMG-160 | Transformation continuity remains unresolved. | replacement_transformation_continuity | death_destruction_profile | replacement_transformation_and_identity_owners | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-161 | Swarm loses one node. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-162 | Swarm loses a specialized node. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-163 | Shared function degrades gradually. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-164 | Harm propagates through a familiar network. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-165 | Propagation is redirected voluntarily. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-166 | Redirection lacks consent. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-167 | Hidden injury affects action feasibility. | distributed_secrecy_replay_model_safety | hidden_state_security | distributed_embodiment_or_projection_security_owner | Keep private state authoritative but remove hidden content, identifiers, counts, and linkable metadata from unauthorized projections. |
| DMG-168 | Visible blocker leaks hidden injury. | distributed_secrecy_replay_model_safety | hidden_state_security | distributed_embodiment_or_projection_security_owner | Keep private state authoritative but remove hidden content, identifiers, counts, and linkable metadata from unauthorized projections. |
| DMG-169 | Secret implant changes protection. | distributed_secrecy_replay_model_safety | hidden_state_security | distributed_embodiment_or_projection_security_owner | Keep private state authoritative but remove hidden content, identifiers, counts, and linkable metadata from unauthorized projections. |
| DMG-170 | Model packet exposes internal damage. | distributed_secrecy_replay_model_safety | model_authority_or_projection_violation | distributed_embodiment_or_projection_security_owner | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-171 | Cross-packet retrieval exposes diagnosis. | distributed_secrecy_replay_model_safety | hidden_state_security | distributed_embodiment_or_projection_security_owner | Keep private state authoritative but remove hidden content, identifiers, counts, and linkable metadata from unauthorized projections. |
| DMG-172 | Stable digest links secret condition. | distributed_secrecy_replay_model_safety | hidden_state_security | distributed_embodiment_or_projection_security_owner | Keep private state authoritative but remove hidden content, identifiers, counts, and linkable metadata from unauthorized projections. |
| DMG-173 | Aggregate body state is promoted to detailed simulation. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-174 | Promotion invents no historical injury. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-175 | Detailed body state is demoted safely. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-176 | Current profile differs from historical profile. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-177 | Replay produces different rounding. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-178 | Duplicate harm command is retried. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-179 | Cross-owner commit partially fails. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-180 | Invariant failure leaves impossible body state. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-181 | Model invents bleeding. | distributed_secrecy_replay_model_safety | model_authority_or_projection_violation | distributed_embodiment_or_projection_security_owner | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-182 | Model invents unconsciousness. | distributed_secrecy_replay_model_safety | model_authority_or_projection_violation | distributed_embodiment_or_projection_security_owner | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-183 | Model infers weakness from species. | distributed_secrecy_replay_model_safety | model_authority_or_projection_violation | distributed_embodiment_or_projection_security_owner | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-184 | Model treats impairment as lack of agency. | distributed_secrecy_replay_model_safety | model_authority_or_projection_violation | distributed_embodiment_or_projection_security_owner | Reject unsupported model inference or narration expansion; preserve the committed state and emit validator/noninterference failure. |
| DMG-185 | Model exposes hidden vulnerability. | distributed_secrecy_replay_model_safety | hidden_state_security | distributed_embodiment_or_projection_security_owner | Keep private state authoritative but remove hidden content, identifiers, counts, and linkable metadata from unauthorized projections. |
| DMG-186 | Narration conflicts with committed injury. | distributed_secrecy_replay_model_safety | conflict_or_incomparability | distributed_embodiment_or_projection_security_owner | Create a typed conflict or incomparability set; apply no implicit priority or averaging. |
| DMG-187 | Public record conflicts with body truth. | distributed_secrecy_replay_model_safety | conflict_or_incomparability | distributed_embodiment_or_projection_security_owner | Create a typed conflict or incomparability set; apply no implicit priority or averaging. |
| DMG-188 | Medical record is sealed. | distributed_secrecy_replay_model_safety | hidden_state_security | distributed_embodiment_or_projection_security_owner | Keep private state authoritative but remove hidden content, identifiers, counts, and linkable metadata from unauthorized projections. |
| DMG-189 | Source-local damage system conflicts with Astra doctrine. | distributed_secrecy_replay_model_safety | source_local_containment | distributed_embodiment_or_projection_security_owner | Retain under a source-local integrity ontology and explicit bridge; quarantine universal effect or continuity claims. |
| DMG-190 | Donor hit points cannot map directly. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-191 | Unknown material lacks interaction profile. | distributed_secrecy_replay_model_safety | lawful_unresolved_or_escalated | distributed_embodiment_or_projection_security_owner | Return unresolved, absent, quarantine, or doctrine escalation; do not invent anatomy, semantics, bridge, criterion, or outcome. |
| DMG-192 | Unknown anatomy lacks localization profile. | distributed_secrecy_replay_model_safety | lawful_unresolved_or_escalated | distributed_embodiment_or_projection_security_owner | Return unresolved, absent, quarantine, or doctrine escalation; do not invent anatomy, semantics, bridge, criterion, or outcome. |
| DMG-193 | Unknown condition is quarantined. | distributed_secrecy_replay_model_safety | lawful_unresolved_or_escalated | distributed_embodiment_or_projection_security_owner | Return unresolved, absent, quarantine, or doctrine escalation; do not invent anatomy, semantics, bridge, criterion, or outcome. |
| DMG-194 | No valid healing bridge exists. | distributed_secrecy_replay_model_safety | intervention_candidate | distributed_embodiment_or_projection_security_owner | Require identity, consent/authority, eligibility, resources, procedure, time, complication, and owner commit; no narration-based recovery. |
| DMG-195 | No valid death criterion exists. | distributed_secrecy_replay_model_safety | death_destruction_profile | distributed_embodiment_or_projection_security_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |
| DMG-196 | Embodiment state is corrupted. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-197 | Historical topology version is unavailable. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-198 | Historical condition evaluator is unavailable. | distributed_secrecy_replay_model_safety | profile_scoped_candidate | distributed_embodiment_or_projection_security_owner | Freeze all required bases, apply the registered profile, and produce an owner-scoped candidate or determination. |
| DMG-199 | No typed construct represents the harm. | distributed_secrecy_replay_model_safety | lawful_unresolved_or_escalated | distributed_embodiment_or_projection_security_owner | Return unresolved, absent, quarantine, or doctrine escalation; do not invent anatomy, semantics, bridge, criterion, or outcome. |
| DMG-200 | Embodiment outcome remains lawfully unresolved. | distributed_secrecy_replay_model_safety | death_destruction_profile | distributed_embodiment_or_projection_security_owner | Apply body/structure scope, purpose, evidence, death/destruction and recoverability profiles; route identity and legal status separately. |

## Part XXVI — Current runtime disposition

**Exists:** backend-authority and deterministic-event doctrine; a future ownership statement for injury, condition, damage, and recovery; narrow actor, target, object, lever, visible-condition, hidden-fact, event, delta, and audit fixtures.

**Fixture-only:** a visible condition string and object/lever mutation. These do not establish a condition owner or harm mutation.

**Conversion-only:** creature health descriptors, HP, damage labels, resistances, exposures, conditions, vehicle/platform records, hazards, implants, prosthetics, repair, and transformations.

**Narrative-only:** combat, injury, death, medical, repair, and transformation prose.

**Absent:** all generalized AFQR-16 owners and evaluators.

**May proceed:** schemas, registries, validators, conversion pressure IR, non-mutating dry runs, and hard-case certification.

**Blocked:** all authoritative harm, injury, condition, function, death, treatment, repair, replacement, and transformation mutation.

**Prohibited:** model-authored bodily outcomes or treating RT-002 action legality as damage resolution.

## Part XXVII — Required artifacts

1. **Immediate:** every artifact in this pack.
2. **Before authoritative embodiment state:** embodiment, structure, component, topology, substrate, function, dependency, identity/control/occupancy registries.
3. **Before harm and protection:** harm/exposure/route/quantity/protection/interaction registries and AFQR-05/07 integration.
4. **Before injury and condition mutation:** effect, injury, condition, function owners; scheduler; cross-owner invariants.
5. **Before death:** death, destruction, recoverability, remains, evidence, identity, social, and legal handoffs.
6. **Before treatment and recovery:** consent, authority, eligibility, resource, procedure, complication, and schedule owners.
7. **Before repair and replacement:** historical configuration, repairability, parts, integration, ownership, and maintenance services.
8. **Before transformation:** staged transformations and continuity manifests.
9. **Before model narration:** grounding, claim allowlist, evidence binding, output validator, isolation, noninterference.
10. **Before mass conversion:** donor pressure fixtures and family certification.
11. **Deferred:** final combat, armor, hazards, epidemiology, trauma, medical ethics, treatment law, and high-scale physics.

## Part XXVIII — Non-mutating prototype

**Prototype:** `AFQR-16 Embodiment, Harm, Injury, Condition, Death, Recovery, and Repair Dry Run`

It evaluates **50** cases and produces only candidate records, determinations, private receipts, projections, deterministic commitments, and AFQR handoffs. It performs no world, body, structure, resource, injury, condition, death, treatment, healing, repair, or transformation mutation and makes no model calls.

## Part XXIX — Acceptance tests

The pack contains **164** acceptance assertions covering embodiment, topology, harm, protection, injury, conditions, function, impairment, diagnosis, consciousness, death, treatment, recovery, repair, transformation, platforms, distributed bodies, hidden state, replay, conversion, and runtime containment.

See `evaluation/acceptance_test_matrix.yaml`.

## Part XXX — Residual uncertainty ledger

- **Final combat resolution and sequencing:** deferred composition of AFQR-02–04, spatial doctrine, AFQR-16, and future combat profiles.
- **Final armor and penetration formulas:** profile-specific implementation research.
- **Environment and hazards:** AFQR-17.
- **Population epidemiology and ecosystems:** later environment/population owners.
- **Psychological trauma:** later dedicated doctrine; bodily harm does not create trauma automatically.
- **Universal death metaphysics:** intentionally unresolved.
- **Resurrection identity:** AFQR-08 and source-local doctrine.
- **Medical ethics and treatment law:** AFQR-11 and AFQR-15 source-specific profiles.
- **Disability and accessibility content:** requires expert and sensitivity review in implementation and sourcebook phases.
- **Maintenance economy:** AFQR-07 and future economic/crafting implementation.
- **Large-scale structural simulation:** tier and performance benchmarks required.
- **Conceptual harm:** source-local interfaces and certification.
- **Distributed performance:** implementation benchmark required.
- **Training-model behavior:** adversarial grounding and projection evaluation required.

## Part XXXI — Roadmap conclusion

1. **Ratification:** Yes; AFQR-16 is sufficiently resolved.
2. **Second broad research pass:** No.
3. **Mandatory amendments:** federated owners; component–function–dependency graphs; staged exposure; AFQR-07 quantity manifests; stage-specific protection; injury/condition separation; contextual impairment and accommodation; AFQR-10 diagnosis; orthogonal consciousness; profile-scoped death/destruction/recoverability; separated treatment/healing/repair/replacement/transformation; family-specific continuity; simulation tiers; hidden-state validation.
4. **Immediate artifacts:** included in this pack.
5. **Minimum prototype:** the 50-case non-mutating dry run.
6. **Execution blocked:** all authoritative embodiment and integrity mutation.
7. **Authoritative damage or recovery unlocked:** No.
8. **Bounded bodily narration unlocked:** only after grounding, evidence bindings, claim allowlists, validation, and isolation are implemented.
9. **RT-002G:** unchanged and non-harmful/non-medical.
10. **AFQR-17:** Environment, Exposure, Hazards, Atmosphere, Weather, Terrain, Contamination, and Ecological Processes.
11. **Exact action:** ratify AFQR-16, run the dry run and RT-002A–F noninterference audit, keep RT-002G narrow, and open AFQR-17 read-only.

## Part XXXII — Machine-readable decision block

```yaml
question_id: AFQR-16
question_title: Bodies Structures Integrity Harm Damage Injury Conditions Impairment Death Recovery Repair Replacement and
  Transformation
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: ratification_candidate
selected_architecture: Registered Federated Embodiment–Integrity Architecture with Typed Component–Function–Dependency Graphs,
  Staged Exposure–Transfer–Effect Pipelines, Profile-Scoped Injury–Condition–Death Families, and Bitemporal Recovery–Transformation
  Continuity
selected_architecture_abbreviation: RFEIA-CFDG-SETE-ICD-BRTC
confidence: high
central_law: No body, structure, component, anatomy label, hit-point value, damage number, injury label, condition, death
  flag, treatment text, repair result, transformation description, donor rule, or model narration possesses mutation authority
  by itself. Every authoritative embodiment result is a purpose-scoped, version-pinned, bitemporal determination over frozen
  identity, embodiment, topology, substrate, function, dependency, redundancy, protection, exposure, quantity, epistemic,
  agency, consent, behavioral, social, communication, governed-relation, and institutional bases. Contact, transfer, penetration,
  uptake, effect, injury, condition, impairment, death or destruction, recoverability, treatment, repair, replacement, and
  transformation remain separate. Only owner-prepared AFQR-01 transitions mutate state; later diagnosis, reinterpretation,
  recovery, and continuity determinations append records rather than rewriting history; unresolved and source-local outcomes
  remain lawful.
accepted_dependencies:
  AFQR_01: &id001
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_02: &id002
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_03: &id003
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_04: &id004
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_05: &id005
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_06: &id006
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_07: &id007
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_08: &id008
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_09: &id009
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_10: &id010
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_11: &id011
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_12: &id012
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_13: &id013
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_14: &id014
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_15: &id015
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
definitions:
  embodiment: A purpose-scoped relation by which one or more identities are manifested, hosted, represented, or enabled through
    one or more body or structure instances.
  body: An embodiment-oriented organized substrate or component system; not automatically a person, actor, owner, controller,
    or legal subject.
  structure: An organized material, synthetic, digital, energetic, or source-local component system evaluated for integrity
    and function.
  vessel: A body or structure capable of hosting, carrying, or supporting an identity, occupant, process, or controlled manifestation
    under a named profile.
  form: A versioned topology, appearance, substrate, or manifestation state of an embodiment.
  manifestation: A source- and profile-scoped appearance or operational presence of an identity that may or may not be a persistent
    body.
  body instance: A particular identity-bearing body record at a recorded interval.
  structural instance: A particular structure record with versioned topology, components, functions, and state.
  component: A typed part, node, tissue, organ, module, layer, or process with its own identity, interfaces, state, and relations
    where relevant.
  subcomponent: A component whose part-of relation is scoped beneath another component without implying inheritance of all
    properties.
  tissue: A biological or source-local substrate organization with profile-defined properties and functions.
  organ: A functionally organized body component; its semantics are embodiment-profile specific rather than universally biological.
  module: A replaceable, detachable, or logically bounded component with declared interfaces and dependencies.
  subsystem: A coordinated component set providing one or more functions.
  layer: A topological or functional stratum that may affect contact, transfer, containment, protection, or propagation.
  surface: A registered contact boundary; it may be spatial, network, energetic, informational, or source-local.
  interface: A registered boundary through which matter, energy, signal, load, control, support, or source-local effects may
    pass.
  topology: A versioned graph of component, attachment, containment, interface, reachability, and support relations.
  material: A source-scoped substrate category with named property sets rather than a universal physics list.
  biological substrate: A living or once-living substrate governed by a biological or source-local profile.
  synthetic substrate: An engineered nonbiological or hybrid substrate.
  distributed body: An embodiment whose functions or continuity are spread across multiple nodes without requiring a privileged
    central component.
  incorporeal body: A source-local embodiment lacking ordinary physical substrate while retaining declared interfaces, topology,
    and integrity semantics.
  function: A purpose-scoped contribution or operation provided by one or more components, substrates, processes, supports,
    or environments.
  functional domain: A named class of function such as mobility, sensing, regulation, processing, protection, transport, communication,
    or source-local operation.
  capacity: A typed upper bound, current ability, or task-specific performance measure under a named profile.
  reserve: Available capacity beyond current ordinary demand that can support compensation, peak use, or degradation.
  redundancy: Multiple providers or pathways capable of sustaining a function under a registered failover or aggregation profile.
  dependency: A typed relation stating that a function, component, process, or state relies on another subject, component,
    interface, resource, or environment.
  support relation: A dependency-family relation providing enabling, stabilizing, load-bearing, regulatory, or maintenance
    support.
  baseline function: The reference functional state for a profile and interval, not a universal normality standard.
  available function: The currently usable function after dependencies, impairment, reserve, environment, support, and accommodations
    are evaluated.
  assisted function: Function made usable through an aid, replacement, external support, interface, person, or environmental
    modification.
  degraded function: Function that remains available with reduced capacity, reliability, precision, duration, safety, or scope.
  lost function: Function unavailable under the evaluated context; it does not imply universal incapacity.
  impairment: A context- and purpose-scoped alteration or limitation of function; not loss of agency, personhood, or universal
    inability.
  limitation: A task- or environment-specific restriction in performance or access.
  accommodation: A change to tools, environment, procedure, assistance, or interface that improves practical function without
    requiring removal of the underlying impairment.
  adaptation: A persistent or learned change that alters function, tolerance, compensation, or interaction with the environment.
  harmful event: A committed event capable of producing adverse embodiment or structural effects under one or more registered
    profiles.
  harm agent: A typed source, carrier, process, substance, load, signal, or source-local effect capable of harmful exposure.
  damage family: A registered interoperability and effect-routing family; not a universal list of damage types or severity
    scale.
  exposure: A relation in which a target boundary is presented to a harm agent through a route for an interval.
  contact: A profile-scoped determination that source or carrier reached a target surface or interface.
  impact: A contact event involving a registered load, momentum, energy, pressure, or source-local transfer profile.
  transfer: A determined movement of typed quantity or effect potential across an interface.
  penetration: A determination that exposure crosses a layer or boundary under a named profile.
  uptake: Absorption, entry, ingestion, inhalation, injection, infection, reception, or other acquisition by a target subsystem.
  propagation: Movement or reproduction of an exposure, fault, load, condition, or effect through a registered path.
  load: A typed demand, force, stressor, flow, computation, or source-local burden applied to a component or structure.
  dose: A typed exposure quantity qualified by route, target, time, concentration, distribution, and measurement basis.
  intensity: A typed magnitude or rate associated with an exposure or load.
  duration: The logical-time extent of an exposure, state, or process.
  attenuation: A profile-governed reduction or transformation of an exposure before it reaches a later stage.
  absorption: Acquisition or storage of exposure quantity by a protection, substrate, or target, with capacity and byproducts
    explicit.
  reflection: Redirection toward a defined outgoing path without assuming identity or quantity preservation.
  redirection: Transfer of all or part of an exposure to another path, target, or sink under a registered manifest.
  byproduct: An output generated by transfer, conversion, protection, damage, treatment, or repair in addition to intended
    outputs.
  secondary exposure: A new exposure produced by an earlier event, conversion, byproduct, propagation, or component failure.
  protection: A registered mechanism affecting a specific stage of targeting, contact, transfer, uptake, propagation, effect,
    progression, or recovery.
  armor: A protective body or structure component with coverage, interfaces, capacity, condition, and damage semantics.
  shield: An active, passive, energetic, informational, or source-local protection with defined coverage and capacity.
  barrier: A boundary intended to block, filter, contain, redirect, or attenuate specified interactions.
  cover: An external spatial or interface obstruction affecting targeting, contact, or transfer.
  resistance: A profile-scoped reduction, delay, or altered response to a harm family or stage.
  tolerance: A profile-scoped range or threshold within which exposure produces limited or no specified adverse effect.
  immunity: A qualified claim that a specified effect cannot occur under exact route, threshold, source, state, and profile
    conditions; never an unqualified universal boolean.
  vulnerability: A qualified interaction property increasing likelihood, transfer, severity, progression, or consequence for
    a specified target and harm family.
  insulation: Protection that limits transfer through a declared interface or route.
  containment: Protection limiting escape, spread, contact, or propagation.
  filtering: Selective passage, removal, transformation, or rejection of exposure components.
  damping: Reduction of oscillation, shock, vibration, signal, or other dynamic response.
  ablative protection: Protection designed to consume, shed, erode, or sacrifice capacity or material while attenuating exposure.
  active defense: A protection requiring sensing, power, control, timing, action, or resource expenditure.
  damage: A qualified embodiment or structural state change produced by a committed effect; prohibited as an unqualified numeric
    currency.
  injury: A typed adverse alteration to a body component, tissue, organ, function-support system, or source-local embodiment.
  wound: An injury family involving localized physical or source-local disruption under a named profile.
  lesion: A localized structural or functional abnormality represented under a diagnostic or injury profile.
  defect: A structural, material, software, informational, or component deviation that may affect function.
  malfunction: Failure or abnormal operation of a function or subsystem without requiring physical damage.
  degradation: A progressive or accumulated decline in material, component, system, data, or functional condition.
  condition: A versioned state family with origin, stage, triggers, progression, suppression, remission, recurrence, and resolution
    semantics.
  disease: A biological or source-local condition family; no universal human disease ontology is assumed.
  infection: A condition involving establishment or proliferation of an infectious agent after exposure and uptake.
  poison: A harmful substance or source-local agent identified by route, dose, kinetics, and effect profiles.
  toxin: A harmful agent produced biologically or source-locally; it remains distinct from the condition it may cause.
  contamination: Presence or distribution of an unwanted agent, substance, signal, or corrupting influence on or within a
    target.
  corruption: A source-local, informational, spiritual, magical, or systemic degradation family requiring explicit interfaces
    and semantics.
  chronic condition: A condition with long-duration or persistent management semantics under a named profile.
  latent condition: A condition present without active effects, visible signs, or current detectability under the evaluated
    profile.
  progressive condition: A condition whose state can worsen or spread over scheduled or triggered transitions.
  complication: A new or worsened condition, injury, impairment, or treatment consequence arising from another state or intervention.
  sequela: A persistent or later consequence of a prior injury, condition, or treatment after the initiating state has changed
    or resolved.
  symptom: A subject-experienced or subject-reported phenomenon; not condition truth.
  sign: An observer- or instrument-detectable phenomenon; not automatically diagnosis.
  pain: A subjective sensory and emotional experience represented separately from nociception, injury, function, and report
    credibility.
  diagnosis: An epistemic or institutional determination selecting or preserving condition candidates from evidence under
    a versioned profile.
  prognosis: A bounded forecast candidate about future state or function under stated assumptions and uncertainty.
  stable: A profile-scoped state in which specified adverse transitions are not currently expected without new triggers.
  unstable: A profile-scoped state with material risk of near-term adverse transition or insufficient control.
  critical: A profile-scoped state requiring urgent attention under a defined purpose; not a universal severity label.
  incapacitated: Unable to perform one or more specified actions or task families under an incapacity profile; not automatically
    unconscious or without agency.
  unconscious: A state determined under a consciousness profile; it does not by itself decide personhood, consent history,
    or all task capacities.
  dying: A source- and profile-scoped state of active transition toward a death criterion; not universal or irreversible.
  dead: A qualified death determination for a specified body, function, process, legal purpose, or source-local profile.
  destroyed: A qualified structural or process determination that specified integrity or function criteria are met.
  dormant: Inactive but potentially recoverable or resumable under a profile.
  shut down: A process or system is inactive through controlled, protective, failed, or unknown cause.
  recoverable: A determination that a registered restoration pathway remains feasible under stated assumptions and resources.
  irrecoverable: A purpose-scoped determination that no registered recovery pathway satisfies the profile and evidence basis.
  remains: A post-death or post-destruction body, component, material, data, or source-local record retaining identity and
    provenance where relevant.
  corpse: A source- and profile-scoped biological remains classification.
  wreck: A damaged or destroyed structure retained as a distinct salvage or remains state.
  salvage state: A determination of recoverable components, materials, data, or functions after damage or destruction.
  stabilization: An intervention or transition that limits immediate deterioration without necessarily healing or resolving
    the cause.
  treatment: A registered intervention intended to alter injury, condition, symptom, progression, or function.
  healing: Biological or source-local restoration process affecting injuries or conditions under a named profile.
  recovery: A broader transition toward restored or adapted function, state, participation, or capacity.
  regeneration: Restoration or regrowth of substrate, component, topology, or function through a registered process.
  repair: A technical, material, digital, magical, or hybrid intervention restoring specified structure or function.
  maintenance: Preventive, corrective, or condition-based work intended to preserve or improve reliability and function.
  replacement: Substitution of a component, body, process, data set, or function provider with a distinct identity or instance.
  rehabilitation: Interventions optimizing function and participation through recovery, adaptation, training, environment,
    and assistive support.
  reconstruction: Rebuilding a body or structure from components, records, templates, remains, or source-local processes.
  restoration: A general return toward a specified state or function without assuming historical identity or exact configuration.
  resurrection: A source-local process attempting to restore a dead body, embodiment, identity relation, or living state;
    person continuity routes to AFQR-08.
  reincarnation: A source-local continuity claim involving embodiment through a new body or form.
  body transfer: A process changing which body or structure embodies, hosts, or is controlled by an identity.
  mutation: A persistent topology, substrate, property, or function change arising through a registered mechanism.
  metamorphosis: A staged transformation between embodiment profiles.
  shapeshifting: A reversible or recurring change of form or topology under an embodiment profile.
  augmentation: Addition or enhancement of components, functions, interfaces, or capacities.
  implantation: Installation of a component within or onto an embodiment through a registered procedure.
  transplantation: Transfer and integration of biological or source-local material or organs between bodies or origins.
  purification: A source-local process removing or transforming specified corruption, contamination, or condition layers.
  possession: A control or occupancy transition in which a distinct subject operates or inhabits a body without automatically
    changing body identity.
  fusion: An n-ary transformation combining bodies, structures, components, identities, or functions under explicit continuity
    manifests.
  fission: An n-ary transformation dividing one body or structure into several successors with explicit state allocation.
  transformation: A staged, versioned alteration of embodiment profile, topology, substrate, function, or manifestation.
  continuity: A purpose-scoped determination of what identity, body, component, injury, condition, function, or relation persists
    across transition.
  replacement body: A distinct body instance intended to host or embody an identity after or alongside another body.
  nociception: Neural or source-local processing of harmful stimuli; distinct from pain experience.
  functional reserve: Capacity available to compensate for increased demand or loss of ordinary providers.
  mission capability: A purpose-scoped assessment of whether a platform can perform a specified mission; not whole-structure
    integrity or survival.
  catastrophic failure: A profile-scoped transition causing specified high-level losses; not universal destruction or identity
    extinction.
  recoverability profile: A registered method for evaluating restoration pathways, resources, evidence, time, and uncertainty.
  body death: A death determination scoped to a body instance, not identity continuity.
  legal death: An AFQR-15 institutional determination, not body truth or identity extinction.
  social death claim: An AFQR-13 audience-relative status or recognition claim, not biological death.
  condition truth: The authoritative condition state owned by the embodiment or condition owner; distinct from diagnosis and
    records.
  historical configuration: A versioned topology, component, software, material, or embodiment state used as a restoration
    reference.
  source-local integrity ontology: A namespaced harm, embodiment, condition, death, or restoration system that is not universalized.
  lawful unresolved outcome: A typed result preserving missing, conflicting, incomparable, unsupported, or source-local bases
    without inventing certainty.
guarantees:
- federated embodiment, topology, function, exposure, injury, condition, diagnosis, death, recovery, repair, replacement,
  transformation, and projection ownership
- identity, body, form, control, ownership, occupancy, and legal subject separation
- heterogeneous component/function/dependency graphs
- staged contact-transfer-effect pipeline with lawful failure at every stage
- profile-scoped harm, protection, injury, condition, impairment, death, destruction, and recoverability semantics
- contextual function with redundancy, reserve, assistance, and accommodation
- append-only bitemporal diagnosis, treatment, recovery, repair, and continuity records
- source-local harm and restoration containment
- hidden-safe model projections and deterministic replay
non_guarantees:
- universal anatomy
- universal hit-point pool
- universal damage taxonomy
- universal material or physiology model
- universal impairment or disability model
- universal consciousness metric
- universal death criterion
- universal healing rate
- universal resurrection metaphysics
- final combat, armor, medicine, hazard, or repair formulas
- authoritative model diagnosis or harm
embodiment_model:
  families:
  - biological
  - synthetic
  - mechanical
  - cybernetic
  - biotech
  - vehicle
  - ship
  - building
  - tool
  - armor
  - digital_process
  - distributed_computation
  - swarm
  - colony
  - symbiotic_composite
  - possessed_body
  - incorporeal_manifestation
  - spirit_vessel
  - projected_avatar
  - source_local_conceptual_body
  one_identity_one_body_assumed: false
  one_body_one_subject_assumed: false
  profile_scoped: true
body_and_structure_model:
  body_not_person_actor_agent_or_legal_subject: true
  structure_not_identity_material_component_graph_function_or_condition: true
  separate_owner_families: true
identity_and_control_bindings:
  roles:
  - identity_embodied
  - body_identity
  - owner
  - controller
  - occupant
  - possessor
  - operator
  - maintainer
  - legal_custodian
  AFQR08_identity: true
  AFQR11_control: true
  AFQR15_legal_status: true
topology_model:
  versioned_graph: true
  relations:
  - part_of
  - attachment
  - containment
  - interface
  - support
  - load_path
  - transport_network
  - distributed_membership
  n_ary_nested_mutable_nonspatial: true
  transition_receipts: true
component_model:
  component_identity_and_provenance: true
  component_loss_not_whole_death: true
  detached_component_continuity: true
substrate_model:
  extensible_profiles:
  - material
  - tissue
  - synthetic
  - digital
  - metaphysical
  universal_property_list: false
  interaction_profiles_required: true
function_model:
  intrinsic_available_assisted_reserve_contextual_separate: true
  task_specific: true
  provider_consumer_bindings: true
dependency_model:
  typed_bounded_versioned: true
  automatic_cascade: false
  orphan_and_support_consequences: true
redundancy_and_reserve_model:
  provider_failover_and_aggregation_profiles: true
  common_cause_groups: true
  reserve_consumption_typed: true
impairment_and_accommodation_model:
  impairment_not_agency_or_personhood: true
  context_binding_required: true
  assisted_function_supported: true
  capability_handoff_only: true
harm_agent_model:
  registry_required: true
  families_extensible: true
  universal_damage_type_list: false
  source_local_supported: true
exposure_model:
  source_carrier_route_target_quantity_duration_explicit: true
  intended_actual_target_separate: true
  secondary_exposure_supported: true
contact_model:
  contact_not_transfer_or_injury: true
  candidate_and_determination: true
transfer_and_penetration_model:
  transfer_penetration_uptake_separate: true
  interface_binding_required: true
  loss_and_byproduct_manifest: true
propagation_model:
  paths_bounded_versioned: true
  network_and_cascade_supported: true
  hidden_path_protected: true
quantity_and_dose_model:
  AFQR07: true
  typed_units_precision_rounding_duration_route_target_basis: true
  damage_not_currency: true
  nonlinear_profile_supported: true
protection_model:
  stage_specific:
  - targeting
  - contact
  - transfer
  - penetration
  - uptake
  - propagation
  - effect
  - progression
  - recovery
  coverage_orientation_state_capacity_required: true
  can_be_damaged_depleted_or_failed: true
  registered_order: true
resistance_model:
  not_immunity_armor_or_recovery: true
  initial_and_progression_effects_separate: true
immunity_model:
  claim_and_determination_separate: true
  absolute_conditional_route_threshold_source_local_supported: true
  unqualified_boolean_prohibited: true
vulnerability_model:
  target_substrate_route_state_and_harm_family_scoped: true
  species_label_not_sufficient: true
injury_model:
  component_or_subsystem_targeted: true
  severity_profile_scoped: true
  localization_optional: true
  damage_amount_not_required: true
condition_model:
  states:
  - latent
  - active
  - suppressed
  - remitting
  - chronic
  - progressive
  - recurring
  - resolved
  origin_stage_progression_separate: true
progression_model:
  AFQR04_scheduler: true
  onset_progression_complication_recurrence_distinct: true
  historical_profile_retained: true
complication_model:
  new_or_worsened_injury_condition_impairment_or_intervention_effect: true
  not_implicit: true
symptom_and_sign_model:
  subjective_symptom_observable_sign_condition_truth_separate: true
  self_report_and_observation_provenance: true
pain_and_sensation_model:
  pain_subjective_private_experience: true
  nociception_injury_function_report_separate: true
  pain_without_injury_and_injury_without_pain: true
diagnosis_model:
  AFQR10_owner: true
  differential_candidates_and_misdiagnosis: true
  frozen_evidence_and_versioned_profile: true
  does_not_mutate_condition_truth: true
prognosis_model:
  bounded_forecast_candidate: true
  assumptions_uncertainty_and_profile_explicit: true
  model_only_prognosis_authoritative: false
consciousness_model:
  dimensions:
  - wakefulness
  - awareness
  - responsiveness
  - orientation
  - motor_control
  - communication_access
  universal_scalar: false
  source_local_profiles: true
incapacitation_model:
  purpose_and_task_scoped: true
  not_unconsciousness_paralysis_restraint_surrender_or_loss_of_consent: true
  AFQR11_capacity_handoff: true
death_model:
  profile_and_criterion_based: true
  scope_and_purpose_explicit: true
  biological_body_organ_process_source_local_and_legal_separate: true
  identity_continuity_not_decided: true
destruction_model:
  structure_process_data_and_source_local_profiles: true
  not_irrecoverability_or_identity_extinction: true
recoverability_model:
  pathway_evidence_resources_time_and_uncertainty: true
  recoverability_irrecoverability_separate_determinations: true
remains_model:
  body_component_material_data_wreck_salvage_supported: true
  identity_and_provenance_retained: true
stabilization_model:
  limits_deterioration_not_healing: true
  success_delay_failure_supported: true
treatment_model:
  identity_practitioner_authority_consent_eligibility_resources_tools_facilities_contraindications: true
  outcome_and_complication_candidates: true
healing_model:
  biological_or_source_local_profiles: true
  not_stabilization_recovery_regeneration_repair: true
recovery_model:
  milestones_schedule_interruptions_residuals_recurrence: true
  context_and_support_required: true
regeneration_model:
  substrate_topology_function_and_memory_continuity_separate: true
  does_not_guarantee_condition_removal: true
repair_model:
  technical_material_digital_magical_hybrid: true
  historical_configuration_basis: true
  degraded_temporary_substituted_unstable_failed_outcomes: true
maintenance_model:
  preventive_corrective_condition_based: true
  schedule_inspection_and_record_integrity: true
replacement_model:
  distinct_replacement_identity: true
  ownership_compatibility_procedure_and_continuity: true
  not_restoration: true
integration_model:
  integration_rejection_calibration_maintenance_dependency: true
  capability_vulnerability_changes_handoff: true
transformation_model:
  trigger_eligibility_stage_attempt_outcome_completion: true
  topology_injury_condition_function_continuity_manifest: true
  not_damage_healing_or_progression: true
body_transfer_model:
  original_and_destination_body_states_separate: true
  several_active_bodies_supported: true
  identity_continuity_AFQR08: true
fusion_and_fission_handoff:
  n_ary: true
  body_component_injury_condition_function_allocation_explicit: true
  identity_AFQR08: true
resurrection_handoff:
  body_state_and_process_AFQR16: true
  person_continuity_AFQR08: true
  legal_status_AFQR15: true
  social_recognition_AFQR13: true
vehicle_and_structure_model:
  platform_crew_cargo_AI_environment_separate: true
  load_paths_subsystems_emergency_modes_mission_capability: true
cascading_failure_model:
  bounded_recursion: true
  common_cause_and_dependency_profiles: true
  partial_and_arrested_propagation: true
distributed_body_model:
  nodes_contributions_shared_functions_thresholds_and_continuity: true
  no_privileged_node_required: true
  node_loss_not_whole_death: true
identity_handoff: AFQR-08
epistemic_handoff: AFQR-10
agency_and_consent_handoff: AFQR-11
behavioral_handoff: AFQR-12
social_handoff: AFQR-13
communication_handoff: AFQR-14
institutional_handoff: AFQR-15
governed_relation_handoff: AFQR-09
quantity_and_settlement_handoff: AFQR-07
action_gateway_handoff: AFQR-03
scheduler_handoff: AFQR-04
embodiment_simulation_tier_model:
  tiers:
  - descriptive_reference
  - aggregate_integrity
  - component_summary
  - active_condition
  - detailed_topology
  - full_embodiment_fixture
  promotion_not_retroactive: true
embodiment_materialization_policy:
  promotion_input_closure_required: true
  no_invented_history_anatomy_components_symptoms_diagnoses_or_treatments: true
  demotion_retention_manifest: true
hidden_embodiment_state_policy:
  private_receipts:
  - embodiment
  - injury
  - condition
  - diagnosis
  - death
  - transformation
  no_raw_private_ids_in_projection: true
visible_projection_policy:
  audience_minimized: true
  observable_signs_not_hidden_truth: true
  uncertainty_exact: true
model_context_policy:
  grounding_manifest_required: true
  permitted_claim_kinds_required: true
  evidence_bindings_required: true
  model_untrusted: true
model_output_validation:
  required: true
  forbidden_unsupported_claims:
  - injury
  - diagnosis
  - prognosis
  - vulnerability
  - impairment
  - unconsciousness
  - death
  - healing
  - repair
  - transformation continuity
  generated_text_candidate_only: true
side_channel_protection:
  threat_count: 25
  audience_tokens: true
  projection_specific_digests: true
  cross_packet_isolation: true
  cross_audience_linkability_test: true
historical_replay_policy:
  topology_substrate_protection_quantity_rounding_injury_condition_death_recovery_repair_transformation_profiles_retained: true
  current_profile_not_historical_rewrite: true
  missing_evaluator: unverifiable
bitemporal_policy:
  record_specific: true
  times:
  - event
  - contact
  - exposure
  - onset
  - progression
  - diagnosis
  - treatment
  - recovery
  - death_or_destruction
  - transformation
  - recorded
  - logical
  all_fields_not_applied_to_every_schema: true
owner_boundaries:
  federated: true
  coordinators_non_mutating: true
  owner_count: 25
AFQR_handoffs:
  AFQR-01: *id001
  AFQR-02: *id002
  AFQR-03: *id003
  AFQR-04: *id004
  AFQR-05: *id005
  AFQR-06: *id006
  AFQR-07: *id007
  AFQR-08: *id008
  AFQR-09: *id009
  AFQR-10: *id010
  AFQR-11: *id011
  AFQR-12: *id012
  AFQR-13: *id013
  AFQR-14: *id014
  AFQR-15: *id015
hybrid_ascendant_stress_case:
  subjects:
  - Ascendant identity
  - organic body
  - cybernetic limbs
  - symbiotic implant
  - external shield
  - adaptive armor
  - spiritual reserve
  - shapeshifting form
  - regeneration owner
  - treatment actor
  analysis_points:
  - Identity, current body, current form, installed components, controller, owner, maintainer, and source-local spiritual
    reserve remain distinct.
  - The hostile event is segmented into kinetic, thermal, electrical, psychic, armor-penetration, shield-overload, implant-malfunction,
    and delayed-complication exposure branches.
  - 'Protection order is registered per branch: targeting/contact, shield, armor coverage/orientation, penetration, substrate
    interaction, absorption/depletion, and byproducts.'
  - AFQR-07 manifests retain quantities, conversion, loss, stored energy, overload, heat/electrical byproducts, and no universal
    damage total.
  - Organic injury, cybernetic defect, shield depletion, armor damage, implant malfunction, spiritual reserve use, and psychic
    condition are separate owner candidates.
  - Function evaluation applies dependency, redundancy, reserve, assistance, and action context before capability changes.
  - Hidden internal damage and delayed complications remain private and scheduled without leaking through model wording or
    option counts.
  - Shapeshifting invokes a topology transition and injury/condition continuity manifest; it cannot erase all damage by default.
  - Field treatment and regeneration require consent/authority, eligibility, resources, profile versions, complications, and
    AFQR-01 atomic commits.
  - Replay preserves each branch, profile, quantity, rounding, topology version, protection state, and scheduled transition.
  lawful_result: A multi-owner staged resolution with several committed or unresolved effects; continued action through redundancy
    is lawful and no universal damage number is created.
familiar_derivative_stress_case:
  subjects:
  - original familiar identity
  - derivative identities
  - distinct derivative bodies
  - source-local ritual network
  - contract authority
  - treatment actor
  - public observers
  analysis_points:
  - Each derivative identity and body is distinct; the original and derivative network are not one body by label.
  - Shared functions use distributed provider and contribution profiles; node or component loss changes only qualified shared
    functions.
  - Harm propagation and voluntary redirection require registered interfaces, quantities, direction, consent, capacity, and
    byproduct manifests.
  - Component loss in one derivative does not create the same injury in all bodies.
  - A delayed condition is scheduled against the affected body and may remain hidden from others.
  - The contract may define maintenance obligations or access but does not create treatment consent, body ownership, or controller
    status automatically.
  - Refusal of treatment is an AFQR-11 consent/control handoff and may coexist with institutional emergency claims.
  - Body destruction uses a body-scoped destruction profile; derivative identity continuity routes to AFQR-08.
  - Public assumptions are AFQR-10/13 beliefs and social claims, not body truth.
  lawful_result: Distributed embodiment and source-local propagation remain explicit; destroyed body, continuing identity,
    treatment refusal, and public misinformation can coexist.
ship_cascade_stress_case:
  subjects:
  - ship structure
  - hull components
  - compartments
  - power subsystem
  - sensor subsystem
  - life support
  - ship AI process
  - crew bodies
  - cargo objects
  - internal environment
  - repair teams
  analysis_points:
  - The ship, crew, cargo, AI, and compartment environments are separate entities and owners with typed containment and occupancy
    relations.
  - Hull breach creates structural damage and an environmental interface; decompression is a secondary exposure to compartment
    occupants and cargo.
  - Power loss, fire, toxic release, sensor degradation, AI corruption, and isolation follow bounded failure and propagation
    graphs.
  - Common-cause and dependency groups prevent naive independent redundancy assumptions.
  - Emergency modes and redundant systems can preserve selected functions while mission capability is degraded or lost.
  - Crew injury uses body profiles; ship damage does not directly mutate crew HP.
  - Containment, shutdown, isolation, repair, and restoration consume typed resources and logical time.
  - Hidden internal defects use private structure receipts and qualified projections.
  - Cross-owner effects require an AFQR-01 atomic plan or ordered causal events where atomicity is not required.
  lawful_result: The ship may be mission-incapable yet recoverable while some compartments remain safe, crew states differ,
    cargo is separately damaged, and AI integrity is uncertain.
death_and_replacement_stress_case:
  subjects:
  - character identity claim
  - original body
  - viable organs
  - partial-memory backup
  - replacement body
  - clone body
  - resurrection process
  - allies
  - legal institution
  - property/office/relation owners
  analysis_points:
  - Biological death, structural destruction, organ viability, remains, recoverability, and resurrection eligibility are separate
    determinations.
  - The backup, clone, replacement body, original body, and possible resurrected body are distinct identity-bearing candidates.
  - AFQR-16 records body facts and restoration outcomes; AFQR-08 determines person/identity continuity for each purpose.
  - Memory continuity is an AFQR-10 and identity evidence input, not decisive by itself.
  - Legal death is an AFQR-15 determination and may be wrong or later reversed without rewriting biological history.
  - Social recognition and relationship treatment are AFQR-13 handoffs and may remain divided.
  - Offices, property, debts, obligations, licenses, and contracts use AFQR-09/15 continuity profiles rather than following
    the first active body.
  - Resurrection and backup restoration can both succeed physically while identity continuity remains contested.
  - Model portrayal must state only authorized body-state facts and qualified uncertainty.
  lawful_result: AFQR-16 can determine original-body death, viable remains, replacement-body activation, clone state, and
    restoration outcomes while leaving person continuity unresolved to AFQR-08.
conversion_pipeline_handoff:
  pressure_IR_types:
  - EmbodimentPressureIR
  - BodyPressureIR
  - StructurePressureIR
  - AnatomyPressureIR
  - ComponentPressureIR
  - TopologyPressureIR
  - FunctionPressureIR
  - DependencyPressureIR
  - MaterialPressureIR
  - TissuePressureIR
  - DamageFamilyPressureIR
  - ExposurePressureIR
  - ProtectionPressureIR
  - ResistancePressureIR
  - ImmunityPressureIR
  - VulnerabilityPressureIR
  - InjuryPressureIR
  - ConditionPressureIR
  - DiseasePressureIR
  - PoisonPressureIR
  - ImpairmentPressureIR
  - ConsciousnessPressureIR
  - DeathPressureIR
  - DestructionPressureIR
  - HealingPressureIR
  - RecoveryPressureIR
  - RepairPressureIR
  - ReplacementPressureIR
  - RegenerationPressureIR
  - ResurrectionPressureIR
  - TransformationPressureIR
  - VehicleDamagePressureIR
  - DistributedBodyPressureIR
  - SourceLocalIntegrityOntologyPressureIR
  campaign_mutation_prohibited: true
  lawful_outcomes:
  - direct_astra_mapping
  - normalized_astra_mapping
  - source_local_retained_construct
  - quarantined_construct
  - escalated_doctrine_problem
model_authority_policy:
  damage_resolver: false
  injury_generator: false
  diagnostic_engine: false
  impairment_assessor: false
  death_authority: false
  healer: false
  repair_engine: false
  transformation_authority: false
  grounded_renderer_and_candidate_generator: true
current_runtime_disposition:
  exists:
  - backend authority doctrine
  - future injury/condition/damage/recovery ownership statement
  - typed/versioned state and event doctrine
  - narrow actor/target/object/lever refs
  - one visible condition label
  - object/lever event and replay envelopes
  fixture_only:
  - actor/target refs
  - visible condition string
  - hazard clock
  - object/lever legality
  - preview/commit/audit receipts
  conversion_only:
  - creature health and condition descriptors
  - damage/resistance/exposure references
  - vehicle/platform and hazard schemas
  - implant/prosthetic/repair pressure
  - donor hit points and damage systems
  narrative_only:
  - combat prose
  - injury descriptions
  - healing descriptions
  - dead/broken labels
  - medical or technical narration
  absent:
  - embodiment registry
  - topology/component service
  - function/dependency service
  - exposure/transfer engine
  - protection and interaction registry
  - injury/condition owner
  - diagnosis/consciousness/death services
  - treatment/recovery/repair/replacement/transformation services
  - embodiment model validator
required_artifacts:
  immediate:
  - AFQR-16 ADR
  - decision registry
  - terminology
  - repository audit
  - research synthesis
  - contract catalog
  - operation grammar
  - conversion pressure IR
  - threat model
  - DMG-001–200 evaluation
  - 50-case dry run
  - stress fixtures
  - acceptance matrix
  - manifests/checksums
  before_authoritative_embodiment_state:
  - embodiment/structure/topology/component/substrate/function registries
  - identity/control/occupancy bindings
  before_harm_protection:
  - harm/exposure/route/quantity/protection/interaction registries
  - AFQR-05/07 integration
  before_injury_condition:
  - effect/injury/condition/function owners
  - scheduler and invariant gates
  before_death:
  - death/destruction/recoverability/remains profile service
  - AFQR-08/10/15 handoffs
  before_treatment_recovery:
  - consent/authority/eligibility/resources/procedure/recovery schedules
  before_repair_replacement:
  - historical configuration, repairability, parts/integration/ownership/maintenance services
  before_transformation:
  - staged transformation and continuity manifests
  before_model_narration:
  - grounding, claim registry, evidence binding, validator, isolation
  before_mass_conversion:
  - pressure IR fixtures and donor-family certification
required_prototype:
  name: AFQR-16 Embodiment, Harm, Injury, Condition, Death, Recovery, and Repair Dry Run
  case_count: 50
  mutating: false
required_fixtures:
- AFQR16-DRY-001
- AFQR16-DRY-002
- AFQR16-DRY-003
- AFQR16-DRY-004
- AFQR16-DRY-005
- AFQR16-DRY-006
- AFQR16-DRY-007
- AFQR16-DRY-008
- AFQR16-DRY-009
- AFQR16-DRY-010
- AFQR16-DRY-011
- AFQR16-DRY-012
- AFQR16-DRY-013
- AFQR16-DRY-014
- AFQR16-DRY-015
- AFQR16-DRY-016
- AFQR16-DRY-017
- AFQR16-DRY-018
- AFQR16-DRY-019
- AFQR16-DRY-020
- AFQR16-DRY-021
- AFQR16-DRY-022
- AFQR16-DRY-023
- AFQR16-DRY-024
- AFQR16-DRY-025
- AFQR16-DRY-026
- AFQR16-DRY-027
- AFQR16-DRY-028
- AFQR16-DRY-029
- AFQR16-DRY-030
- AFQR16-DRY-031
- AFQR16-DRY-032
- AFQR16-DRY-033
- AFQR16-DRY-034
- AFQR16-DRY-035
- AFQR16-DRY-036
- AFQR16-DRY-037
- AFQR16-DRY-038
- AFQR16-DRY-039
- AFQR16-DRY-040
- AFQR16-DRY-041
- AFQR16-DRY-042
- AFQR16-DRY-043
- AFQR16-DRY-044
- AFQR16-DRY-045
- AFQR16-DRY-046
- AFQR16-DRY-047
- AFQR16-DRY-048
- AFQR16-DRY-049
- AFQR16-DRY-050
blocked_work:
- authoritative contact/transfer/effect resolution
- damage/injury/condition mutation
- functional capability mutation
- consciousness/incapacitation mutation
- death/destruction/recoverability commitment
- treatment/healing/recovery execution
- repair/replacement/integration execution
- transformation/resurrection execution
- model-authored bodily conclusions
work_unlocked:
- schema and registry design
- non-mutating harm and embodiment fixtures
- component/function/dependency certification
- quantity and protection manifests
- diagnosis/death/recovery candidate records
- hidden-state validators
- bounded bodily narration after validator implementation
rejected_alternatives:
- universal hit-point pool
- universal wound ladder
- humanoid hit-location anatomy
- component graph without aggregate/profile layers
- tags as sole objective integrity state
- full physics/physiology simulation as universal law
- unbounded source-local adapters
residual_risks:
- final combat sequencing and attack formulas
- armor and penetration formulas
- environmental hazard engine
- population epidemiology
- psychological trauma doctrine
- universal death metaphysics intentionally unresolved
- resurrection identity
- medical ethics
- disability/accessibility content review
- treatment law
- maintenance economy
- large-scale structural simulation
- source-local conceptual harm
- distributed runtime performance
- training-model behavior
RT_002G_status: 'unchanged narrow gate: may build an object/lever context packet only after AFQR-01–16 noninterference amendments;
  gains no harm, injury, condition, death, recovery, medical, repair, or transformation semantics'
next_foundational_question:
  question_id: AFQR-17
  title: Environment, Exposure, Hazards, Atmosphere, Weather, Terrain, Contamination, and Ecological Processes
  central_question: How should Astra represent, own, evolve, expose, propagate, mitigate, forecast, and replay environmental
    media, terrain, atmosphere, weather, pressure, temperature, radiation, contamination, hazards, ecological processes, and
    interactions with bodies, structures, travel, settlements, and planetary or source-local systems without collapsing environment
    into encounter damage or one universal physics model?
  priority_reason: AFQR-16 now owns target-side embodiment and integrity. The highest-priority missing source-side owner for
    exposure, travel, survival, hazards, contamination, structures, and ecological consequences is environmental state; combat
    sequencing can remain a later composition of AFQR-02–04, AFQR-16, and spatial/environmental doctrine.
exact_next_roadmap_action: Ratify and register AFQR-16; execute the 50-case non-mutating embodiment dry run and an RT-002A–RT-002F
  harm/model noninterference audit; keep RT-002G non-harmful and non-medical; then open AFQR-17 as a read-only foundational
  investigation.
```
