# Astra AFQR-11 Ratification Pack v1.0

Selected architecture: **Registered Purpose-Scoped Agency and Personhood Architecture with Orthogonal Consent-Control Planes, Bitemporal Action-Origin Graphs, and Profiled Responsibility** (`RPSAP-OCC-BAOG-PR`)

This pack is read-only architecture and evaluation material. It contains no repository modification, runtime implementation, executable domination/possession logic, model calls, campaign personhood assignment, consent creation, or responsibility punishment.

## Normative artifacts

- `master/Astra_AFQR_11_Master_Ratification_v1_0.md`
- `adrs/AFQR-11_Agency_Personhood_Consent_Control_Responsibility.md`
- `registries/afqr_11_decision_registry.yaml`
- `contracts/afqr_11_typed_contract_catalog.yaml`
- `operations/afqr_11_operation_grammar.yaml`
- `evaluation/afqr_11_adversarial_scenarios_A_GR.yaml`
- `fixtures/afqr_11_non_mutating_dry_run.yaml`
- three central stress-case graphs

Repository commit inspected: `928bb79ce00a2de749d127dcc5cb8299de788a15`.
