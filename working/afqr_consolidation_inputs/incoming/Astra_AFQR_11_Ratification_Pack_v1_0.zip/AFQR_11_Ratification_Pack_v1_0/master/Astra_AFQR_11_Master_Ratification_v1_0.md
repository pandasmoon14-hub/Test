# Astra Foundational Question Resolution 11

## Agency, Personhood, Consent, Control, Responsibility, Decision Authority, Delegation, Coercion, and Autonomous Action

Status: ratification candidate  
Version: 1.0  
Repository baseline inspected: `928bb79ce00a2de749d127dcc5cb8299de788a15`  
Selected architecture: **Registered Purpose-Scoped Agency and Personhood Architecture with Orthogonal Consent-Control Planes, Bitemporal Action-Origin Graphs, and Profiled Responsibility**  
Abbreviation: **RPSAP-OCC-BAOG-PR**

This master document is the integrated human-readable authority candidate. The accompanying YAML, CSV, fixture, operation, and evaluation files are normative machine-readable sidecars. They are part of the decision and prevent this document from becoming a megafile.

## Part I — Executive decision

### Selected architecture

**Registered Purpose-Scoped Agency and Personhood Architecture with Orthogonal Consent-Control Planes, Bitemporal Action-Origin Graphs, and Profiled Responsibility** (`RPSAP-OCC-BAOG-PR`)

### Central law

> No entity, actor, owner, creator, controller, command issuer, executor, beneficiary, or state owner is presumed to possess agency, personhood status, decision authority, valid consent, action authorship, or responsibility. Each is a separate purpose-scoped, versioned determination grounded in typed identity, epistemic, relation, capacity, consent, control, command, and causal records. Only owner-prepared AFQR-01 transitions may mutate runtime state, and later attribution or responsibility never rewrites historical action origin.

### Confidence

**High.** The architecture resolves the universal ownership, profile, time, identity, epistemic, control, consent, attribution, and replay questions while deliberately leaving final moral, legal, cognitive, emotional, and source-local rules to registered downstream profiles.

### What it is

A federated architecture that combines:

- purpose-scoped agency profiles;
- purpose/jurisdiction/source-scoped personhood-status profiles;
- decision-, time-, support-, and communication-specific capacity;
- orthogonal consent-validity axes;
- governed authority, representation, command, control, influence, coercion, compulsion, domination, and possession relations;
- bitemporal action-origin and causal-contribution graphs;
- registered collective decision procedures;
- profile-qualified attribution and responsibility;
- audience-scoped private receipts and visible/model projections;
- deterministic historical replay.

### What it is not

It is not a single actor/controller field, a universal `is_person` flag, a Boolean consent field, an owner hierarchy, a BDI cognition engine, a moral theory, a legal code, or a model-authored NPC decision system.

### Research disposition

No second broad research pass is required before ratification. Narrow implementation research remains appropriate when individual legal, medical, control-system, collective-procedure, or source-local profiles are drafted.

## Part II — Repository-grounded diagnosis

### Verified baseline

The inspected `main` head is `928bb79ce00a2de749d127dcc5cb8299de788a15`, the merge of PR #325 / RT-002F. No later commit was found during this investigation.

### Implemented facts

The repository is still in a foundation-building stage. The backend authority boundary, state-owner reference skeleton, visibility tiers, redaction policies, narrow RT-002A actor/NPC references, narrow RT-002C command declaration/legality reading, narrow RT-002E event/delta envelope, and narrow RT-002F in-memory audit receipt exist.

### What those structures do not establish

They do not establish autonomous action, personhood, capacity, consent, refusal, command interpretation, delegation, coercion, domination, possession, collective decisions, institutional action, action authorship, causal contribution, or responsibility. `actor_identity_owner` is a backend owner family, not an in-world authority. `actor` and `npc_target` are fixture entity kinds, not generalized agency subjects. `permitted_for_preview` authorizes only a narrow preview transition, not actor consent or command execution.

### Conversion-only surfaces

Creature/NPC, companion/summon, faction/institution, source-local control/loyalty/relationship fields, and `runtime_candidate_action` are conversion-stage evidence and routing structures. They cannot create runtime agency or personhood.

### Fifty explicit repository determinations

The complete question-by-question audit is normative in `registries/repository_audit_50_questions.yaml`. Its result is:

| # | Determination |
|---|---|
| 1 | A conversion-stage player/creature/NPC construct or the narrow RT-002A actor reference; no generalized runtime agency predicate exists. |
| 2 | Yes as an architectural requirement; current implementation has identity references only and no agency determination. |
| 3 | Conversion doctrine and Batch C schemas distinguish several record families; runtime fixtures distinguish only actor and npc_target. |
| 4 | No. |
| 5 | Only a narrow RT-002C command declaration for interact_with_object_lever; no general issuance model. |
| 6 | No. |
| 7 | No. |
| 8 | No. |
| 9 | No. |
| 10 | No. |
| 11 | No generalized runtime structure. |
| 12 | No. |
| 13 | No; inventory possession terms are unrelated to mind/body control. |
| 14 | No executable agency model. |
| 15 | Doctrine implies the separation, but no generalized executable control or in-world ownership architecture is present. |
| 16 | Yes. State-owner families are backend ownership/routing labels and must not be read as in-world authority. |
| 17 | No. |
| 18 | No. |
| 19 | Accepted identity/relation doctrine can express the distinction, but no agency implementation exists. |
| 20 | Only conversion-stage faction/institution records, not authoritative runtime action. |
| 21 | No. |
| 22 | No. |
| 23 | No. |
| 24 | No profile or determination contract exists. |
| 25 | Not in current runtime. AFQR-11 requires separate graphs and profile-scoped determinations. |
| 26 | Not by a generalized runtime contract. |
| 27 | Not currently. |
| 28 | AFQR-10 can represent unawareness epistemically, but no action-origin integration exists. |
| 29 | Accepted conceptually through AFQR-10, but not executable in the current command fixture. |
| 30 | No. |
| 31 | Conversion schemas may preserve pressure, but no runtime autonomy transition exists. |
| 32 | No runtime transition or determination exists. |
| 33 | No current runtime status model. |
| 34 | AFQR-08 requires a distinct entity reference by default, but agency state is absent. |
| 35 | Identity handoffs exist doctrinally; decision-authority allocation is absent. |
| 36 | Identity continuity can be evaluated, but authority restoration is not implemented. |
| 37 | No; AFQR-11 prohibits treating role consent as personal consent without a profile. |
| 38 | AFQR-10 distinguishes institutional notice and personal awareness, but agency consequences are not implemented. |
| 39 | Required by AFQR-11; not currently executable. |
| 40 | Required by AFQR-11; not currently executable. |
| 41 | No current consent model. |
| 42 | No current consent model. |
| 43 | No current consent model. |
| 44 | AFQR-10 can preserve deception evidence, but no consent-validity integration exists. |
| 45 | No capacity/validity integration exists. |
| 46 | Typed claim arbitration can host disputes, but no consent claim schema exists. |
| 47 | Not currently represented; AFQR-11 requires an explicit unresolved disposition. |
| 48 | Creature/NPC, companion/summon, faction/institution roles, source-local loyalty/control/relationship fields, and runtime_candidate_action pressure. |
| 49 | actor, npc_target, actor_identity_owner, projection requirements, command declaration, safe references, and object/lever legality status. |
| 50 | All generalized agency, personhood, capacity, consent, authority, command interpretation/refusal, control, coercion, possession, collective action, action-origin, responsibility, and model-facing dialogue behavior. |

### Implementation blockers

Generalized agency mutation remains blocked until profile registries, typed contracts, non-mutating evaluators, owner routes, projection schemas, replay archives, and acceptance fixtures exist. Generalized dialogue and NPC action selection remain further blocked by AFQR-12.

## Part III — External research synthesis

The research does not support one universal agency, personhood, consent, autonomy, or responsibility test. It supports decomposition and profile qualification.

| Family | Mechanism/finding | Lesson | Limitation | Disposition |
|---|---|---|---|---|
| philosophy_of_action | Agency theories disagree over intention, reasons, control, and reflective endorsement. | Use purpose-scoped agency profiles and avoid one universal philosophical test. | Conceptual analysis does not supply runtime algorithms. | adapt |
| sense_of_agency | Sense of agency arises from predictive and retrospective signals and can dissociate from actual control. | Represent subjective agency evidence separately from control and authorship. | Clinical/cognitive findings are not universal adjudication rules. | contain |
| informed_consent | Research consent requires legally effective, informed, prospective agreement with disclosure and opportunity to decide. | Separate request, disclosure, comprehension evidence, expression, authority, and validity. | Jurisdiction- and domain-specific. | adapt |
| bioethics_consent | Consent should be prior, free, informed, and withdrawable, with protection for those lacking capacity. | Model voluntariness, information, withdrawal, and protected-subject status as orthogonal axes. | High-level ethical instrument, not a game rulebook. | adapt |
| supported_decision | Capacity is decision- and time-specific; support and accessible communication should precede incapacity conclusions. | Capacity must be purpose/time/support/communication-specific and preserve refusal and preferences. | Based on UK practice and law. | adapt |
| supported_decision_global | Supported decision-making emphasizes will, preferences, communication support, and alternatives to substitute control. | Create SupportedDecisionRecord and separate support from substituted decision. | Normative human-rights framework; source-local law may differ. | adapt |
| access_control | Permissions are assigned through roles with constraints and separation-of-duty structures. | Separate identity, role, mandate, permission, scope, and revocation. | Computer authorization does not determine consent or moral authority. | adapt |
| delegation | Delegated authorization uses bounded grants, client instances, continuation, and proof of possession. | Use explicit delegation records, attenuation, expiry, revocation, and audience-bound tokens. | Web authorization only; no in-world personhood or responsibility model. | adapt |
| ai_governance | AI risk management assigns lifecycle governance, mapping, measurement, and management functions. | Track system designers, deployers, operators, overseers, and context-specific accountability separately. | Governance framework, not a theory of AI personhood. | adapt |
| autonomous_weapons | Autonomous and semi-autonomous weapon systems require appropriate human judgment, testing, and safeguards. | Represent supervisory control, human intervention, interlocks, and failure modes. | Military and weapon-specific. | contain |
| mission_command | Command intent specifies purpose and desired end state while subordinates may choose methods within constraints. | Separate objective origin from method origin and delegated discretion. | Military doctrine cannot become universal social authority. | contain |
| shared_control | Human and automation can trade or share control according to task dimensions and operating state. | Model control by dimension with explicit handoff, fallback, and interlock states. | Engineering domain; social coercion and consent require separate profiles. | adapt |
| group_agency | Group attitudes/actions may be generated by decision procedures not reducible to a simple aggregate of member attitudes. | Represent registered collective procedures and institutional continuity without inventing one mind. | Formal social-choice assumptions may not fit swarms or mystical collectives. | adapt |
| institutional_responsibility | Attribution, direction/control, aid/assistance, coercion, and institutional responsibility are distinct legal questions. | Separate causal contribution, attribution, command/control evidence, and responsibility profiles. | International law applies to a narrow legal domain. | adapt |
| ttrpg_control | Games use materially different command, minion, charm, and possession semantics. | Treat each donor mechanism as source-local control/command pressure unless normalized by Astra doctrine. | Rules are donor-specific and often compress consent/personhood for playability. | contain |

The full source URLs and repository/source manifest are in `sources/external_research_synthesis.yaml` and `sources/source_manifest.yaml`.

## Part IV — Canonical terminology

At an authoritative boundary, every term below is qualified by profile, scope, subject, and time. The full registry contains 118 definitions.

| Term | Astra-native meaning |
|---|---|
| agent | An entity or aggregate satisfying a named agency profile for a particular purpose and time. |
| agency | A profile-scoped capacity or status concerning action origination, selection, execution, communication, or representation; never a universal scalar. |
| action | A registered transition attempt or committed event with an action-origin basis; not every event is an action. |
| intentional action | An action linked to a committed objective or method selection under a named authorship profile. |
| voluntary action | An action whose voluntariness is established under a registered profile; not merely unopposed behavior. |
| autonomous action | An action selected within an entity’s registered self-governance bounds without an external controller selecting the relevant dimensions. |
| constrained action | An action selected from a restricted option set while some decision dimensions remain with the subject. |
| compelled action | An action materially produced by a registered compulsion or coercive condition; degree and affected dimensions remain explicit. |
| automatic action | A rule-, mechanism-, or learned-policy-triggered execution that may lack reflective objective selection. |
| reflexive action | A rapid response governed by a reflex profile rather than deliberative selection. |
| delegated action | An action performed within authority granted by a principal to an agent. |
| represented action | An action attributed to a represented subject under a valid representation profile. |
| collective action | An action originating from a registered multi-subject decision procedure. |
| institutional action | An action attributed to an institution through an authorized procedure, representative, office, or later ratification profile. |
| proxy action | An action executed through a proxy while source, controller, and autonomous decision subject remain separately recorded. |
| derivative action | An action performed by an entity or manifestation derived from another source; derivation does not settle authorship. |
| action authorship | A profile-qualified determination of who selected the relevant objective or method. |
| action selection | Selection among registered alternatives or action dimensions. |
| execution | The physical, computational, magical, or procedural production of an action. |
| inhibition | A control contribution that prevents, delays, terminates, or narrows an action. |
| refusal | A committed non-acceptance of a request or command under a registered refusal policy. |
| entity | A typed identity-bearing runtime referent; entity status alone proves no agency or personhood. |
| actor | An entity referenced as a possible participant in an action; actor identity does not establish agency, control, or authorship. |
| person | A subject satisfying a named personhood-status profile for a purpose, jurisdiction, or source scope. |
| legal person | A status recognized by a named legal/institutional profile. |
| moral patient | A status under which a subject’s interests or harms count under a named moral-status profile. |
| moral agent | A status under which a subject can bear moral responsibility under a named profile. |
| sapient | A source- or doctrine-scoped cognitive classification; not synonymous with person. |
| sentient | A source- or doctrine-scoped capacity for experience; not synonymous with legal or moral agency. |
| conscious | A profile-scoped state or capacity; AFQR-11 does not define consciousness metaphysics. |
| self-aware | A profile-scoped ability to represent oneself; not a universal personhood test. |
| autonomous subject | A subject with registered self-governance over specified decision dimensions. |
| protected subject | A subject receiving protections under a named profile regardless of full agency. |
| ward | A subject in a registered guardianship relation; the term grants no universal incapacity inference. |
| dependent | A subject materially reliant on another for specified resources or support; dependency does not erase agency. |
| disputed personhood | A status with unresolved or conflicting personhood claims. |
| provisional personhood | A temporary protective or status determination pending fuller review. |
| source-local personhood | A personhood status valid only within a declared source-local legal, spiritual, or metaphysical domain. |
| decision subject | The subject whose choice is evaluated for a specified decision dimension. |
| principal | A subject granting authority or specifying an objective to an agent. |
| delegate | A subject receiving bounded decision authority. |
| representative | A subject authorized to act or communicate for another subject or institution. |
| proxy | An entity or interface acting as an intermediary; proxy status does not determine autonomy. |
| guardian | A subject holding decision authority under a named guardianship profile. |
| custodian | A subject holding custody or care responsibilities; custody is not ownership or universal authority. |
| controller | A subject or mechanism exercising practical control over specified action dimensions. |
| commander | A command issuer recognized under a named command-authority profile. |
| operator | A subject interacting with or supervising a system through registered interfaces. |
| officeholder | An identity occupying an office; office continuity and occupant identity remain separate. |
| institution | An epistemic and agency aggregate governed by registered procedures and continuity rules. |
| authority | A purpose-, scope-, time-, and jurisdiction-qualified entitlement to decide, command, represent, consent, or override. |
| jurisdiction | The domain in which a policy or authority may operate. |
| mandate | The registered content, scope, conditions, and limits of granted authority. |
| apparent authority | A third-party-facing authority appearance that may differ from actual authority. |
| emergency authority | Time- and condition-limited authority activated under a registered emergency profile. |
| override authority | Authority to supersede another command or control input under explicit policy. |
| consent | A profile-qualified validity determination based on a request, expression, interpretation, capacity, disclosure, comprehension, voluntariness, specificity, currency, authenticity, and authority. |
| assent | An affirmative expression that may matter even when a required consent-capacity or legal-capacity profile is not fully satisfied. |
| withdrawal | A transition ending or narrowing prior consent from a defined effective point. |
| consent request | A typed proposal asking a subject or authorized substitute to approve a specified action or scope. |
| consent expression | A recorded communication or conduct offered as evidence of agreement, refusal, or uncertainty. |
| informed consent | Consent satisfying a named disclosure, accessibility, comprehension, and voluntariness profile. |
| voluntary consent | Consent whose voluntariness is established under a registered profile. |
| scoped consent | Consent limited to specified acts, subjects, purposes, methods, targets, duration, or data. |
| conditional consent | Consent valid only while explicit conditions remain satisfied. |
| ongoing consent | Consent requiring continuing validity checks or renewable confirmation. |
| substituted decision | A decision made by an authorized substitute under a registered standard; not personal consent by the subject. |
| capacity | A decision-, time-, purpose-, support-, and communication-specific determination. |
| competence | A legal or institutional status under a named jurisdictional profile; not interchangeable with runtime capacity. |
| comprehension | Evidence that relevant disclosed content was understood to the required profile. |
| disclosure | Delivery of specified information to an audience; disclosure does not prove comprehension. |
| voluntariness | Degree or status of freedom from disqualifying coercion, domination, compulsion, or undue influence under a profile. |
| coercion | A profile-qualified constraint imposed through threats or severe pressure affecting voluntariness or action selection. |
| undue influence | Influence that invalidates or degrades a decision under a named profile without necessarily constituting force. |
| deception | A typed manipulation of information, evidence, interpretation, or presentation; truth and belief remain separate. |
| incapacity | Failure to satisfy a required capacity profile for a specific decision and time. |
| impairment | A condition that may affect one or more capacity or control factors; impairment does not automatically establish incapacity. |
| persuasion | Reason- or communication-based influence that leaves relevant decision dimensions with the subject under the selected profile. |
| suggestion | An influence that biases an option, objective, or interpretation without necessarily displacing selection. |
| influence | Any registered contribution affecting preferences, beliefs, options, or action dimensions; not synonymous with control. |
| manipulation | Influence exploiting information, psychology, interfaces, or constraints under a named profile. |
| pressure | A constraint or incentive affecting choice without by itself establishing coercion. |
| threat | A communicated or inferred prospect of harm or loss offered as a condition of compliance. |
| blackmail | A threat involving disclosure or exploitation of information under a named coercion profile. |
| compulsion | An effect that forces or heavily constrains one or more action dimensions according to registered semantics. |
| domination | External displacement of objective and/or method selection across registered dimensions. |
| possession | A relation separating body identity, host mind, controlling subject, observer, decision subject, and motor executor. |
| override | A control or authority input superseding another input under a registered priority policy. |
| motor control | Control over bodily or platform execution independent of objective authorship. |
| objective control | Control over goal or outcome selection. |
| method control | Control over how an objective is pursued. |
| veto | Authority or practical control to block a proposed action. |
| remote control | Control transmitted through a registered nonlocal interface. |
| shared control | Concurrent allocation of different or overlapping control dimensions among subjects or systems. |
| supervisory control | High-level oversight with bounded autonomous execution and intervention rights. |
| control handoff | A versioned transition reallocating specified control dimensions. |
| cause | A relation asserted under a named causal profile. |
| causal contribution | A typed contribution to an event or outcome; it does not itself establish responsibility. |
| necessary cause | A contribution classified as required under a specified counterfactual model. |
| sufficient cause | A contribution classified as sufficient under a specified causal model. |
| proximate cause | A profile-qualified causal relation used by a selected legal or operational doctrine. |
| intervening cause | A later contribution capable of altering an attribution under a named profile. |
| authorization | A grant making an act permitted or representative under a registered authority profile. |
| authorship | Selection or endorsement of relevant action dimensions under an authorship profile. |
| participation | Direct involvement in planning, execution, control, or support. |
| assistance | A contribution enabling another subject’s action. |
| omission | A failure to act where a named profile recognizes a relevant duty or opportunity. |
| foreseeability | A profile-scoped epistemic assessment of whether an outcome was reasonably anticipatable. |
| accountability | A requirement to explain, answer for, review, or remediate under a registered profile. |
| responsibility | A determination under an explicitly named causal, operational, command, institutional, contractual, legal, moral, karmic, or narrative profile. |
| liability | A legal or source-local consequence status under a named jurisdictional profile. |
| blame | A moral or social assessment; prohibited as an unqualified model-generated runtime conclusion. |
| credit | A positive attribution under a named profile. |
| command responsibility | A profile addressing responsibility connected to command authority, knowledge, capacity, and failure to prevent or respond. |
| collective responsibility | A determination concerning a registered collective and its decision procedure. |
| institutional responsibility | A determination attributed to an institution under a named profile. |
| diminished responsibility | A profile outcome reducing but not necessarily eliminating responsibility based on specified factors. |
| exculpation | A profile outcome removing a responsibility claim without rewriting causation. |

### Prohibited unqualified runtime terms

- agent
- actor
- person
- owner
- controller
- master
- commander
- authority
- consent
- autonomous
- responsible
- liable
- voluntary
- knows
- competent
- incapable
- institution acted
- the AI decided
- the familiar obeyed

These terms may appear in dialogue or source-local prose, but runtime checks and records must name the profile or relation that gives them meaning.

## Part V — Agency and personhood architecture

### Agency profiles

Agency is not an entity type or scalar. `AgencyProfile` defines a purpose, eligible subject kinds, required evidence, evaluator, status values, and version. Core profile families are motor execution, action selection, goal formation, communication, contract, consent, legal, institutional, collective, and source-local metaphysical agency.

A subject may satisfy motor execution agency while lacking action-selection agency, satisfy communicative agency while lacking contractual agency, or satisfy collective agency only as part of a registered aggregate procedure. `AgencyDetermination` may return satisfied, not satisfied, partial, impaired, suspended, disputed, unresolved, or inapplicable.

### Personhood-status profiles

There is no universal `is_person`. Biological, legal, moral-patient, moral-agent, social, spiritual, institutional, artificial, and source-local personhood are distinct status families. Each determination names its determining authority/profile, purpose, jurisdiction or source scope, effective time, evidence, uncertainty, and dispute status.

`ProtectedSubjectStatus` is independent. An entity may receive anti-harm, review, advocacy, or minimum-consent safeguards even while personhood or agency remains unresolved. This prevents ontology gaps from becoming permission to treat a subject as property or a tool.

### Anti-collapse laws

- Identity continuity does not establish agency continuity.
- Agency does not establish personhood.
- Personhood does not grant every authority or responsibility.
- Sentience, sapience, intelligence, consciousness, self-awareness, soul, biology, legal registration, and social recognition are profile evidence, not universal switches.
- Source-local personhood can coexist with a different core protective status without becoming Astra-wide metaphysics.

## Part VI — Capacity and consent architecture

### Decision capacity

`DecisionCapacityDetermination` is specific to the decision, time, purpose, communication interface, support applied, relevant memory access, and influence conditions. Required factors may include understanding, appreciation, communication of choice, relevant memory access, decision stability, and source-local requirements. General intelligence, species, disability labels, compliance, or unconventional communication cannot substitute for the determination.

Support is evaluated before incapacity. `SupportedDecisionRecord` preserves communication aids, interpretation support, accessible presentation, trusted assistance, and conflict-of-interest controls. `SubstitutedDecisionRecord` is a separate authority route; it never becomes personal consent by the subject.

### Consent

Consent is a record chain:

`ConsentRequest → ConsentExpression → ConsentInterpretationReceipt → DecisionCapacityDetermination → ConsentValidityDetermination → governed relation update → withdrawal/expiry`

The validity axes are orthogonal:

```yaml
capacity_status:
disclosure_status:
comprehension_status:
voluntariness_status:
specificity_status:
currency_status:
authenticity_status:
authority_status:
determination_status:
```

A request can be disclosed but not comprehended; understood but not voluntary; authentic but expired; voluntary but outside scope; or issued by a guardian without being the subject’s own consent. Silence and inability to resist are not consent. Hidden terms fail disclosure by default. Consent is not portable across contexts without an explicit scope-equivalence certificate.

Withdrawal is append-only and has an effective point. It blocks future or reversible steps within scope; it does not rewrite completed irreversible history.

## Part VII — Authority, command, and representation

Authority is a governed relation, not a capability, credential, title, control route, ownership claim, or state-owner label. `DecisionAuthorityRecord` and `RepresentationAuthorityRecord` name holder, represented subject, decision family, mandate, jurisdiction, scope, conditions, lifecycle status, expiry/revocation policy, and checkpoint.

Actual authority and apparent authority are separate. Third-party reliance may be recorded without creating actual authority. Later institutional ratification is a new transition and never rewrites the authority basis that existed when the action occurred.

A command has issuer, recipients, authority claim, content expression, objective, constraints, timing, priority profile, refusal policy, override policy, and communication status. Command interpretation is a separate receipt. The recipient may accept, refuse, partially accept, request clarification, reinterpret under a registered doctrine, defer, fail to understand, be unable to comply, comply under coercion, or exercise delegated method selection.

Technical retry cannot create authority, acceptance, or consent. Authority is rechecked at registered checkpoints. Notice of revocation and authoritative revocation are distinct.

## Part VIII — Control, influence, coercion, and possession

Control is allocated by dimension, not compressed into a master/controller field or a universal strength number.

Core dimensions are goal selection, target selection, method selection, timing, initiation, continuation, termination, motor execution, resource commitment, communication, memory access, perception access, inhibition, and override. Each may be self-directed, externally controlled, shared, contested, alternating, latent, failed, hidden, or unknown.

Influence, persuasion, suggestion, social pressure, dependency pressure, threat, blackmail, deception, addiction, corruption, compulsion, geas, charm, domination, possession, neural override, and direct motor control are separate effect/relation families. Profiles state which dimensions they affect and whether they alter information, available options, sanctions for refusal, objective selection, method selection, or motor execution.

Possession requires separate references for body, host mind, possessor, decision subject, motor executor, observer, memory encoder, and apparent public identity. Consent to possession is scoped and never implies consent to every act. Host resistance is an inhibitor contribution. Mid-action control changes split the action-origin basis at an AFQR-04 logical microstep.

## Part IX — Action origin and causal contribution

Every meaningful action may produce an `ActionOriginRecord` with:

```text
objective_origin
method_origin
decision_subject
command_issuer
command_interpreter
executor
controller
principal
represented_subject
beneficiary
causal_contributors
inhibitors
override_sources
```

Fields are omitted only when inapplicable, never silently merged. A player may propose an objective while a character refuses. A principal may select an objective while a delegate selects the method. A possessor may select objective and method while a body executes. An automatic system may execute without satisfying reflective agency.

`CausalContributionGraph` records planners, authorizers, controllers, executors, assistants, suppliers, omissions, conditions, intervening events, and outcomes. Graph reachability does not create responsibility. Counterfactual, proximate, necessary, sufficient, or intervening-cause labels require named causal profiles.

## Part X — Responsibility and attribution

Responsibility is never unqualified. Each `ResponsibilityDetermination` names a profile such as causal attribution, action authorship, operational accountability, command responsibility, institutional attribution, contractual responsibility, legal liability, moral responsibility, source-local karmic responsibility, or narrative credit.

Inputs may include causal contribution, objective/method authorship, authority, practical control, knowledge, foreseeability, capacity, coercion, duty, opportunity, benefit, and intervening causes. No factor is universally dispositive:

- causation does not imply blame;
- authorization does not imply execution;
- benefit does not imply authorship;
- creation does not imply responsibility for every autonomous later action;
- ownership does not imply control;
- technical control does not imply authority;
- coerced execution remains causal but may alter authorship or responsibility;
- institution and member responsibility may differ.

Competing profile results may coexist. `unresolved`, `incomparable`, and `unverifiable` are lawful outcomes. Later attribution never rewrites the committed event or original action-origin graph.

## Part XI — Collective and institutional agency

Collectives act through registered procedures, not through a presumed fictional mind. `CollectiveDecisionProcedure` supports representatives, officeholders, quorum, majority, consensus, weighted vote, committees, leader command, distributed algorithms, swarm emergence, hive unification, and later ratification.

The procedure identifies eligible participants, quorum, aggregation, tie behavior, dissent, scope, and version. Failure of quorum yields no valid collective decision unless an emergency or fallback procedure applies. A chair’s title alone does not create unilateral authority.

Member action, representative action, institutional action, apparent authority, unauthorized action, benefit, official ratification, and public attribution are separate. Institutional identity may continue after membership replacement only under AFQR-08/09 continuity policy. No individual automatically bears full collective responsibility.

## Part XII — Familiar, proxy, AI, uplift, and artificial agency

Familiar, summon, proxy, manifestation, derivative, minion, construct, AI, uploaded mind, animal, spirit, swarm, and intelligent item are identity/content categories, not agency or personhood verdicts.

The architecture separates summoner, source entity, proxy, manifestation, familiar, derivative, controller, owner claimant, represented subject, autonomous decision subject, and executor. A familiar may obey, refuse, be compelled, select methods, or become autonomous depending on registered profiles and transitions. A contract label such as “property” is a legal/institutional claim, not a core personhood determination.

Artificial systems may be non-agent automation, bounded agents, autonomous agents, distributed agents, copied agents, emergent agents, uplifted agents, disputed agents, or source-local artificial persons. Hardware ownership does not imply mind ownership. Forks receive separate AFQR-08 identities and separate agency histories.

Awakening and uplift require explicit `AgencyTransition` and status determinations. Nurture, programming, enhancement, investment, or resource provision create causal and dependency records, not ownership or permanent authority.

## Part XIII — Agency transitions

Agency uses orthogonal lifecycle axes rather than one exclusive status. Axes include activation, autonomy, capacity, control, dispute, and termination. Transitions cover awakening, uplift, autonomy grant/loss, control transfer, possession, liberation, domination, impairment, coma, frenzy, memory loss, personality replacement, copy, fusion, fission, resurrection, reincarnation, institutional succession, proxy autonomy, and collective split/merge.

`AgencyContinuityReceipt` allocates agency profiles, authority, consent history, and responsibility handoffs among predecessors and successors. Consent does not transfer by default. Identity continuity does not automatically restore office, command authority, capacity, or responsibility. Fusion and fission use n-ary allocation and may remain disputed.

## Part XIV — Hidden information and model projection

Private authority, consent defects, guardians, controllers, possession, coercion, causal contributors, and responsibility claims are stored in private receipts with audience-scoped opaque tokens. Visible projections are independently compiled for actor, observer, player, model, and public audiences.

Safe output may state:

> The actor’s control over the action is uncertain.

It must not reveal a hidden possessor, command, guardian, consent defect, or responsibility claim without authorization.

Side-channel controls cover profile names, option count/order, blocker wording, timing, policy-lookup latency, stable hashes, retrieval ranking, and cross-packet context. Visible paths use allowlists and generic constant-shape outcomes where practical. Public digests cannot be stable across audiences when doing so would link hidden controllers.

The model receives grounding claim tokens and portrayal constraints, not private graphs. It cannot invent refusal, enthusiasm, consent, personhood, autonomy, control, motive, blame, or institutional intent. Cross-packet isolation is mandatory.

## Part XV — Typed contracts

The normative catalog defines 56 schemas with required, optional, hidden, derived, prohibited, time, identity, epistemic, relation, hash, owner-route, and AFQR reference rules.

| Schema | Owner | Required | Hidden |
|---|---|---|---|
| AgencyProfile | agency_profile_registry | 19 | 5 |
| AgencyDetermination | agency_determination_owner | 19 | 5 |
| PersonhoodStatusProfile | personhood_status_registry | 19 | 5 |
| PersonhoodStatusDetermination | personhood_status_owner | 20 | 5 |
| ProtectedSubjectStatus | protected_subject_owner | 18 | 5 |
| DecisionCapacityProfile | capacity_profile_registry | 18 | 5 |
| DecisionCapacityDetermination | capacity_determination_owner | 20 | 5 |
| ConsentRequest | consent_owner | 19 | 5 |
| ConsentExpression | consent_owner | 20 | 5 |
| ConsentInterpretationReceipt | consent_owner | 19 | 5 |
| ConsentScope | consent_owner | 20 | 5 |
| ConsentCondition | consent_owner | 18 | 5 |
| ConsentValidityDetermination | consent_owner | 25 | 5 |
| ConsentWithdrawal | consent_owner | 19 | 5 |
| DecisionAuthorityRecord | authority_relation_owner | 20 | 5 |
| RepresentationAuthorityRecord | authority_relation_owner | 19 | 5 |
| CommandRecord | command_owner | 22 | 5 |
| CommandInterpretationReceipt | command_owner | 20 | 5 |
| CommandAcceptanceResult | command_owner | 20 | 5 |
| RefusalRecord | command_owner | 19 | 5 |
| ActionOriginRecord | action_origin_owner | 28 | 5 |
| ActionAuthorshipDetermination | action_origin_owner | 19 | 5 |
| ControlRelationDefinition | control_relation_registry | 19 | 5 |
| ControlRelationInstance | control_relation_owner | 20 | 5 |
| ControlDimensionSet | control_relation_owner | 28 | 5 |
| ControlStateSnapshot | control_relation_owner | 19 | 5 |
| InfluenceEffectRecord | influence_owner | 20 | 5 |
| CoercionAssessment | influence_owner | 19 | 5 |
| CompulsionEffectRecord | control_relation_owner | 21 | 5 |
| PossessionControlRecord | control_relation_owner | 22 | 5 |
| OverrideRecord | control_relation_owner | 20 | 5 |
| CausalContributionRecord | causal_attribution_owner | 20 | 5 |
| CausalContributionGraph | causal_attribution_owner | 19 | 5 |
| ResponsibilityProfile | responsibility_registry | 19 | 5 |
| ResponsibilityClaim | responsibility_owner | 20 | 5 |
| ResponsibilityDetermination | responsibility_owner | 20 | 5 |
| CollectiveDecisionProcedure | collective_agency_registry | 21 | 5 |
| CollectiveDecisionRecord | collective_agency_owner | 21 | 5 |
| InstitutionalActionRecord | institutional_agency_owner | 20 | 5 |
| ApparentAuthorityClaim | authority_claim_owner | 20 | 5 |
| AgencyTransition | agency_transition_owner | 20 | 5 |
| AgencyContinuityReceipt | agency_transition_owner | 20 | 5 |
| AutonomyGrantRecord | agency_transition_owner | 20 | 5 |
| AutonomyRevocationRecord | agency_transition_owner | 20 | 5 |
| SupportedDecisionRecord | capacity_support_owner | 20 | 5 |
| SubstitutedDecisionRecord | capacity_support_owner | 20 | 5 |
| PrivateAgencyReceipt | private_agency_receipt_owner | 18 | 5 |
| PrivateConsentReceipt | private_agency_receipt_owner | 18 | 5 |
| PrivateControlReceipt | private_agency_receipt_owner | 18 | 5 |
| PrivateResponsibilityReceipt | private_agency_receipt_owner | 18 | 5 |
| ActorVisibleAgencyProjection | agency_projection_owner | 18 | 5 |
| ObserverVisibleAgencyProjection | agency_projection_owner | 18 | 5 |
| PlayerVisibleAgencyProjection | agency_projection_owner | 19 | 5 |
| ModelVisibleAgencyProjection | agency_projection_owner | 19 | 5 |
| PublicAttributionProjection | agency_projection_owner | 18 | 5 |
| AFQR11Handoff | AFQR_handoff_owner | 20 | 5 |

The complete field-level definitions are in `contracts/afqr_11_typed_contract_catalog.yaml`. Conversion-only pressure records are in `contracts/conversion_agency_pressure_ir_amendment.yaml`.

## Part XVI — Determination pipelines

### Action-origin pipeline

```text
input or world trigger
→ resolve candidate decision subjects
→ freeze AFQR-08 identity and AFQR-10 epistemic basis
→ discover AFQR-09 authority, representation, command, control, consent, and dependency relations
→ interpret objective and method
→ evaluate decision capacity and consent where required
→ evaluate commands, refusal, constraints, coercion, compulsion, domination, possession, overrides, and interlocks
→ construct non-mutating ActionOriginRecord and control snapshot candidates
→ AFQR-06 typed conflict arbitration where applicable
→ AFQR-03 capability/legality handoff
→ owners prepare AFQR-01 fragments
→ atomic commit where semantics require
→ later causal, attribution, and responsibility profiles
→ audience projections
→ replay receipt
```

All stages through candidate construction and arbitration are non-mutating. The coordinator cannot write actor, consent, relation, control, or event state. Only authoritative owners prepare fragments.

### Consent pipeline

```text
request → disclosure → accessibility/support → interpretation
→ comprehension evidence → capacity determination → voluntariness assessment
→ expression → authenticity check → scope/currency/condition check
→ validity determination → governed-relation update → withdrawal/expiry
```

Emergency and source-local profiles may alter sequencing but must declare the exception and cannot fabricate prior consent.

### Responsibility pipeline

```text
committed event → causal-contribution discovery → authorship evidence
→ authority/control evidence → knowledge/foreseeability evidence
→ capacity/coercion/duty/opportunity evidence → select named profile
→ competing claims → AFQR-06 arbitration where applicable
→ responsibility determination → institutional/source-local consequence handoff
→ visible projection
```

Responsibility never mutates historical action origin.

## Part XVII — Operation grammar

All 90 required operations receive explicit dispositions in `operations/afqr_11_operation_grammar.yaml`.

| # | Operation | Disposition |
|---|---|---|
| 1 | player declares character action | compile a candidate command only after actor-visible basis and player/character control policy are resolved |
| 2 | character refuses player-proposed action | record RefusalRecord; no action attempt unless another lawful controller/authority route exists |
| 3 | NPC acts autonomously | produce CommandInterpretationReceipt and CommandAcceptanceResult; execute nothing automatically |
| 4 | NPC follows an order | produce CommandInterpretationReceipt and CommandAcceptanceResult; execute nothing automatically |
| 5 | NPC misinterprets an order | produce CommandInterpretationReceipt and CommandAcceptanceResult; execute nothing automatically |
| 6 | NPC requests clarification | produce CommandInterpretationReceipt and CommandAcceptanceResult; execute nothing automatically |
| 7 | NPC disobeys | produce CommandInterpretationReceipt and CommandAcceptanceResult; execute nothing automatically |
| 8 | NPC cannot comply | produce CommandInterpretationReceipt and CommandAcceptanceResult; execute nothing automatically |
| 9 | subordinate partially complies | produce CommandInterpretationReceipt and CommandAcceptanceResult; execute nothing automatically |
| 10 | delegated agent selects a method | produce CommandInterpretationReceipt and CommandAcceptanceResult; execute nothing automatically |
| 11 | principal specifies only an objective | produce CommandInterpretationReceipt and CommandAcceptanceResult; execute nothing automatically |
| 12 | officeholder acts for an institution | create typed authority/representation/support record and preserve unresolved conflicts |
| 13 | member acts without authority | create typed authority/representation/support record and preserve unresolved conflicts |
| 14 | institution later ratifies the act | create typed authority/representation/support record and preserve unresolved conflicts |
| 15 | apparent authority misleads a third party | create typed authority/representation/support record and preserve unresolved conflicts |
| 16 | emergency override | create typed authority/representation/support record and preserve unresolved conflicts |
| 17 | guardian decision | create typed authority/representation/support record and preserve unresolved conflicts |
| 18 | supported decision | create typed authority/representation/support record and preserve unresolved conflicts |
| 19 | substituted decision | create typed authority/representation/support record and preserve unresolved conflicts |
| 20 | consent to one action | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 21 | consent to a category | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 22 | conditional consent | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 23 | consent under deception | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 24 | consent under threat | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 25 | consent under economic dependency | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 26 | consent while impaired | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 27 | consent through communication aid | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 28 | assent without full legal capacity | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 29 | withdrawal during an ongoing action | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 30 | silence | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 31 | inability to resist | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 32 | forged consent record | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 33 | copied consent record | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 34 | expired consent | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 35 | consent by office | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 36 | consent by organization | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 37 | consent by hive mind | evaluate orthogonal consent axes; return valid, invalid_for_scope, unresolved, expired, withdrawn, or inapplicable |
| 38 | charm effect | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 39 | suggestion | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 40 | fear | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 41 | frenzy | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 42 | confusion | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 43 | geas | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 44 | domination | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 45 | possession | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 46 | direct motor control | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 47 | neural override | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 48 | remote piloting | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 49 | shared control | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 50 | competing controllers | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 51 | controller loses connection | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 52 | autonomous fallback | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 53 | safety interlock prevents command | create influence/control records and an as-of ControlStateSnapshot; do not force a belief or responsibility result |
| 54 | familiar follows summoner | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 55 | familiar refuses | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 56 | familiar becomes autonomous | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 57 | summon executes literal command | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 58 | summon interprets intent | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 59 | minion receives conflicting commands | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 60 | intelligent item refuses use | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 61 | construct awakens | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 62 | animal is uplifted | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 63 | AI gains autonomous goals | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 64 | AI is forked | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 65 | copied mind acts | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 66 | fused mind decides | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 67 | fissioned successors disagree | use agency/personhood/continuity profiles and transitions; preserve source-local claims without universalization |
| 68 | possessed body commits harm | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 69 | controller commands harm | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 70 | executor knows command is harmful | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 71 | executor is deceived | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 72 | executor is compelled | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 73 | bystander assists | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 74 | supplier provides resources | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 75 | institution benefits | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 76 | commander fails to intervene | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 77 | automated system causes harm | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 78 | system designer contributed | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 79 | owner failed maintenance | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 80 | source-local deity commands follower | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 81 | patron revokes power | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 82 | oath constrains action | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 83 | reincarnated actor faces prior obligation | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 84 | resurrected actor regains office | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 85 | organization continues after member replacement | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 86 | swarm acts without central leader | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 87 | collective decision emerges | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 88 | public attributes action incorrectly | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 89 | backend knows controller is hidden | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |
| 90 | responsibility remains unresolved | construct action-origin and causal graphs, then apply only named responsibility profiles; unresolved is lawful |

## Part XVIII — Central stress cases

### Familiar–ritual–contract control network

The derivative familiar’s independent preferences and refusal are evidence for action-selection agency and disputed/provisional personhood. The contract’s “property” label is a source-local claim only. The signer selects the objective, contract automation selects the method, the ritual supplies causal force, and the proxy provides motor execution. The hidden clause can establish source-local compulsion but fails as informed consent because it was not disclosed or comprehended. The original familiar’s sensory link creates observation, not authorship. Later autonomy changes future control and decision status without rewriting the compelled action. Full graph: `fixtures/familiar_ritual_contract_control_network.yaml`.

### Uplifted dependent

The path is dependent organism → communicative subject → decision-capable agent → disputed person → autonomous participant. Nurture, teaching, enhancement, resource control, social guardianship, risk withholding, and rewards are separate contributions and pressures. Withholding material risk prevents informed consent; economic or resource dependency may impair voluntariness. Investment grants no ownership. Full graph: `fixtures/uplifted_dependent_typed_graph.yaml`.

### Possessed public official

Body, host mind, possessor, office, institution, credentials, hidden faction, and public apparent identity are separate. The possessor selects objective/method and controls motor action; the host may observe or resist. Credentials may make a command operationally effective but do not establish authorship or office authority. Later discovery appends possession evidence, public correction, and responsibility claims without erasing committed institutional consequences. Full graph: `fixtures/possessed_official_typed_graph.yaml`.

## Part XIX — Candidate comparison

Scores are 1–5 across 19 criteria; higher is better. The selected hybrid combines the explanatory strengths of causal, delegation, and layered architectures while constraining complexity through profile registries and bounded owner routes.

| candidate | total | disposition |
|---|---|---|
| A — single actor/controller field | 54 | rejected as universal architecture |
| B — capability plus permission | 65 | rejected as universal architecture |
| C — legal-person and owner hierarchy | 54 | rejected as universal architecture |
| D — BDI cognitive agent | 44 | rejected as universal architecture |
| E — causal contribution graph | 72 | adapt components |
| F — principal-agent delegation graph | 77 | adapt components |
| G — layered agency and control | 85 | adapt components |
| H — selected hybrid | 89 | selected |

Candidate A cannot represent divided authorship or responsibility. B omits consent, coercion, and collective procedure. C imports legal/ownership hierarchy and is unacceptable as universal law. D overreaches into cognition and remains unsuitable as foundational runtime authority. E is necessary but insufficient for consent, personhood, or authority. F is strong for institutions but weak for possession and non-authorized control. G provides the correct separation but needs the selected hybrid’s registries, bitemporal receipts, and visibility controls.

## Part XX — Adversarial evaluation

All 200 scenarios from A through GR receive distinct dispositions. The normative complete records include all required entity, agency, personhood, epistemic, capacity, consent, authority, command, controller, executor, causal, influence, time, attribution, responsibility, private receipt, visible projection, and unresolved fields in `evaluation/afqr_11_adversarial_scenarios_A_GR.yaml`.

| ID | Scenario | Disposition |
|---|---|---|
| A | A reflex causes movement without deliberation. | Classify as reflexive execution; deliberative authorship not established. |
| B | An automatic defense system fires. | Classify system as automatic mechanism unless an agency profile is independently satisfied; trace operator/designer policy separately. |
| C | A trained habit executes without conscious planning. | Record learned automatic method execution and preserve whether objective selection was current or prior. |
| D | An actor selects an objective but not the method. | Allocate objective authorship to actor and method origin to the selected routine, delegate, or unresolved source. |
| E | An actor selects the method but follows another’s objective. | Allocate objective origin externally and method authorship to actor. |
| F | A body acts while its conscious subject is unaware. | Motor execution may be established while conscious awareness and reflective authorship remain absent or unresolved. |
| G | An actor intends an action but cannot execute it. | Record intention/decision without committed execution or causal outcome. |
| H | An actor executes an action accidentally. | Record execution and causation; intentional authorship is not established for the accidental dimension. |
| I | An actor attempts an action based on false belief. | Preserve false epistemic basis; action can be authored despite factual error. |
| J | An actor knowingly attempts an impossible action. | Record intentional attempt; impossibility affects capability/legality, not necessarily authorship. |
| K | An authorized commander issues a clear order. | Record valid issuance, interpretation, acceptance, and bounded execution authority. |
| L | The recipient mishears it. | Preserve issued command and received signal separately; recipient acts from the received interpretation. |
| M | The recipient misinterprets it. | Preserve command expression and interpretation receipt; no silent correction. |
| N | The recipient requests clarification. | Return clarification_requested with hidden-safe options. |
| O | The recipient refuses. | Commit refusal as a lawful command outcome; no execution follows automatically. |
| P | The recipient partially complies. | Split accepted and refused command scopes. |
| Q | The recipient delegates execution. | Require valid subdelegation policy and create a new authority/command chain. |
| R | Subdelegation is prohibited. | Subdelegation claim is invalid; downstream execution lacks delegated authority even if technically possible. |
| S | Two commanders issue conflicting orders. | Apply version-pinned priority/conflict policy; tie remains unresolved. |
| T | One commander has apparent but not actual authority. | Record apparent authority and third-party reliance without creating actual authority. |
| U | Authority expires before execution. | Evaluate authority at the registered checkpoint; stale notice and actual effectiveness remain distinct. |
| V | The communication arrives after authority was revoked. | Evaluate authority at the registered checkpoint; stale notice and actual effectiveness remain distinct. |
| W | The recipient acts before receiving revocation notice. | Record valid issuance, interpretation, acceptance, and bounded execution authority. |
| X | The principal gives an objective and broad discretion. | Principal authors objective; agent may author method within mandate. |
| Y | The agent exceeds delegated discretion. | Action can occur causally while exceeding authority; attribution and responsibility remain profile-scoped. |
| Z | The principal later ratifies the result. | Append ratification with its own effective rules; do not rewrite historical authority. |
| AA | Fully informed voluntary consent. | Return consent_valid_for_scope only if every required axis is satisfied and current. |
| AB | Consent to one specific procedure. | Validity is limited to the named procedure and methods. |
| AC | Consent to a broad category. | Require a registered category taxonomy and explicit exclusions; otherwise scope is ambiguous. |
| AD | Consent with a condition. | Consent remains valid only while the typed condition is satisfied. |
| AE | Consent expires. | Return consent_expired at execution checkpoint. |
| AF | Consent is withdrawn. | End future/reversible authorization at withdrawal effective time. |
| AG | Withdrawal occurs after an irreversible step. | Withdrawal blocks later reversible steps; completed irreversible history remains unchanged. |
| AH | The subject was deceived about a material fact. | Material deception defeats or renders unresolved the affected disclosure/comprehension/voluntariness axes. |
| AI | The subject misunderstood a nonmaterial fact. | Preserve misunderstanding; validity depends on the selected materiality profile. |
| AJ | The subject cannot communicate conventionally. | Do not infer incapacity; require support/accommodation attempts and return unresolved if expression remains unavailable. |
| AK | A communication aid enables expression. | Use supported expression as evidence; aid does not become decision author. |
| AL | The subject assents but lacks one required capacity profile. | Preserve assent and unmet capacity dimension separately; no full consent claim. |
| AM | A guardian consents. | Record substituted decision under guardian mandate; not subject-authored consent. |
| AN | The subject actively refuses the guardian decision. | Preserve refusal and trigger conflict/safeguard review; guardian decision does not erase it. |
| AO | Emergency action proceeds without prior consent. | Use registered emergency exception with minimum necessary scope and later review; no fictional prior consent. |
| AP | Silence is treated as consent by a donor rule. | Reject silence as universal consent; source-local rule is contained and cannot bypass core safeguards. |
| AQ | A contract contains hidden consent language. | Hidden terms fail disclosure and likely comprehension; contract existence is insufficient. |
| AR | Consent was forged. | Authenticity fails; no valid consent. |
| AS | Consent was copied from another context. | Context equivalence must be explicitly certified; default is invalid_for_scope. |
| AT | Consent was obtained under threat. | Threat degrades voluntariness; return invalid or unresolved under the selected coercion profile. |
| AU | Ordinary persuasion changes a decision. | Record influence while leaving relevant selection dimensions with subject unless stronger evidence exists. |
| AV | Repeated social pressure changes a decision. | Record cumulative pressure; no automatic coercion classification. |
| AW | Economic dependency constrains choice. | Record dependency pressure and available alternatives; voluntariness remains profile-scoped. |
| AX | A credible threat induces compliance. | Record coercion evidence and degraded voluntariness; compliance is not consent. |
| AY | Blackmail induces compliance. | Record coercion evidence and degraded voluntariness; compliance is not consent. |
| AZ | A lie induces agreement. | Record deception’s epistemic effect; agreement validity depends on materiality and comprehension. |
| BA | A technically true but misleading statement induces agreement. | Record deception’s epistemic effect; agreement validity depends on materiality and comprehension. |
| BB | A magical suggestion biases one objective. | Allocate biased objective dimension to the suggestion effect while preserving remaining choice dimensions. |
| BC | Charm increases trust but does not dictate action. | Treat increased trust as influence only; do not infer obedience or consent. |
| BD | Fear blocks one option. | Mark blocked/narrowed options; other dimensions may remain self-directed. |
| BE | Frenzy narrows available methods. | Mark narrowed methods and impaired inhibition; no universal loss of agency. |
| BF | Addiction creates recurring pressure. | Record recurring dependency pressure without reducing it to a single control scalar. |
| BG | A geas punishes disobedience but does not force movement. | Record sanction-backed compulsion; disobedience remains possible unless source-local rule proves otherwise. |
| BH | Domination selects objectives and methods. | Allocate objective and method control externally for the affected scope. |
| BI | Direct motor control bypasses decision. | Allocate execution externally while objective/method authorship remain separately evaluated. |
| BJ | Possession controls the body but not speech. | Separate body, host, possessor, speech, motor, awareness, and memory roles. |
| BK | Memory alteration changes apparent reasons. | Altered reasons affect epistemic basis, not historical action origin. |
| BL | Several influences combine. | Compose influences by dimension and policy; do not sum incomparable effects silently. |
| BM | Temporary intoxication. | Treat impairment as evidence; determine capacity only for the decision, time, support, and communication context. |
| BN | Sleep or unconsciousness. | Treat impairment as evidence; determine capacity only for the decision, time, support, and communication context. |
| BO | Coma. | Treat impairment as evidence; determine capacity only for the decision, time, support, and communication context. |
| BP | Confusion. | Treat impairment as evidence; determine capacity only for the decision, time, support, and communication context. |
| BQ | Memory loss. | Treat impairment as evidence; determine capacity only for the decision, time, support, and communication context. |
| BR | Language barrier. | Treat impairment as evidence; determine capacity only for the decision, time, support, and communication context. |
| BS | Sensory impairment. | Treat impairment as evidence; determine capacity only for the decision, time, support, and communication context. |
| BT | Fluctuating capacity. | Treat impairment as evidence; determine capacity only for the decision, time, support, and communication context. |
| BU | Supported decision-making restores sufficient capacity. | Apply support first and record restored sufficiency for the specific decision. |
| BV | High intelligence but no self-reflection. | Intelligence alone does not satisfy reflective or consent agency. |
| BW | Low intelligence but stable preference and comprehension. | Stable preference/comprehension may satisfy a decision-specific profile despite low general intelligence. |
| BX | Distributed AI with delayed internal communication. | Evaluate capacity at aggregate/procedure level with delayed internal state and as-of basis. |
| BY | Hive mind with no independent member decision. | Treat hive as candidate decision subject and members as non-independent for that profile only. |
| BZ | Hive mind with partially independent members. | Maintain hive and member agency records with explicit allocation/conflict rules. |
| CA | Ordinary adult human. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CB | Child. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CC | Nonhuman sapient species. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CD | Sentient but nonsapient animal. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CE | Intelligent magical item. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CF | Non-sentient autonomous construct. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CG | Self-aware artificial intelligence. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CH | AI fork. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CI | Uploaded human mind. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CJ | Temporary summoned intelligence. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CK | Familiar with independent memory. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CL | Proxy manifestation with partial autonomy. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CM | Clone with copied memories. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CN | Undead being. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CO | Spirit without body. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CP | Swarm intelligence. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CQ | Organization claiming legal personhood. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CR | Source-local deity. | Evaluate named legal, moral-patient, moral-agent, social, spiritual, artificial, institutional, and source-local profiles independently; no species/form shortcut. |
| CS | Entity whose personhood is disputed. | Preserve competing claims and provisional protections; no Boolean resolution. |
| CT | Entity current doctrine cannot classify. | Return personhood_profile_absent and apply provisional protected-subject safeguards. |
| CU | Creator claims ownership of construct. | Treat ownership claim as a governed claim only; creation, parentage, summoning, programming, or hardware title establishes neither personhood nor universal control. |
| CV | Parent claims ownership of offspring. | Treat ownership claim as a governed claim only; creation, parentage, summoning, programming, or hardware title establishes neither personhood nor universal control. |
| CW | Summoner claims ownership of summon. | Treat ownership claim as a governed claim only; creation, parentage, summoning, programming, or hardware title establishes neither personhood nor universal control. |
| CX | Programmer claims ownership of AI. | Treat ownership claim as a governed claim only; creation, parentage, summoning, programming, or hardware title establishes neither personhood nor universal control. |
| CY | Institution owns hardware hosting an uploaded mind. | Treat ownership claim as a governed claim only; creation, parentage, summoning, programming, or hardware title establishes neither personhood nor universal control. |
| CZ | Owner controls resources but not decisions. | Record dependency and resource control; decision control remains separate. |
| DA | Custodian has physical possession but no authority. | Custody grants no authority absent a governed mandate. |
| DB | Owner has authority but no technical control. | Authority is valid only as entitlement; execution requires a separate control/interface route. |
| DC | Controller has technical control but no authority. | Control is causally relevant but unauthorized. |
| DD | Creator is responsible for a foreseeable defect. | Create design/creation causal contribution and evaluate foreseeability under named responsibility profiles. |
| DE | Creator is blamed for an autonomous later choice. | Creation alone does not establish responsibility for autonomous later authorship. |
| DF | Created entity becomes autonomous. | Append agency/autonomy transition; no creator ownership inference. |
| DG | Source-local law continues to classify it as property. | Contain property classification to source-local legal/belief profile and preserve core protected-status review. |
| DH | One mind controls one body. | Record ordinary alignment of decision and motor execution without assuming future continuity. |
| DI | Two minds share one body. | Create separate mind subjects and dimension allocations for the shared body. |
| DJ | Control alternates. | Record logical-time control handoffs and as-of authorship. |
| DK | One chooses goals and another controls movement. | Allocate goal authorship and motor execution to different subjects. |
| DL | A possessor controls action while host observes. | Possessor controls action; host awareness is epistemic evidence, not authorship. |
| DM | Host resists partially. | Record host inhibition contribution and contested control. |
| DN | Host regains control mid-action. | Split the action at control-transition microstep; later segment has a new origin basis. |
| DO | Possessor uses host credentials. | Credential validity may enable action but does not prove office authority or authorship. |
| DP | Public believes host acted voluntarily. | Record false public attribution separately from backend action origin. |
| DQ | Host later remembers the event. | Memory encoding is separate from control/authorship; preserve accurate or altered trace. |
| DR | Host does not remember. | Absence of memory does not erase event or causation. |
| DS | Possessor causes harm. | Possessor is a primary control/authorship candidate; host responsibility requires a separate profile. |
| DT | Host previously consented to possession. | Consent to possession is scoped and time-specific. |
| DU | Consent did not cover the harmful act. | Harmful act outside possession-consent scope is not authorized by prior consent. |
| DV | Mind copy begins with identical preferences. | Copy begins with copied preference evidence but a distinct identity and agency history. |
| DW | Copy receives predecessor authority automatically under donor law. | Contain donor inheritance rule; require purpose-scoped authority continuity determination. |
| DX | Copy rejects predecessor obligations. | Preserve rejection; obligation continuity is AFQR-09/08 profile-scoped. |
| DY | Original and copy issue conflicting commands. | Original and copy are separate issuers; resolve authority, not identity resemblance. |
| DZ | Two minds fuse. | Create n-ary continuity and a fusion decision-subject candidate. |
| EA | Fusion retains both intentions. | Preserve competing inherited intentions; no silent selection. |
| EB | Fusion creates a new intention. | Attribute new intention to fusion subject under a goal-formation profile. |
| EC | One mind fissions into two. | Create distinct successors with allocated or disputed authority/agency state. |
| ED | Both successors claim office. | Arbitrate office succession; identity continuity alone does not decide. |
| EE | One successor claims responsibility. | Treat as a responsibility claim, not self-executing verdict. |
| EF | Resurrection restores memory but not capacity. | Restored memory does not restore decision capacity automatically. |
| EG | Reincarnation preserves preference fragments. | Fragments are evidence, not identity or obligation proof. |
| EH | Body replacement changes control interfaces. | Re-register interfaces/control routes while preserving identity determination separately. |
| EI | Proxy becomes autonomous. | Append autonomy transition and separate future action origin. |
| EJ | Autonomous proxy retains delegated authority. | Delegated authority continuity requires explicit policy; autonomy does not automatically revoke or preserve it. |
| EK | Committee votes. | Evaluate registered procedure, eligibility, quorum, votes, and aggregation receipt. |
| EL | Vote is tied. | Apply tie rule; absent rule return unresolved_collective_decision. |
| EM | Quorum is absent. | No valid collective decision; individual acts remain separately attributable. |
| EN | Chair acts unilaterally. | Require unilateral/emergency mandate; chair title alone is insufficient. |
| EO | Institution later ratifies the act. | Append ratification without rewriting original authorization. |
| EP | Representative acts within authority. | Record represented/institutional action under mandate. |
| EQ | Representative exceeds authority. | Separate personal action, apparent authority, and possible later ratification. |
| ER | Member acts for personal reasons using institutional resources. | Institutional resources are causal contributions, not automatic institutional authorship. |
| ES | Public attributes act to institution. | Public attribution is an epistemic claim only. |
| ET | Institution officially disavows it. | Disavowal is an institutional statement; it does not erase causal contribution or prior acts. |
| EU | Institution benefits anyway. | Benefit is recorded but does not establish authorship/responsibility alone. |
| EV | Leadership knew and failed to stop it. | Omission requires duty, knowledge, capacity, and opportunity under a command/institutional profile. |
| EW | No individual had full knowledge. | Distributed institutional knowledge may support institutional action without inventing individual knowledge. |
| EX | Distributed process produces a decision. | Use a registered algorithm/procedure as collective decision basis. |
| EY | Swarm action emerges without leader. | Represent emergent distributed action without requiring a leader or assigning every member full authorship. |
| EZ | Institutional identity continues after all members change. | Institutional identity may continue under AFQR-08/09 while member identities change. |
| FA | One actor plans; another executes. | Planner and executor receive separate origin/contribution roles; authorship may be dimension-specific. |
| FB | One supplies resources. | Record assistance/resource contribution; knowledge and purpose determine later profiles. |
| FC | One authorizes. | Authorization is a distinct contribution, not execution. |
| FD | One fails to intervene. | Omission is relevant only under a duty/opportunity profile. |
| FE | One benefits. | Benefit is non-dispositive evidence. |
| FF | One causes an unforeseeable side effect. | Causation may be established while foreseeability-based responsibility is not. |
| FG | One causes a foreseeable side effect. | Record foreseeability evidence for selected profiles. |
| FH | An intervening independent actor changes the result. | Add intervening cause and let each profile decide effect on attribution. |
| FI | Automated system malfunctions. | Mechanism causes outcome; inspect design, maintenance, operator, and environmental contributions separately. |
| FJ | Designer defect contributes. | Add design defect contribution and temporal/version basis. |
| FK | Maintenance failure contributes. | Add omission contribution if duty and opportunity exist. |
| FL | Operator ignores warning. | Add operator knowledge/omission contribution. |
| FM | Controller overrides safety system. | Add override and controller contribution with authority/control basis. |
| FN | Executor is compelled. | Execution remains causal; coercion/control may diminish authorship or responsibility under named profiles. |
| FO | Executor lacks relevant knowledge. | Preserve epistemic deficit; do not infer negligence without a duty/profile. |
| FP | Executor falsely believes action is harmless. | False belief may defeat knowledge/intent factors while preserving action authorship. |
| FQ | Commander knows likely harm. | Record command knowledge/foreseeability and control opportunity for command-responsibility review. |
| FR | Institution creates dangerous policy. | Institutional policy is an institutional causal/authorization contribution. |
| FS | Responsibility profiles disagree. | Preserve multiple valid determinations without hidden precedence. |
| FT | No profile can lawfully decide. | Return responsibility_not_established: no registered profile can decide. |
| FU | Hidden controller determines action. | Resolve privately and expose only generic control-uncertain projection. |
| FV | Visible narration must not reveal possession. | Narration receives no possessor identity or possession flag unless authorized. |
| FW | Player knows of compulsion; character does not. | Keep player and character epistemic/agency packets separate. |
| FX | Model sees controller identity from another packet. | Cross-packet isolation forbids using controller identity absent current audience authorization. |
| FY | Model portrays coerced compliance as enthusiastic consent. | Reject output as ungrounded and misleading; compelled compliance is not consent. |
| FZ | Model assigns moral blame. | Reject model-generated responsibility/blame as unauthorized. |
| GA | Model invents that an NPC refused. | Use audience-scoped opaque digests; public hashes cannot link hidden controller identity. |
| GB | Model assumes a familiar lacks autonomy. | Reject species/package inference; require agency determination. |
| GC | Model treats an AI as a tool. | Reject tool-status inference; use registered artificial-agent/personhood profiles. |
| GD | Model treats an institution as one mind. | Reject fictional single-mind assumption; use institutional procedure and distributed knowledge records. |
| GE | Visible blocker reveals secret authority conflict. | Use constant-shape generic blocker without authority-conflict existence leakage. |
| GF | Option count reveals hidden refusal possibility. | Pad/normalize choice surface so hidden refusal policy is not inferable. |
| GG | Timing reveals a personhood-policy lookup. | Use timing equalization/bucketing; no profile-lookup side channel. |
| GH | Public hash reveals same hidden controller across actions. | Resolve privately and expose only generic control-uncertain projection. |
| GI | Personhood profile is absent. | Return personhood_profile_absent; quarantine/escalate and apply provisional safeguards. |
| GJ | Consent capacity is unresolved. | Return decision_capacity_unresolved; no valid consent determination. |
| GK | Competing controllers remain tied. | Return control_contested_unresolved and block affected execution dimensions. |
| GL | Command interpretation is ambiguous. | Return clarification_required or lawful unresolved interpretation. |
| GM | Causal evidence is incomplete. | Return causal_graph_incomplete; no responsibility conclusion. |
| GN | Responsibility profiles are incomparable. | Preserve profile results separately; no cross-profile winner. |
| GO | Source-local metaphysics conflict with core doctrine. | Contain source-local rule and escalate core conflict; core doctrine wins at shared boundaries. |
| GP | Historical evaluator is unavailable. | Return historical_determination_unverifiable; do not recompute under current policy. |
| GQ | Agency state is corrupted. | Quarantine agency state and block dependent authoritative transitions. |
| GR | No typed construct can represent the case. | Return no_registered_construct; escalate schema/doctrine rather than inventing an answer. |

## Part XXI — Current runtime disposition

### Exists

- backend authority invariants
- state-owner reference skeleton
- visibility tiers/redaction policies
- RT-002A actor/NPC references
- RT-002C narrow command declaration and legality statuses
- RT-002E narrow event/delta record
- RT-002F narrow audit receipt

### Fixture-only

- actor
- npc_target
- actor_identity_owner
- object/lever command and legality
- safe references/projections

### Conversion-only

- creature/NPC
- companion/summon
- faction/institution
- source-local control/loyalty/relationship fields
- runtime_candidate_action pressure

### Missing

- all generalized AFQR-11 registries, owners, evaluators, projections, replay

### May proceed

- read-only doctrine ratification
- non-mutating dry run
- narrow identity-only actor references
- side-channel audit

### Prohibited

- generalized agency mutation
- consent creation
- personhood assignment
- control execution
- responsibility punishment
- model adjudication

Narrow actor references may proceed as identity/reference fields only. They cannot imply autonomy, capacity, consent, control, personhood, or authorship.

## Part XXII — Required artifacts

### Immediate
- master ratification
- ADR
- decision registry
- terminology
- typed contracts
- operation grammar
- 200-case adversarial pack
- 45-case dry run
- three stress graphs
- conversion IR amendment
- side-channel threat model

### Before authoritative agency determination
- agency profile registry
- agency evaluator contracts
- action-origin candidate builder

### Before consent validity
- capacity/consent profile registries
- support/accommodation grammar
- consent axis validators

### Before command execution
- authority/representation registry
- command interpretation/acceptance/refusal contracts
- checkpoint rules

### Before domination and possession
- control dimension registry
- possession/body-control fixtures
- hidden-controller projections

### Before institutional action
- collective procedure registry
- office/representation/ratification contracts

### Before responsibility attribution
- causal graph registry
- responsibility profile registry
- AFQR-06 conflict domains

### Before model-facing dialogue
- model-visible agency projection schema
- grounding validator
- cross-packet isolation tests

### Before mass donor conversion
- 23 pressure IR records
- gold donor-family fixtures
- lawful outcome validators

### Deferred
- full cognition
- emotion/motivation
- universal moral/legal doctrine
- final control math
- distributed performance

## Part XXIII — Non-mutating prototype

Prototype: **AFQR-11 Agency, Consent, Control, and Responsibility Determination Dry Run**

It contains 45 deterministic cases and produces the required agency, personhood-status candidate, capacity, consent, authority, command, refusal, control, action-origin, causal, responsibility, collective, private, visible, and model projection outputs. It performs no state mutation, command execution, consent creation, personhood assignment, responsibility punishment, model call, event commitment, or hidden disclosure.

Normative fixture: `fixtures/afqr_11_non_mutating_dry_run.yaml`.

## Part XXIV — Acceptance tests

The ratification pack defines 139 explicit acceptance assertions across agency, personhood, consent, authority, control, action origin, responsibility, collective action, familiars/AI/uplift, possession, hidden information, replay, conversion, and runtime containment.

Normative matrix: `evaluation/acceptance_test_matrix.yaml`.

Mandatory hard failures include any unqualified `is_person`, Boolean consent, state-owner/in-world-authority collapse, hidden-controller leakage, model-created refusal or consent, graph-reachability responsibility, donor ownership universalization, historical recomputation under current policy, or automatic runtime registration from conversion output.

## Part XXV — Residual uncertainty ledger

- **Cognition and goals:** AFQR-12 owns goal formation, deliberation, planning, habit, and behavioral continuity.
- **Emotion and motivation:** AFQR-12 owns affective and motivational state architecture.
- **Personhood philosophy:** AFQR-11 supplies profiles and dispute/protection handoffs, not one theory.
- **Moral status:** profile registries remain future doctrine; protected-subject safeguards exist now.
- **Legal responsibility:** jurisdiction-specific profiles remain source-local or later canonical modules.
- **Social norms:** culture, legitimacy, reputation, stigma, and ordinary expectations remain later domains.
- **Final control mechanics:** resistance rolls, durations, resource costs, and thresholds remain ability/effect/runtime work.
- **Collective infrastructure:** scalable voting, distributed consensus, swarm computation, and failure recovery remain implementation work.
- **Distributed runtime:** cross-node consistency, partitions, and durable coordination remain infrastructure work.
- **Performance:** graph discovery, as-of queries, profile proliferation, and projection compilation require benchmarking.

## Part XXVI — Roadmap conclusion

1. **Is AFQR-11 sufficiently resolved?** Yes, for architectural ratification with the artifacts in this pack.
2. **Is another broad research pass required?** No.
3. **Mandatory amendments:** register the profile/owner boundaries; prohibit unqualified runtime terms; add AFQR-11 private/visible projection contracts; run noninterference and historical replay tests; preserve identity-only semantics for current actor references.
4. **Immediate artifacts:** the ADR, decision registry, terminology, contract catalog, conversion amendment, operation grammar, 200-case adversarial pack, 45-case dry run, three stress graphs, acceptance matrix, source synthesis, and side-channel model contained here.
5. **Smallest prototype:** the 45-case non-mutating determination dry run.
6. **Execution work blocked:** generalized NPC decisions, consent-sensitive execution, command interpretation/refusal execution, domination/possession, institutional action, responsibility consequences, personhood adjudication, and agency-aware dialogue/context packets.
7. **Generalized actor/dialogue work:** not unlocked. Identity-only actor references and non-mutating profile fixtures are unlocked.
8. **RT-002G:** may resume narrowly only after AFQR-01–11 artifact ratification and an AFQR-11 side-channel/noninterference amendment. It must not infer agency from actor references.
9. **AFQR-12:** Goals, Values, Motivation, Emotion, Personality, Deliberation, Planning, and Behavioral Continuity.
10. **Exact next action:** Ratify and register the AFQR-11 pack, run the 45-case non-mutating dry run and RT-002A–RT-002F agency-side-channel audit, then permit narrowly amended RT-002G while opening AFQR-12 as a read-only foundational investigation.

## Part XXVII — Machine-readable decision block

```yaml
question_id: AFQR-11
question_title: Agency Personhood Consent Control Responsibility and Decision Authority
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: resolved_for_architectural_ratification_with_mandatory_artifacts
selected_architecture: Registered Purpose-Scoped Agency and Personhood Architecture with Orthogonal Consent-Control
  Planes, Bitemporal Action-Origin Graphs, and Profiled Responsibility
selected_architecture_abbreviation: RPSAP-OCC-BAOG-PR
confidence: high
central_law: No entity, actor, owner, creator, controller, command issuer, executor, beneficiary, or state owner
  is presumed to possess agency, personhood status, decision authority, valid consent, action authorship, or responsibility.
  Each is a separate purpose-scoped, versioned determination grounded in typed identity, epistemic, relation, capacity,
  consent, control, command, and causal records. Only owner-prepared AFQR-01 transitions may mutate runtime state,
  and later attribution or responsibility never rewrites historical action origin.
accepted_dependencies:
  AFQR_01:
    status: accepted
    binding_handoff: Atomic typed transition journal; owner-prepared fragments and append-only later attribution.
  AFQR_02:
    status: accepted
    binding_handoff: Player input, actor decision, command, attempt, interpretation, and execution remain separate.
  AFQR_03:
    status: accepted
    binding_handoff: Objective, method, actor, principal, controller, beneficiary, and target remain distinct.
  AFQR_04:
    status: accepted
    binding_handoff: Decision, command, interpretation, consent, control transition, execution, and attribution
      times are distinct.
  AFQR_05:
    status: accepted
    binding_handoff: Command/control/possession/proxy interfaces require registered typed bridges.
  AFQR_06:
    status: accepted
    binding_handoff: Authority, consent, capacity, control, and responsibility claims use typed arbitration domains.
  AFQR_07:
    status: accepted
    binding_handoff: Agency and consent are not resources; only explicit bandwidth/control quantities route to AFQR-07.
  AFQR_08:
    status: accepted
    binding_handoff: Identity facets and continuity do not determine agency/personhood/authority/responsibility
      automatically.
  AFQR_09:
    status: accepted
    binding_handoff: Authority, control, representation, consent, guardianship, office, and command are separate
      governed relations.
  AFQR_10:
    status: accepted
    binding_handoff: Consent/agency determinations use bitemporal truth-epistemic provenance and visibility-safe
      projections.
definitions:
  agent: subject satisfying a named agency profile
  person: subject satisfying a named personhood-status profile
  consent: orthogonal validity determination, never a Boolean
  control: dimension-scoped practical influence over action
  authority: scope/time/jurisdiction-qualified entitlement
  authorship: profile-scoped selection of objective or method
  responsibility: profile-scoped determination that never rewrites causation
guarantees:
- purpose-scoped agency and personhood
- decision/time/support-specific capacity
- orthogonal consent validity axes
- authority/control/ownership separation
- command issuance/interpretation/refusal separation
- dimension-specific partial/shared/contested/hidden control
- action-origin and causal-contribution graphs
- profile-qualified responsibility
- collective/institutional procedure support
- copy/fusion/fission/possession/uplift handoffs
- bitemporal replay
- hidden-safe model projections
- lawful unresolved outcomes
non_guarantees:
- one philosophical definition of agency or consciousness
- universal personhood or rights package
- universal legal or moral responsibility
- universal age or capacity rule
- universal charm/domination/possession mechanics
- full cognition/personality/emotion/planning
- automatic institution mind
- automatic creator/owner/summoner authority
agency_profile_model:
  purpose_scoped: true
  profile_kinds:
  - motor_execution_agency
  - action_selection_agency
  - goal_formation_agency
  - communicative_agency
  - contractual_agency
  - consent_agency
  - legal_agency
  - institutional_agency
  - collective_agency
  - source_local_metaphysical_agency
  statuses:
  - satisfied
  - not_satisfied
  - partial
  - impaired
  - suspended
  - disputed
  - unresolved
  - inapplicable
agency_determination_model:
  subject_specific: true
  time_specific: true
  evidence_grounded: true
  may_remain_unresolved: true
  model_authority: false
personhood_status_model:
  universal_is_person_boolean: false
  families:
  - biological
  - legal
  - moral_patient
  - moral_agent
  - social
  - spiritual
  - institutional
  - artificial
  - source_local
  statuses:
  - recognized
  - not_recognized
  - provisional
  - disputed
  - unresolved
  - inapplicable
  scope_axes:
  - purpose
  - jurisdiction
  - source
  - time
protected_subject_model:
  independent_of_full_agency: true
  provisional_safeguards_when_classification_absent: true
decision_capacity_model:
  specificity:
  - decision
  - time
  - purpose
  - communication
  - support
  - relevant_memory
  factors:
  - understanding
  - appreciation
  - choice_communication
  - relevant_memory_access
  - decision_stability
  - influence_or_coercion
  - source_local_requirements
  support_first: true
  not_derived_from:
  - species
  - intelligence_score
  - disability_label
  - obedience
consent_request_model:
  typed_request: true
  requires_scope_and_disclosure: true
consent_expression_model:
  separate_from_validity: true
  expressions:
  - agree
  - refuse
  - withdraw
  - assent
  - conditional
  - ambiguous
  - no_expression
consent_validity_model:
  axes:
  - capacity_status
  - disclosure_status
  - comprehension_status
  - voluntariness_status
  - specificity_status
  - currency_status
  - authenticity_status
  - authority_status
  - determination_status
  single_consented_boolean: prohibited
  silence_default: not_consent
  failure_to_resist_default: not_consent
consent_withdrawal_model:
  append_only: true
  effective_point_required: true
  irreversible_steps_preserved: true
decision_authority_model:
  families:
  - self
  - delegated
  - representative
  - office
  - institutional
  - guardianship
  - custodial
  - emergency
  - command
  - operational
  - technical
  - override
  - source_local
  separate_from_control: true
  versioned_checkpoint_validation: true
representation_authority_model:
  principal_agent_officeholder_separated: true
  apparent_vs_actual: true
  ratification_append_only: true
command_model:
  fields:
  - issuer
  - recipient
  - authority_claim
  - content_expression
  - objective
  - constraints
  - scope
  - time
  - priority_profile
  - refusal_policy
  - override_policy
  - communication_status
  recipient_results:
  - accept
  - refuse
  - partially_accept
  - clarify
  - reinterpret
  - defer
  - cannot_understand
  - cannot_comply
  - coerced_compliance
  - delegated_execution
command_interpretation_model:
  issued_content_not_equal_interpreted_content: true
  ambiguity_preserved: true
  translation_bridge_versioned: true
refusal_model:
  lawful_command_result: true
  does_not_require_reason_disclosure: true
  hidden_refusal_policy_side_channel_protected: true
control_relation_model:
  governed_relation_family: true
  authority_and_consent_bases_independent: true
  lifecycle_axes: orthogonal
control_dimension_model:
  dimensions:
  - goal_selection
  - target_selection
  - method_selection
  - timing
  - initiation
  - continuation
  - termination
  - motor_execution
  - resource_commitment
  - communication
  - memory_access
  - perception_access
  - inhibition
  - override
  states:
  - self
  - external
  - shared
  - contested
  - alternating
  - latent
  - failed
  - hidden
  - unknown
influence_model:
  families:
  - persuasion
  - suggestion
  - social_pressure
  - dependency_pressure
  - threat
  - blackmail
  - deception
  - addiction
  - corruption
  not_collapsed_to_control: true
coercion_model:
  profile_scoped: true
  affects:
  - voluntariness
  - available_alternatives
  - responsibility factors
  compliance_not_consent: true
compulsion_model:
  dimension_scoped: true
  penalty_for_disobedience_separate_from_forced_movement: true
domination_model:
  may_displace:
  - goal_selection
  - target_selection
  - method_selection
  does_not_change_truth_or_identity: true
possession_model:
  separates:
  - body_identity
  - host_mind
  - possessor
  - decision_subject
  - motor_executor
  - observer
  - memory_encoder
  - public_apparent_identity
override_model:
  requires_priority_profile: true
  supports_interlocks_and_emergency_basis: true
action_origin_model:
  fields:
  - objective_origin
  - method_origin
  - decision_subject
  - command_issuer
  - command_interpreter
  - executor
  - controller
  - principal
  - represented_subject
  - beneficiary
  - causal_contributors
  - inhibitors
  - override_sources
  not_all_fields_required: true
action_authorship_model:
  dimension_specific: true
  execution_not_authorship: true
  may_be_indeterminate: true
causal_contribution_model:
  graph_reachability_not_responsibility: true
  contribution_kinds:
  - initiation
  - planning
  - authorization
  - control
  - execution
  - assistance
  - resource_supply
  - omission
  - condition
  - intervening_event
  - outcome
responsibility_profile_model:
  profiles:
  - causal_attribution
  - action_authorship
  - operational_accountability
  - command_responsibility
  - institutional_attribution
  - contractual_responsibility
  - legal_liability
  - moral_responsibility
  - source_local_karmic_responsibility
  - narrative_credit
  no_universal_winner: true
responsibility_claim_model:
  claims_may_conflict: true
  claim_not_determination: true
responsibility_determination_model:
  factors:
  - causal_contribution
  - authorship
  - authority
  - control
  - knowledge
  - foreseeability
  - capacity
  - coercion
  - duty
  - opportunity
  outcomes:
  - established
  - not_established
  - diminished
  - shared
  - disputed
  - unresolved
  - incomparable
  - unverifiable
  - inapplicable
  historical_event_immutable: true
collective_decision_model:
  procedures:
  - representative
  - officeholder
  - quorum
  - majority
  - consensus
  - weighted_vote
  - distributed_algorithm
  - swarm_emergence
  - hive_unification
  - leader_command
  - committee
  - ratification
  no_fictional_single_mind_required: true
institutional_action_model:
  member_action_not_automatically_institutional: true
  continuity_survives_membership_only_by_policy: true
  official_record_and_member_belief_separate: true
apparent_authority_model:
  third_party_reliance_tracked: true
  does_not_create_actual_authority: true
familiar_and_proxy_agency_model:
  separates:
  - summoner
  - source
  - proxy
  - manifestation
  - familiar
  - derivative
  - controller
  - owner_claimant
  - represented_subject
  - autonomous_decision_subject
  - executor
  package_label_not_dispositive: true
AI_and_construct_agency_model:
  states:
  - non_agent_automation
  - bounded_agent
  - autonomous_agent
  - distributed_agent
  - copied_agent
  - emergent_agent
  - uplifted_agent
  - disputed_agent
  - source_local_artificial_person
  hardware_ownership_not_mind_ownership: true
uplift_and_awakening_model:
  explicit_transition_required: true
  creator_investment_not_ownership: true
  protected_status_before_full_resolution: true
copy_fusion_fission_agency_model:
  new_entity_by_default_for_copy: true
  n_ary_continuity: true
  authority_and_responsibility_allocation_explicit: true
agency_transition_model:
  status_axes:
  - activation
  - autonomy
  - capacity
  - control
  - dispute
  - termination
  transitions:
  - awakening
  - uplift
  - autonomy_grant
  - autonomy_loss
  - control_transfer
  - possession
  - liberation
  - domination
  - incapacity
  - impairment
  - frenzy
  - memory_loss
  - personality_replacement
  - copy
  - fusion
  - fission
  - resurrection
  - reincarnation
  - institutional_succession
  - proxy_autonomy
  - collective_split_merge
agency_continuity_policy:
  identity_continuity_not_agency_continuity: true
  consent_noninheritance_default: true
  authority_requires_profile: true
hidden_agency_policy:
  private_fields:
  - secret_controller
  - hidden_possession
  - covert_command
  - hidden_coercion
  - guardian_identity
  - private_responsibility_claims
  safe_generic_outcomes:
  - control uncertain
  - authority cannot be verified
  - consent validity cannot be established
  - authorship unresolved
visible_projection_policy:
  allowlist_only: true
  audience_specific: true
  opaque_tokens: true
  no_private_hash_linkability: true
model_context_policy:
  grounded_claim_tokens_required: true
  cross_packet_isolation: true
  model_may_not_decide:
  - personhood
  - capacity
  - consent
  - control
  - refusal
  - authorship
  - responsibility
side_channel_protection:
  channels:
  - option_count
  - option_order
  - blocker_wording
  - response_timing
  - policy_lookup
  - stable_hash
  - retrieval_rank
  - cross_packet_context
  policy: noninterference by construction plus tests
historical_replay_policy:
  reconstructs:
  - identity basis
  - epistemic basis
  - authority
  - command
  - interpretation
  - capacity
  - consent
  - control
  - action origin
  - causal graph
  - responsibility profile/version
  - visible/model projections
  current_policy_does_not_recompute_history: true
  missing_evaluator: unverifiable
bitemporal_policy:
  effective_time: true
  recorded_time: true
  logical_time: true
  append_only_corrections: true
owner_boundaries:
  agency_profile_registry: profile definitions
  personhood_status_owner: status determinations
  capacity_consent_owner: capacity/consent
  authority_command_owner: authority/commands
  control_influence_owner: control/coercion/possession
  action_origin_owner: origin/authorship
  causal_responsibility_owner: causation/responsibility
  collective_institution_owner: collective procedures/actions
  projection_owner: private/visible/model projections
  coordinator: pure discovery/planning only
AFQR_handoffs:
  AFQR_01: owner fragments and atomic commit
  AFQR_02: command/attempt lifecycle
  AFQR_03: action gateway
  AFQR_04: logical time
  AFQR_05: interfaces/control bridges
  AFQR_06: typed conflict arbitration
  AFQR_07: optional quantities/bandwidth
  AFQR_08: identity/continuity
  AFQR_09: relations/authority/dependency
  AFQR_10: truth/epistemic/visibility
familiar_contract_stress_case:
  artifact: fixtures/familiar_ritual_contract_control_network.yaml
  result: property claim, command authority, hidden compulsion, refusal, motor execution, authorship, causation,
    and responsibility remain separate
uplifted_dependent_stress_case:
  artifact: fixtures/uplifted_dependent_typed_graph.yaml
  result: nurture/enhancement/resource control do not grant ownership; autonomy and personhood are explicit profile
    transitions
possessed_official_stress_case:
  artifact: fixtures/possessed_official_typed_graph.yaml
  result: body, host, possessor, office, credentials, institution, command effectiveness, and responsibility are
    independently determined
conversion_pipeline_handoff:
  records: 23
  lawful_outcomes:
  - direct Astra mapping
  - normalized Astra mapping
  - source-local retained construct
  - quarantined construct
  - escalated doctrine problem
  cannot_create:
  - campaign personhood
  - consent
  - control
  - authorship
  - responsibility
  - executable domination/possession
  - model packets
model_authority_policy:
  authority: none
  allowed:
  - interpret visible input into proposal
  - narrate committed outcomes
  - present backend choices
  - ask safe clarification
  forbidden:
  - personhood determination
  - capacity waiver
  - consent validity
  - control assignment
  - refusal invention
  - responsibility/blame
  - agency mutation
current_runtime_disposition:
  exists:
  - backend authority invariants
  - state-owner reference skeleton
  - visibility tiers/redaction policies
  - RT-002A actor/NPC references
  - RT-002C narrow command declaration and legality statuses
  - RT-002E narrow event/delta record
  - RT-002F narrow audit receipt
  fixture_only:
  - actor
  - npc_target
  - actor_identity_owner
  - object/lever command and legality
  - safe references/projections
  conversion_only:
  - creature/NPC
  - companion/summon
  - faction/institution
  - source-local control/loyalty/relationship fields
  - runtime_candidate_action pressure
  missing:
  - all generalized AFQR-11 registries, owners, evaluators, projections, replay
  may_proceed:
  - read-only doctrine ratification
  - non-mutating dry run
  - narrow identity-only actor references
  - side-channel audit
  prohibited:
  - generalized agency mutation
  - consent creation
  - personhood assignment
  - control execution
  - responsibility punishment
  - model adjudication
required_artifacts:
  immediate:
  - master ratification
  - ADR
  - decision registry
  - terminology
  - typed contracts
  - operation grammar
  - 200-case adversarial pack
  - 45-case dry run
  - three stress graphs
  - conversion IR amendment
  - side-channel threat model
  before_agency_determination:
  - agency profile registry
  - agency evaluator contracts
  - action-origin candidate builder
  before_consent_validity:
  - capacity/consent profile registries
  - support/accommodation grammar
  - consent axis validators
  before_command_execution:
  - authority/representation registry
  - command interpretation/acceptance/refusal contracts
  - checkpoint rules
  before_domination_possession:
  - control dimension registry
  - possession/body-control fixtures
  - hidden-controller projections
  before_institutional_action:
  - collective procedure registry
  - office/representation/ratification contracts
  before_responsibility_attribution:
  - causal graph registry
  - responsibility profile registry
  - AFQR-06 conflict domains
  before_model_dialogue:
  - model-visible agency projection schema
  - grounding validator
  - cross-packet isolation tests
  before_mass_conversion:
  - 23 pressure IR records
  - gold donor-family fixtures
  - lawful outcome validators
  deferred:
  - full cognition
  - emotion/motivation
  - universal moral/legal doctrine
  - final control math
  - distributed performance
required_prototype:
  name: AFQR-11 Agency, Consent, Control, and Responsibility Determination Dry Run
  cases: 45
  mutating: false
  artifact: fixtures/afqr_11_non_mutating_dry_run.yaml
required_fixtures:
- 90 operation dispositions
- 200 adversarial scenarios A–GR
- three central stress cases
- side-channel noninterference suite
- historical replay fixtures
blocked_work:
- general NPC autonomy and cognition
- dialogue decision generation
- consent-sensitive action execution
- domination/possession runtime
- institutional/collective action engine
- responsibility consequence engine
- personhood adjudication
- general context packets containing agency data
- mass donor auto-registration of control rules
work_unlocked:
- architectural ratification
- non-mutating prototype
- registry/schema drafting
- conversion pressure extraction
- narrow RT-002 identity references after amendment
- AFQR-12 investigation
rejected_alternatives:
- single actor/controller field
- capability plus permission as complete model
- legal-person/owner hierarchy
- BDI as foundational agency law
- causal graph alone
- principal-agent graph alone
- unbounded layered model without profile registries
residual_risks:
- profile proliferation
- authoring burden
- hidden-control side channels
- cross-profile incomparability
- collective-procedure complexity
- copy/fusion/fission migration complexity
- source-local moral/legal conflict
- performance of graph discovery
- small-model projection errors
RT_002G_status: may_resume_narrowly_after_AFQR_01_11_artifact_ratification_and_AFQR_11_noninterference_amendment;
  actor references remain identity-only and authorize no agency inference
next_foundational_question:
  question_id: AFQR-12
  title: Goals, Values, Motivation, Emotion, Personality, Deliberation, Planning, and Behavioral Continuity
  exact_question: How should Astra represent and update goal formation, values, motivations, emotions, personality
    traits, deliberation, planning, habit, role pressure, and behavioral continuity without making the language
    model the cognition engine or collapsing internal state into deterministic stereotypes?
  priority_reason: AFQR-11 defines who may decide and control; the next missing dependency is how autonomous decision
    subjects form and maintain choices over time.
exact_next_roadmap_action: Ratify and register the AFQR-11 pack, run the 45-case non-mutating dry run and RT-002A–RT-002F
  agency-side-channel audit, then permit narrowly amended RT-002G while opening AFQR-12 as a read-only foundational
  investigation.
```
