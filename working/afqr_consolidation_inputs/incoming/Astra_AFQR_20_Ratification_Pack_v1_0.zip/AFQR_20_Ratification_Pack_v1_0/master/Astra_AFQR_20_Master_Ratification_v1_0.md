# Astra AFQR-20 Master Ratification v1.0

Generated: 2026-07-19T01:29:41+00:00

Repository commit inspected: `928bb79ce00a2de749d127dcc5cb8299de788a15`

## Part I — Executive decision

**Selected architecture:** Registered Federated Signal–Sensing–Acquisition Architecture with Typed Source–Modality–Propagation Ownership, Staged Exposure–Acquisition–Detection–Recognition Pipelines, Observer-Relative Concealment–Countermeasure Profiles, and Bitemporal Contact–Track–Evidence Continuity  
**Abbreviation:** `RFSSA-SMP-SEADR-OCCP-BCTEC`  
**Confidence:** High  
**Resolution:** Sufficiently resolved for architectural ratification.

> No world fact, signal label, visibility flag, sensor reading, search declaration, contact, track, donor rule, public report, or model narration creates authoritative detection, recognition, identification, belief, knowledge, target eligibility, or disclosure by itself. Every authoritative sensing result is a purpose-, audience-, and time-scoped, version-pinned determination over frozen signal, propagation, sensor, attention, identity, epistemic, agency, behavioral, social, communication, institutional, embodiment, environmental, spatial, capability-and-action, governed-relation, quantity, scheduler, concealment, search, tracking, and fusion bases. AFQR-20 produces sensing, observation, evidence, contact, and track candidates only; AFQR-10 and AFQR-19 may accept, reject, qualify, or require revalidation, and only AFQR-01 commits accepted owner fragments. Narration follows audience-visible committed records and never expands them.

This architecture is a donor-neutral ownership, pipeline, interface, security, materialization, and replay framework. It is not a final perception statistic, stealth roll, tactical visibility algorithm, sensor equation, search procedure, divination ontology, or runtime implementation. Another broad research pass is not required; family-specific calibration and certification research remains mandatory.

## Part II — Repository-grounded diagnosis

The exact repository commit inspected is `928bb79ce00a2de749d127dcc5cb8299de788a15`, the merge of PR #325 / RT-002F. The repository is still foundation-building. Its README assigns truth, RNG, hidden-state partitioning, consequence commitment, persistence, and replay to the future backend. RT-002B is a visibility-classification adapter over a narrow read-only fixture. It does not model signal sources, propagation, sensors, attention, detection, recognition, search, contacts, tracks, fusion, or surveillance.

Implemented facts must therefore be separated from accepted AFQR doctrine. The only current sensing-adjacent executable behavior is projection classification and redaction for the tiny vertical slice. Insight, assessment, visibility, hidden, perception, search, investigation, sensor, stealth, and discovery labels elsewhere are doctrine, conversion, schema, fixture, or narrative descriptors.

| # | Investigation question | Status | Determination |
|---:|---|---|---|
| 1 | Are signal sources represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 2 | Are signal occurrences distinct from world facts? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 3 | Are modalities and carriers represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 4 | Is signal propagation represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 5 | Are environmental and spatial propagation inputs separated? | accepted_architectural_handoff_not_implemented | The accepted AFQR architecture supplies a lawful separation or handoff, but no generalized runtime implementation is present at the inspected commit. |
| 6 | Are sensors represented authoritatively? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 7 | Are sensor owners, operators, observers, and evidence recipients separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 8 | Are sensor activation and function represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 9 | Are calibration, orientation, coverage, resolution, and latency represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 10 | Are false positives and false negatives represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 11 | Is attention represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 12 | Are attention, wakefulness, awareness, and behavioral focus separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 13 | Are passive and active sensing separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 14 | Are detection stages separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 15 | Are detection, localization, recognition, identification, and tracking separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 16 | Are observations separated from beliefs and knowledge? | accepted_architectural_handoff_not_implemented | The accepted AFQR architecture supplies a lawful separation or handoff, but no generalized runtime implementation is present at the inspected commit. |
| 17 | Are target contacts represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 18 | Are tracks represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 19 | Are track identity and target identity separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 20 | Are concealment and stealth represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 21 | Are concealment families separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 22 | Are invisibility and undetectability separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 23 | Are disguise and identity separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 24 | Are illusions represented without automatic false belief? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 25 | Are jamming and spoofing separated? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 26 | Are search actions represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 27 | Are search coverage and completeness represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 28 | Can failed search avoid proving absence? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 29 | Is sensor fusion represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 30 | Is conflicting evidence preserved? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 31 | Is surveillance represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 32 | Are technical sensing and institutional authority separated? | accepted_architectural_handoff_not_implemented | The accepted AFQR architecture supplies a lawful separation or handoff, but no generalized runtime implementation is present at the inspected commit. |
| 33 | Are hidden sensing results audience-scoped? | narrow_fixture_only | RT-002A/RT-002B provide audience- and visibility-classified projection handling for a tiny vertical slice, including redacted and unknown packets, but they do not model signals, sensors, detection, search, contacts, tracks, or perception. |
| 34 | Can hidden targets remain invisible to the model? | narrow_fixture_only | RT-002A/RT-002B provide audience- and visibility-classified projection handling for a tiny vertical slice, including redacted and unknown packets, but they do not model signals, sensors, detection, search, contacts, tracks, or perception. |
| 35 | Can option counts avoid leaking concealed entities? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 36 | Are target-contact handoffs to action resolution represented? | accepted_architectural_handoff_not_implemented | The accepted AFQR architecture supplies a lawful separation or handoff, but no generalized runtime implementation is present at the inspected commit. |
| 37 | Are sensing retries idempotent? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 38 | Is backend-owned randomness available? | future_backend_requirement_not_implemented | The repository doctrine assigns RNG authority to the future backend, but no generalized sensing RNG service or receipt path exists. |
| 39 | Are sensing simulation tiers represented? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 40 | Can promotion preserve unknown detection history? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 41 | Are observations bitemporal? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 42 | Can delayed sensing preserve event and reception time? | absent | No generalized authoritative implementation was found. Any similarly named fields are conversion, schema, doctrine, projection, or fixture surfaces only. |
| 43 | Are source-local senses contained? | accepted_architectural_handoff_not_implemented | The accepted AFQR architecture supplies a lawful separation or handoff, but no generalized runtime implementation is present at the inspected commit. |
| 44 | Can no lawful sensing profile apply? | accepted_architectural_handoff_not_implemented | The accepted AFQR architecture supplies a lawful separation or handoff, but no generalized runtime implementation is present at the inspected commit. |
| 45 | Are Insight or assessment fields authoritative, provisional, or narrative? | doctrine_conversion_or_narrative_only | Related labels exist in doctrine, conversion schemas, examples, or narrative descriptors. They are not authoritative sensing state and do not authorize runtime execution. |
| 46 | Does current visibility metadata prove generalized sensing? | narrow_fixture_only | RT-002A/RT-002B provide audience- and visibility-classified projection handling for a tiny vertical slice, including redacted and unknown packets, but they do not model signals, sensors, detection, search, contacts, tracks, or perception. |
| 47 | Which fields are conversion-only? | doctrine_conversion_or_narrative_only | Related labels exist in doctrine, conversion schemas, examples, or narrative descriptors. They are not authoritative sensing state and do not authorize runtime execution. |
| 48 | Which are fixture-only? | narrow_fixture_only | RT-002A/RT-002B provide audience- and visibility-classified projection handling for a tiny vertical slice, including redacted and unknown packets, but they do not model signals, sensors, detection, search, contacts, tracks, or perception. |
| 49 | Which are narrative-only? | doctrine_conversion_or_narrative_only | Related labels exist in doctrine, conversion schemas, examples, or narrative descriptors. They are not authoritative sensing state and do not authorize runtime execution. |
| 50 | What sensing execution remains blocked? | blocked | Authoritative signal production, propagation, sensor readiness, attention-task execution, detection, localization, recognition, identification, search, tracking, fusion, surveillance, evidence adoption, and target-contact execution remain blocked. |

**Blocked:** all generalized authoritative signal production, sensor state, attention-task allocation, detection, recognition, identification, search, track, fusion, surveillance, evidence adoption, target contact, and model-facing sensing execution.

## Part III — External research synthesis

The research supports a staged, uncertain, provenance-bearing architecture rather than one perception score. Signal-detection theory requires hits, misses, false alarms, and correct rejections. Metrology requires calibration and uncertainty. Sensor engineering requires multidimensional readiness. Search theory requires bounded coverage and stopping rules. Tracking and fusion require data association, continuity, conflict preservation, and uncertainty. Intelligence and forensic systems separate collection from evidence and dissemination.

| ID | Family | Actual mechanism | Astra lesson | Limitation | Disposition |
|---|---|---|---|---|---|
| RES-01 | 10.1 Signal-detection theory | Separates sensitivity from decision criterion and distinguishes hit, miss, false alarm, and correct rejection through ROC analysis. | Represent detection profiles with explicit confusion outcomes, criterion, uncertainty, and purpose; never treat failure as absence. | Classical SDT assumes a specified signal/noise framing and does not supply propagation, recognition, or identity semantics. | adapt |
| RES-02 | 10.2 Measurement and metrology | Measurement results require calibration, uncertainty, traceability, repeatability, resolution, bias, and validity conditions. | Sensor readings and derived estimates must carry calibration version, uncertainty, method, units, and provenance. | Metrology does not decide game-world epistemic adoption or source-local magical measurement. | adopt_and_adapt |
| RES-03 | 10.3 Sensor engineering | Sensor behavior is multidimensional: activation, sensitivity, selectivity, dynamic range, saturation, sampling, quantization, latency, drift, and failure modes. | Model sensor readiness as a vector and keep sensor exposure, response, acquisition, and detection distinct. | No single engineering transfer function spans biological, psychic, magical, and conceptual sensors. | adapt |
| RES-04 | 10.4 Radar, sonar, lidar, and remote sensing | Active and passive systems differ; range and angular resolution, clutter, attenuation, Doppler, false contacts, tracking, and countermeasures are separate concerns. | Use modality-specific profiles and propagation closure; contacts may be bearing-only, range-only, region-valued, delayed, or false. | Equations and Earth media are platform-specific and cannot become universal Astra sensing law. | contain_and_adapt |
| RES-05 | 10.5 Computer vision | Detection, segmentation, classification, recognition, identification, tracking, confidence, occlusion, and adversarial inputs are separate pipeline stages. | Preserve staged determinations and profile-specific confidence; machine output is evidence, not identity truth. | Dataset and model limitations make computer-vision assumptions unsuitable as universal biological perception. | adapt |
| RES-06 | 10.6 Auditory and acoustic perception | Localization depends on binaural and monaural cues, frequency, intensity, reverberation, masking, and scene segregation. | Acoustic path availability does not ensure source separation or localization; represent mixtures and observer-relative uncertainty. | Human auditory mechanisms do not govern synthetic, alien, or magical hearing. | adapt |
| RES-07 | 10.7 Olfactory and chemical sensing | Detection depends on concentration, mixtures, transport, adaptation, plume structure, persistence, and threshold variability; source localization is a separate process. | Use AFQR-17 transport inputs and distinguish plume acquisition, detection, tracking, and source declaration. | Odor detection is not a reliable universal proxy for toxic exposure or exact source location. | adapt |
| RES-08 | 10.8 Human attention and perception | Selective/divided attention, vigilance, orienting, inattentional blindness, change blindness, perceptual load, and top-down influences affect sampling and awareness. | Separate physiological wakefulness, voluntary attention choice, sensing-task allocation, sampling, and detection. | Human cognition cannot be universalized to machines, swarms, spirits, or source-local entities. | adapt |
| RES-09 | 10.9 Psychophysics | Thresholds, discrimination, adaptation, scaling, observer variation, and Weber-like relations are modality- and range-specific. | Detection and discrimination profiles may use qualified psychophysical functions without one universal perception scale. | Simple threshold laws break outside their calibration domain and do not establish recognition or belief. | contain |
| RES-10 | 10.10 Cognitive science of recognition | Classification, familiarity, recognition, and identification are context-sensitive and fallible; unfamiliar-person recognition is especially error-prone. | Keep recognition purpose-scoped, candidate-based, evidence-backed, and distinct from identity continuity and belief adoption. | Human face/object recognition does not define nonhuman or machine recognition. | adapt |
| RES-11 | 10.11 Search theory | Search effectiveness depends on area, effort allocation, coverage, target movement, repeated sampling, false reports, and stopping criteria. | Represent coverage, sampling, completeness, effort, and stopping conditions; no detection within coverage is not global absence. | Operational search models require calibrated detection functions and domain-specific movement assumptions. | adapt |
| RES-12 | 10.12 Tracking and estimation | Tracking involves initiation, data association, state estimation, prediction, uncertainty, maintenance, split/merge, loss, and reacquisition. | Treat tracks as operational hypotheses with lineage, confidence, identity candidates, and time-scoped estimates—not target truth. | Specific filters and motion models are domain-dependent and should remain profile-local. | adapt |
| RES-13 | 10.13 Sensor fusion | Fusion requires correlation, data association, duplicate suppression, uncertainty propagation, provenance, and preservation of conflicting inputs. | Fuse candidate evidence without deleting source records or manufacturing certainty; correlated failures must remain visible. | Fusion algorithms are assumption-heavy and may fail under adversarial or source-local modalities. | adapt |
| RES-14 | 10.14 Surveillance and intelligence systems | Collection, tasking, processing, exploitation, dissemination, source reliability, confidence, classification, access, and audit are distinct stages. | Separate technical sensing, collection, recording, access, analysis, dissemination, and institutional authority. | Real-world intelligence doctrine carries legal and organizational assumptions that Astra cannot universalize. | contain_and_adapt |
| RES-15 | 10.15 Electronic warfare and countermeasures | Emission control, signature management, jamming, spoofing, decoys, passive detection, anti-jamming, and counter-detection affect different sensing stages. | Countermeasures must declare whether they alter production, propagation, sensor response, acquisition, classification, or data association. | Military taxonomies are context-specific and do not cover every magical or conceptual countermeasure. | adapt |
| RES-16 | 10.16 Cybersecurity monitoring | Logs, telemetry, alerts, anomaly detection, correlation, provenance, observability gaps, evasion, tampering, and false positives are separate. | Network events require explicit logical carriers and routes; alerts are observations, not proof of intrusion or physical presence. | Cyber observability is not physical sensing without a registered bridge. | adapt |
| RES-17 | 10.17 Robotics and autonomous perception | Autonomous systems separate sensor acquisition, localization, mapping, obstacle detection, tracking, active perception, degraded modes, and shared control. | Support active sensing, map uncertainty, sensor degradation, and operator/observer/controller separation. | Robotics pipelines usually assume engineered coordinate and sensor models and cannot define source-local metaphysics. | adapt |
| RES-18 | 10.18 Forensics and investigation | Trace collection requires sampling discipline, chain of custody, contamination control, analytical uncertainty, alternative hypotheses, and source-attribution limits. | Collection and analysis produce AFQR-10 evidence candidates; they do not create facts, beliefs, guilt, or identity automatically. | Real-world forensic validity varies by method and jurisdiction; Astra must profile methods rather than assume certainty. | adapt |
| RES-19 | 10.19 Camouflage, concealment, and signature management | Concealment can be multispectral and observer-relative; movement discipline, environmental blending, signature reduction, and decoys affect different modalities. | Represent modality-, stage-, observer-class-, purpose-, and interval-specific concealment profiles. | Military visual/thermal/radar models do not cover social disguise, psychic concealment, or magical invisibility. | adapt |
| RES-20 | 10.20 Illusions, deception, and adversarial perception | Illusions, hallucinations, spoofed sensors, adversarial inputs, mimicry, false trails, and confabulation occur at different layers. | Tag the deception layer: signal occurrence, sensor input, percept, interpretation, memory, record, or source-local reality transition. | No single deception ontology covers physical, cognitive, social, computational, and magical cases. | contain_and_adapt |
| RES-21 | 10.21 Distributed systems and event observability | Logs and traces are delayed, duplicated, missing, clock-skewed, and correlation-dependent; observability is not system truth. | Store event time, reception time, record time, causality refs, deduplication, and unverifiable replay status. | Software telemetry concepts need adaptation for biological and metaphysical sensing. | adapt |
| RES-22 | 10.22 Games and simulation systems | Game engines commonly separate stimuli sources, listeners, sensing configurations, perceived actors, age/strength, last-known locations, and fog-of-war projections. | Use authoritative stimulus/sensor/contact state with audience projections, but do not let engine convenience types become universal sensing law. | Engine implementations are optimized for specific genres and real-time performance. | adapt |
| RES-23 | 10.23 TTRPG systems | TTRPGs variously use passive scores, opposed rolls, observer-relative conditions, search actions, automatic senses, clocks, and source-local divination. | Treat each as donor pressure and decompose signal, propagation, sensor, attention, detection, recognition, search coverage, evidence, and target handoff. | Rules often collapse multiple stages for table speed and cannot be imported as universal runtime doctrine. | contain |

The authoritative source bibliography and adoption records are in `research/external_research_synthesis.yaml`.

## Part IV — Canonical terminology

### Signal terms
- **signal:** A typed, temporally scoped physical, informational, metaphysical, or source-local pattern capable of participating in a registered sensing interface; it is not the underlying world fact or an observation.
- **signal source:** The identity-scoped world entity, event, process, relation, record, or source-local construct from which a signal occurrence is attributed.
- **signal occurrence:** A particular emitted, reflected, leaked, deposited, transmitted, or residual signal event with event-time provenance.
- **signal content:** A typed AFQR-20 concept for signal content, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **signature:** A typed AFQR-20 concept for signature, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **trace:** A typed AFQR-20 concept for trace, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **residue:** A typed AFQR-20 concept for residue, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **emission:** A typed AFQR-20 concept for emission, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **reflection:** A typed AFQR-20 concept for reflection, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **transmission:** A typed AFQR-20 concept for transmission, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **leakage:** A typed AFQR-20 concept for leakage, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **carrier:** A typed AFQR-20 concept for carrier, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **modality:** A typed AFQR-20 concept for modality, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **channel:** A typed AFQR-20 concept for channel, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **propagation:** A typed AFQR-20 concept for propagation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **attenuation:** A typed AFQR-20 concept for attenuation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **interference:** A typed AFQR-20 concept for interference, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **noise:** A typed AFQR-20 concept for noise, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **clutter:** A typed AFQR-20 concept for clutter, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **distortion:** A typed AFQR-20 concept for distortion, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **latency:** A typed AFQR-20 concept for latency, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **signal availability.:** A typed AFQR-20 concept for signal availability., qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
### Sensor terms
- **sensor:** A registered biological, synthetic, remote, distributed, institutional, or source-local mechanism whose interface can respond to compatible signal exposures.
- **sensing interface:** A typed AFQR-20 concept for sensing interface, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **observer:** The subject or system for whose sensing state a response, contact, or observation candidate is evaluated; not necessarily sensor owner, operator, or evidence recipient.
- **sensor owner:** A typed AFQR-20 concept for sensor owner, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sensor operator:** A typed AFQR-20 concept for sensor operator, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **evidence recipient:** A typed AFQR-20 concept for evidence recipient, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sensor activation:** A typed AFQR-20 concept for sensor activation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sensor configuration:** A typed AFQR-20 concept for sensor configuration, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **calibration:** A typed AFQR-20 concept for calibration, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sensitivity:** A typed AFQR-20 concept for sensitivity, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **selectivity:** A typed AFQR-20 concept for selectivity, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **resolution:** A typed AFQR-20 concept for resolution, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **coverage:** A typed AFQR-20 concept for coverage, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **dynamic range:** A typed AFQR-20 concept for dynamic range, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sampling:** A typed AFQR-20 concept for sampling, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sensor response:** A typed AFQR-20 concept for sensor response, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sensor saturation:** A typed AFQR-20 concept for sensor saturation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sensor impairment.:** A typed AFQR-20 concept for sensor impairment., qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
### Attention terms
- **alertness:** A typed AFQR-20 concept for alertness, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **wakefulness:** A typed AFQR-20 concept for wakefulness, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **attention:** A purpose- and interval-scoped allocation of sensing-task processing capacity; not wakefulness, awareness, curiosity, or guaranteed sampling.
- **focus:** A typed AFQR-20 concept for focus, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **orientation:** A typed AFQR-20 concept for orientation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **vigilance:** A typed AFQR-20 concept for vigilance, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **divided attention:** A typed AFQR-20 concept for divided attention, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **passive monitoring:** A typed AFQR-20 concept for passive monitoring, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **active sensing:** A typed AFQR-20 concept for active sensing, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sensing task:** A typed AFQR-20 concept for sensing task, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **observation window:** A typed AFQR-20 concept for observation window, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **scan:** A typed AFQR-20 concept for scan, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sampling window.:** A typed AFQR-20 concept for sampling window., qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
### Acquisition terms
- **acquisition:** A typed AFQR-20 concept for acquisition, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **detection:** A registered determination that an acquired sensor response satisfies a detection profile; not localization, recognition, identification, belief, or target eligibility.
- **discrimination:** A typed AFQR-20 concept for discrimination, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **localization:** A typed AFQR-20 concept for localization, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **classification:** A typed AFQR-20 concept for classification, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **recognition:** A purpose-scoped comparison that supports a class, type, role, object, body, voice, or familiarity candidate from admissible features.
- **identification:** A purpose-scoped identity-candidate determination tied to AFQR-08 identity facets and uncertainty; not legal identity or belief adoption.
- **contact:** An observer-relative operational sensing record representing detected or otherwise qualified signal evidence, possibly without identity or location.
- **target contact:** A typed AFQR-20 concept for target contact, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **observation:** An AFQR-10-owned epistemic record candidate grounded in sensing evidence; not the sensing process itself or guaranteed truth.
- **percept:** A qualified representation of sensed input for an observer, where the profile supports such a layer; not automatically a belief.
- **evidence candidate:** A typed AFQR-20 concept for evidence candidate, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **detection confidence:** A typed AFQR-20 concept for detection confidence, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **false positive:** A typed AFQR-20 concept for false positive, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **false negative:** A typed AFQR-20 concept for false negative, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **correct rejection:** A typed AFQR-20 concept for correct rejection, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **missed detection.:** A typed AFQR-20 concept for missed detection., qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
### Concealment terms
- **concealment:** An observer-, modality-, stage-, purpose-, and time-relative counter-detection relation; not universal hiddenness.
- **occlusion:** A typed AFQR-20 concept for occlusion, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **camouflage:** A typed AFQR-20 concept for camouflage, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **masking:** A typed AFQR-20 concept for masking, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **clutter exploitation:** A typed AFQR-20 concept for clutter exploitation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **signature reduction:** A typed AFQR-20 concept for signature reduction, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **emission control:** A typed AFQR-20 concept for emission control, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **silence:** A typed AFQR-20 concept for silence, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **invisibility:** A profile that suppresses or alters specified signal modalities or sensing stages; not absence, incorporeality, universal undetectability, or immunity to targeting.
- **disguise:** A typed AFQR-20 concept for disguise, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **jamming:** A typed AFQR-20 concept for jamming, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **spoofing:** A typed AFQR-20 concept for spoofing, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **decoy:** A typed AFQR-20 concept for decoy, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **false trail:** A typed AFQR-20 concept for false trail, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **anti-sensing:** A typed AFQR-20 concept for anti-sensing, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **anti-divination:** A typed AFQR-20 concept for anti-divination, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **source-local concealment.:** A typed AFQR-20 concept for source-local concealment., qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
### Search terms
- **search:** A bounded, method-defined, area- or corpus-scoped sensing activity with explicit coverage, sampling, depth, time, resources, and stopping conditions.
- **search method:** A typed AFQR-20 concept for search method, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **search area:** A typed AFQR-20 concept for search area, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **search plan:** A typed AFQR-20 concept for search plan, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **search coverage:** A typed AFQR-20 concept for search coverage, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **search depth:** A typed AFQR-20 concept for search depth, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **sample:** A typed AFQR-20 concept for sample, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **inspection:** A typed AFQR-20 concept for inspection, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **investigation:** A typed AFQR-20 concept for investigation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **scan:** A typed AFQR-20 concept for scan, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **survey:** A typed AFQR-20 concept for survey, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **reconnaissance:** A typed AFQR-20 concept for reconnaissance, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **forensic examination:** A typed AFQR-20 concept for forensic examination, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **discovery candidate:** A typed AFQR-20 concept for discovery candidate, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **search completeness:** A typed AFQR-20 concept for search completeness, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **stopping condition.:** A typed AFQR-20 concept for stopping condition., qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
### Tracking terms
- **track:** A bitemporal operational hypothesis that correlates contacts or observations across time; it is not authoritative target state.
- **track state:** A typed AFQR-20 concept for track state, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **tentative track:** A typed AFQR-20 concept for tentative track, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **confirmed track:** A typed AFQR-20 concept for confirmed track, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **track identity candidate:** A typed AFQR-20 concept for track identity candidate, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **track position estimate:** A typed AFQR-20 concept for track position estimate, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **track confidence:** A typed AFQR-20 concept for track confidence, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **track continuity:** A typed AFQR-20 concept for track continuity, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **track split:** A typed AFQR-20 concept for track split, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **track merge:** A typed AFQR-20 concept for track merge, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **track handoff:** A typed AFQR-20 concept for track handoff, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **track prediction:** A typed AFQR-20 concept for track prediction, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **lost contact:** A typed AFQR-20 concept for lost contact, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **reacquisition:** A typed AFQR-20 concept for reacquisition, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **false track.:** A typed AFQR-20 concept for false track., qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
### Fusion and surveillance terms
- **sensor fusion:** A typed AFQR-20 concept for sensor fusion, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **observation correlation:** A typed AFQR-20 concept for observation correlation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **data association:** A typed AFQR-20 concept for data association, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **duplicate observation:** A typed AFQR-20 concept for duplicate observation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **conflicting observation:** A typed AFQR-20 concept for conflicting observation, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **surveillance:** A tasking and collection arrangement for repeated or persistent sensing; technical execution, recording, access, dissemination, authority, and legitimacy remain separate.
- **monitoring:** A typed AFQR-20 concept for monitoring, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **collection:** A typed AFQR-20 concept for collection, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **recording:** A typed AFQR-20 concept for recording, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **retrospective review:** A typed AFQR-20 concept for retrospective review, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **classification:** A typed AFQR-20 concept for classification, qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
- **dissemination.:** A typed AFQR-20 concept for dissemination., qualified by owner, purpose, modality or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.

Runtime use of visible, hidden, detected, identified, known, search complete, nothing there, stealthed, invisible, target acquired, or exact position is prohibited unless observer, purpose, modality, time, profile, uncertainty, and audience are qualified.

## Part V — Signals, sources, modalities, carriers, and production

A signal is not the underlying fact. Signal production is represented through registered definitions and occurrences with source identity, modality, content/signature, production profile, event time, continuity, provenance, and source-local namespace. Emission, reflection, transmission, leakage, induced production, residual traces, recorded traces, spoofed production, and source-local production remain distinct. One source may produce several modalities and several sources may produce similar signals. Intentional communication signals hand off to AFQR-14 rather than acquiring semantic meaning inside AFQR-20.

## Part VI — Propagation, media, spatial paths, and interfaces

AFQR-20 requests propagation closure but does not own environmental media or spatial truth. AFQR-17 supplies medium, field, noise, weather, transport, and boundary-environment state. AFQR-18 supplies positions, spatial supports, paths, boundaries, portals, sensor geometry, and uncertainty. Registered sensing profiles evaluate direct, reflected, refracted, scattered, diffracted, conducted, network, portal, sympathetic, psychic, magical, delayed, stored-trace, and source-local routes. The result is a sensor-interface exposure candidate with attenuation, interference, delay, transformation, and termination evidence—not a detection.

## Part VII — Sensors, readiness, calibration, and performance

Sensor definitions and instances are separate from sensory capabilities, sensing interfaces, observers, owners, operators, and evidence recipients. Readiness is a multidimensional, purpose- and interval-scoped assessment over activation, power, function, components, calibration, configuration, orientation, coverage, resolution, sensitivity, selectivity, latency, sampling, dynamic range, saturation, connectivity, and source-local constraints. AFQR-16 owns embodied sensory function. AFQR-19 owns capability readiness where invocation is an action; AFQR-20 consumes certified references and evaluates sensing-specific performance.

## Part VIII — Attention, sensing tasks, sampling, and observation windows

Wakefulness and physiological alertness remain AFQR-16-owned. Voluntary attention choice, search strategy, and vigilance policy remain AFQR-11/12-owned. AFQR-20 owns the execution record for an authorized sensing task: channel allocation, sensor set, scan pattern, observation window, sampling schedule, divided attention, interruption, passive monitoring, and automatic policy. Attention does not create signal exposure, acquisition, or detection.

## Part IX — Acquisition, detection, discrimination, and localization

The canonical sensing chain is optional and staged: interface exposure → sensor response → sampling → acquisition → detection → discrimination → localization → classification. Profiles may be deterministic, stochastic, opposed, accumulated-evidence, repeated-sampling, automatic, resource-spend, multi-stage, or source-local. False positives and false negatives are first-class. Localization may be bearing-only, range-only, region-valued, uncertain, triangulated, track-based, or unsupported. AFQR-18 remains authoritative for target position.

## Part X — Recognition, identification, contacts, and epistemic handoffs

Recognition is purpose-scoped classification or familiarity evidence. Identification is an AFQR-08 identity-candidate determination; it is not belief, legal identity, or truth. Contacts are observer-relative operational records that may lack location, class, or identity. AFQR-20 packages provenance-complete evidence candidates for AFQR-10, which may accept, qualify, reject, or quarantine them. No belief or knowledge mutation occurs in AFQR-20.

## Part XI — Concealment, camouflage, stealth, jamming, spoofing, and illusions

Counter-detection families bind explicitly to affected modalities and stages. Occlusion alters path availability; camouflage alters discrimination or classification; masking and clutter affect signal-to-noise; signature reduction and emission control affect production; jamming affects noise, response, acquisition, or saturation; spoofing creates or transforms false inputs; decoys are distinct entities that may receive contacts or tracks; disguise affects recognition evidence; invisibility suppresses named modalities or stages; anti-divination blocks source-local bridges. Illusions must identify whether they create signals, sensor inputs, percept candidates, interpretations, memories, records, or source-local reality changes. Stealth is an observer-relative process, never one global hidden flag.

## Part XII — Search, inspection, investigation, and forensics

Searches have explicit objective, area or corpus, target profile, method, sensor set, coverage plan, sampling plan, depth, duration, resources, candidate budget, and stopping conditions. Results distinguish found, partial coverage, no detection within sampled coverage, incomplete, interrupted, hidden, or unresolved. Failed search never proves absence unless a certified completeness profile supports that narrow conclusion. Investigation and forensic methods collect trace/sample records and produce AFQR-10 evidence and alternative-hypothesis candidates with chain-of-custody and contamination state.

## Part XIII — Tracking, data association, sensor fusion, and surveillance

Tracks are bitemporal operational hypotheses over contacts. They support tentative/confirmed state, identity candidates, localization and motion estimates, confidence, prediction, split, merge, handoff, loss, reacquisition, false tracks, and decoy association. Fusion preserves input provenance, duplicates, associations, conflicts, correlated failure, and uncertainty. Surveillance separates authority, tasking, sensor set, collection, recording, access, review, analysis, classification, and dissemination. Technical collection does not establish legitimacy or knowledge.

## Part XIV — AFQR-10 and AFQR-19 handoffs

AFQR-10 receives `SensingEvidenceCandidate`, provenance, observation-owner, uncertainty, and interpretation-prohibition records; it controls evidence acceptance, observation records, beliefs, memories, knowledge, secrecy, and disclosure. AFQR-19 receives time- and audience-scoped contact, detection, localization, recognition, identification, and tracking references. It may reject or require revalidation. Detection does not select a target, establish eligibility, open a reaction, authorize pursuit, or permit combat.

## Part XV — Sensing simulation tiers

The tiers are `descriptive_visibility_reference`, `aggregate_contact_state`, `observer_contact_network`, `materialized_sensor_state`, `detailed_signal_acquisition`, and `full_sensing_fixture`. Authority partitions are explicit. Promotion materializes only certified current detail and never invents historical readings, misses, searches, contacts, tracks, or concealed entities. Aggregate and detailed tiers may not double-detect. Demotion retains committed observations, tracks, resources, and unresolved history.

## Part XVI — Hidden sensing state and model projection

Private signal, detection, search, track, and surveillance receipts are audience-scoped. Visible packets use opaque audience tokens and projection-specific keyed digests. Candidate counts, option counts, search depth, track confidence, sensor activation, sensor weakness, processing time, and stable public hashes must not reveal concealed state. The model receives a closed grounding manifest and permitted claim registry. Every generated signal, detection, identity, search-discovery, or tracking claim requires evidence binding. Prompt instructions are not the security boundary; semantic validation and retrieval isolation are mandatory.

## Part XVII — Typed contracts

The binding catalog contains **261** schema-level definitions, including every contract requested in the AFQR-20 prompt. Each record identifies required, optional, hidden, derived, and prohibited fields; owner; references; profile versions; record-specific temporal semantics; cross-domain bases; security fields; determinism requirements; AFQR references; invariants; and lawful absence results.

| Contract family | Count |
|---|---:|
| acquisition_detection | 14 |
| attention_task | 11 |
| concealment | 15 |
| contact | 14 |
| countermeasure | 10 |
| epistemic_handoff | 8 |
| fusion | 11 |
| handoff | 1 |
| investigation_forensics | 12 |
| localization_classification | 13 |
| modality_carrier | 9 |
| private_security | 14 |
| propagation | 11 |
| recognition_identification | 14 |
| search | 15 |
| sensing_core | 1 |
| sensor_performance | 15 |
| sensor_registry | 9 |
| signal | 10 |
| signal_production | 9 |
| simulation_tier | 8 |
| stealth | 9 |
| surveillance | 12 |
| tracking | 16 |

Binding artifact: `contracts/afqr_20_typed_contract_catalog.yaml`.

## Part XVIII — Determination pipelines

| # | Pipeline | Determination flow |
|---:|---|---|
| 1 | Signal production | world event/source → source/modality/signature closure → production determination → signal occurrence → provenance; no observation |
| 2 | Propagation | signal occurrence → carrier/path/medium/boundaries → attenuation/noise/delay/transformation → sensor exposure; no detection |
| 3 | Sensor readiness | sensor/purpose → capability/power/function/calibration/configuration/orientation/coverage/time → readiness vector |
| 4 | Attention/task | authorized task/policy → sensor/channel/window/scan allocation → sampling schedule; no guaranteed acquisition |
| 5 | Acquisition/detection | exposure → response → sampling → acquisition → registered detection → hit/miss/false positive/false negative/unresolved |
| 6 | Localization | detected input → method/geometry/timing → bearing/range/region/uncertain support → AFQR-10 evidence |
| 7 | Recognition/identification | features/references/candidates → classification/recognition/identification → ambiguous evidence; no belief |
| 8 | Concealment interaction | signal/sensing attempt → stage-specific countermeasures → transformed candidates with provenance |
| 9 | Search | legal attempt → objective/area/method/coverage/sampling/resources → bounded execution → coverage/result receipt |
| 10 | Tracking | contacts → association/prior track/motion model → update/split/merge/loss/reacquisition → AFQR-19 contact handoff |
| 11 | Fusion | multiple inputs → provenance/timing/uncertainty → dedup/association/conflict preservation → fused candidate |
| 12 | Surveillance | authority/policy → tasking/sensors/coverage/schedule/recording/access → collection records |
| 13 | AFQR-10 handoff | sensing result → provenance-complete evidence candidate → accept/qualify/reject/quarantine |
| 14 | AFQR-19 handoff | contact/track state → time/audience-scoped reference → accept/reject/revalidate; no target selection |
| 15 | Tier transition | freeze authority partitions → certified materialization/demotion → reconcile without invented history or double detection |

## Part XIX — Operation grammar

| # | Operation | Lawful result | Ownership boundary |
|---:|---|---|---|
| 1 | source emits signal | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 2 | source reflects signal | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 3 | source leaks signal | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 4 | event leaves residual trace | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 5 | signal production is suppressed | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 6 | signal uses incompatible modality | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 7 | signal enters environmental medium | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 8 | propagation path exists | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 9 | propagation is blocked | record_bounded_failure_or_incomplete_state_without_negative_truth_inference | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 10 | propagation is attenuated | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 11 | signal is delayed | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 12 | signal is reflected | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 13 | signal is transformed | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 14 | noise increases | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 15 | interference occurs | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 16 | sensor is active | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 17 | sensor is unpowered | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 18 | sensor is impaired | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 19 | sensor is miscalibrated | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 20 | sensor is saturated | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 21 | sensor orientation is valid | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 22 | target lies outside coverage | record_bounded_failure_or_incomplete_state_without_negative_truth_inference | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 23 | sampling begins | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 24 | sampling is interrupted | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 25 | passive monitoring applies | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 26 | voluntary attention is allocated | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 27 | attention is divided | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 28 | signal reaches sensor interface | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 29 | sensor responds | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 30 | acquisition occurs | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 31 | detection succeeds | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 32 | detection fails | record_bounded_failure_or_incomplete_state_without_negative_truth_inference | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 33 | false positive occurs | commit_private_false_positive_detection_receipt_without_target_truth | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 34 | false negative occurs | commit_private_missed_detection_receipt_without_proving_absence | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 35 | two signals are discriminated | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 36 | signals remain unresolved mixture | preserve_multiple_candidates_or_conflict_without_forced_certainty | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 37 | bearing is estimated | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 38 | region-valued localization occurs | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 39 | exact localization is unsupported | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 40 | class is recognized | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 41 | identity candidate is generated | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 42 | identification remains ambiguous | preserve_multiple_candidates_or_conflict_without_forced_certainty | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 43 | disguise changes recognition result | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 44 | illusion creates a false signal candidate | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 45 | invisibility suppresses one modality | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 46 | alternate modality still detects target | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 47 | camouflage reduces discrimination | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 48 | occlusion blocks visual path | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 49 | masking hides signal in clutter | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 50 | jamming degrades acquisition | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 51 | spoofing creates false contact | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 52 | decoy receives track association | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 53 | anti-divination blocks source-local bridge | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 54 | stealth attempt reduces signature | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 55 | stealth attempt fails against one observer | record_bounded_failure_or_incomplete_state_without_negative_truth_inference | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 56 | stealth remains effective against another observer | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 57 | search begins | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 58 | search coverage expands | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 59 | search area remains incomplete | record_bounded_failure_or_incomplete_state_without_negative_truth_inference | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 60 | search finds trace | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 61 | search detects nothing within sampled coverage | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 62 | search is interrupted | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 63 | failed search does not prove absence | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 64 | forensic sample is collected | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 65 | sample is contaminated | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 66 | analysis produces several hypotheses | preserve_multiple_candidates_or_conflict_without_forced_certainty | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 67 | contact is created | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 68 | contact remains unlocalized | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 69 | tentative track is initiated | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 70 | track is confirmed | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 71 | track identity changes | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 72 | track splits | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 73 | tracks merge | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 74 | track is handed to another sensor | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 75 | contact is lost | record_bounded_failure_or_incomplete_state_without_negative_truth_inference | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 76 | target is reacquired | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 77 | sensor fusion suppresses duplicate report | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 78 | sensor fusion preserves conflict | preserve_multiple_candidates_or_conflict_without_forced_certainty | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 79 | surveillance collection begins | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 80 | surveillance authority expires | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 81 | delayed observation is received | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 82 | AFQR-10 rejects unsupported evidence | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 83 | AFQR-19 rejects stale contact | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 84 | hidden contact affects feasibility | commit_private_receipt_and_project_visibility_safe_opaque_result | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 85 | visible response protects hidden identity | commit_private_receipt_and_project_visibility_safe_opaque_result | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 86 | aggregate sensing is promoted | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 87 | promotion preserves unknown detection history | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 88 | model invents a hidden observer | reject_model_claim_and_emit_noninterference_receipt | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 89 | model declares target identified | reject_model_claim_and_emit_noninterference_receipt | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |
| 90 | no lawful sensing determination exists | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile | AFQR-20 owns sensing-stage candidate/receipt only; AFQR-10 owns evidence/belief, AFQR-19 owns targeting/action, and AFQR-01 owns commitment. |

## Part XX — Central stress cases

### Multimodal shipboard detection under jamming and environmental failure
- Smoke and decompression alter AFQR-17 medium and noise inputs; rotation and damaged alignment alter AFQR-18 geometry/orientation references.
- Optical, radar, thermal, acoustic, network, and automated-defense sensors retain separate readiness and modality profiles.
- Jamming raises noise or saturation; spoofing creates false signal occurrences and contacts rather than merely subtracting a modifier.
- Distracted human attention is separate from automated policy sampling.
- Classified feeds may technically collect while remaining institutionally inaccessible.
- Fusion preserves the contradiction between physical sensors and network alerts.
- Only private contact/evidence candidates are produced; AFQR-19 target eligibility remains separate.
- Replay pins signal event times, propagation intervals, calibration versions, RNG receipts, and reception times.

Lawful outcomes: intruder not acquired, false contact created, region-valued localization, classification without identity, classified evidence withheld, fusion conflict unresolved.

### Familiar, derivatives, shared senses, and contested observation
- Shared raw signals, shared observations, delayed summaries, and copied sensing capabilities are distinct contracts.
- A familiar may refuse voluntary relay; contract automation cannot override agency unless a lawful automation/authority profile applies.
- Anti-scrying is a private source-local countermeasure affecting named modalities and stages.
- Psychic relation sensing may support a relation candidate without physical identity.
- Similar manifestations require identity-candidate sets and track-continuity analysis.
- A hostile observer tracking the link targets a signal/relation interface, not automatically every familiar.

Lawful outcomes: relay refused, raw signal delivered without interpretation, delayed observation accepted, identity ambiguous, track split, source-local bridge unavailable.

### Mixed physical, informational, social, and magical investigation
- Physical traces, altered records, testimony, network logs, magical residue, disguise, decoys, alarms, footage, and samples remain separate evidence channels.
- Collection receipts preserve sampling method, contamination risk, chain of custody, event time, and record time.
- False alarm and planted decoy are signal-layer deceptions; altered records are evidence-record deceptions; disguise affects recognition.
- Competing hypotheses remain explicit and may be incomparable.
- Institutional admissibility neither creates nor destroys technical evidence.
- No single investigation roll can create knowledge or guilt.

Lawful outcomes: sample contaminated, several hypotheses retained, identity unresolved, evidence rejected by AFQR-10, institutionally inadmissible but technically extant, source-local residue quarantined.

### Aggregate surveillance promoted into detailed pursuit
- Aggregate contact density does not contain invented individual readings.
- Promotion materializes only certified sensors, current contacts, uncertainty bounds, decoy pressures, maps, environmental inputs, and authority partitions.
- The unusual contact receives a new local contact lineage tied to aggregate evidence without fictitious historical detections.
- Hidden routes and inaccurate maps remain AFQR-18/AFQR-10 uncertainty.
- Weather effects come from AFQR-17.
- Local access differences produce audience-specific sensor/network projections.
- Pursuit receives a valid contact/track handoff but movement and interception remain AFQR-18/19.
- Demotion reconciles committed contacts and resource use without double detection.

Lawful outcomes: local contact tentative, decoy association unresolved, historical detection unknown, pursuit handoff accepted conditionally, hidden route preserved, aggregate/detail double count prevented.

## Part XXI — Candidate comparison

Candidate H is selected. It is the only architecture that preserves signal, propagation, sensor, attention, detection, recognition, evidence, contact, track, concealment, search, surveillance, hidden-state, conversion, and simulation-tier boundaries across the full corpus. Its higher authoring/runtime cost is controlled by registries, profile families, bounded candidate generation, tiers, and certification fixtures.

| Candidate | Name | Score | Disposition |
|---|---|---:|---|
| A | Universal perception score | 57 | rejected as universal |
| B | Universal stealth-versus-perception contest | 59 | rejected as universal |
| C | Visibility-state architecture | 66 | rejected as universal |
| D | Universal signal-detection pipeline | 111 | rejected as universal |
| E | Evidence-centric architecture | 110 | rejected as universal |
| F | Source-local sensing adapters | 113 | rejected as universal |
| G | Observer–target relation model | 117 | rejected as universal |
| H | Registered federated signal–sensing–acquisition architecture | 149 | selected |

## Part XXII — Adversarial evaluation

All `SEN-001` through `SEN-200` receive distinct records with source/modality/propagation, sensor, attention, detection/analysis, concealment, search/track, owner, AFQR-10/19 handoff, private receipt, visible/model projection, and final lawful disposition fields.

| ID | Scenario | Family | Final disposition |
|---|---|---|---|
| SEN-001 | Continuous visual signal exists. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-001 — Continuous visual signal exists. |
| SEN-002 | Action emits acoustic signal. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-002 — Action emits acoustic signal. |
| SEN-003 | Object reflects radar signal. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-003 — Object reflects radar signal. |
| SEN-004 | Device leaks electromagnetic signal. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-004 — Device leaks electromagnetic signal. |
| SEN-005 | Movement leaves physical trace. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-005 — Movement leaves physical trace. |
| SEN-006 | Event leaves magical residue. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-006 — Event leaves magical residue. |
| SEN-007 | Network action produces log event. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-007 — Network action produces log event. |
| SEN-008 | Source suppresses emission. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-008 — Source suppresses emission. |
| SEN-009 | Signature varies over time. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-009 — Signature varies over time. |
| SEN-010 | Signal identity is ambiguous. | signal_production | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-010 — Signal identity is ambiguous. |
| SEN-011 | One source emits several modalities. | signal_production | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-011 — One source emits several modalities. |
| SEN-012 | Several sources produce similar signals. | signal_production | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-012 — Several sources produce similar signals. |
| SEN-013 | Signal is intentional communication. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-013 — Signal is intentional communication. |
| SEN-014 | Signal is incidental. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-014 — Signal is incidental. |
| SEN-015 | Signal is reflected rather than emitted. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-015 — Signal is reflected rather than emitted. |
| SEN-016 | Trace persists after source leaves. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-016 — Trace persists after source leaves. |
| SEN-017 | Trace decays. | signal_production | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-017 — Trace decays. |
| SEN-018 | Source-local signal lacks a bridge. | signal_production | quarantine_or_lawfully_unresolved_pending_registered_bridge_or_profile: SEN-018 — Source-local signal lacks a bridge. |
| SEN-019 | Model invents a signal. | signal_production | reject_model_claim_and_emit_noninterference_receipt: SEN-019 — Model invents a signal. |
| SEN-020 | Signal production remains unresolved. | signal_production | lawfully_unresolved_with_frozen_basis_and_no_mutation: SEN-020 — Signal production remains unresolved. |
| SEN-021 | Signal propagates directly. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-021 — Signal propagates directly. |
| SEN-022 | Boundary blocks propagation. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-022 — Boundary blocks propagation. |
| SEN-023 | Medium attenuates signal. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-023 — Medium attenuates signal. |
| SEN-024 | Medium amplifies signal. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-024 — Medium amplifies signal. |
| SEN-025 | Signal reflects. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-025 — Signal reflects. |
| SEN-026 | Signal refracts. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-026 — Signal refracts. |
| SEN-027 | Signal scatters. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-027 — Signal scatters. |
| SEN-028 | Signal is delayed. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-028 — Signal is delayed. |
| SEN-029 | Signal crosses portal. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-029 — Signal crosses portal. |
| SEN-030 | Network route carries signal. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-030 — Network route carries signal. |
| SEN-031 | Environmental noise increases. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-031 — Environmental noise increases. |
| SEN-032 | Interference overlaps signal. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-032 — Interference overlaps signal. |
| SEN-033 | Carrier becomes incompatible. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-033 — Carrier becomes incompatible. |
| SEN-034 | Spatial path is incomplete. | propagation | record_bounded_failure_or_incomplete_state_without_negative_truth_inference: SEN-034 — Spatial path is incomplete. |
| SEN-035 | Propagation crosses several partitions. | propagation | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-035 — Propagation crosses several partitions. |
| SEN-036 | Source-local path is directional. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-036 — Source-local path is directional. |
| SEN-037 | Propagation transform loses information. | propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-037 — Propagation transform loses information. |
| SEN-038 | Model assumes line of sight is sufficient. | propagation | reject_model_claim_and_emit_noninterference_receipt: SEN-038 — Model assumes line of sight is sufficient. |
| SEN-039 | Propagation profile is missing. | propagation | quarantine_or_lawfully_unresolved_pending_registered_bridge_or_profile: SEN-039 — Propagation profile is missing. |
| SEN-040 | Propagation remains unresolved. | propagation | lawfully_unresolved_with_frozen_basis_and_no_mutation: SEN-040 — Propagation remains unresolved. |
| SEN-041 | Biological sensor is functional. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-041 — Biological sensor is functional. |
| SEN-042 | Synthetic sensor is active. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-042 — Synthetic sensor is active. |
| SEN-043 | Sensor is unpowered. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-043 — Sensor is unpowered. |
| SEN-044 | Sensor is damaged. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-044 — Sensor is damaged. |
| SEN-045 | Sensor is miscalibrated. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-045 — Sensor is miscalibrated. |
| SEN-046 | Sensor is saturated. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-046 — Sensor is saturated. |
| SEN-047 | Sensor is misoriented. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-047 — Sensor is misoriented. |
| SEN-048 | Signal lies outside coverage. | sensor_readiness_attention | record_bounded_failure_or_incomplete_state_without_negative_truth_inference: SEN-048 — Signal lies outside coverage. |
| SEN-049 | Signal lies below resolution. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-049 — Signal lies below resolution. |
| SEN-050 | Sensor uses wrong configuration. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-050 — Sensor uses wrong configuration. |
| SEN-051 | Passive monitoring is active. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-051 — Passive monitoring is active. |
| SEN-052 | Voluntary attention is allocated. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-052 — Voluntary attention is allocated. |
| SEN-053 | Attention is divided. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-053 — Attention is divided. |
| SEN-054 | Observer is awake but inattentive. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-054 — Observer is awake but inattentive. |
| SEN-055 | Observer is attentive but sensor impaired. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-055 — Observer is attentive but sensor impaired. |
| SEN-056 | Automated sensor lacks activation policy. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-056 — Automated sensor lacks activation policy. |
| SEN-057 | Remote operator controls sensor. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-057 — Remote operator controls sensor. |
| SEN-058 | Evidence recipient differs from operator. | sensor_readiness_attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-058 — Evidence recipient differs from operator. |
| SEN-059 | Model equates wakefulness with detection. | sensor_readiness_attention | reject_model_claim_and_emit_noninterference_receipt: SEN-059 — Model equates wakefulness with detection. |
| SEN-060 | Sensor readiness remains unresolved. | sensor_readiness_attention | lawfully_unresolved_with_frozen_basis_and_no_mutation: SEN-060 — Sensor readiness remains unresolved. |
| SEN-061 | Sensor interface is exposed. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-061 — Sensor interface is exposed. |
| SEN-062 | Sensor responds. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-062 — Sensor responds. |
| SEN-063 | Acquisition succeeds. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-063 — Acquisition succeeds. |
| SEN-064 | Acquisition fails. | acquisition_detection_localization | record_bounded_failure_or_incomplete_state_without_negative_truth_inference: SEN-064 — Acquisition fails. |
| SEN-065 | Detection succeeds. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-065 — Detection succeeds. |
| SEN-066 | Detection fails. | acquisition_detection_localization | record_bounded_failure_or_incomplete_state_without_negative_truth_inference: SEN-066 — Detection fails. |
| SEN-067 | False positive occurs. | acquisition_detection_localization | commit_private_false_positive_detection_receipt_without_target_truth: SEN-067 — False positive occurs. |
| SEN-068 | False negative occurs. | acquisition_detection_localization | commit_private_missed_detection_receipt_without_proving_absence: SEN-068 — False negative occurs. |
| SEN-069 | Detection profile is deterministic. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-069 — Detection profile is deterministic. |
| SEN-070 | Detection profile is stochastic. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-070 — Detection profile is stochastic. |
| SEN-071 | Opposed stealth profile applies. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-071 — Opposed stealth profile applies. |
| SEN-072 | Repeated samples accumulate evidence. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-072 — Repeated samples accumulate evidence. |
| SEN-073 | Two signals are discriminated. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-073 — Two signals are discriminated. |
| SEN-074 | Signals remain unresolved mixture. | acquisition_detection_localization | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-074 — Signals remain unresolved mixture. |
| SEN-075 | Bearing is estimated. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-075 — Bearing is estimated. |
| SEN-076 | Range is estimated. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-076 — Range is estimated. |
| SEN-077 | Region-valued localization occurs. | acquisition_detection_localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-077 — Region-valued localization occurs. |
| SEN-078 | Localization conflicts across sensors. | acquisition_detection_localization | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-078 — Localization conflicts across sensors. |
| SEN-079 | Model turns contact into exact position. | acquisition_detection_localization | reject_model_claim_and_emit_noninterference_receipt: SEN-079 — Model turns contact into exact position. |
| SEN-080 | Detection outcome remains unresolved. | acquisition_detection_localization | lawfully_unresolved_with_frozen_basis_and_no_mutation: SEN-080 — Detection outcome remains unresolved. |
| SEN-081 | Signal class is recognized. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-081 — Signal class is recognized. |
| SEN-082 | Object type is recognized. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-082 — Object type is recognized. |
| SEN-083 | Individual identity is recognized. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-083 — Individual identity is recognized. |
| SEN-084 | Recognition is mistaken. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-084 — Recognition is mistaken. |
| SEN-085 | Identification remains ambiguous. | recognition_identification | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-085 — Identification remains ambiguous. |
| SEN-086 | Several identity candidates remain. | recognition_identification | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-086 — Several identity candidates remain. |
| SEN-087 | Target has transformed. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-087 — Target has transformed. |
| SEN-088 | Copy resembles original. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-088 — Copy resembles original. |
| SEN-089 | Disguise changes apparent identity. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-089 — Disguise changes apparent identity. |
| SEN-090 | Disguise fools one observer but not another. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-090 — Disguise fools one observer but not another. |
| SEN-091 | Voice and visual recognition disagree. | recognition_identification | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-091 — Voice and visual recognition disagree. |
| SEN-092 | Record match conflicts with current appearance. | recognition_identification | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-092 — Record match conflicts with current appearance. |
| SEN-093 | Component is recognized but principal is not. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-093 — Component is recognized but principal is not. |
| SEN-094 | Role is recognized but identity is not. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-094 — Role is recognized but identity is not. |
| SEN-095 | Source-local recognition lacks bridge. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-095 — Source-local recognition lacks bridge. |
| SEN-096 | Recognition result is not adopted as belief. | recognition_identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-096 — Recognition result is not adopted as belief. |
| SEN-097 | Institutional identity record conflicts with sensing. | recognition_identification | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-097 — Institutional identity record conflicts with sensing. |
| SEN-098 | Model declares identity from weak evidence. | recognition_identification | reject_model_claim_and_emit_noninterference_receipt: SEN-098 — Model declares identity from weak evidence. |
| SEN-099 | Identity profile is unavailable. | recognition_identification | quarantine_or_lawfully_unresolved_pending_registered_bridge_or_profile: SEN-099 — Identity profile is unavailable. |
| SEN-100 | Identification remains unresolved. | recognition_identification | lawfully_unresolved_with_frozen_basis_and_no_mutation: SEN-100 — Identification remains unresolved. |
| SEN-101 | Opaque wall creates visual occlusion. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-101 — Opaque wall creates visual occlusion. |
| SEN-102 | Smoke creates visual masking. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-102 — Smoke creates visual masking. |
| SEN-103 | Camouflage reduces discrimination. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-103 — Camouflage reduces discrimination. |
| SEN-104 | Signature reduction lowers emission. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-104 — Signature reduction lowers emission. |
| SEN-105 | Silence suppresses acoustic signal. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-105 — Silence suppresses acoustic signal. |
| SEN-106 | Invisibility suppresses visual modality. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-106 — Invisibility suppresses visual modality. |
| SEN-107 | Thermal sensor still detects invisible target. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-107 — Thermal sensor still detects invisible target. |
| SEN-108 | Anti-divination blocks magical sensing. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-108 — Anti-divination blocks magical sensing. |
| SEN-109 | Jamming raises noise. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-109 — Jamming raises noise. |
| SEN-110 | Jamming saturates sensor. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-110 — Jamming saturates sensor. |
| SEN-111 | Spoofing creates false signal. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-111 — Spoofing creates false signal. |
| SEN-112 | Decoy receives detection. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-112 — Decoy receives detection. |
| SEN-113 | False trail misdirects search. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-113 — False trail misdirects search. |
| SEN-114 | Disguise affects recognition only. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-114 — Disguise affects recognition only. |
| SEN-115 | Concealment affects one observer class. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-115 — Concealment affects one observer class. |
| SEN-116 | Countermeasure expires. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-116 — Countermeasure expires. |
| SEN-117 | Counter-countermeasure applies. | concealment_countermeasure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-117 — Counter-countermeasure applies. |
| SEN-118 | Hidden countermeasure affects feasibility. | concealment_countermeasure | commit_private_receipt_and_project_visibility_safe_opaque_result: SEN-118 — Hidden countermeasure affects feasibility. |
| SEN-119 | Model reveals concealment mechanism. | concealment_countermeasure | reject_model_claim_and_emit_noninterference_receipt: SEN-119 — Model reveals concealment mechanism. |
| SEN-120 | Concealment outcome remains unresolved. | concealment_countermeasure | lawfully_unresolved_with_frozen_basis_and_no_mutation: SEN-120 — Concealment outcome remains unresolved. |
| SEN-121 | Area search begins. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-121 — Area search begins. |
| SEN-122 | Search covers one sector. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-122 — Search covers one sector. |
| SEN-123 | Search area remains incomplete. | search_investigation | record_bounded_failure_or_incomplete_state_without_negative_truth_inference: SEN-123 — Search area remains incomplete. |
| SEN-124 | Search sampling is interrupted. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-124 — Search sampling is interrupted. |
| SEN-125 | Search finds a trace. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-125 — Search finds a trace. |
| SEN-126 | Search finds no signal within coverage. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-126 — Search finds no signal within coverage. |
| SEN-127 | Failed search is treated as absence incorrectly. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-127 — Failed search is treated as absence incorrectly. |
| SEN-128 | Object inspection finds hidden component. | search_investigation | commit_private_receipt_and_project_visibility_safe_opaque_result: SEN-128 — Object inspection finds hidden component. |
| SEN-129 | Inspection lacks compatible sensor. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-129 — Inspection lacks compatible sensor. |
| SEN-130 | Trap search detects suspicious cue. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-130 — Trap search detects suspicious cue. |
| SEN-131 | Trap identity remains unknown. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-131 — Trap identity remains unknown. |
| SEN-132 | Network search finds log anomaly. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-132 — Network search finds log anomaly. |
| SEN-133 | Record search returns forged entry. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-133 — Record search returns forged entry. |
| SEN-134 | Forensic sample is collected. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-134 — Forensic sample is collected. |
| SEN-135 | Sample is contaminated. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-135 — Sample is contaminated. |
| SEN-136 | Analysis yields several hypotheses. | search_investigation | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-136 — Analysis yields several hypotheses. |
| SEN-137 | Divination returns source-local evidence. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-137 — Divination returns source-local evidence. |
| SEN-138 | Model invents discovery. | search_investigation | reject_model_claim_and_emit_noninterference_receipt: SEN-138 — Model invents discovery. |
| SEN-139 | Search candidate budget is exhausted. | search_investigation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-139 — Search candidate budget is exhausted. |
| SEN-140 | Search result remains unresolved. | search_investigation | lawfully_unresolved_with_frozen_basis_and_no_mutation: SEN-140 — Search result remains unresolved. |
| SEN-141 | Tentative contact is created. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-141 — Tentative contact is created. |
| SEN-142 | Contact lacks localization. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-142 — Contact lacks localization. |
| SEN-143 | Contact gains classification. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-143 — Contact gains classification. |
| SEN-144 | Contact gains identity candidate. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-144 — Contact gains identity candidate. |
| SEN-145 | Track is initiated. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-145 — Track is initiated. |
| SEN-146 | Track confidence rises. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-146 — Track confidence rises. |
| SEN-147 | Track confidence falls. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-147 — Track confidence falls. |
| SEN-148 | Track position is predicted. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-148 — Track position is predicted. |
| SEN-149 | Prediction is wrong. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-149 — Prediction is wrong. |
| SEN-150 | Track identity changes. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-150 — Track identity changes. |
| SEN-151 | Track splits. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-151 — Track splits. |
| SEN-152 | Tracks merge. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-152 — Tracks merge. |
| SEN-153 | Decoy steals track association. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-153 — Decoy steals track association. |
| SEN-154 | Track is handed to another sensor. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-154 — Track is handed to another sensor. |
| SEN-155 | Contact is lost. | contact_tracking_fusion | record_bounded_failure_or_incomplete_state_without_negative_truth_inference: SEN-155 — Contact is lost. |
| SEN-156 | Target is reacquired. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-156 — Target is reacquired. |
| SEN-157 | Fusion suppresses duplicate reports. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-157 — Fusion suppresses duplicate reports. |
| SEN-158 | Fusion preserves contradictory reports. | contact_tracking_fusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-158 — Fusion preserves contradictory reports. |
| SEN-159 | Model treats track as target truth. | contact_tracking_fusion | reject_model_claim_and_emit_noninterference_receipt: SEN-159 — Model treats track as target truth. |
| SEN-160 | Tracking outcome remains unresolved. | contact_tracking_fusion | lawfully_unresolved_with_frozen_basis_and_no_mutation: SEN-160 — Tracking outcome remains unresolved. |
| SEN-161 | Authorized surveillance begins. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-161 — Authorized surveillance begins. |
| SEN-162 | Unauthorized surveillance occurs. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-162 — Unauthorized surveillance occurs. |
| SEN-163 | Surveillance records only alerts. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-163 — Surveillance records only alerts. |
| SEN-164 | Surveillance records raw signals. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-164 — Surveillance records raw signals. |
| SEN-165 | Surveillance feed is classified. | surveillance_secrecy_replay | commit_private_receipt_and_project_visibility_safe_opaque_result: SEN-165 — Surveillance feed is classified. |
| SEN-166 | Access permission expires. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-166 — Access permission expires. |
| SEN-167 | Retrospective review finds prior contact. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-167 — Retrospective review finds prior contact. |
| SEN-168 | Historical sensor calibration differs. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-168 — Historical sensor calibration differs. |
| SEN-169 | Delayed observation arrives. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-169 — Delayed observation arrives. |
| SEN-170 | Duplicate observation is replayed. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-170 — Duplicate observation is replayed. |
| SEN-171 | Psychic sense detects relation, not identity. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-171 — Psychic sense detects relation, not identity. |
| SEN-172 | Spiritual sense detects manifestation. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-172 — Spiritual sense detects manifestation. |
| SEN-173 | Conceptual concealment suppresses recognition. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-173 — Conceptual concealment suppresses recognition. |
| SEN-174 | Source-local sense lacks translation bridge. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-174 — Source-local sense lacks translation bridge. |
| SEN-175 | Hidden detection affects target feasibility. | surveillance_secrecy_replay | commit_private_receipt_and_project_visibility_safe_opaque_result: SEN-175 — Hidden detection affects target feasibility. |
| SEN-176 | Option count leaks hidden contact. | surveillance_secrecy_replay | commit_private_receipt_and_project_visibility_safe_opaque_result: SEN-176 — Option count leaks hidden contact. |
| SEN-177 | Timing leaks sensor activation. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-177 — Timing leaks sensor activation. |
| SEN-178 | Stable digest links concealed target. | surveillance_secrecy_replay | commit_private_receipt_and_project_visibility_safe_opaque_result: SEN-178 — Stable digest links concealed target. |
| SEN-179 | Cross-packet retrieval exposes track. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-179 — Cross-packet retrieval exposes track. |
| SEN-180 | Sensing state is corrupted. | surveillance_secrecy_replay | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-180 — Sensing state is corrupted. |
| SEN-181 | Donor passive perception maps directly. | conversion_model_lawful_absence | route_to_conversion_pressure_IR_with_lawful_outcome_review: SEN-181 — Donor passive perception maps directly. |
| SEN-182 | Donor opposed stealth roll requires normalization. | conversion_model_lawful_absence | route_to_conversion_pressure_IR_with_lawful_outcome_review: SEN-182 — Donor opposed stealth roll requires normalization. |
| SEN-183 | Donor invisibility remains source-local. | conversion_model_lawful_absence | route_to_conversion_pressure_IR_with_lawful_outcome_review: SEN-183 — Donor invisibility remains source-local. |
| SEN-184 | Donor true sight collapses several stages. | conversion_model_lawful_absence | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-184 — Donor true sight collapses several stages. |
| SEN-185 | Donor search action assumes complete area coverage. | conversion_model_lawful_absence | route_to_conversion_pressure_IR_with_lawful_outcome_review: SEN-185 — Donor search action assumes complete area coverage. |
| SEN-186 | Donor investigation roll creates unsupported knowledge. | conversion_model_lawful_absence | route_to_conversion_pressure_IR_with_lawful_outcome_review: SEN-186 — Donor investigation roll creates unsupported knowledge. |
| SEN-187 | Donor sensor range lacks propagation semantics. | conversion_model_lawful_absence | route_to_conversion_pressure_IR_with_lawful_outcome_review: SEN-187 — Donor sensor range lacks propagation semantics. |
| SEN-188 | Donor disguise changes social identity incorrectly. | conversion_model_lawful_absence | route_to_conversion_pressure_IR_with_lawful_outcome_review: SEN-188 — Donor disguise changes social identity incorrectly. |
| SEN-189 | Donor illusion directly alters belief. | conversion_model_lawful_absence | route_to_conversion_pressure_IR_with_lawful_outcome_review: SEN-189 — Donor illusion directly alters belief. |
| SEN-190 | Donor fog-of-war state conflicts with AFQR-10. | conversion_model_lawful_absence | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-190 — Donor fog-of-war state conflicts with AFQR-10. |
| SEN-191 | Model invents a hidden target. | conversion_model_lawful_absence | reject_model_claim_and_emit_noninterference_receipt: SEN-191 — Model invents a hidden target. |
| SEN-192 | Model invents a successful search. | conversion_model_lawful_absence | reject_model_claim_and_emit_noninterference_receipt: SEN-192 — Model invents a successful search. |
| SEN-193 | Model reveals sensor capability. | conversion_model_lawful_absence | reject_model_claim_and_emit_noninterference_receipt: SEN-193 — Model reveals sensor capability. |
| SEN-194 | Model declares target recognized. | conversion_model_lawful_absence | reject_model_claim_and_emit_noninterference_receipt: SEN-194 — Model declares target recognized. |
| SEN-195 | Model treats failed detection as absence. | conversion_model_lawful_absence | reject_model_claim_and_emit_noninterference_receipt: SEN-195 — Model treats failed detection as absence. |
| SEN-196 | Narration conflicts with observation receipt. | conversion_model_lawful_absence | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-196 — Narration conflicts with observation receipt. |
| SEN-197 | Public report conflicts with sensing evidence. | conversion_model_lawful_absence | preserve_multiple_candidates_or_conflict_without_forced_certainty: SEN-197 — Public report conflicts with sensing evidence. |
| SEN-198 | Historical detector is unavailable. | conversion_model_lawful_absence | quarantine_or_lawfully_unresolved_pending_registered_bridge_or_profile: SEN-198 — Historical detector is unavailable. |
| SEN-199 | No typed construct represents the sense. | conversion_model_lawful_absence | quarantine_or_lawfully_unresolved_pending_registered_bridge_or_profile: SEN-199 — No typed construct represents the sense. |
| SEN-200 | Sensing outcome remains lawfully unresolved. | conversion_model_lawful_absence | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile: SEN-200 — Sensing outcome remains lawfully unresolved. |

Binding artifact: `evaluation/afqr_20_adversarial_scenarios_SEN_001_200.yaml`.

## Part XXIII — Current runtime disposition

**Exists:** backend-first doctrine; read-only state-owner facade; visibility-classified projection adapter; hidden/raw metadata rejection; narrow object/lever legality, preview, commit, and audit fixture.

**Fixture-only:** hidden-fact references, visibility tiers, visible/redacted/backend/unknown projection packets, safe-reference envelopes.

**Conversion-only:** donor perception, visibility, stealth, search, investigation, sensor, ability, and target descriptors.

**Narrative-only:** sensory prose, assessment language, visibility descriptions, and contextual discovery wording.

**Absent:** generalized signal sources/occurrences, propagation closure, sensors, calibration, attention tasks, detection profiles, recognition/identification, contacts, tracks, search coverage, fusion, surveillance, evidence/contact adapters, RNG receipts, and simulation tiers.

**May proceed:** ratification, pressure IR, schemas, non-mutating dry runs, side-channel tests, and projection validator design.

**Blocked:** all campaign sensing execution and every AFQR-19 action depending on unimplemented detection or contact.

**Prohibited:** model-authored signals, detections, identities, discoveries, tracks, surveillance results, hidden disclosures, and target eligibility.

## Part XXIV — Required artifacts

1. **Immediate:** ADR, decision registry, terminology, repository audit, research synthesis, candidate comparison, contract catalog, conversion IR, operation grammar, 200 scenarios, four stress fixtures, 50-case dry run, acceptance matrix, side-channel model, manifests, validation report.
2. **Before authoritative signal production:** signal/source/occurrence registry, production profiles, event adapters, continuity fixtures.
3. **Before sensor readiness:** sensor registry, embodied-interface adapters, calibration/configuration schemas, owner bindings.
4. **Before detection:** propagation certificates, backend RNG, detection profile registry, false-positive/negative tests.
5. **Before recognition/identification:** AFQR-08 identity adapters, feature/evidence schemas, ambiguity fixtures.
6. **Before concealment/stealth:** modality/stage countermeasure registry, AFQR-19 contest adapters, hidden-state tests.
7. **Before search/investigation:** search coverage executor, sampling/chain-of-custody records, AFQR-10 evidence adapters.
8. **Before tracking/fusion:** contact/track owners, association and continuity profiles, conflict-preserving fusion.
9. **Before surveillance:** authority/tasking/recording/access separation and institutional adapters.
10. **Before AFQR-19 handoffs:** contact validity/revalidation contracts and cardinality noninterference.
11. **Before model narration:** closed grounding manifests, semantic validator, cross-packet isolation, timing/linkability fixtures.
12. **Before mass conversion:** certified pressure IR examples across biological, synthetic, magical, psychic, forensic, network, and aggregate donors.
13. **Deferred:** final perception skills, tactical visibility, detailed sensor equations, surveillance law, hacking, divination, illusion metaphysics, distributed optimization.

## Part XXV — Non-mutating prototype

**Prototype:** AFQR-20 Signal, Sensing, Detection, Search, Concealment, and Tracking Dry Run.

It executes no model calls and mutates no world, signal, sensor, attention, evidence, target, search, track, surveillance, resource, or event state. It validates candidate generation, profile applicability, lawful absence, projections, private commitments, AFQR-10/19 handoffs, and noninterference.

| # | Case | Expected disposition |
|---:|---|---|
| 1 | continuous visual signal | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 2 | event-triggered acoustic signal | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 3 | residual trace | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 4 | source-local signal | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 5 | direct propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 6 | attenuated propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 7 | blocked propagation | record_bounded_failure_or_incomplete_state_without_negative_truth_inference |
| 8 | noisy propagation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 9 | functional biological sensor | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 10 | synthetic sensor | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 11 | miscalibrated sensor | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 12 | saturated sensor | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 13 | invalid orientation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 14 | passive monitoring | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 15 | voluntary attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 16 | divided attention | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 17 | sensor exposure | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 18 | acquisition | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 19 | deterministic detection | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 20 | stochastic detection | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 21 | false positive | commit_private_false_positive_detection_receipt_without_target_truth |
| 22 | false negative | commit_private_missed_detection_receipt_without_proving_absence |
| 23 | discrimination | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 24 | region-valued localization | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 25 | classification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 26 | ambiguous recognition | preserve_multiple_candidates_or_conflict_without_forced_certainty |
| 27 | mistaken identification | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 28 | contact creation | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 29 | visual occlusion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 30 | camouflage | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 31 | modality-specific invisibility | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 32 | jamming | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 33 | spoofing | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 34 | decoy | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 35 | stealth against two observer classes | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 36 | bounded search | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 37 | incomplete search | record_bounded_failure_or_incomplete_state_without_negative_truth_inference |
| 38 | trace collection | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 39 | contaminated sample | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 40 | tentative track | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 41 | lost contact | record_bounded_failure_or_incomplete_state_without_negative_truth_inference |
| 42 | reacquisition | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 43 | conflicting sensor fusion | preserve_multiple_candidates_or_conflict_without_forced_certainty |
| 44 | surveillance access restriction | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 45 | AFQR-10 evidence handoff | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 46 | AFQR-19 contact handoff | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 47 | aggregate-to-detailed promotion | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 48 | hidden-contact model projection | reject_model_claim_and_emit_noninterference_receipt |
| 49 | source-local sense without bridge | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |
| 50 | no lawful sensing determination | produce_non_mutating_typed_candidate_or_receipt_under_registered_profile |

## Part XXVI — Acceptance tests

The binding matrix contains **152** tests.

| Test group | Count |
|---|---:|
| Signals and modalities | 7 |
| Propagation | 7 |
| Sensors | 7 |
| Attention and sensing tasks | 7 |
| Detection stages | 7 |
| Recognition and identity | 7 |
| Concealment and stealth | 8 |
| Search and investigation | 7 |
| Contacts and tracking | 7 |
| Sensor fusion | 7 |
| Surveillance | 7 |
| Epistemic handoffs | 7 |
| AFQR-19 handoffs | 7 |
| Hidden state and model safety | 8 |
| Simulation tiers | 8 |
| Replay | 8 |
| Conversion | 8 |
| Runtime containment | 8 |
| Ratification hardening | 20 |

Every requirement from the prompt is represented, with additional ratification hardening for sequence completeness, cross-owner handoffs, side channels, model validation, promotion/demotion, retries, and lawful non-discovery.

## Part XXVII — Residual uncertainty ledger

- **Final player-facing perception skills:** deferred to player/chassis and resolver design.
- **Final attention economy:** deferred; AFQR-20 defines typed handoffs only.
- **Tactical visibility:** spatial candidate exists, final combat algorithm deferred.
- **Social perception/deception:** requires dedicated social-cognition handoff rather than sensory collapse.
- **Memory and belief revision:** AFQR-10/12 territory.
- **Detailed signal equations:** profile-local engineering work.
- **Forensic depth and investigation structure:** source/family-specific modules.
- **Surveillance law:** institutional doctrine and campaign canon.
- **Hacking/network sensing:** source-local or later cyber doctrine.
- **Magical divination and illusion metaphysics:** source-local registries and bridges.
- **Large-scale distributed performance:** implementation research after authority contracts.
- **Training-model behavior:** separate play-facing adapter phase after runtime authority.

## Part XXVIII — Roadmap conclusion

1. **Ratifiable:** Yes.
2. **Second broad research pass:** No; targeted family certification remains.
3. **Mandatory amendments:** semantic contract specialization; federated signal/sensor/contact/track ownership; signal/event separation; modality/carrier bridges; AFQR-17/18 propagation closure; multidimensional sensor readiness; attention-owner separation; staged acquisition/detection/recognition; false-positive/negative records; observer-relative concealment; bounded search coverage; contact/track lineage; conflict-preserving fusion; surveillance authority separation; AFQR-10/19 acceptance receipts; bitemporal replay; side-channel controls; semantic model validation; simulation-tier exclusion.
4. **Immediate artifacts:** supplied in this pack.
5. **Smallest prototype:** supplied 50-case non-mutating dry run.
6. **Execution blocked:** all generalized signal, sensor, detection, recognition, search, track, fusion, surveillance, evidence adoption, and target-contact execution.
7. **Authoritative signal or sensor state unlocked:** No.
8. **Detection, recognition, search, tracking, fusion, or surveillance unlocked:** No.
9. **AFQR-19 targeting, pursuit, reactions, or combat unlocked:** No; only the handoff contract is architecturally specified.
10. **Bounded sensory narration unlocked:** Conditionally, only after grounding, semantic validation, isolation, cardinality, timing, and evidence-binding controls are implemented.
11. **RT-002G:** unchanged; it remains object/lever-only and non-perceptual.
12. **AFQR-21:** Objects, Assets, Items, Equipment, Affordances, Use, Custody, Installation, and Material Interaction.
13. **Exact action:** ratify/register AFQR-20, run the dry run and RT-002A–F sensing/model noninterference audit, keep RT-002G narrow, then open AFQR-21 read-only.

## Part XXIX — Machine-readable decision block

```yaml
question_id: AFQR-20
question_title: Signals Sensing Attention Perception Detection Recognition Search Concealment Stealth Tracking Surveillance
  and Information Acquisition
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: ratifiable_architectural_decision
selected_architecture: Registered Federated Signal–Sensing–Acquisition Architecture with Typed Source–Modality–Propagation
  Ownership, Staged Exposure–Acquisition–Detection–Recognition Pipelines, Observer-Relative Concealment–Countermeasure Profiles,
  and Bitemporal Contact–Track–Evidence Continuity
selected_architecture_abbreviation: RFSSA-SMP-SEADR-OCCP-BCTEC
confidence: high
central_law: No world fact, signal label, visibility flag, sensor reading, search declaration, contact, track, donor rule,
  public report, or model narration creates authoritative detection, recognition, identification, belief, knowledge, target
  eligibility, or disclosure by itself. Every authoritative sensing result is a purpose-, audience-, and time-scoped, version-pinned
  determination over frozen signal, propagation, sensor, attention, identity, epistemic, agency, behavioral, social, communication,
  institutional, embodiment, environmental, spatial, capability-and-action, governed-relation, quantity, scheduler, concealment,
  search, tracking, and fusion bases. AFQR-20 produces sensing, observation, evidence, contact, and track candidates only;
  AFQR-10 and AFQR-19 may accept, reject, qualify, or require revalidation, and only AFQR-01 commits accepted owner fragments.
  Narration follows audience-visible committed records and never expands them.
accepted_dependencies:
  AFQR_01:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_02:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_03:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_04:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_05:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_06:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_07:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_08:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_09:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_10:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_11:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_12:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_13:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_14:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_15:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_16:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_17:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_18:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
  AFQR_19:
    status: accepted_architectural_dependency
    implementation_status: not assumed implemented
    required_boundary: preserve owner and handoff separation
definitions:
  signal: A typed, temporally scoped physical, informational, metaphysical, or source-local pattern capable of participating
    in a registered sensing interface; it is not the underlying world fact or an observation.
  signal source: The identity-scoped world entity, event, process, relation, record, or source-local construct from which
    a signal occurrence is attributed.
  signal occurrence: A particular emitted, reflected, leaked, deposited, transmitted, or residual signal event with event-time
    provenance.
  signal content: A typed AFQR-20 concept for signal content, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  signature: A typed AFQR-20 concept for signature, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  trace: A typed AFQR-20 concept for trace, qualified by owner, purpose, modality or family, temporal validity, profile version,
    provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  residue: A typed AFQR-20 concept for residue, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  emission: A typed AFQR-20 concept for emission, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  reflection: A typed AFQR-20 concept for reflection, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  transmission: A typed AFQR-20 concept for transmission, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  leakage: A typed AFQR-20 concept for leakage, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  carrier: A typed AFQR-20 concept for carrier, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  modality: A typed AFQR-20 concept for modality, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  channel: A typed AFQR-20 concept for channel, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  propagation: A typed AFQR-20 concept for propagation, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  attenuation: A typed AFQR-20 concept for attenuation, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  interference: A typed AFQR-20 concept for interference, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  noise: A typed AFQR-20 concept for noise, qualified by owner, purpose, modality or family, temporal validity, profile version,
    provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  clutter: A typed AFQR-20 concept for clutter, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  distortion: A typed AFQR-20 concept for distortion, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  latency: A typed AFQR-20 concept for latency, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  signal availability.: A typed AFQR-20 concept for signal availability., qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  sensor: A registered biological, synthetic, remote, distributed, institutional, or source-local mechanism whose interface
    can respond to compatible signal exposures.
  sensing interface: A typed AFQR-20 concept for sensing interface, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  observer: The subject or system for whose sensing state a response, contact, or observation candidate is evaluated; not
    necessarily sensor owner, operator, or evidence recipient.
  sensor owner: A typed AFQR-20 concept for sensor owner, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  sensor operator: A typed AFQR-20 concept for sensor operator, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  evidence recipient: A typed AFQR-20 concept for evidence recipient, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  sensor activation: A typed AFQR-20 concept for sensor activation, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  sensor configuration: A typed AFQR-20 concept for sensor configuration, qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  calibration: A typed AFQR-20 concept for calibration, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  sensitivity: A typed AFQR-20 concept for sensitivity, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  selectivity: A typed AFQR-20 concept for selectivity, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  resolution: A typed AFQR-20 concept for resolution, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  coverage: A typed AFQR-20 concept for coverage, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  dynamic range: A typed AFQR-20 concept for dynamic range, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  sampling: A typed AFQR-20 concept for sampling, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  sensor response: A typed AFQR-20 concept for sensor response, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  sensor saturation: A typed AFQR-20 concept for sensor saturation, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  sensor impairment.: A typed AFQR-20 concept for sensor impairment., qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  alertness: A typed AFQR-20 concept for alertness, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  wakefulness: A typed AFQR-20 concept for wakefulness, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  attention: A purpose- and interval-scoped allocation of sensing-task processing capacity; not wakefulness, awareness, curiosity,
    or guaranteed sampling.
  focus: A typed AFQR-20 concept for focus, qualified by owner, purpose, modality or family, temporal validity, profile version,
    provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  orientation: A typed AFQR-20 concept for orientation, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  vigilance: A typed AFQR-20 concept for vigilance, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  divided attention: A typed AFQR-20 concept for divided attention, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  passive monitoring: A typed AFQR-20 concept for passive monitoring, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  active sensing: A typed AFQR-20 concept for active sensing, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  sensing task: A typed AFQR-20 concept for sensing task, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  observation window: A typed AFQR-20 concept for observation window, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  scan: A typed AFQR-20 concept for scan, qualified by owner, purpose, modality or family, temporal validity, profile version,
    provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  sampling window.: A typed AFQR-20 concept for sampling window., qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  acquisition: A typed AFQR-20 concept for acquisition, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  detection: A registered determination that an acquired sensor response satisfies a detection profile; not localization,
    recognition, identification, belief, or target eligibility.
  discrimination: A typed AFQR-20 concept for discrimination, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  localization: A typed AFQR-20 concept for localization, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  classification: A typed AFQR-20 concept for classification, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  recognition: A purpose-scoped comparison that supports a class, type, role, object, body, voice, or familiarity candidate
    from admissible features.
  identification: A purpose-scoped identity-candidate determination tied to AFQR-08 identity facets and uncertainty; not legal
    identity or belief adoption.
  contact: An observer-relative operational sensing record representing detected or otherwise qualified signal evidence, possibly
    without identity or location.
  target contact: A typed AFQR-20 concept for target contact, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  observation: An AFQR-10-owned epistemic record candidate grounded in sensing evidence; not the sensing process itself or
    guaranteed truth.
  percept: A qualified representation of sensed input for an observer, where the profile supports such a layer; not automatically
    a belief.
  evidence candidate: A typed AFQR-20 concept for evidence candidate, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  detection confidence: A typed AFQR-20 concept for detection confidence, qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  false positive: A typed AFQR-20 concept for false positive, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  false negative: A typed AFQR-20 concept for false negative, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  correct rejection: A typed AFQR-20 concept for correct rejection, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  missed detection.: A typed AFQR-20 concept for missed detection., qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  concealment: An observer-, modality-, stage-, purpose-, and time-relative counter-detection relation; not universal hiddenness.
  occlusion: A typed AFQR-20 concept for occlusion, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  camouflage: A typed AFQR-20 concept for camouflage, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  masking: A typed AFQR-20 concept for masking, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  clutter exploitation: A typed AFQR-20 concept for clutter exploitation, qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  signature reduction: A typed AFQR-20 concept for signature reduction, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  emission control: A typed AFQR-20 concept for emission control, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  silence: A typed AFQR-20 concept for silence, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  invisibility: A profile that suppresses or alters specified signal modalities or sensing stages; not absence, incorporeality,
    universal undetectability, or immunity to targeting.
  disguise: A typed AFQR-20 concept for disguise, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  jamming: A typed AFQR-20 concept for jamming, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  spoofing: A typed AFQR-20 concept for spoofing, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  decoy: A typed AFQR-20 concept for decoy, qualified by owner, purpose, modality or family, temporal validity, profile version,
    provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  false trail: A typed AFQR-20 concept for false trail, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  anti-sensing: A typed AFQR-20 concept for anti-sensing, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  anti-divination: A typed AFQR-20 concept for anti-divination, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  source-local concealment.: A typed AFQR-20 concept for source-local concealment., qualified by owner, purpose, modality
    or family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as
    an unqualified runtime shortcut.
  search: A bounded, method-defined, area- or corpus-scoped sensing activity with explicit coverage, sampling, depth, time,
    resources, and stopping conditions.
  search method: A typed AFQR-20 concept for search method, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  search area: A typed AFQR-20 concept for search area, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  search plan: A typed AFQR-20 concept for search plan, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  search coverage: A typed AFQR-20 concept for search coverage, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  search depth: A typed AFQR-20 concept for search depth, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  sample: A typed AFQR-20 concept for sample, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  inspection: A typed AFQR-20 concept for inspection, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  investigation: A typed AFQR-20 concept for investigation, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  survey: A typed AFQR-20 concept for survey, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  reconnaissance: A typed AFQR-20 concept for reconnaissance, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  forensic examination: A typed AFQR-20 concept for forensic examination, qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  discovery candidate: A typed AFQR-20 concept for discovery candidate, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  search completeness: A typed AFQR-20 concept for search completeness, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  stopping condition.: A typed AFQR-20 concept for stopping condition., qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  track: A bitemporal operational hypothesis that correlates contacts or observations across time; it is not authoritative
    target state.
  track state: A typed AFQR-20 concept for track state, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  tentative track: A typed AFQR-20 concept for tentative track, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  confirmed track: A typed AFQR-20 concept for confirmed track, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  track identity candidate: A typed AFQR-20 concept for track identity candidate, qualified by owner, purpose, modality or
    family, temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an
    unqualified runtime shortcut.
  track position estimate: A typed AFQR-20 concept for track position estimate, qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  track confidence: A typed AFQR-20 concept for track confidence, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  track continuity: A typed AFQR-20 concept for track continuity, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  track split: A typed AFQR-20 concept for track split, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  track merge: A typed AFQR-20 concept for track merge, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  track handoff: A typed AFQR-20 concept for track handoff, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  track prediction: A typed AFQR-20 concept for track prediction, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  lost contact: A typed AFQR-20 concept for lost contact, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  reacquisition: A typed AFQR-20 concept for reacquisition, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  false track.: A typed AFQR-20 concept for false track., qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  sensor fusion: A typed AFQR-20 concept for sensor fusion, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  observation correlation: A typed AFQR-20 concept for observation correlation, qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  data association: A typed AFQR-20 concept for data association, qualified by owner, purpose, modality or family, temporal
    validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime
    shortcut.
  duplicate observation: A typed AFQR-20 concept for duplicate observation, qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  conflicting observation: A typed AFQR-20 concept for conflicting observation, qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  surveillance: A tasking and collection arrangement for repeated or persistent sensing; technical execution, recording, access,
    dissemination, authority, and legitimacy remain separate.
  monitoring: A typed AFQR-20 concept for monitoring, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  collection: A typed AFQR-20 concept for collection, qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  recording: A typed AFQR-20 concept for recording, qualified by owner, purpose, modality or family, temporal validity, profile
    version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
  retrospective review: A typed AFQR-20 concept for retrospective review, qualified by owner, purpose, modality or family,
    temporal validity, profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified
    runtime shortcut.
  dissemination.: A typed AFQR-20 concept for dissemination., qualified by owner, purpose, modality or family, temporal validity,
    profile version, provenance, uncertainty, and audience visibility. It must not be used as an unqualified runtime shortcut.
guarantees:
- federated sensing ownership
- staged signal-to-contact pipeline
- observer-relative modality-specific concealment
- false positive and false negative support
- bounded search coverage
- track/evidence separation
- AFQR-10 and AFQR-19 handoff separation
- hidden-state-safe projections
- deterministic replay
- lawful unresolved outcomes
non_guarantees:
- one perception attribute
- one passive score
- one stealth contest
- one sensor equation
- one visibility state
- one invisibility rule
- one search procedure
- one illusion ontology
- authoritative runtime sensing execution
- model-authored hidden truth
signal_model:
  owner: signal registry and occurrence owners
  stages:
  - source
  - definition
  - occurrence
  - content/signature
  - continuity
  law: world truth is not a signal occurrence
signal_source_model:
  supports:
  - entity
  - event
  - process
  - relation
  - record
  - environmental cue
  - source-local construct
  identity: AFQR-08 purpose-scoped
signal_production_model:
  families:
  - emission
  - reflection
  - transmission
  - leakage
  - trace
  - residue
  - controlled
  - accidental
  - spoofed
  output: SignalOccurrence candidate or receipt
signal_identity_and_continuity_model:
  separates:
  - signal definition
  - occurrence
  - signature
  - contact
  - track
  continuity: profile-scoped lineage
modality_and_carrier_model:
  modalities: open registry
  compatibility: typed directional bridges
  no_universal_medium: true
signal_propagation_model:
  inputs:
  - AFQR-17 medium/field
  - AFQR-18 path/boundary
  effects:
  - attenuation
  - delay
  - noise
  - interference
  - reflection
  - transformation
  ends_at: sensor-interface exposure candidate
sensor_model:
  families:
  - biological
  - synthetic
  - remote
  - distributed
  - magical
  - psychic
  - spiritual
  - network
  - forensic
  - source-local
sensor_owner_and_operator_model:
  roles:
  - owner
  - operator
  - observer
  - evidence recipient
  - decision authority
  roles_may_differ: true
sensor_readiness_model:
  dimensions:
  - activation
  - power
  - function
  - calibration
  - configuration
  - orientation
  - coverage
  - sampling
  - saturation
  result_states:
  - ready
  - degraded
  - saturated
  - misconfigured
  - unavailable
  - hidden
  - unresolved
sensor_calibration_model:
  versioned: true
  uncertainty_and_drift: true
  historical_profile_retained: true
sensor_performance_model:
  dimensions:
  - sensitivity
  - selectivity
  - resolution
  - coverage
  - range
  - latency
  - sample rate
  - dynamic range
  - false-positive behavior
  - false-negative behavior
attention_handoff:
  AFQR12: voluntary behavioral allocation
  AFQR16: wakefulness and physiological alertness
  AFQR20: sensing-task execution and observation windows
sensing_task_model:
  supports:
  - passive monitoring
  - active scan
  - vigilance
  - delegated monitoring
  - automatic policy
  - source-local task
  no_guaranteed_detection: true
sampling_model:
  schedule: AFQR-04 logical time
  retries: idempotent
  outputs: sampling receipts
observation_window_model:
  time_scoped: true
  interruptible: true
  audience_safe: true
acquisition_model:
  stages:
  - interface exposure
  - sensor response
  - sampling
  - acquisition
  not_detection: true
detection_model:
  profiles:
  - deterministic
  - stochastic
  - opposed
  - accumulated evidence
  - repeated sampling
  - automatic
  - resource-spend
  - source-local
  outputs:
  - hit
  - miss
  - false-positive
  - false-negative
  - unresolved
false_positive_false_negative_model:
  first_class: true
  failed_detection_not_absence: true
discrimination_model:
  purpose: separate competing signals or retain unresolved mixture
localization_model:
  outputs:
  - bearing
  - range
  - region-valued estimate
  - uncertain support
  - no localization
  authoritative_position_owner: AFQR-18
classification_model:
  outputs: class/type candidates with uncertainty
recognition_model:
  purpose_scoped: true
  not_identification_or_belief: true
identification_model:
  identity_candidates: AFQR-08-scoped
  belief_owner: AFQR-10
  legal_identity_owner: AFQR-15 where relevant
contact_model:
  observer_relative: true
  may_lack:
  - localization
  - classification
  - identity
  not_target_truth: true
target_contact_model:
  handoff_consumer: AFQR-19
  does_not_select_or_authorize_target: true
track_model:
  operational_hypothesis: true
  supports:
  - initiation
  - confidence
  - prediction
  - split
  - merge
  - handoff
  - loss
  - reacquisition
  - decoy
track_continuity_model:
  profile_scoped: true
  separate_from_target_identity: true
sensor_fusion_model:
  operations:
  - correlation
  - association
  - deduplication
  - conflict preservation
  - uncertainty propagation
  cannot_manufacture_certainty: true
concealment_model:
  observer_modality_stage_purpose_time_relative: true
  not_universal_hidden_flag: true
occlusion_model:
  affects: propagation/path stage
  spatial_basis: AFQR-18
camouflage_model:
  affects:
  - signal discrimination
  - classification
  - recognition
  not_occlusion: true
masking_model:
  affects: signal-to-noise or clutter stage
invisibility_model:
  modality_and_stage_scoped: true
  not_undetectability: true
disguise_model:
  affects:
  - classification
  - recognition
  - identification evidence
  not_identity_change: true
jamming_model:
  may_affect:
  - propagation
  - noise
  - sensor response
  - acquisition
  - saturation
  not_spoofing: true
spoofing_model:
  creates_or_alters: false signal/input/contact candidates
  not_jamming: true
decoy_model:
  separate_identity: true
  may_receive_contact_or_track_association: true
stealth_model:
  process_inputs:
  - movement
  - behavior
  - timing
  - emission management
  - environment
  - equipment
  - observer knowledge
  - counter-detection
  observer_relative: true
source_local_anti_sensing_model:
  requires: registered AFQR-05 bridge
  missing_bridge: quarantine or unresolved
search_model:
  bounded: true
  separates:
  - plan
  - coverage
  - sampling
  - execution
  - detection
  - discovery
  - recognition
  no_detection_not_absence: true
search_coverage_model:
  dimensions:
  - area/corpus
  - depth
  - sample density
  - time
  - method
  - unsearched remainder
  - stopping condition
investigation_model:
  outputs:
  - evidence candidates
  - alternative hypotheses
  no_single_roll_knowledge: true
forensics_model:
  requires:
  - sampling
  - chain of custody
  - contamination state
  - method validity
  - uncertainty
  - alternative hypotheses
surveillance_model:
  separates:
  - authority
  - tasking
  - collection
  - recording
  - review
  - access
  - dissemination
  technical_execution_not_legitimacy: true
identity_handoff:
  owner: AFQR-08
  AFQR20_output: identity candidates and feature evidence
epistemic_handoff:
  owner: AFQR-10
  AFQR20_output: provenance-complete observation/evidence candidates
agency_and_control_handoff:
  owner: AFQR-11
  applies_to:
  - operator control
  - voluntary observation
  - compelled surveillance
  - automation
behavioral_handoff:
  owner: AFQR-12
  applies_to:
  - attention choice
  - search strategy
  - track-following choice
social_handoff:
  owner: AFQR-13
  recognition_not_relationship: true
communication_handoff:
  owner: AFQR-14
  signal_detection_not_message_delivery_or_grounding: true
institutional_handoff:
  owner: AFQR-15
  authority_not_technical_detection: true
embodiment_handoff:
  owner: AFQR-16
  sensory_function_and_harm: true
environmental_handoff:
  owner: AFQR-17
  medium_field_noise_and_transport: true
spatial_handoff:
  owner: AFQR-18
  path_geometry_position_and_visibility_candidate: true
capability_and_action_handoff:
  owner: AFQR-19
  detection_not_target_selection: true
governed_relation_handoff:
  owner: AFQR-09
  sensor_dependency_and_access_relations: true
quantity_and_settlement_handoff:
  owner: AFQR-07
  typed_signal_sensor_search_resources: true
scheduler_handoff:
  owner: AFQR-04
  logical_time_sampling_tracks_and_delays: true
AFQR10_evidence_handoff:
  candidate_only: true
  responses:
  - accept
  - qualify
  - reject
  - quarantine
  belief_mutation_in_AFQR20: false
AFQR19_target_contact_handoff:
  candidate_only: true
  validity_interval_required: true
  uncertainty_required: true
  selection_or_eligibility_authorized: false
pursuit_and_interception_handoff:
  requires:
  - AFQR-20 contact/track
  - AFQR-18 spatial state
  - AFQR-19 contest/action
  no_automatic_interception: true
sensing_simulation_tier_model:
  tiers:
  - descriptive_visibility_reference
  - aggregate_contact_state
  - observer_contact_network
  - materialized_sensor_state
  - detailed_signal_acquisition
  - full_sensing_fixture
sensing_materialization_policy:
  certified_detail_only: true
  no_invented_history: true
sensing_authority_partition:
  aggregate_and_detailed_exclusive: true
  no_double_detection: true
hidden_signal_policy:
  audience_scoped: true
  private_receipts: true
hidden_sensor_policy:
  capability_and_activation_private_by_default: true
hidden_target_policy:
  option_count_and_timing_protected: true
hidden_contact_policy:
  private_contact_and_track_receipts: true
visible_projection_policy:
  evidence_bound: true
  generic_blockers_allowed: true
  no_hidden_mechanism_names: true
model_context_policy:
  closed_world_manifest: true
  only_authorized_projections: true
  cross_packet_isolation: true
model_output_validation:
  semantic_claim_registry: true
  rejects:
  - invented signal
  - unsupported detection
  - unsupported identity
  - invented discovery
  - unsupported track
side_channel_protection:
  controls:
  - audience tokens
  - projection-specific digests
  - constant-shape responses
  - timing controls
  - candidate-count protection
  - retrieval isolation
historical_replay_policy:
  version_pinned_profiles: true
  RNG_receipts: true
  missing_evaluator: unverifiable not reinterpreted
bitemporal_policy:
  times:
  - event/signal time
  - propagation interval
  - sampling/detection time
  - observation record time
  - transaction time
  no_history_rewrite: true
owner_boundaries:
  AFQR20_owns:
  - signal/sensing registries
  - sensing-stage determinations
  - contacts/tracks
  - search coverage
  - fusion
  - surveillance collection
  does_not_own:
  - world truth
  - belief/knowledge
  - spatial truth
  - environmental medium
  - body function
  - target selection
  - combat
AFQR_handoffs:
  AFQR01: commit
  AFQR04: logical time
  AFQR05: interfaces
  AFQR07: quantities/resources
  AFQR08: identity
  AFQR10: evidence/belief
  AFQR16: sensor embodiment
  AFQR17: environment
  AFQR18: space
  AFQR19: target/action
shipboard_detection_stress_case:
  title: Multimodal shipboard detection under jamming and environmental failure
  owners:
  - ship/platform owner
  - AFQR-17 compartment environment owners
  - AFQR-18 spatial owners
  - sensor owners
  - observer owners
  - AFQR-10 evidence owners
  - AFQR-19 target-contact consumer
  typed_analysis:
  - Smoke and decompression alter AFQR-17 medium and noise inputs; rotation and damaged alignment alter AFQR-18 geometry/orientation
    references.
  - Optical, radar, thermal, acoustic, network, and automated-defense sensors retain separate readiness and modality profiles.
  - Jamming raises noise or saturation; spoofing creates false signal occurrences and contacts rather than merely subtracting
    a modifier.
  - Distracted human attention is separate from automated policy sampling.
  - Classified feeds may technically collect while remaining institutionally inaccessible.
  - Fusion preserves the contradiction between physical sensors and network alerts.
  - Only private contact/evidence candidates are produced; AFQR-19 target eligibility remains separate.
  - Replay pins signal event times, propagation intervals, calibration versions, RNG receipts, and reception times.
  lawful_outcomes:
  - intruder not acquired
  - false contact created
  - region-valued localization
  - classification without identity
  - classified evidence withheld
  - fusion conflict unresolved
familiar_shared_senses_stress_case:
  title: Familiar, derivatives, shared senses, and contested observation
  owners:
  - each sensor-interface owner
  - each familiar or derivative agency owner
  - contract relation owner
  - AFQR-10 evidence owners per recipient
  - track owner
  typed_analysis:
  - Shared raw signals, shared observations, delayed summaries, and copied sensing capabilities are distinct contracts.
  - A familiar may refuse voluntary relay; contract automation cannot override agency unless a lawful automation/authority
    profile applies.
  - Anti-scrying is a private source-local countermeasure affecting named modalities and stages.
  - Psychic relation sensing may support a relation candidate without physical identity.
  - Similar manifestations require identity-candidate sets and track-continuity analysis.
  - A hostile observer tracking the link targets a signal/relation interface, not automatically every familiar.
  lawful_outcomes:
  - relay refused
  - raw signal delivered without interpretation
  - delayed observation accepted
  - identity ambiguous
  - track split
  - source-local bridge unavailable
mixed_investigation_stress_case:
  title: Mixed physical, informational, social, and magical investigation
  owners:
  - trace and sample owners
  - network log owners
  - communication/testimony owners
  - AFQR-10 evidence and hypothesis owners
  - institutional admissibility owner
  - identity owner
  typed_analysis:
  - Physical traces, altered records, testimony, network logs, magical residue, disguise, decoys, alarms, footage, and samples
    remain separate evidence channels.
  - Collection receipts preserve sampling method, contamination risk, chain of custody, event time, and record time.
  - False alarm and planted decoy are signal-layer deceptions; altered records are evidence-record deceptions; disguise affects
    recognition.
  - Competing hypotheses remain explicit and may be incomparable.
  - Institutional admissibility neither creates nor destroys technical evidence.
  - No single investigation roll can create knowledge or guilt.
  lawful_outcomes:
  - sample contaminated
  - several hypotheses retained
  - identity unresolved
  - evidence rejected by AFQR-10
  - institutionally inadmissible but technically extant
  - source-local residue quarantined
surveillance_promotion_stress_case:
  title: Aggregate surveillance promoted into detailed pursuit
  owners:
  - aggregate sensing partition
  - materialized local sensor owners
  - contact and track owners
  - AFQR-10 evidence owners
  - AFQR-19 pursuit owner
  typed_analysis:
  - Aggregate contact density does not contain invented individual readings.
  - Promotion materializes only certified sensors, current contacts, uncertainty bounds, decoy pressures, maps, environmental
    inputs, and authority partitions.
  - The unusual contact receives a new local contact lineage tied to aggregate evidence without fictitious historical detections.
  - Hidden routes and inaccurate maps remain AFQR-18/AFQR-10 uncertainty.
  - Weather effects come from AFQR-17.
  - Local access differences produce audience-specific sensor/network projections.
  - Pursuit receives a valid contact/track handoff but movement and interception remain AFQR-18/19.
  - Demotion reconciles committed contacts and resource use without double detection.
  lawful_outcomes:
  - local contact tentative
  - decoy association unresolved
  - historical detection unknown
  - pursuit handoff accepted conditionally
  - hidden route preserved
  - aggregate/detail double count prevented
conversion_pipeline_handoff:
  candidate_only: true
  lawful_outcomes:
  - direct
  - normalized
  - source-local
  - quarantine
  - escalation
  campaign_mutation: false
model_authority_policy:
  model_is_untrusted: true
  allowed:
  - intent proposal
  - visible portrayal
  - uncertainty wording
  prohibited:
  - signal generation
  - detection
  - identity
  - search discovery
  - track mutation
  - hidden disclosure
current_runtime_disposition:
  exists:
  - RT-002A read-only owner facade
  - RT-002B visibility-classified projection adapter
  - RT-002C–F object/lever legality-preview-commit-audit fixture
  fixture_only:
  - hidden_fact references
  - visibility tiers
  - redacted/unknown projection packets
  conversion_only:
  - perception/Insight/assessment/stealth/search/sensor descriptors in doctrine/schema
  narrative_only:
  - sensory and visibility prose
  absent:
  - signal registry
  - propagation
  - sensor state
  - attention tasks
  - detection
  - recognition
  - search
  - track
  - fusion
  - surveillance
  blocked: all generalized sensing execution
required_artifacts:
  immediate:
  - ADR
  - decision registry
  - terminology registry
  - contract catalog
  - repository audit
  - research synthesis
  - candidate comparison
  - side-channel model
  - operation grammar
  - 200 scenarios
  - 50-case dry run
  - four stress fixtures
  - acceptance matrix
  - conversion IR amendment
  before_execution:
  - runtime registries
  - versioned evaluators
  - RNG service
  - owner adapters
  - AFQR-10/19 handoff validators
  - projection validator
  - isolation tests
required_prototype:
  name: AFQR-20 Signal, Sensing, Detection, Search, Concealment, and Tracking Dry Run
  case_count: 50
  mutating: false
required_fixtures:
- shipboard multimodal detection
- familiar shared senses
- mixed investigation
- aggregate surveillance promotion
- cross-audience linkability
- model unsupported-claim rejection
blocked_work:
- authoritative signal occurrence mutation
- sensor activation/readiness mutation
- detection execution
- recognition/identification execution
- search execution
- track/fusion mutation
- surveillance execution
- AFQR-19 targeting/pursuit based on unimplemented contact
- model-authored sensory truth
work_unlocked:
- architectural ratification
- conversion pressure classification
- schema drafting
- non-mutating certification fixtures
- bounded narration contract design after security implementation
rejected_alternatives:
- candidate: A
  reason: rejected as universal architecture; retained only as profile-local pressure where useful
- candidate: B
  reason: rejected as universal architecture; retained only as profile-local pressure where useful
- candidate: C
  reason: rejected as universal architecture; retained only as profile-local pressure where useful
- candidate: D
  reason: rejected as universal architecture; retained only as profile-local pressure where useful
- candidate: E
  reason: rejected as universal architecture; retained only as profile-local pressure where useful
- candidate: F
  reason: rejected as universal architecture; retained only as profile-local pressure where useful
- candidate: G
  reason: rejected as universal architecture; retained only as profile-local pressure where useful
residual_risks:
- final perception skills
- attention economy
- tactical visibility
- social perception/deception
- memory and belief revision
- detailed signal equations
- forensic depth
- surveillance law
- hacking
- divination
- illusion metaphysics
- distributed performance
- training-model behavior
AFQR19_sensing_handoff_status: architecturally_closed_conditionally; runtime_targeting_remains_blocked
RT_002G_status: unchanged; object/lever-only, non-perceptual, no sensing or target-contact authority
next_foundational_question:
  question_id: AFQR-21
  title: Objects, Assets, Items, Equipment, Affordances, Use, Custody, Installation, and Material Interaction
  rationale: 'Highest immediate dependency value for the first bounded runtime slice: the current fixture is object/lever
    based, AFQR-19 capability providers and AFQR-20 sensors often depend on equipment and installed components, while economy
    and population simulation are downstream.'
exact_next_roadmap_action: Ratify and register AFQR-20; execute the 50-case non-mutating dry run and an RT-002A–RT-002F sensing/model-noninterference
  audit; keep RT-002G object/lever-only and non-perceptual; then open AFQR-21 as a read-only foundational investigation before
  generalized object, sensor, targeting, or combat execution.
```
