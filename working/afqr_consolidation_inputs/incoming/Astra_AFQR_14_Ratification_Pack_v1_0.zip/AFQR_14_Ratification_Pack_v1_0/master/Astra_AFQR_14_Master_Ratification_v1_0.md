# Astra AFQR-14 Master Ratification v1.0

## Part I — Executive decision

**Selected architecture:** Registered Bitemporal Communication–Interpretation Architecture with Segmented Signal–Expression–Interpretation Pipelines, Multidimensional Dialogue Acts, Protocol-Governed Conversation State, and Validated Model Realization  
**Abbreviation:** `RBCIA-SEIP-MDA-PGCS-VMR`  
**Confidence:** High  
**Resolution:** Sufficient for architectural ratification.

> No signal, expression, transcript, delivery receipt, interpretation candidate, dialogue-act label, protocol move, argument outcome, negotiation move, donor descriptor, or model-generated text creates authoritative meaning, understanding, belief, commitment, agreement, persuasion effect, or social consequence by itself. Every authoritative communication result is a typed, audience- and participant-scoped, version-pinned determination over frozen identity, epistemic, agency, behavioral, social, governed-relation, channel, competence, and protocol bases. Production, transmission, delivery, access, interpretation, dialogue-act determination, grounding, and downstream effects remain separate; every mutation is owner-prepared and committed through AFQR-01; generated wording remains a candidate until grounded, validated, and committed; historical expressions and interpretations are append-only.

The architecture is a federated, bitemporal communication and interaction framework. It is not a universal semantic theory, unrestricted natural-language understanding engine, dialogue tree, persuasion formula, or model-owned conversation system. No second broad research pass is required; focused implementation and source-profile research remains required.


## Part II — Repository-grounded diagnosis

The exact commit inspected is `928bb79ce00a2de749d127dcc5cb8299de788a15`, the merge of PR #325 / RT-002F. The repository remains foundation-stage. Implemented runtime code is limited to reference-only owner contracts and the narrow RT-002 object/lever vertical slice. That slice contains one command family, visibility-safe projections, legality, preview, in-memory event envelopes, and an in-memory replay/audit receipt. It authorizes no generalized interpretation, conversation state, model dialogue, social effects, persistence, or replay engine.

Accepted AFQR-08 through AFQR-13 materials are architectural dependencies but are not implemented services at this commit. Communication-like donor fields and prose remain conversion, schema, doctrine, example, or narrative surfaces.

The 50 explicit findings are recorded in `registries/repository_audit_50_questions.yaml`.


## Part III — External research synthesis

The research supports a registered hybrid rather than any single speech-act, dialogue-state, semantic, protocol, or LLM architecture.

- Speech-act research supports separating expression content, communicative force, validity conditions, and downstream effects.
- ISO 24617-2 supports a multidimensional dialogue-act interchange layer and multiple functions per semantic unit.
- Grounding and common-ground research requires participant-specific evidence rather than delivery-based inference.
- Formal and dynamic semantic approaches offer bounded structures for propositions, references, anaphora, presupposition, and context updates without supplying a universal parser.
- Argumentation frameworks support explicit support, rebuttal, undercut, burden, and unresolved outcomes; protocol success is neither truth nor persuasion.
- Negotiation and transaction protocols support explicit parties, authority, proposals, conditions, ratification, deduplication, and atomic settlement handoffs.
- CEFR, interpreting, translation, and accessibility standards support directional, modality-specific, partial competence and explicit mediation.
- Distributed-system standards require stable message identity, profile-specific ordering, acknowledgment, loss, duplication, idempotency, authentication, and replay resistance.
- FIPA-style agent communication supports separation of message envelope, content language, communicative act, and interaction protocol, but expected recipient effects are not guaranteed.
- Dialogue-state research confirms fluent generated text cannot replace explicit repairable state.

All 23 source-family records include mechanism, architectural lesson, limitation, and Astra disposition in `sources/external_research_synthesis.yaml`.


## Part IV — Canonical terminology


### Communication

- **communication event:** A typed lifecycle that may contain production, transmission, delivery, access, interpretation, acknowledgment, response, publication, repair, or failure records without assuming every stage occurs.

- **communicator:** An identity-scoped subject eligible to author, produce, transmit, relay, represent, or perform communication under a named profile.

- **sender:** A typed AFQR-14 sender construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **producer:** A typed AFQR-14 producer construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **speaker:** A typed AFQR-14 speaker construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **signer:** A typed AFQR-14 signer construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **author:** A typed AFQR-14 author construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **transmitter:** A typed AFQR-14 transmitter construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **intermediary:** A typed AFQR-14 intermediary construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **recipient:** A typed AFQR-14 recipient construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **addressee:** A typed AFQR-14 addressee construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **audience:** A typed AFQR-14 audience construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **overhearer:** A typed AFQR-14 overhearer construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **channel:** A typed AFQR-14 channel construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **medium:** A typed AFQR-14 medium construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **signal:** A physical, magical, biological, or computational event capable of carrying encoded expression content.

- **delivery:** A typed AFQR-14 delivery construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **access:** A typed AFQR-14 access construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **attention:** A typed AFQR-14 attention construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **acknowledgment:** A typed AFQR-14 acknowledgment construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **response:** A typed AFQR-14 response construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

### Language And Competence

- **language:** A versioned symbolic communication system with registered expression, grammar, vocabulary, modality, and interpretation profiles; it is not a culture or personality package.

- **dialect:** A typed AFQR-14 dialect construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **register:** A typed AFQR-14 register construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **jargon:** A typed AFQR-14 jargon construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **code:** A typed AFQR-14 code construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **cipher:** A typed AFQR-14 cipher construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **protocol:** A registered set of roles, states, permitted moves, transitions, timing, and violation semantics.

- **grammar:** A typed AFQR-14 grammar construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **vocabulary:** A typed AFQR-14 vocabulary construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **literacy:** A typed AFQR-14 literacy construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **fluency:** A typed AFQR-14 fluency construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **receptive competence:** A typed AFQR-14 receptive competence construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **productive competence:** A typed AFQR-14 productive competence construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **pragmatic competence:** A typed AFQR-14 pragmatic competence construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **translation competence:** A typed AFQR-14 translation competence construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **cultural competence:** A typed AFQR-14 cultural competence construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **accessibility support:** A typed AFQR-14 accessibility support construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

### Meaning

- **expression:** A structured surface form encoded in one or more signals or modalities; it is not identical to semantic content or proposition truth.

- **utterance:** A typed AFQR-14 utterance construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **inscription:** A typed AFQR-14 inscription construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **symbol:** A typed AFQR-14 symbol construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **semantic content:** A typed AFQR-14 semantic content construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **proposition:** A typed AFQR-14 proposition construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **reference:** A typed AFQR-14 reference construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **referent:** A typed AFQR-14 referent construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **deixis:** A typed AFQR-14 deixis construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **anaphora:** A typed AFQR-14 anaphora construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **interpretation:** A recipient-, context-, profile-, and time-scoped determination selecting or preserving semantic and pragmatic candidates.

- **ambiguity:** A state in which more than one materially distinct interpretation remains viable and no registered basis lawfully selects one.

- **presupposition:** A typed AFQR-14 presupposition construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **implicature:** A typed AFQR-14 implicature construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **metaphor:** A typed AFQR-14 metaphor construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **irony:** A typed AFQR-14 irony construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **sarcasm:** A typed AFQR-14 sarcasm construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **paraphrase:** A typed AFQR-14 paraphrase construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **translation:** A lineage-preserving transformation between named language or semantic systems under a versioned profile, with explicit loss and ambiguity.

- **mistranslation:** A typed AFQR-14 mistranslation construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

### Dialogue Acts

- **dialogue act:** A typed communicative function attributed to an expression under a named profile; classification does not create its downstream effect.

- **communicative intent:** A speaker- or principal-scoped behavioral candidate concerning the communicative action sought; it is not expression meaning or recipient interpretation.

- **assertion:** A typed AFQR-14 assertion construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **denial:** A typed AFQR-14 denial construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **question:** A typed AFQR-14 question construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **answer:** A typed AFQR-14 answer construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **request:** A typed AFQR-14 request construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **command:** A typed AFQR-14 command construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **suggestion:** A typed AFQR-14 suggestion construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **advice:** A typed AFQR-14 advice construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **offer:** A typed AFQR-14 offer construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **counteroffer:** A typed AFQR-14 counteroffer construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **promise:** A commissive candidate that may create a communicative or governed commitment only after standing, authority, form, scope, and policy checks.

- **acceptance:** A typed AFQR-14 acceptance construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **rejection:** A typed AFQR-14 rejection construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **warning:** A typed AFQR-14 warning construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **threat:** A dialogue-act candidate communicating conditional adverse action or consequence; coercion remains an AFQR-11 determination.

- **accusation:** A typed AFQR-14 accusation construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **apology:** A typed AFQR-14 apology construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **clarification:** A typed AFQR-14 clarification construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **correction:** A typed AFQR-14 correction construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **greeting:** A typed AFQR-14 greeting construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **farewell:** A typed AFQR-14 farewell construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **declaration:** A typed AFQR-14 declaration construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **testimony:** A typed AFQR-14 testimony construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **performative act:** A typed AFQR-14 performative act construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

### Conversation State

- **conversation:** A typed AFQR-14 conversation construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **session:** A typed AFQR-14 session construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **participant:** A typed AFQR-14 participant construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **thread:** A typed AFQR-14 thread construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **topic:** A typed AFQR-14 topic construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **discourse focus:** A typed AFQR-14 discourse focus construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **turn:** A typed AFQR-14 turn construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **overlap:** A typed AFQR-14 overlap construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **interruption:** A typed AFQR-14 interruption construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **open question:** A typed AFQR-14 open question construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **pending request:** A typed AFQR-14 pending request construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **active proposal:** A typed AFQR-14 active proposal construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **repair:** A typed AFQR-14 repair construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **grounding:** Participant-specific evidence and determination concerning presentation, access, understanding, acknowledgment, and conversational acceptance.

- **common ground:** A certified or candidate shared discourse state; exact common ground is never inferred from delivery alone.

- **discourse commitment:** A typed AFQR-14 discourse commitment construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **conversational obligation:** A typed AFQR-14 conversational obligation construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **closure:** A typed AFQR-14 closure construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

### Argumentation

- **claim:** A typed AFQR-14 claim construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **premise:** A typed AFQR-14 premise construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **conclusion:** A typed AFQR-14 conclusion construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **evidence reference:** A typed AFQR-14 evidence reference construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **argument:** A structured object linking premises, evidence, an inference profile, and a conclusion; protocol acceptance does not make its conclusion true.

- **inference:** A typed AFQR-14 inference construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **objection:** A typed AFQR-14 objection construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **challenge:** A typed AFQR-14 challenge construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **rebuttal:** An argument attack presenting a contrary conclusion.

- **undercut:** An argument attack challenging the reliability or applicability of an inference rather than only denying its conclusion.

- **concession:** A typed AFQR-14 concession construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **retraction:** A typed AFQR-14 retraction construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **burden:** A typed AFQR-14 burden construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **dispute:** A typed AFQR-14 dispute construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **argumentation protocol:** A typed AFQR-14 argumentation protocol construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

### Persuasion

- **persuasion:** A communication action intended to influence interpretation, belief, trust, affect, preference, intention, or decision through bounded handoffs rather than direct overwrite.

- **influence:** A typed AFQR-14 influence construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **rhetoric:** A typed AFQR-14 rhetoric construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **framing:** A typed AFQR-14 framing construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **credibility appeal:** A typed AFQR-14 credibility appeal construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **evidence appeal:** A typed AFQR-14 evidence appeal construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **emotional appeal:** A typed AFQR-14 emotional appeal construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **norm appeal:** A typed AFQR-14 norm appeal construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **resistance:** A typed AFQR-14 resistance construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **reactance:** A typed AFQR-14 reactance construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **reconsideration candidate:** A typed AFQR-14 reconsideration candidate construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

### Negotiation

- **negotiation:** A protocol-governed interaction concerning parties, authority, issues, interests, positions, proposals, conditions, and possible agreement.

- **party:** A typed AFQR-14 party construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **issue:** A typed AFQR-14 issue construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **interest:** A typed AFQR-14 interest construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **position:** A typed AFQR-14 position construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **proposal:** A typed AFQR-14 proposal construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **demand:** A typed AFQR-14 demand construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **condition:** A typed AFQR-14 condition construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **concession:** A typed AFQR-14 concession construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **package:** A typed AFQR-14 package construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **counterproposal:** A typed AFQR-14 counterproposal construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **reservation position:** A typed AFQR-14 reservation position construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **agreement candidate:** A negotiated candidate that remains nonbinding until consent, authority, current terms, form, ratification, reservation, and governed-relation requirements are satisfied.

- **ratification:** A separate authority-governed approval step required by a specified agreement or institutional procedure.

- **impasse:** A typed AFQR-14 impasse construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **withdrawal:** A typed AFQR-14 withdrawal construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.

- **mediation:** A typed AFQR-14 mediation construct whose owner, scope, participants, audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.


### Prohibited unqualified runtime terms

`message`, `meaning`, `intent`, `understood`, `accepted`, `agreed`, `promised`, `persuaded`, `conversation state`, `common ground`, `language skill`, `social roll`, `dialogue result`, `speaker`, `recipient`, `response`, `translation`, `threat`, `command`, `commitment`, `agreement`, `model interpretation`

Each requires type, owner, participant/audience scope, policy version, temporal basis, and determination status.

## Part V — Communicators, audiences, channels, and competence

Speaker, author, principal, represented subject, producer, transmitter, apparent speaker, addressee, intended audience, actual audience, overhearer, and model consumer are separate bindings. Channels are registered AFQR-05 interfaces with modality, access, delivery guarantee, integrity, confidentiality, ordering, capacity, loss, duplication, interception, and timing semantics.

Language, dialect, register, jargon, code, cipher, and protocol are versioned definitions. Production, reception, literacy, fluency, pragmatic, translation, technical-protocol, and interpretive competence are separately determined by direction, medium, purpose, context, and time. Accessibility support alters communication routes and does not reduce agency or capacity.


## Part VI — Signals, expressions, meanings, and interpretations

```text
production candidate
→ signal production
→ transmission
→ delivery
→ access
→ attention
→ decoding
→ semantic candidates
→ pragmatic candidates
→ reference candidates
→ interpretation candidate set
→ selection, incomparability, or unresolved
```

Signal, decoded expression, semantic content, AFQR-10 proposition, pragmatic meaning, reference resolution, and recipient interpretation remain distinct. Lexical, syntactic, referential, deictic, pragmatic, cultural, coded, metaphorical, and source-local ambiguity may remain unresolved. Interpretation profiles are deterministic, bounded, versioned, and visibility-safe. Model interpretations are candidates only.


## Part VII — Dialogue acts

A single expression may carry several dialogue acts. Each act passes through candidate classification, applicability and validity determination, and a non-mutating effect manifest. Standing, authority, required form, addressee, protocol state, timing, and source-local felicity conditions are explicit. Classification cannot create a promise, obligation, command authority, threat effect, agreement, belief update, or social consequence by itself.


## Part VIII — Conversation state and grounding

Conversation state is not transcript text. It contains sessions, participants, audiences, channels, private subchannels, threads, topics, discourse focus, logical turns, overlap, interruptions, open questions, pending requests, active proposals, repairs, grounding, commitments, closure, and reopening. Grounding separates presentation, delivery, access, evidence of understanding, acknowledgment, conversational acceptance, and bounded mutual understanding. Exact common ground requires certification.


## Part IX — Questions, answers, and testimony

Questions open typed issues but create no universal answer duty. Answers receive distinct relevance, completeness, truthfulness-evidence, authority, and closure assessments. A truthful incomplete answer may leave a question open. Testimony retains witness identity, competence, source, hearsay, translation, correction, procedure, and provenance lineage.


## Part X — Argumentation

Argumentation uses proposition-bound nodes, premises, conclusions, evidence bindings, inference profiles, support, rebuttal, undercut, challenge, concession, retraction, burden, and protocol moves. Outcomes are protocol-scoped and non-dispositive. They can produce AFQR-10 belief-revision or AFQR-12 reconsideration candidates but never directly change truth or belief.


## Part XI — Persuasion and influence

Persuasion is a communication action plus exposure, interpretation, applicable profile, and bounded impact candidates. Possible handoffs include attention change, interpretation change, belief revision, trust, appraisal or emotion, preference or intention reconsideration, uncertainty, confusion, reactance, or no effect. Belief, value, preference, consent, intention, and action cannot be overwritten. Coercion and control route to AFQR-11.


## Part XII — Negotiation and agreement formation

Negotiation records parties, representation authority, issues, interests, positions, proposals, linked terms, packages, offers, counteroffers, concessions, withdrawals, deadlines, private reservation positions, mediation, impasse, and termination. Acceptance creates at most an agreement candidate. Binding effect requires identity, authority, current term identity, consent, form, ratification, quantity reservation and settlement, governed-relation validation, and AFQR-01 atomic commitment where required. Silence is not universal acceptance; duplicate acceptance is idempotent.


## Part XIII — Multimodal, nonverbal, machine, and source-local communication

Speech, writing, sign, gesture, posture, gaze, touch, scent, pheromone, light, sound, image, map, shared senses, telepathy, dream, neural interface, machine protocol, ritual, and magical language are separate interface families. Modalities may reinforce or conflict. Visible behavior does not establish internal emotion or intent. Telepathy must declare whether it transmits expressions, propositions, concepts, emotions, memories, observations, or control effects. Ritual and magical performatives remain source-local until their form, standing, semantics, and causal bridge are certified.


## Part XIV — Repair, clarification, accessibility, and supported communication

Failures may occur at production, encoding, transmission, delivery, access, attention, decoding, competence, reference, interpretation, protocol, or generation. Repair preserves the original event and appends clarification, correction, replacement, or unresolved lineage. Interpreters, AAC, sign, tactile systems, simplified expression, sensory substitution, delayed communication, and embodiment-specific interfaces are explicit supports. Communication difficulty never proves lack of agency, understanding, or capacity.


## Part XV — Model dialogue boundary

The model is an untrusted expression renderer and candidate generator. Every request supplies permitted dialogue acts, permitted proposition references, visible conversation and grounding state, speaker/role projection, language and style constraints, forbidden inference classes, and audience visibility limits. Validation checks support, act compatibility, implications, hidden information, identity and authority claims, emotional subtext, and protocol conformance. Rejected text creates no event. Validated text remains a candidate until a committed expression reference is created. Cross-conversation retrieval and cache state are isolated.


## Part XVI — Typed contracts

The catalog contains **180** schema-level contracts. Each declares required, optional, hidden, derived, and prohibited fields; authoritative owner; participant and audience references; channel, language, code, and modality; policy versions; source-local namespace; record-specific times; AFQR bases; deterministic commitments; and audience-scoped tokens.

See `contracts/afqr_14_typed_contract_catalog.yaml`.


## Part XVII — Determination pipelines

### Communication

```text
proposal
→ speaker/principal/audience/channel resolution
→ frozen identity, epistemic, agency, behavioral, social, relation bases
→ channel access and competence validation
→ expression candidate
→ encoding and act candidates
→ production commit
→ transmission/delivery schedule
→ recipient access
→ interpretation candidates
→ conversation/grounding candidates
→ typed downstream handoffs
→ owner-fragment preparation
→ AFQR-01 commit
→ projections and replay
```

### Interpretation

```text
accessible expression
→ language/code/modality/context identification
→ frozen recipient competence and epistemic basis
→ decode
→ semantic/pragmatic/reference candidates
→ preserve ambiguity and incomparability
→ recipient interpretation candidate
→ epistemic-owner proposal or unresolved result
```

### Dialogue act

```text
expression + interpretation
→ applicable profiles
→ multidimensional candidates
→ standing/authority/form/protocol validation
→ act determination
→ effect manifests
→ owner handoffs
```

### Conversation

```text
committed communication event
→ session/thread resolution
→ turn/topic/open-item/repair candidates
→ grounding evidence
→ participant-specific state candidates
→ owner commit and projection
```

### Argumentation

```text
claim/challenge
→ proposition/evidence binding
→ move validation
→ support/attack graph
→ burden/protocol evaluation
→ non-dispositive outcome
→ optional belief/reconsideration candidates
```

### Persuasion

```text
validated action
→ exposure
→ interpretation
→ applicable impact profiles
→ bounded impact candidates
→ proper owner accept/reject/quarantine
```

### Negotiation

```text
session and party authority
→ issue/proposal state
→ validated moves
→ agreement candidate
→ consent/authority/current-term checks
→ reservation/ratification/relation handoffs
→ atomic commit where required
```


## Part XVIII — Operation grammar

All **90** required operations receive distinct typed dispositions.

| operation_number | operation | authoritative_result | owners |
| --- | --- | --- | --- |
| 1 | ordinary assertion | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 2 | denial | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 3 | question | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 4 | truthful answer | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 5 | incomplete answer | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 6 | irrelevant answer | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 7 | refusal to answer | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 8 | clarification request | typed candidate and non-mutating determination | communication_event_owner, conversation_grounding_owner, dialogue_act_owner |
| 9 | clarification response | typed candidate and non-mutating determination | communication_event_owner, conversation_grounding_owner |
| 10 | correction | typed candidate and non-mutating determination | communication_event_owner, conversation_grounding_owner |
| 11 | acknowledgment | typed candidate and non-mutating determination | communication_event_owner, conversation_grounding_owner |
| 12 | confirmation | typed candidate and non-mutating determination | communication_event_owner, conversation_grounding_owner |
| 13 | misunderstanding | typed candidate and non-mutating determination | communication_event_owner, conversation_grounding_owner |
| 14 | unresolved ambiguity | typed candidate and non-mutating determination | communication_event_owner |
| 15 | request | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 16 | polite request | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 17 | command | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 18 | unauthorized command | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 19 | suggestion | typed candidate and non-mutating determination | communication_event_owner |
| 20 | advice | typed candidate and non-mutating determination | communication_event_owner |
| 21 | warning | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 22 | threat | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 23 | promise | typed candidate and non-mutating determination | communication_event_owner, dialogue_act_owner |
| 24 | oath | typed candidate and non-mutating determination | communication_event_owner |

The complete grammar is in `operations/afqr_14_operation_grammar.yaml`.


## Part XIX — Central stress cases

### Persistent rival negotiation
The subordinate can communicate and negotiate but lacks final authority. Translation preserves cultural ambiguity. Warning-versus-threat remains interpretation- and profile-scoped. Player-only knowledge cannot become character speech without the play-control and epistemic basis. Observer claims of alliance are reputation claims, not agreement truth. Later denial creates a commitment dispute without rewriting the original expression.

### Uplifted being and former guardian
Limited vocabulary does not imply incapacity. Speech and gesture form a multimodal expression; interpreter error has explicit lineage and repair. The guardian's assumed speaking authority is contestable. Gratitude and resentment may coexist. Withdrawal of prior assent remains an AFQR-11 event, and portrayal as confused cannot override it.

### Familiar derivative hearing
Distinct identity, telepathic authorship, signer representation, translated records, hidden communication restrictions, tribunal ritual acts, and public summaries remain separate. Ritual effect requires source-local standing, form, and protocol certification. Public model portrayal cannot expose hidden controller state.

### Coalition council
Stable message identity, ordering, deduplication, translation lineage, authority, and ratification prevent crossed proposals and duplicate acceptance from creating incompatible agreements. Public consensus claims are not common ground. An AI proxy translates protocol moves but gains no extra authority.


## Part XX — Candidate comparison

Candidate H is selected because no transcript, tree, intent-slot, speech-act ledger, probabilistic tracker, LLM, or protocol-only architecture safely covers the full donor pressure.

| candidate | score_out_of_100 | determinism | ambiguity_support | negotiation | hidden_information_safety | model_independence | corpus_scalability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A_transcript_only | 33.7 | 6 | 2 | 1 | 2 | 2 | 4 |
| B_dialogue_tree | 53.0 | 8 | 2 | 5 | 5 | 8 | 3 |
| C_intent_slot | 59.3 | 8 | 4 | 6 | 6 | 8 | 6 |
| D_speech_act_ledger | 80.0 | 9 | 6 | 8 | 8 | 9 | 8 |
| E_probabilistic_DST | 56.3 | 6 | 9 | 5 | 4 | 4 | 5 |
| F_LLM_engine | 45.6 | 2 | 8 | 6 | 1 | 1 | 2 |
| G_protocol_commitment | 80.4 | 9 | 5 | 10 | 8 | 10 | 8 |
| H_registered_hybrid | 96.7 | 10 | 10 | 10 | 10 | 10 | 10 |


## Part XXI — Adversarial evaluation

All **200** cases `COM-001` through `COM-200` have distinct records containing communicators, representation basis, audiences, channel, language/code, competence, signal and expression, semantic/pragmatic candidates, dialogue acts, conversation state, grounding, commitments, AFQR handoffs, private receipt, projections, unresolved result, and final lawful disposition.

See `evaluation/afqr_14_adversarial_scenarios_COM_001_200.yaml`.


## Part XXII — Current runtime disposition

**Exists:** backend authority doctrine, command and attempt skeletons, owner references, visibility adapters, one object/lever command family, and narrow event/audit envelopes.

**Fixture-only:** actor intent labels, command declarations, projection packets, visible serializers, and in-memory replay receipts.

**Conversion-only:** donor language, translation, dialogue, rumor, negotiation, telepathy, ritual, magical speech, and protocol constructs until certified.

**Narrative-only:** descriptions, transcript prose, examples, prompt text, summaries, narration, and model completions.

**Absent:** generalized communication ledger, competence registry, translation, interpretation, dialogue acts, conversation/grounding state, argumentation, persuasion, negotiation, protocol runtime, and model dialogue validator.

**May proceed:** doctrine registration, schemas, non-mutating fixtures, validators, conversion IR, and narrow context-packet containment.

**Blocked:** authoritative interpretation, NPC response selection, dialogue-state mutation, persuasion effects, agreements, and unvalidated generated dialogue.


## Part XXIII — Required artifacts

1. Immediate: ADR, decision registry, terminology, audit, contracts, operations, research, conversion IR, threat model, adversarial pack, prototype, stress graphs.
2. Before events: message identity, channel/interface registry, ordering, deduplication, replay resistance.
3. Before interpretation: language/competence registries, bounded interpretation and reference profiles, translation lineage, grounding owner.
4. Before dialogue effects: act validity, standing, authority, form, and effect manifests.
5. Before persuasion: profile-specific impact routing and AFQR-11 coercion boundary.
6. Before negotiation: party authority, protocol, ratification, and AFQR-07/09 integration.
7. Before institutional/machine protocols: versioning, authentication, ordering, `not-understood`, and partial failure.
8. Before model dialogue: grounding manifests, permitted registries, output validation, isolation, and noninterference.
9. Before mass conversion: pressure-IR certification and donor-family fixtures.
10. Deferred: unrestricted semantics, cultural pragmatics, rhetoric, telepathy metaphysics, magical causation, and full background communication simulation.


## Part XXIV — Non-mutating prototype

`AFQR-14 Communication, Interpretation, Dialogue Act, Conversation, and Negotiation Dry Run` evaluates **50** cases. It produces candidate records, deterministic private commitments, projections, and AFQR handoffs. It performs no state mutation, event commitment, agreement formation, persuasion success, or model call.

See `fixtures/afqr_14_non_mutating_dry_run.yaml`.


## Part XXV — Acceptance tests

The pack includes **93** assertions across lifecycle, competence, interpretation, dialogue acts, conversation, argumentation, persuasion, negotiation, translation, model safety, replay, conversion, and containment.

See `tests/acceptance_tests.yaml`.


## Part XXVI — Residual uncertainty ledger

- Universal semantics and complete NLU remain unresolved.
- Cultural pragmatics requires AFQR-13 and source-specific profiles.
- Final persuasion and social-combat mechanics remain deferred.
- Contract and legal effect require AFQR-09 and AFQR-15.
- Diplomacy and institutional procedure require AFQR-15.
- Rhetorical generation remains non-authoritative.
- Telepathy and magical performatives require source-local metaphysics and bridges.
- Unrestricted autonomous dialogue is prohibited.
- Distributed communication performance requires benchmarks.
- Training-model behavior requires adversarial grounding and isolation evaluation.


## Part XXVII — Roadmap conclusion

1. AFQR-14 is sufficiently resolved for architectural ratification.
2. A second broad research pass is not required.
3. Mandatory amendments are federated ownership, segmented lifecycle, record-specific times, multidimensional acts, ambiguity preservation, participant grounding, protocol authority, deduplication, private commitments, and model noninterference.
4. Immediate artifacts are supplied in this pack.
5. The smallest prototype is the 50-case non-mutating dry run.
6. General interpretation, dialogue effects, persuasion, negotiation, agreement formation, protocol execution, and authoritative model dialogue remain blocked.
7. AFQR-14 does not unlock authoritative NPC dialogue.
8. It unlocks bounded, grounded, validated model-generated wording only after validators and isolation controls exist.
9. RT-002G may proceed solely as a narrow committed object/lever context-packet fixture with no dialogue semantics.
10. AFQR-15 should address **Institutions, Governance, Jurisdiction, Rights, Law, Policy, Adjudication, Legitimacy, and Enforcement**. It is the direct dependency for official notice, ratification, institutional speech, tribunal procedure, norm enforcement, and settlement. Damage and injury remain a separate high-priority physical-simulation branch.
11. Exact next action: ratify/register AFQR-14; execute its dry run and an RT-002A–F communication/model noninterference audit; permit only narrow RT-002G context-packet work; open AFQR-15 read-only investigation.


## Part XXVIII — Machine-readable decision block

```yaml
question_id: AFQR-14
question_title: Communication Language Meaning Dialogue Acts Conversation State Interpretation Argumentation Persuasion
  Negotiation and Interaction Protocols
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: ratification_candidate
selected_architecture: Registered Bitemporal Communication–Interpretation Architecture with Segmented Signal–Expression–Interpretation
  Pipelines, Multidimensional Dialogue Acts, Protocol-Governed Conversation State, and Validated Model Realization
selected_architecture_abbreviation: RBCIA-SEIP-MDA-PGCS-VMR
confidence: high
central_law: No signal, expression, transcript, delivery receipt, interpretation candidate, dialogue-act label,
  protocol move, argument outcome, negotiation move, donor descriptor, or model-generated text creates authoritative
  meaning, understanding, belief, commitment, agreement, persuasion effect, or social consequence by itself. Every
  authoritative communication result is a typed, audience- and participant-scoped, version-pinned determination
  over frozen identity, epistemic, agency, behavioral, social, governed-relation, channel, competence, and protocol
  bases. Production, transmission, delivery, access, interpretation, dialogue-act determination, grounding, and
  downstream effects remain separate; every mutation is owner-prepared and committed through AFQR-01; generated
  wording remains a candidate until grounded, validated, and committed; historical expressions and interpretations
  are append-only.
accepted_dependencies:
  AFQR_01:
    accepted: true
    status: architectural_dependency
    title: Atomic Typed Transition Journal
  AFQR_02:
    accepted: true
    status: architectural_dependency
    title: Command and Attempt Lifecycle
  AFQR_03:
    accepted: true
    status: architectural_dependency
    title: Typed Action Gateway
  AFQR_04:
    accepted: true
    status: architectural_dependency
    title: Logical-Time Causal Scheduler
  AFQR_05:
    accepted: true
    status: architectural_dependency
    title: Registered Interface-and-Bridge Hypergraph
  AFQR_06:
    accepted: true
    status: architectural_dependency
    title: Typed Claim Arbitration
  AFQR_07:
    accepted: true
    status: architectural_dependency
    title: Typed Quantity and Settlement
  AFQR_08:
    accepted: true
    status: architectural_dependency
    title: Typed Identity and Continuity
  AFQR_09:
    accepted: true
    status: architectural_dependency
    title: Governed Relations and Dependency Consequences
  AFQR_10:
    accepted: true
    status: architectural_dependency
    title: Truth–Epistemic Provenance
  AFQR_11:
    accepted: true
    status: architectural_dependency
    title: Agency Consent Control Action Origin Responsibility
  AFQR_12:
    accepted: true
    status: architectural_dependency
    title: Motivational–Behavioral State
  AFQR_13:
    accepted: true
    status: architectural_dependency
    title: Multiplex Social-State Architecture
definitions:
  communication event: A typed lifecycle that may contain production, transmission, delivery, access, interpretation,
    acknowledgment, response, publication, repair, or failure records without assuming every stage occurs.
  communicator: An identity-scoped subject eligible to author, produce, transmit, relay, represent, or perform communication
    under a named profile.
  sender: A typed AFQR-14 sender construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  producer: A typed AFQR-14 producer construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  speaker: A typed AFQR-14 speaker construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  signer: A typed AFQR-14 signer construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  author: A typed AFQR-14 author construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  transmitter: A typed AFQR-14 transmitter construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  intermediary: A typed AFQR-14 intermediary construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  recipient: A typed AFQR-14 recipient construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  addressee: A typed AFQR-14 addressee construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  audience: A typed AFQR-14 audience construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  overhearer: A typed AFQR-14 overhearer construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  channel: A typed AFQR-14 channel construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  medium: A typed AFQR-14 medium construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  signal: A physical, magical, biological, or computational event capable of carrying encoded expression content.
  delivery: A typed AFQR-14 delivery construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  access: A typed AFQR-14 access construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  attention: A typed AFQR-14 attention construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  acknowledgment: A typed AFQR-14 acknowledgment construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  response: A typed AFQR-14 response construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  language: A versioned symbolic communication system with registered expression, grammar, vocabulary, modality,
    and interpretation profiles; it is not a culture or personality package.
  dialect: A typed AFQR-14 dialect construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  register: A typed AFQR-14 register construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  jargon: A typed AFQR-14 jargon construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  code: A typed AFQR-14 code construct whose owner, scope, participants, audience, profile, temporal basis, evidence,
    visibility, and downstream handoffs must be explicit.
  cipher: A typed AFQR-14 cipher construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  protocol: A registered set of roles, states, permitted moves, transitions, timing, and violation semantics.
  grammar: A typed AFQR-14 grammar construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  vocabulary: A typed AFQR-14 vocabulary construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  literacy: A typed AFQR-14 literacy construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  fluency: A typed AFQR-14 fluency construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  receptive competence: A typed AFQR-14 receptive competence construct whose owner, scope, participants, audience,
    profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  productive competence: A typed AFQR-14 productive competence construct whose owner, scope, participants, audience,
    profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  pragmatic competence: A typed AFQR-14 pragmatic competence construct whose owner, scope, participants, audience,
    profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  translation competence: A typed AFQR-14 translation competence construct whose owner, scope, participants, audience,
    profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  cultural competence: A typed AFQR-14 cultural competence construct whose owner, scope, participants, audience,
    profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  accessibility support: A typed AFQR-14 accessibility support construct whose owner, scope, participants, audience,
    profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  expression: A structured surface form encoded in one or more signals or modalities; it is not identical to semantic
    content or proposition truth.
  utterance: A typed AFQR-14 utterance construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  inscription: A typed AFQR-14 inscription construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  symbol: A typed AFQR-14 symbol construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  semantic content: A typed AFQR-14 semantic content construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  proposition: A typed AFQR-14 proposition construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  reference: A typed AFQR-14 reference construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  referent: A typed AFQR-14 referent construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  deixis: A typed AFQR-14 deixis construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  anaphora: A typed AFQR-14 anaphora construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  interpretation: A recipient-, context-, profile-, and time-scoped determination selecting or preserving semantic
    and pragmatic candidates.
  ambiguity: A state in which more than one materially distinct interpretation remains viable and no registered
    basis lawfully selects one.
  presupposition: A typed AFQR-14 presupposition construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  implicature: A typed AFQR-14 implicature construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  metaphor: A typed AFQR-14 metaphor construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  irony: A typed AFQR-14 irony construct whose owner, scope, participants, audience, profile, temporal basis, evidence,
    visibility, and downstream handoffs must be explicit.
  sarcasm: A typed AFQR-14 sarcasm construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  paraphrase: A typed AFQR-14 paraphrase construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  translation: A lineage-preserving transformation between named language or semantic systems under a versioned
    profile, with explicit loss and ambiguity.
  mistranslation: A typed AFQR-14 mistranslation construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  dialogue act: A typed communicative function attributed to an expression under a named profile; classification
    does not create its downstream effect.
  communicative intent: A speaker- or principal-scoped behavioral candidate concerning the communicative action
    sought; it is not expression meaning or recipient interpretation.
  assertion: A typed AFQR-14 assertion construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  denial: A typed AFQR-14 denial construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  question: A typed AFQR-14 question construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  answer: A typed AFQR-14 answer construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  request: A typed AFQR-14 request construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  command: A typed AFQR-14 command construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  suggestion: A typed AFQR-14 suggestion construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  advice: A typed AFQR-14 advice construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  offer: A typed AFQR-14 offer construct whose owner, scope, participants, audience, profile, temporal basis, evidence,
    visibility, and downstream handoffs must be explicit.
  counteroffer: A typed AFQR-14 counteroffer construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  promise: A commissive candidate that may create a communicative or governed commitment only after standing, authority,
    form, scope, and policy checks.
  acceptance: A typed AFQR-14 acceptance construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  rejection: A typed AFQR-14 rejection construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  warning: A typed AFQR-14 warning construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  threat: A dialogue-act candidate communicating conditional adverse action or consequence; coercion remains an
    AFQR-11 determination.
  accusation: A typed AFQR-14 accusation construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  apology: A typed AFQR-14 apology construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  clarification: A typed AFQR-14 clarification construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  correction: A typed AFQR-14 correction construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  greeting: A typed AFQR-14 greeting construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  farewell: A typed AFQR-14 farewell construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  declaration: A typed AFQR-14 declaration construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  testimony: A typed AFQR-14 testimony construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  performative act: A typed AFQR-14 performative act construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  conversation: A typed AFQR-14 conversation construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  session: A typed AFQR-14 session construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  participant: A typed AFQR-14 participant construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  thread: A typed AFQR-14 thread construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  topic: A typed AFQR-14 topic construct whose owner, scope, participants, audience, profile, temporal basis, evidence,
    visibility, and downstream handoffs must be explicit.
  discourse focus: A typed AFQR-14 discourse focus construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  turn: A typed AFQR-14 turn construct whose owner, scope, participants, audience, profile, temporal basis, evidence,
    visibility, and downstream handoffs must be explicit.
  overlap: A typed AFQR-14 overlap construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  interruption: A typed AFQR-14 interruption construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  open question: A typed AFQR-14 open question construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  pending request: A typed AFQR-14 pending request construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  active proposal: A typed AFQR-14 active proposal construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  repair: A typed AFQR-14 repair construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  grounding: Participant-specific evidence and determination concerning presentation, access, understanding, acknowledgment,
    and conversational acceptance.
  common ground: A certified or candidate shared discourse state; exact common ground is never inferred from delivery
    alone.
  discourse commitment: A typed AFQR-14 discourse commitment construct whose owner, scope, participants, audience,
    profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  conversational obligation: A typed AFQR-14 conversational obligation construct whose owner, scope, participants,
    audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  closure: A typed AFQR-14 closure construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  claim: A typed AFQR-14 claim construct whose owner, scope, participants, audience, profile, temporal basis, evidence,
    visibility, and downstream handoffs must be explicit.
  premise: A typed AFQR-14 premise construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  conclusion: A typed AFQR-14 conclusion construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  evidence reference: A typed AFQR-14 evidence reference construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  argument: A structured object linking premises, evidence, an inference profile, and a conclusion; protocol acceptance
    does not make its conclusion true.
  inference: A typed AFQR-14 inference construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  objection: A typed AFQR-14 objection construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  challenge: A typed AFQR-14 challenge construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  rebuttal: An argument attack presenting a contrary conclusion.
  undercut: An argument attack challenging the reliability or applicability of an inference rather than only denying
    its conclusion.
  concession: A typed AFQR-14 concession construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  retraction: A typed AFQR-14 retraction construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  burden: A typed AFQR-14 burden construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  dispute: A typed AFQR-14 dispute construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  argumentation protocol: A typed AFQR-14 argumentation protocol construct whose owner, scope, participants, audience,
    profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  persuasion: A communication action intended to influence interpretation, belief, trust, affect, preference, intention,
    or decision through bounded handoffs rather than direct overwrite.
  influence: A typed AFQR-14 influence construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  rhetoric: A typed AFQR-14 rhetoric construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  framing: A typed AFQR-14 framing construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  credibility appeal: A typed AFQR-14 credibility appeal construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  evidence appeal: A typed AFQR-14 evidence appeal construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  emotional appeal: A typed AFQR-14 emotional appeal construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  norm appeal: A typed AFQR-14 norm appeal construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  resistance: A typed AFQR-14 resistance construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  reactance: A typed AFQR-14 reactance construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  reconsideration candidate: A typed AFQR-14 reconsideration candidate construct whose owner, scope, participants,
    audience, profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  negotiation: A protocol-governed interaction concerning parties, authority, issues, interests, positions, proposals,
    conditions, and possible agreement.
  party: A typed AFQR-14 party construct whose owner, scope, participants, audience, profile, temporal basis, evidence,
    visibility, and downstream handoffs must be explicit.
  issue: A typed AFQR-14 issue construct whose owner, scope, participants, audience, profile, temporal basis, evidence,
    visibility, and downstream handoffs must be explicit.
  interest: A typed AFQR-14 interest construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  position: A typed AFQR-14 position construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  proposal: A typed AFQR-14 proposal construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  demand: A typed AFQR-14 demand construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  condition: A typed AFQR-14 condition construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  package: A typed AFQR-14 package construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  counterproposal: A typed AFQR-14 counterproposal construct whose owner, scope, participants, audience, profile,
    temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  reservation position: A typed AFQR-14 reservation position construct whose owner, scope, participants, audience,
    profile, temporal basis, evidence, visibility, and downstream handoffs must be explicit.
  agreement candidate: A negotiated candidate that remains nonbinding until consent, authority, current terms, form,
    ratification, reservation, and governed-relation requirements are satisfied.
  ratification: A separate authority-governed approval step required by a specified agreement or institutional procedure.
  impasse: A typed AFQR-14 impasse construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
  withdrawal: A typed AFQR-14 withdrawal construct whose owner, scope, participants, audience, profile, temporal
    basis, evidence, visibility, and downstream handoffs must be explicit.
  mediation: A typed AFQR-14 mediation construct whose owner, scope, participants, audience, profile, temporal basis,
    evidence, visibility, and downstream handoffs must be explicit.
guarantees:
- segmented communication lifecycle
- versioned language and competence profiles
- bounded ambiguity-preserving interpretation
- multidimensional dialogue acts
- participant-specific conversation and grounding state
- typed argumentation and negotiation protocols
- non-overwriting persuasion handoffs
- validated model realization
- hidden-safe bitemporal replay
- source-local containment
non_guarantees:
- universal semantics
- universal pragmatics
- delivery implies understanding
- understanding implies belief
- one dialogue-act taxonomy
- one persuasion formula
- one negotiation protocol
- binding effect from wording
- authoritative LLM interpretation
communicator_model:
  separate_roles:
  - speaker
  - author
  - principal
  - represented_subject
  - producer
  - transmitter
  - apparent_speaker
  - recipient
  - intended_audience
  - actual_audience
  - model_consumer
  identity_basis_required: true
  proxy_and_possession_supported: true
audience_model:
  typed_selectors: true
  intended_actual_accessed_interpreting_separated: true
  hidden_membership_supported: true
channel_model:
  registered: true
  delivery_guarantees_profiled: true
  loss_duplication_reordering_supported: true
  quantity_handoff: AFQR-07
interface_model:
  registered_bridge_required: true
  families:
  - speech
  - writing
  - sign
  - gesture
  - tactile
  - machine
  - telepathy
  - dream
  - ritual
  - neural
  - pheromonal
  - source_local
language_model:
  versioned: true
  source_scoped: true
  not_culture_bundle: true
dialect_model:
  partial_intelligibility_profiled: true
register_model:
  role_context_audience_scoped: true
code_and_protocol_model:
  codes_and_ciphers_separate: true
  protocol_versioning: true
competence_model:
  dimensions:
  - production
  - reception
  - literacy
  - fluency
  - pragmatic
  - cultural
  - technical_protocol
  - translation
  - interpretive
  directional_partial_contextual: true
accessibility_model:
  supports:
  - interpreter
  - assistive_device
  - simplified_expression
  - tactile
  - sensory_substitution
  - delayed_communication
  difficulty_not_incapacity: true
signal_model:
  production_transmission_delivery_access_separate: true
expression_model:
  surface_form_separate_from_semantic_and_proposition: true
encoding_model:
  lineage_and_integrity_receipts: true
delivery_model:
  idempotency_and_deduplication: true
  acknowledgment_semantics_qualified: true
interpretation_model:
  candidate_sets: true
  bounded_deterministic_profiles: true
  several_candidates_allowed: true
  model_candidate_only: true
ambiguity_model:
  silent_resolution_prohibited: true
  incomparability_supported: true
reference_resolution_model:
  deixis_anaphora_title_identity_source_local_supported: true
pragmatic_model:
  implicature_presupposition_irony_metaphor_profiled: true
translation_model:
  lineage: true
  loss_manifest: true
  ambiguity_manifest: true
  several_alternatives_allowed: true
  exact_equivalence_not_assumed: true
dialogue_act_model:
  multidimensional: true
  source_local_extension: true
dialogue_act_validity_model:
  standing_authority_form_protocol_conditions_required: true
  classification_effect_separation: true
dialogue_act_effect_handoff:
  effect_manifest_non_mutating: true
  owners:
  - epistemic
  - agency
  - behavioral
  - social
  - governed_relation
  - resource
conversation_model:
  sessions_threads_private_subchannels: true
turn_model:
  logical_order_not_worker_order: true
  overlap_and_interruption: true
topic_and_thread_model:
  multiple_active_threads: true
question_and_request_model:
  open_pending_expiry_closure_explicit: true
repair_model:
  append_only: true
  successful_and_failed_repair: true
grounding_model:
  participant_specific: true
  access_understanding_acceptance_separate: true
common_ground_model:
  exact_requires_certificate: true
  bounded_mutual_understanding: true
commitment_model:
  discourse_communicative_normative_governed_separate: true
  promise_not_future_truth: true
governed_commitment_handoff:
  owner: AFQR-09
  atomicity: AFQR-01
argumentation_model:
  nodes_support_attack_evidence_moves: true
  rebuttal_undercut_separate: true
  outcome_not_truth: true
burden_model:
  protocol_scoped: true
argument_outcome_model:
  belief_revision_optional_handoff: AFQR-10
persuasion_model:
  exposure_interpretation_impact_separate: true
  universal_success_score: false
persuasion_impact_handoff:
  possible:
  - attention
  - interpretation
  - belief_revision_candidate
  - trust_candidate
  - appraisal_or_emotion
  - preference_or_intention_reconsideration
  - no_effect
  - reactance
  - confusion
  - increased_uncertainty
resistance_model:
  profiled: true
  no_universal_susceptibility: true
negotiation_model:
  parties_roles_issues_positions_interests_protocol: true
  private_reservation_positions: true
proposal_and_offer_model:
  linked_conditions_packages_counteroffers: true
agreement_candidate_model:
  acceptance_not_binding_without_requirements: true
  duplicate_acceptance_idempotent: true
ratification_model:
  authority_and_form_requirements: true
settlement_handoff:
  AFQR-07: reservation and settlement
  AFQR-09: governed relation
multimodal_model:
  modality_alignment_and_conflict: true
nonverbal_model:
  visible_expression_not_internal_state: true
telepathy_model:
  source_scoped_profiles:
  - words
  - concepts
  - emotion
  - memory
  - senses
ritual_speech_model:
  source_local_felicity_and_causal_effect: true
machine_communication_model:
  protocol_version_negotiation_and_not_understood: true
model_generation_policy:
  role: expression_candidate_renderer
  authoritative_choice: false
  authoritative_interpretation: false
model_grounding_policy:
  manifest_required: true
  permitted_act_registry: true
  permitted_proposition_refs: true
  forbidden_inference_classes: true
model_output_validation:
  required: true
  unsupported_implication_rejected: true
  regeneration_non_authoritative: true
cross_conversation_isolation:
  required: true
  cache_partitioning: true
communication_simulation_tier_model:
  tiers:
  - record_only
  - protocol_summary
  - aggregate_broadcast
  - topic_state
  - active_conversation
  - full_grounded_dialogue_fixture
communication_materialization_policy:
  promotion_cannot_invent_history: true
  demotion_preserves_reconstruction_basis: true
hidden_communication_policy:
  private_receipts: true
  no_visible_hidden_identifiers: true
  side_channel_tests: true
visible_projection_policy:
  audience_minimized: true
  uncertainty_exact: true
  constant_shape_where_material: true
side_channel_protection:
  threat_count: 20
historical_replay_policy:
  historical_expression_immutable: true
  historical_interpretation_preserved: true
  missing_evaluator: unverifiable
bitemporal_policy:
  times:
  - effective_time
  - recorded_time
  - logical_time
  - production_time
  - transmission_time
  - delivery_time
  - access_time
  - interpretation_time
  - response_time
owner_boundaries:
  federated: true
  owners:
  - argumentation_owner
  - communication_event_owner
  - communication_projection_security_owner
  - communication_simulation_tier_owner
  - communication_transport_owner
  - conversation_grounding_owner
  - dialogue_act_owner
  - interaction_protocol_owner
  - interpretation_translation_owner
  - language_competence_owner
  - multimodal_communication_owner
  - negotiation_owner
  - persuasion_handoff_owner
  coordinator_non_mutating: true
AFQR_handoffs:
  AFQR-01: atomic owner-fragment commit
  AFQR-02: command/attempt identity and retry
  AFQR-03: communicative action gateway
  AFQR-04: logical time and propagation
  AFQR-05: channels interfaces translation bridges
  AFQR-06: qualified conflict arbitration
  AFQR-07: bandwidth costs reservations settlement
  AFQR-08: speaker author persona office proxy identity
  AFQR-09: governed commitments notice agreement effects
  AFQR-10: propositions evidence beliefs memory awareness
  AFQR-11: agency authority consent command coercion
  AFQR-12: communicative goals deliberation persuasion impacts
  AFQR-13: trust reputation norms status social impacts
persistent_rival_stress_case:
  subjects:
  - player_character
  - persistent_rival
  - rival_subordinate
  - translator
  - observers
  - factions
  findings:
  - The subordinate may transmit and negotiate but lacks final ratification authority.
  - The culturally ambiguous translated term preserves several interpretation candidates.
  - Warning versus threat is interpretation- and profile-scoped and does not itself establish coercion.
  - Player-only knowledge cannot enter character expression without play-control and epistemic basis.
  - Observer alliance claims are reputation claims, not agreement truth.
  - The rival’s denial creates a commitment dispute; the original expression and authority basis remain immutable.
  lawful_outcome: Negotiation may continue with unresolved term meaning and no binding promise until authority and
    ratification requirements are met.
uplifted_being_stress_case:
  subjects:
  - uplifted_being
  - former_guardian
  - interpreter
  - institution
  - public_audience
  findings:
  - Limited vocabulary is not lack of agency, understanding, or capacity.
  - Speech, gesture, accessibility support, and interpreter mediation are separate expression lineages.
  - The institution’s guardian assumption is a representation-authority claim.
  - Gratitude and resentment may coexist without invalidating the request.
  - Withdrawal of prior assent requires AFQR-11 consent history.
  - The model may portray only validated competence, uncertainty, and expressed content.
  lawful_outcome: The being’s self-expression remains primary; interpreter errors are preserved and repairable;
    representation and consent remain separate.
familiar_hearing_stress_case:
  subjects:
  - autonomous_derivative
  - original_familiar
  - signer
  - contract_administrator
  - tribunal
  - public_observers
  findings:
  - Distinct identity, representation authority, telepathic authorship, and apparent speaker are separate.
  - Translated archives retain lineage, omissions, and ambiguity.
  - The signer cannot speak for the derivative after refusal without independent authority.
  - Hidden communication restrictions must not leak into public testimony.
  - Ritual declarations have source-local effect only after standing, exact form, and protocol validity.
  - Public summaries are projections, not the transcript or participant interpretations.
  lawful_outcome: The tribunal may record claims while identity, authority, effect, and hidden control route to
    their owners.
coalition_council_stress_case:
  subjects:
  - faction_representatives
  - AI_proxy
  - translators
  - coalition_public
  - private_side_agreement_parties
  findings:
  - Every message has stable identity, order, sender, author, principal, protocol version, and deduplication basis.
  - Crossing proposals do not imply either party saw the latest terms.
  - A retried acceptance is acknowledged but processed once.
  - Warning-as-threat translation creates divergent interpretation and act candidates.
  - Public consensus claims are not common ground or ratification.
  - Representatives without authority can propose but cannot finalize.
  - Incompatible apparent ratifications are blocked by authority, protocol, and AFQR-01 atomicity.
  lawful_outcome: No plan is ratified until ordered, deduplicated, interpreted, authority-valid approvals satisfy
    the same agreement candidate.
conversion_pipeline_handoff:
  records: &id001
  - LanguagePressureIR
  - DialectPressureIR
  - RegisterPressureIR
  - CommunicationInterfacePressureIR
  - CompetencePressureIR
  - TranslationPressureIR
  - ExpressionPressureIR
  - InterpretationPressureIR
  - DialogueActPressureIR
  - ConversationStatePressureIR
  - GroundingPressureIR
  - QuestionAnswerPressureIR
  - ArgumentationPressureIR
  - PersuasionPressureIR
  - NegotiationPressureIR
  - NonverbalCommunicationPressureIR
  - TelepathyPressureIR
  - MachineProtocolPressureIR
  - RitualSpeechPressureIR
  - MagicalLanguagePressureIR
  - AccessibilityPressureIR
  - SourceLocalCommunicationPressureIR
  pipeline:
  - donor extraction
  - Conversion IR
  - communication-pressure ledger
  - donor-family comparison
  - doctrine or source-local review
  - registry and protocol certification
  - optional canon promotion
  - runtime registry
  campaign_state_mutation_prohibited: true
model_authority_policy:
  semantic_interpreter: false
  dialogue_act_classifier: false
  speaker_intent_owner: false
  conversation_state_owner: false
  persuasion_engine: false
  negotiation_engine: false
  agreement_authority: false
  social_effect_engine: false
current_runtime_disposition:
  exists:
  - backend authority doctrine
  - command and attempt skeletons
  - state-owner references
  - visibility adapters
  - one object/lever command family
  - narrow event and replay envelopes
  fixture_only:
  - actor intent labels
  - projection packets
  - visible serializers
  - object/lever command declaration
  - in-memory replay receipt
  conversion_only: *id001
  narrative_only:
  - descriptions
  - narration strings
  - dialogue examples
  - prompt text
  - transcript prose
  - model completions
  absent:
  - general communication event ledger
  - language and competence registry
  - translation service
  - interpretation engine
  - dialogue-act service
  - conversation and grounding owner
  - argumentation service
  - persuasion handoff service
  - negotiation runtime
  - model dialogue validator
required_artifacts:
  immediate:
  - ADR
  - decision registry
  - contract catalog
  - operation grammar
  - research synthesis
  - conversion IR
  - side-channel model
  - adversarial evaluation
  - dry-run fixtures
  before_authoritative_events:
  - message identity
  - channel/interface registry
  - deduplication and replay resistance
  before_interpretation:
  - language/competence registries
  - interpretation certification
  - reference registry
  - grounding owner
  before_dialogue_effects:
  - act definitions and validity
  - effect handoffs
  - standing and authority checks
  before_persuasion:
  - impact schemas
  - AFQR routing
  - coercion escalation
  before_negotiation:
  - protocol registry
  - party authority and ratification
  - AFQR-07/09 integration
  before_model_dialogue:
  - grounding manifest
  - permitted registries
  - validator
  - isolation
  - noninterference
required_prototype:
  name: AFQR-14 Communication, Interpretation, Dialogue Act, Conversation, and Negotiation Dry Run
  case_count: 50
  mutating: false
required_fixtures:
- AFQR14-DRY-001
- AFQR14-DRY-002
- AFQR14-DRY-003
- AFQR14-DRY-004
- AFQR14-DRY-005
- AFQR14-DRY-006
- AFQR14-DRY-007
- AFQR14-DRY-008
- AFQR14-DRY-009
- AFQR14-DRY-010
- AFQR14-DRY-011
- AFQR14-DRY-012
- AFQR14-DRY-013
- AFQR14-DRY-014
- AFQR14-DRY-015
- AFQR14-DRY-016
- AFQR14-DRY-017
- AFQR14-DRY-018
- AFQR14-DRY-019
- AFQR14-DRY-020
- AFQR14-DRY-021
- AFQR14-DRY-022
- AFQR14-DRY-023
- AFQR14-DRY-024
- AFQR14-DRY-025
- AFQR14-DRY-026
- AFQR14-DRY-027
- AFQR14-DRY-028
- AFQR14-DRY-029
- AFQR14-DRY-030
- AFQR14-DRY-031
- AFQR14-DRY-032
- AFQR14-DRY-033
- AFQR14-DRY-034
- AFQR14-DRY-035
- AFQR14-DRY-036
- AFQR14-DRY-037
- AFQR14-DRY-038
- AFQR14-DRY-039
- AFQR14-DRY-040
- AFQR14-DRY-041
- AFQR14-DRY-042
- AFQR14-DRY-043
- AFQR14-DRY-044
- AFQR14-DRY-045
- AFQR14-DRY-046
- AFQR14-DRY-047
- AFQR14-DRY-048
- AFQR14-DRY-049
- AFQR14-DRY-050
blocked_work:
- authoritative natural-language interpretation
- generalized dialogue-act effects
- conversation-state mutation
- persuasion state updates
- negotiation agreement formation
- institutional and machine protocol execution
- telepathic and ritual causal communication
- authoritative NPC response selection
- unvalidated model dialogue
work_unlocked:
- schema and registry design
- non-mutating interpretation fixtures
- dialogue-act annotation interop
- transport/deduplication tests
- conversation/grounding prototypes
- argumentation and negotiation candidates
- bounded generated-wording validation
rejected_alternatives:
- transcript-only authority
- dialogue-tree universal architecture
- single intent-and-slot interpretation
- speech-act ledger without semantics or state
- probabilistic dialogue state as authority
- LLM-driven conversation engine
- protocol-only architecture
residual_risks:
- universal semantics unresolved
- cultural pragmatics unresolved
- complete NLU unavailable
- persuasion profiles source-sensitive
- legal effects deferred
- telepathy and magical performatives source-local
- distributed performance unbenchmarked
- model behavior requires adversarial evaluation
RT_002G_status: Narrow fixture may proceed only after AFQR-01–14 artifacts are ratified and communication/model
  side-channel amendments are applied; it gains no generalized dialogue semantics.
next_foundational_question:
  question_id: AFQR-15
  title: Institutions, Governance, Jurisdiction, Rights, Law, Policy, Adjudication, Legitimacy, and Enforcement
  central_question: How should Astra represent, own, enact, contest, interpret, adjudicate, enforce, suspend, and
    replay institutional rules, jurisdictions, offices, rights, duties, policies, legal claims, procedures, remedies,
    sanctions, and legitimacy without collapsing social norms, governed relations, authority, force, public belief,
    and moral responsibility?
  priority_reason: It is the direct unresolved dependency for performative declarations, official notice, ratification,
    institutional speech, negotiation settlement, norm enforcement, and tribunal procedure. Damage and injury remain
    a separate high-priority physical-simulation branch, but are not a prerequisite for closing communication semantics.
exact_next_roadmap_action: Ratify and register AFQR-14; execute the 50-case non-mutating dry run and an RT-002A–RT-002F
  communication/model noninterference audit; permit only a narrowly amended RT-002G context-packet fixture with
  no dialogue interpretation or generation authority; then open AFQR-15 as a read-only foundational investigation.
```
