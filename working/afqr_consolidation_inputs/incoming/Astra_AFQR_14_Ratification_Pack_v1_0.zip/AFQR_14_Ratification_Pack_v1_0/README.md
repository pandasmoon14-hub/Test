# AFQR-14 Ratification Pack v1.0

Selected architecture: **Registered Bitemporal Communication–Interpretation Architecture with Segmented Signal–Expression–Interpretation Pipelines, Multidimensional Dialogue Acts, Protocol-Governed Conversation State, and Validated Model Realization** (`RBCIA-SEIP-MDA-PGCS-VMR`).

Repository baseline: `928bb79ce00a2de749d127dcc5cb8299de788a15`.

Read-only architecture pack; no repository modifications or merge-ready runtime implementation.

Counts: 180 contracts, 90 operations, 200 scenarios, 50 dry-run cases, 93 acceptance assertions, 23 research dispositions, 22 conversion IR records, and four stress cases.
