# Astra Foundational Question Resolution 19

## Capabilities, Opportunities, Targeting, Contests, Reactions, Interrupts, Conflict, Combat, and Multi-Actor Action Resolution

**Status:** Architecturally resolved for ratification  
**Repository commit inspected:** `928bb79ce00a2de749d127dcc5cb8299de788a15`  
**Selected architecture:** Registered Federated Capability–Opportunity–Targeting–Resolution Architecture with Typed Readiness–Eligibility Closure, Pluggable Deterministic/Stochastic Resolvers, Bounded Trigger–Reaction Partial Orders, and Owner-Prepared Multi-Domain Effect Commitments  
**Abbreviation:** `RFCOTRA-REC-PDSR-BTRPO-OMEC`  
**Confidence:** High

This master document is the integrated normative decision. The machine-readable registries, schemas, fixtures, evaluations and manifests in this pack are binding supplements where referenced.

## Part I — Executive decision

AFQR-19 selects **Registered Federated Capability–Opportunity–Targeting–Resolution Architecture with Typed Readiness–Eligibility Closure, Pluggable Deterministic/Stochastic Resolvers, Bounded Trigger–Reaction Partial Orders, and Owner-Prepared Multi-Domain Effect Commitments** (`RFCOTRA-REC-PDSR-BTRPO-OMEC`).

### Central law

> No capability label, ability record, equipment grant, action declaration, target reference, dice expression, modifier, trigger, reaction claim, initiative value, combat context, donor rule, public report, or model narration possesses action-resolution or mutation authority by itself. Every authoritative action result is a purpose-scoped, version-pinned, bitemporal determination over frozen capability, access, readiness, legality, identity, epistemic, agency, behavioral, social, communication, institutional, embodiment, environmental, spatial, governed-relation, quantity, scheduler, target, contest, reaction, and resolution bases. AFQR-19 may produce resolution receipts and owner-specific effect candidates only; downstream owners may accept, reject, attenuate, transform, or quarantine those candidates, and only AFQR-01 commits accepted owner fragments. Narration follows audience-visible committed results and never expands them.

It is a federated capability, targeting, resolution, contest and reaction architecture. It is not a universal player-facing dice mechanic, initiative system, action economy, combat loop, target grammar, critical table or model-driven adjudicator.

**Confidence:** High. Another broad research pass is not required. Narrow implementation research remains mandatory for selected resolver families, random-stream service, concurrency coordinator, target-query engine, specific combat profiles and source-local bridges.

## Part II — Repository-grounded diagnosis

### Verified baseline

The inspected `main` head is `928bb79ce00a2de749d127dcc5cb8299de788a15`, merge PR #325 / RT-002F.

The README identifies the repository as foundation-building doctrine, schema, extraction/handoff and validation work, with mature runtime design still future work. It assigns future dice/RNG, command lifecycle, state deltas, hidden-information partitioning, event logs and replay to the backend and denies authoritative state to the model.

RT-002C supports only `interact_with_object_lever`; it reads projection-safe inputs, classifies legality for preview, and explicitly denies action resolution, RNG, resource math, combat/ability/skill/effect resolution, model calls and generalized action service authority. RT-002D is a non-mutating preview bridge with all execution, RNG, combat, consequence and narration flags false. RT-002E/F remain narrow object-lever commit/audit envelopes and do not generalize action resolution.

### Conversion-only

Ability, power, technique, activation, target, range, scope, effect, cost, attack, defense, check, roll, critical, reaction, initiative, encounter and combat fields are extraction/conversion pressure or sourcebook candidates unless separately promoted and implemented.

### Fixture-only

RT-001/RT-002 legality, projection, object-lever declaration, preview, event/state-delta envelope and replay/audit identity.

### Narrative-only

Action prose, attack descriptions, tactical descriptions, visible target wording, combat summaries and generated narration.

### Fifty-question diagnosis

| # | Question | Repository determination |
| --- | --- | --- |
| 1 | Are capabilities represented authoritatively? | No. The runtime has no generalized capability owner; ability and technique material is doctrine or conversion evidence. |
| 2 | Are capability definitions distinct from instances and access? | Not in implemented runtime. AFQR-19 establishes the distinction architecturally. |
| 3 | Are intrinsic, learned, equipment-granted, and source-local capabilities separated? | Conversion pressure exists, but no authoritative registries implement these families. |
| 4 | Is readiness represented? | No generalized readiness state exists. |
| 5 | Are suppression, revocation, cooldown, preparation, and depletion represented? | No authoritative lifecycle owner exists; donor fields remain conversion-only. |
| 6 | Are capability dependencies explicit? | Only accepted AFQR-09 doctrine requires typed dependencies; no runtime capability dependency graph exists. |
| 7 | Are action opportunities represented? | No. RT-002C reads legality for one object-lever command but does not produce generalized opportunities. |
| 8 | Are affordance, capability, permission, and opportunity separated? | Not in implementation. The narrow legality reader only classifies projection sufficiency and permission for preview. |
| 9 | Are action methods represented? | No generalized ActionMethod registry exists. |
| 10 | Are targets represented authoritatively? | Only narrow object-lever and optional NPC references exist in fixtures; no generalized target owner exists. |
| 11 | Are declared, perceived, selected, eligible, actual, and affected targets separated? | No generalized target pipeline exists. |
| 12 | Are target facets and components represented? | No generalized implementation; component targeting is conversion pressure only. |
| 13 | Are hidden and mistaken targets supported? | Hidden-information containment exists narrowly, but no target-mistake or decoy architecture is implemented. |
| 14 | Are target sets and area actions represented? | No. |
| 15 | Are target-set generation and closure bounded? | No implementation exists. |
| 16 | Are line of sight, range, awareness, and eligibility separated? | No generalized runtime query chain exists; accepted AFQR-18 and AFQR-10 require separation. |
| 17 | Are resolution profiles represented? | No generalized resolver registry exists. |
| 18 | Is one dice mechanic assumed? | No canonical runtime mechanic is implemented; donor dice remain conversion evidence. |
| 19 | Are deterministic and stochastic resolution both supported? | The roadmap requires backend RNG, but no generalized resolution execution exists. |
| 20 | Is RNG backend-owned and replayable? | The README assigns future dice/RNG authority to the backend; RT-002F performs no RNG. |
| 21 | Are modifier provenance and stacking represented? | No. |
| 22 | Are rerolls, substitutions, and result transformations represented? | No. |
| 23 | Are outcome dimensions represented? | No generalized multidimensional outcome model exists. |
| 24 | Are partial outcomes represented? | Doctrine pressure exists, but no authoritative runtime outcome-vector implementation exists. |
| 25 | Are contests represented? | No. |
| 26 | Are opposed and multi-party contests separated? | No. |
| 27 | Are cooperation and assistance represented? | No generalized action-resolution implementation. |
| 28 | Are contest stakes and termination represented? | No. |
| 29 | Are triggers represented? | No generalized trigger registry exists. |
| 30 | Are trigger occurrence and trigger awareness separated? | No implementation; accepted AFQR-10 and AFQR-14 require the distinction. |
| 31 | Are reaction opportunities represented? | No. |
| 32 | Are reaction choice and execution separated? | No. |
| 33 | Are interrupts and counters represented? | No. |
| 34 | Are nested reactions bounded? | No reaction engine exists. |
| 35 | Is simultaneous action represented? | No. |
| 36 | Is initiative represented? | Only donor or descriptive fields may mention initiative; no runtime authority exists. |
| 37 | Is initiative separated from scheduler time and priority? | No implementation; AFQR-04 supplies logical-time constraints only. |
| 38 | Is combat represented as a specialized context rather than universal mode? | Not in runtime. Batch and conversion documents discuss combat pressure without implementing a mode. |
| 39 | Are hostility and combat participation separated? | No generalized conflict-state owner exists. |
| 40 | Are defenses separated from AFQR-16 protection? | No implemented resolution layer; AFQR-19 establishes the handoff. |
| 41 | Are pursuit and interception represented? | No authoritative implementation. |
| 42 | Are aggregate and detailed conflict tiers represented? | No. |
| 43 | Can hidden capabilities remain invisible to the model? | General hidden-information doctrine and narrow serializers exist, but capability-specific enforcement is absent. |
| 44 | Are action retries idempotent? | AFQR-02 requires it; RT-002 fixtures use narrow deterministic identities, but generalized actions are absent. |
| 45 | Can downstream owners reject effect candidates? | Accepted AFQR architecture requires it; no generalized effect router is implemented. |
| 46 | Can no lawful resolution profile apply? | Doctrine permits lawful unresolved/quarantine outcomes; no runtime resolver selection exists. |
| 47 | Which fields are conversion-only? | Ability, power, technique, target, range, effect, cost, limitation, attack, defense, check, roll, initiative, reaction, encounter, combat and source-local resolver descriptors. |
| 48 | Which are fixture-only? | RT-001/RT-002 action-legality, object-lever command, preview, event/state-delta and replay/audit records. |
| 49 | Which are narrative-only? | Combat prose, attack descriptions, target descriptions, declared tactics, visible action summaries and model-generated narration. |
| 50 | What execution remains blocked? | All generalized capability readiness, opportunity generation, target grounding and eligibility, RNG, resolution, contests, reactions, simultaneous action, combat, pursuit and owner effect routing. |

### Blocked implementation

There is no generalized capability registry, readiness owner, action-opportunity generator, target pipeline, resolver/RNG authority, modifier engine, contest owner, trigger/reaction service, partial-order coordinator, conflict-context executor, pursuit/interception resolver, tier authority partition, effect router or action-output validator. All generalized execution remains blocked.

## Part III — External research synthesis

The research pass extracts reusable distinctions and rejects universalization.

| Family | Actual mechanism | Astra lesson | Limitation | Disposition |
| --- | --- | --- | --- | --- |
| formal_action_theory | PDDL 2.1 and situation-calculus work separate action parameters, start/over-all/end conditions, effects, concurrency and incomplete knowledge. | Use typed action definitions, temporal guards, conditional effects and frozen information bases; never treat preconditions as execution. | Planning formalisms simplify agency, hidden information and domain mutation. | adapt |
| capability_and_affordance_theory | Affordances are relational action possibilities involving agent capability, object/environment and effect rather than intrinsic object tags. | Model opportunities as actor–method–target–context relations and keep capability, access, permission and affordance separate. | Empirical affordance models are often embodied and task-specific. | adapt |
| automated_planning_and_scheduling | Temporal and contingent planners distinguish schemas, conditions, resources, duration, partial orders, replanning and plan validation. | Use planning outputs only as bounded candidates; AFQR-12 chooses actions and AFQR-19 validates opportunities and execution bases. | Planner completeness and optimality depend on finite modeled domains. | adapt |
| concurrent_and_distributed_systems | Lamport’s happens-before relation establishes partial rather than total order, while concurrency control requires conflict detection, idempotency and fencing. | Represent simultaneous actions as dependency/conflict graphs with deterministic partial orders and atomic or explicitly staged commits. | Distributed-system models do not supply game semantics or agent decisions. | adopt_architecture |
| real_time_and_reactive_systems | Reactive systems separate trigger reception, goal acceptance, cancellation, feedback, completion and stale requests. | Open bounded reaction windows with explicit eligibility, reservation, decision authority, execution and closure. | Control-system deadlines and priorities are not universal narrative time. | adapt |
| formal_state_machines_and_protocol_verification | TLA+ and model checking specify guarded transitions, invariants, liveness, deadlocks and temporal properties. | Model reaction chains, contests and conflict contexts as bounded verified protocols with explicit terminal and unresolved states. | State-space explosion requires abstraction and certification fixtures. | adopt_architecture |
| decision_and_game_theory | Game theory distinguishes simultaneous versus sequential information structures, incomplete information, cooperation, commitment and strategic interaction. | Contest profiles must declare information, participant roles, timing and stakes; never infer behavior from equilibrium. | Equilibrium and utility maximization are descriptive assumptions, not universal actor law. | contain |
| operations_research_and_multiobjective_optimization | Multiobjective optimization preserves constraints, Pareto-incomparable outcomes, scheduling and robust alternatives. | Use outcome vectors and lawful incomparability rather than forcing all action quality into one scalar success value. | Optimization objectives are authored and can leak hidden preferences. | adapt |
| probability_and_stochastic_processes | NIST specifies deterministic random-bit generators and construction requirements for reproducible, testable random streams. | Backend RNG reservations, partitioned streams, canonical candidate ordering and immutable draw receipts are mandatory. | Cryptographic RNG guidance does not define game distributions or fairness. | adapt |
| measurement_and_psychometrics | Measurement standards distinguish latent traits, observed performance, reliability, validity, scale properties and measurement error. | Attributes and skills are evidence inputs under profiles, not literal universal physical quantities. | Human testing assumptions do not transfer directly to nonhuman or fictional capability. | contain |
| sports_and_competition_rules | Sports rules separate participant eligibility, start/restart, fouls, sanctions, timing, scoring, withdrawal and official review. | Contest participation, rule violation, scoring, closure and institutional review require separate records. | Sports rules are highly domain-specific and often presume a neutral official. | adapt |
| military_command_and_control | Official targeting doctrine separates target identification/validation, capability analysis, authority, execution, collateral assessment and combat assessment. | Target identity, permission, method compatibility, execution and downstream effects must remain separate. | Real-world military doctrine is legally and ethically specific and cannot define Astra combat. | contain |
| wargaming_and_combat_simulation | Professional wargaming uses adjudication, fog of war, hidden movement, command delay and after-action evidence rather than treating all outcomes as direct simulation. | Support hidden participant state, explicit adjudication profiles, uncertainty and immutable replay evidence. | Wargames commonly abstract morale, logistics and attrition differently. | adapt |
| robotics_and_autonomous_systems | Autonomous systems separate target acquisition, tracking, feasibility, safety constraints, shared control and authorization. | Automatic reactions require explicit policy and authority; agentic choices remain with decision owners. | Robot control loops optimize physical tasks and do not model general agency or social responsibility. | adapt |
| cybersecurity_and_access_control | Capability security and ABAC separate object identity, rights, subject attributes, operation and environmental policy; least privilege prevents confused-deputy escalation. | Capability possession, access, authorization, delegated scope and target identity must be explicit and revocable. | Security authorization does not establish physical capability, opportunity or success. | adopt_architecture |
| game_engine_action_systems | Unreal’s Gameplay Ability System separates definitions/specs, tags, costs, cooldowns, activation, targeting, cancellation and replicated effect contexts. | Use capability instances, readiness state, target data, cost reservations and cancellation receipts while keeping server authority. | A commercial engine’s component and networking assumptions are not donor-neutral law. | adapt |
| fighting_game_and_real_time_combat | Frame-based combat and rollback networking distinguish startup/active/recovery timing, prediction, authoritative correction and deterministic replay. | Reaction and interruption stages require named timing points; speculative presentation must not become authority. | Frame-perfect timing is unsuitable as a universal tabletop or long-duration action model. | contain |
| strategy_and_tactical_games | Strategy systems vary between alternating, simultaneous, phased and reaction-based activation with fog of war and bounded areas. | Initiative and action economy must remain profile-scoped; conflict context cannot impose one ordering scheme. | Individual commercial rules are optimized for specific scale and balance goals. | contain |
| narrative_and_conflict_resolution_games | Narrative systems model partial success, position/effect, clocks, concessions, consequences and stakes. | Adopt multidimensional outcomes, progress and explicit stakes while routing consequences to authoritative owners. | Narrative permissions cannot override backend truth or invent state. | adapt |
| ttrpg_resolution_systems | TTRPGs use incompatible d20, 2d6, percentile, pools, roll-under, cards, tokens, bids, clocks and automatic-success mechanics. | Register pluggable resolver profiles with explicit scale, candidate, modifier, tie, critical and outcome semantics. | No one donor mechanic is conversion-stable across 200–400 sources. | contain |
| ttrpg_reactions_and_initiative | TTRPGs vary among fixed initiative, phases, alternating activations, simultaneous declaration, held actions and reaction triggers. | Separate scheduler time, priority, initiative, windows, reservations, decisions and execution. | Each system embeds an action economy and fairness model that cannot be universalized. | contain |
| mass_vehicle_fleet_and_group_resolution | Large-scale resolution aggregates formations, command, capability, attrition and mission outcomes, then materializes local interactions selectively. | Use explicit authority partitions and prevent aggregate/local double resolution of resources, defenses and effects. | Aggregation loses individual history and requires certified promotion semantics. | adapt |
| human_factors_and_interface_safety | NASA human-factors standards emphasize mode awareness, control handoff, limitation notification, confirmation, recording and recovery from automation failure. | Action option presentation must expose authorized uncertainty and confirmation needs without leaking hidden state or creating automation surprise. | Human-interface guidance does not define game-world authority or agent behavior. | adopt_architecture |

The synthesis supports four non-negotiable decisions: preconditions and opportunities do not execute actions; concurrent actions require partial orders and conflict closure; RNG must be backend-owned and replayable; and automatic/reactive behavior must expose mode, authority, cancellation and stale-event semantics.

## Part IV — Canonical terminology

Unqualified terms such as `ability`, `action`, `attack`, `target`, `success`, `failure`, `defense`, `initiative`, `turn`, `round`, `combat result`, `critical`, `reaction available`, `enemy`, `ally` are prohibited at authoritative runtime boundaries. They require owner, purpose, profile, target stage, temporal validity and effect status.

| Term | Definition | Anti-collapse |
| --- | --- | --- |
| capability | A registered disposition or executable power that can contribute to an action when its provider, bearer, controller, prerequisites, access and readiness bases are satisfied; it is not permission, competence, opportunity or success. | Do not equate capability with permission, eligibility, resolution, downstream mutation or narration. |
| capability definition | Immutable versioned semantics for one capability family, including interfaces, prerequisites, lifecycle, methods and output boundaries. | Do not equate capability definition with permission, eligibility, resolution, downstream mutation or narration. |
| capability instance | A campaign-scoped instantiation of a capability definition with provider, bearer, controller, lineage and current lifecycle references. | Do not equate capability instance with permission, eligibility, resolution, downstream mutation or narration. |
| capability provider | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability provider with permission, eligibility, resolution, downstream mutation or narration. |
| capability bearer | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability bearer with permission, eligibility, resolution, downstream mutation or narration. |
| capability controller | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability controller with permission, eligibility, resolution, downstream mutation or narration. |
| capability access | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability access with permission, eligibility, resolution, downstream mutation or narration. |
| capability enablement | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability enablement with permission, eligibility, resolution, downstream mutation or narration. |
| capability readiness | A time- and purpose-scoped determination that an instance can participate in a specified action method under frozen current conditions. | Do not equate capability readiness with permission, eligibility, resolution, downstream mutation or narration. |
| capability prerequisite | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability prerequisite with permission, eligibility, resolution, downstream mutation or narration. |
| capability dependency | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability dependency with permission, eligibility, resolution, downstream mutation or narration. |
| capability suppression | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability suppression with permission, eligibility, resolution, downstream mutation or narration. |
| capability revocation | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability revocation with permission, eligibility, resolution, downstream mutation or narration. |
| capability cooldown | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability cooldown with permission, eligibility, resolution, downstream mutation or narration. |
| capability charge | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability charge with permission, eligibility, resolution, downstream mutation or narration. |
| capability preparation | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability preparation with permission, eligibility, resolution, downstream mutation or narration. |
| capability invocation | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate capability invocation with permission, eligibility, resolution, downstream mutation or narration. |
| passive capability | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate passive capability with permission, eligibility, resolution, downstream mutation or narration. |
| active capability | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate active capability with permission, eligibility, resolution, downstream mutation or narration. |
| automatic capability | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate automatic capability with permission, eligibility, resolution, downstream mutation or narration. |
| sustained capability | A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate sustained capability with permission, eligibility, resolution, downstream mutation or narration. |
| source-local capability | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate source-local capability with permission, eligibility, resolution, downstream mutation or narration. |
| affordance | A context-relative action possibility supplied by an object, environment, relation or interface; it neither grants capability nor permission. | Do not equate affordance with permission, eligibility, resolution, downstream mutation or narration. |
| opportunity | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate opportunity with permission, eligibility, resolution, downstream mutation or narration. |
| action opportunity | A bounded, time-valid actor–controller–capability–method–target–context relation eligible to proceed to declaration or execution checks. | Do not equate action opportunity with permission, eligibility, resolution, downstream mutation or narration. |
| action family | A registered semantic family admitted by AFQR-03, distinct from a particular declaration, method, attempt or effect. | Do not equate action family with permission, eligibility, resolution, downstream mutation or narration. |
| action method | A versioned realization of an action family specifying capability, interface, target, resource, timing and effect-profile requirements. | Do not equate action method with permission, eligibility, resolution, downstream mutation or narration. |
| action variant | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate action variant with permission, eligibility, resolution, downstream mutation or narration. |
| action declaration | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate action declaration with permission, eligibility, resolution, downstream mutation or narration. |
| command | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate command with permission, eligibility, resolution, downstream mutation or narration. |
| attempt | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate attempt with permission, eligibility, resolution, downstream mutation or narration. |
| execution | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate execution with permission, eligibility, resolution, downstream mutation or narration. |
| resolution | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate resolution with permission, eligibility, resolution, downstream mutation or narration. |
| effect candidate | A complete typed non-mutating proposal routed to the authoritative downstream owner for acceptance, rejection, attenuation, transformation or quarantine. | Do not equate effect candidate with permission, eligibility, resolution, downstream mutation or narration. |
| committed effect | An owner-accepted state transition fragment committed through AFQR-01, distinct from resolution outcome and narration. | Do not equate committed effect with permission, eligibility, resolution, downstream mutation or narration. |
| action outcome | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate action outcome with permission, eligibility, resolution, downstream mutation or narration. |
| completion | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate completion with permission, eligibility, resolution, downstream mutation or narration. |
| interruption | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate interruption with permission, eligibility, resolution, downstream mutation or narration. |
| cancellation | A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate cancellation with permission, eligibility, resolution, downstream mutation or narration. |
| target | An unqualified reference to a possible subject of an action; prohibited at authoritative boundaries without identity purpose, facet and binding status. | Do not equate target with permission, eligibility, resolution, downstream mutation or narration. |
| declared target | The target reference supplied in the declaration, before identity grounding or eligibility. | Do not equate declared target with permission, eligibility, resolution, downstream mutation or narration. |
| intended target | The subject or purpose the action origin meant to affect, which may differ from the declared or actual target. | Do not equate intended target with permission, eligibility, resolution, downstream mutation or narration. |
| perceived target | The target candidate available under the actor’s frozen epistemic state. | Do not equate perceived target with permission, eligibility, resolution, downstream mutation or narration. |
| selected target | A target candidate chosen under an authorized selection policy; selection does not establish eligibility or effect. | Do not equate selected target with permission, eligibility, resolution, downstream mutation or narration. |
| target identity | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate target identity with permission, eligibility, resolution, downstream mutation or narration. |
| target facet | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate target facet with permission, eligibility, resolution, downstream mutation or narration. |
| target component | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate target component with permission, eligibility, resolution, downstream mutation or narration. |
| aim point | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate aim point with permission, eligibility, resolution, downstream mutation or narration. |
| target support | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate target support with permission, eligibility, resolution, downstream mutation or narration. |
| target set | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate target set with permission, eligibility, resolution, downstream mutation or narration. |
| eligible target | A target binding satisfying the applicable layered target profile at a named time and purpose. | Do not equate eligible target with permission, eligibility, resolution, downstream mutation or narration. |
| actual target | The authoritative target binding used by resolution after substitution, redirection, expiry and execution-time revalidation. | Do not equate actual target with permission, eligibility, resolution, downstream mutation or narration. |
| affected subject | An entity or domain record receiving a downstream effect candidate; it need not have been individually targeted. | Do not equate affected subject with permission, eligibility, resolution, downstream mutation or narration. |
| collateral subject | A nonprimary affected-subject candidate produced through a declared target-set or propagation profile. | Do not equate collateral subject with permission, eligibility, resolution, downstream mutation or narration. |
| decoy | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate decoy with permission, eligibility, resolution, downstream mutation or narration. |
| target substitution | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate target substitution with permission, eligibility, resolution, downstream mutation or narration. |
| target redirection | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate target redirection with permission, eligibility, resolution, downstream mutation or narration. |
| resolution profile | A registered deterministic or stochastic evaluator defining canonical inputs, randomization, comparisons, transformations and outcome dimensions. | Do not equate resolution profile with permission, eligibility, resolution, downstream mutation or narration. |
| difficulty | A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate difficulty with permission, eligibility, resolution, downstream mutation or narration. |
| threshold | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate threshold with permission, eligibility, resolution, downstream mutation or narration. |
| comparison | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate comparison with permission, eligibility, resolution, downstream mutation or narration. |
| roll | A backend-owned stochastic draw under a named profile and reserved random stream; never model-generated authority. | Do not equate roll with permission, eligibility, resolution, downstream mutation or narration. |
| draw | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate draw with permission, eligibility, resolution, downstream mutation or narration. |
| random stream | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate random stream with permission, eligibility, resolution, downstream mutation or narration. |
| candidate set | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate candidate set with permission, eligibility, resolution, downstream mutation or narration. |
| modifier | A typed transformation of specified resolution inputs or outputs with provenance, applicability, stacking, order, visibility and consumption semantics. | Do not equate modifier with permission, eligibility, resolution, downstream mutation or narration. |
| modifier provenance | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate modifier provenance with permission, eligibility, resolution, downstream mutation or narration. |
| stacking | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate stacking with permission, eligibility, resolution, downstream mutation or narration. |
| advantage | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate advantage with permission, eligibility, resolution, downstream mutation or narration. |
| disadvantage | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate disadvantage with permission, eligibility, resolution, downstream mutation or narration. |
| reroll | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate reroll with permission, eligibility, resolution, downstream mutation or narration. |
| substitution | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate substitution with permission, eligibility, resolution, downstream mutation or narration. |
| degree | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate degree with permission, eligibility, resolution, downstream mutation or narration. |
| margin | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate margin with permission, eligibility, resolution, downstream mutation or narration. |
| success count | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate success count with permission, eligibility, resolution, downstream mutation or narration. |
| partial outcome | A profile-defined multidimensional outcome that completes some objectives or dimensions while retaining costs, exposure, incompleteness or complications. | Do not equate partial outcome with permission, eligibility, resolution, downstream mutation or narration. |
| critical result | A profile-local qualification of a result; it has no universal doubled-effect, injury or narration meaning. | Do not equate critical result with permission, eligibility, resolution, downstream mutation or narration. |
| complication | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate complication with permission, eligibility, resolution, downstream mutation or narration. |
| outcome dimension | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate outcome dimension with permission, eligibility, resolution, downstream mutation or narration. |
| contest | A registered multi-participant resolution structure with objective, stakes, roles, comparison or progress rules and closure semantics. | Do not equate contest with permission, eligibility, resolution, downstream mutation or narration. |
| participant | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate participant with permission, eligibility, resolution, downstream mutation or narration. |
| opposition | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate opposition with permission, eligibility, resolution, downstream mutation or narration. |
| resistance | A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate resistance with permission, eligibility, resolution, downstream mutation or narration. |
| objective | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate objective with permission, eligibility, resolution, downstream mutation or narration. |
| stake | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate stake with permission, eligibility, resolution, downstream mutation or narration. |
| role | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate role with permission, eligibility, resolution, downstream mutation or narration. |
| contribution | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate contribution with permission, eligibility, resolution, downstream mutation or narration. |
| assistance | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate assistance with permission, eligibility, resolution, downstream mutation or narration. |
| cooperation | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate cooperation with permission, eligibility, resolution, downstream mutation or narration. |
| competition | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate competition with permission, eligibility, resolution, downstream mutation or narration. |
| asymmetric contest | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate asymmetric contest with permission, eligibility, resolution, downstream mutation or narration. |
| multi-party contest | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate multi-party contest with permission, eligibility, resolution, downstream mutation or narration. |
| tie | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate tie with permission, eligibility, resolution, downstream mutation or narration. |
| withdrawal | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate withdrawal with permission, eligibility, resolution, downstream mutation or narration. |
| concession | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate concession with permission, eligibility, resolution, downstream mutation or narration. |
| contest closure | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate contest closure with permission, eligibility, resolution, downstream mutation or narration. |
| trigger | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate trigger with permission, eligibility, resolution, downstream mutation or narration. |
| trigger occurrence | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate trigger occurrence with permission, eligibility, resolution, downstream mutation or narration. |
| trigger access | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate trigger access with permission, eligibility, resolution, downstream mutation or narration. |
| trigger detection | A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate trigger detection with permission, eligibility, resolution, downstream mutation or narration. |
| reaction window | A bounded logical-time interval in which specifically eligible responses may be reserved and declared. | Do not equate reaction window with permission, eligibility, resolution, downstream mutation or narration. |
| reaction opportunity | An audience-safe, actor-scoped possibility to invoke a qualified reaction during an open window; it is not a decision or execution. | Do not equate reaction opportunity with permission, eligibility, resolution, downstream mutation or narration. |
| reaction eligibility | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate reaction eligibility with permission, eligibility, resolution, downstream mutation or narration. |
| reaction decision | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate reaction decision with permission, eligibility, resolution, downstream mutation or narration. |
| reaction reservation | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate reaction reservation with permission, eligibility, resolution, downstream mutation or narration. |
| reaction | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate reaction with permission, eligibility, resolution, downstream mutation or narration. |
| interrupt | A reaction-family response whose registered priority may alter ordering before another action reaches a designated stage. | Do not equate interrupt with permission, eligibility, resolution, downstream mutation or narration. |
| counteraction | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate counteraction with permission, eligibility, resolution, downstream mutation or narration. |
| preemption | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate preemption with permission, eligibility, resolution, downstream mutation or narration. |
| redirection | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate redirection with permission, eligibility, resolution, downstream mutation or narration. |
| replacement action | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate replacement action with permission, eligibility, resolution, downstream mutation or narration. |
| nested response | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate nested response with permission, eligibility, resolution, downstream mutation or narration. |
| response depth | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate response depth with permission, eligibility, resolution, downstream mutation or narration. |
| stale reaction | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate stale reaction with permission, eligibility, resolution, downstream mutation or narration. |
| priority | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate priority with permission, eligibility, resolution, downstream mutation or narration. |
| partial order | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate partial order with permission, eligibility, resolution, downstream mutation or narration. |
| simultaneous declaration | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate simultaneous declaration with permission, eligibility, resolution, downstream mutation or narration. |
| simultaneous execution | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate simultaneous execution with permission, eligibility, resolution, downstream mutation or narration. |
| initiative | A source- or profile-scoped ordering input; it is not universal speed, scheduler time, action priority or reaction precedence. | Do not equate initiative with permission, eligibility, resolution, downstream mutation or narration. |
| turn | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate turn with permission, eligibility, resolution, downstream mutation or narration. |
| round | A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate round with permission, eligibility, resolution, downstream mutation or narration. |
| phase | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate phase with permission, eligibility, resolution, downstream mutation or narration. |
| conflict | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate conflict with permission, eligibility, resolution, downstream mutation or narration. |
| engagement | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate engagement with permission, eligibility, resolution, downstream mutation or narration. |
| combat | A specialized conflict-context family for physical or analogous hostile interaction; it does not create separate truth, physics or mutation authority. | Do not equate combat with permission, eligibility, resolution, downstream mutation or narration. |
| encounter | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate encounter with permission, eligibility, resolution, downstream mutation or narration. |
| hostility | A social, behavioral, institutional or asserted orientation relevant to conflict; it is not participation, legal target status or permission. | Do not equate hostility with permission, eligibility, resolution, downstream mutation or narration. |
| combat participant | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate combat participant with permission, eligibility, resolution, downstream mutation or narration. |
| protected subject | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate protected subject with permission, eligibility, resolution, downstream mutation or narration. |
| neutral subject | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate neutral subject with permission, eligibility, resolution, downstream mutation or narration. |
| surrender | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate surrender with permission, eligibility, resolution, downstream mutation or narration. |
| pursuit | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate pursuit with permission, eligibility, resolution, downstream mutation or narration. |
| interception | A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose, profile version, temporal validity, and basis closure. | Do not equate interception with permission, eligibility, resolution, downstream mutation or narration. |

## Part V — Capability definitions, access, readiness, and dependencies

Capabilities are federated records rather than one actor-owned list. Definition, registration, instance, provider, bearer, controller, origin, access, enablement, readiness, invocation and effect remain separate. Readiness is a determination over frozen dependencies, form, embodiment, equipment access, resources, preparation, charge, cooldown, suppression, damage, delegation scope and source-local interfaces. Revocation or component loss emits bounded dependency consequences under AFQR-09; it does not silently delete actors, actions or prior history. Automatic capabilities require an explicit policy and authority receipt.

## Part VI — Action opportunities, methods, and contexts

An action opportunity is a time-scoped actor–controller–capability–method–target–context relation. Affordances may contribute environmental or object-side support, but do not grant capability, permission or success. AFQR-03 retains action-legality authority. Method variants declare target, interface, cost, timing and effect differences; a material change after confirmation requires a new command or confirmation. Option generation is bounded and non-behavioral: AFQR-12 remains responsible for agentic selection.

## Part VII — Target identity, binding, eligibility, and target sets

Target processing is staged: declaration → perceived/intended candidates → identity-purpose and facet binding → selected candidate → layered eligibility → execution-time persistence → substitution/redirection → actual target → downstream affected subjects. Bodies, components, manifestations, regions, relations, processes, capabilities, records, institutions and source-local subjects can be targeted through registered families. Area, chain, bounce, aura and explicit-list profiles use bounded canonical target-set generation, identity-safe deduplication, deterministic ordering, caps, exclusions and private candidate sets. Line of sight, range, awareness, interface compatibility, permission and eligibility remain separate.

## Part VIII — Resolution profiles, randomness, modifiers, and outcomes

Resolution profiles may be deterministic thresholds, static difficulties, opposed comparisons, roll-over, roll-under, dice pools, success counts, cards, tokens, bids, clocks, tables, tag comparisons, multi-stage or source-local. Backend RNG reserves a canonical candidate set and partitioned stream, records immutable draws, and prevents unrelated rerolls. Modifiers declare source, applicability, stacking, order, visibility and consumption. Outcomes are vectors rather than one universal success scalar; dimensions can be partial or incomparable. Critical qualification is profile-local. Resolution emits evidence and effect candidates, never direct downstream mutation.

## Part IX — Contests, assistance, cooperation, and multi-party resolution

Contest families distinguish unopposed, resisted, bilateral opposed, competitive multi-party, cooperative, parallel, asymmetric, hidden-participant, environmental, pursuit and source-local forms. Objectives, stakes, roles, participation eligibility, contribution, resistance, tie policy, progress, withdrawal, replacement and closure are registered. Assistance may alter opportunity, candidate generation, resources, risk, resolution or outcome; it is not universally a bonus. Claim arbitration remains AFQR-06-owned.

## Part X — Triggers, reaction windows, reactions, interrupts, and counters

Trigger occurrence, validity, access, detection and belief are separate. A qualified trigger may open an audience-safe reaction window for eligible capabilities and proper decision authorities. Reaction opportunity, choice, reservation, attempt and outcome remain distinct. Agentic reactions cannot be selected by the model. Automatic responses require policy authority. Interrupts, counters, cancellation, preemption, redirection, replacement and contingencies use a typed dependency/conflict graph, priority profile, depth budget, cycle detection, duplicate suppression, stale-window rejection and explicit termination receipt.

## Part XI — Simultaneous actions, priority, and partial-order resolution

Simultaneous declaration is not simultaneous execution or effect. A logical-time group freezes declarations and identifies resource, occupancy, target, tool, dependency and reaction conflicts. Independent actions may resolve in deterministic concurrent groups. Semantic dependencies and priority claims produce a partial order; missing priority may remain unresolved. Mutual actions can both resolve. AFQR-04 owns logical time and AFQR-01 owns commitment; worker latency and model response order are never authoritative.

## Part XII — Conflict, engagement, combat, and participation

Conflict contexts organize objectives, participants, observers, protected and neutral subjects, hidden participants, rules, timing and simulation tier. Combat is one specialized conflict family and does not create separate physics or truth. Hostility, participation, legal target status and responsibility remain distinct. Entry, withdrawal, surrender offer, surrender acceptance, ceasefire and closure are separate records. Conflict success does not automatically establish victory, legal authority, identity termination or social consequence.

## Part XIII — Defense, interception, pursuit, and withdrawal

Passive difficulty, active defense, reaction defense, automatic countermeasure, AFQR-16 protection, resistance, immunity, counteraction, interception, redirection and substitution remain separate. AFQR-18 supplies range, line-of-effect, movement and interception candidates. AFQR-19 resolves action interaction but does not move participants or create harm. Pursuit combines knowledge, routes, progress, reaction windows and contest profiles; reaching an old position is not interception, and loss of contact is not escape.

## Part XIV — Multi-target, area, collateral, and distributed actions

Multi-target actions close a target set before resolution using time-valid spatial and identity bases. Distributed bodies and shared identities require purpose-specific deduplication. Areas target supports or regions; occupants become candidates only through an inclusion profile. Collateral candidates remain separate from individually declared targets and committed effects. Moving areas, chains and bounces re-evaluate according to their registered temporal semantics without exposing hidden target counts.

## Part XV — Conflict simulation tiers

The tiers are `descriptive_conflict_reference`, `aggregate_engagement`, `group_resolution`, `materialized_participants`, `detailed_reaction_resolution`, and `full_conflict_fixture`. Promotion transfers authority rather than duplicating it, allocates capability/resource/defense state, and never invents historical attacks, reactions, targets, costs, movement or injuries. Demotion reconciles committed outcomes. Aggregate and detailed owners are fenced against double resolution.

## Part XVI — Hidden state and model projection

Capability, target, modifier, defense, trigger, reaction, priority, RNG and conflict state are audience-scoped. Visible packets use constant-shape or bucketed alternatives where option counts or timing would leak hidden state. Tokens and digests are audience-specific. Model inputs include permitted claim kinds and evidence bindings, never raw private candidate sets. Generated capability, target, reaction, outcome, damage, critical, victory and defeat claims require semantic validation; unsupported claims are rejected and create no event.

## Part XVII — Typed contracts

The binding schema catalog contains **353** specialized contracts. Every contract specifies required, optional, hidden, derived and prohibited fields; authoritative owner; record-specific temporal semantics; identity and participant references; profile versions; cross-domain bases; security fields; deterministic commitments; and AFQR-01–18 references.

| # | Contract | Family | Owner |
| --- | --- | --- | --- |
| 1 | CapabilityDefinition | capability | capability_registry_owner |
| 2 | CapabilityRegistration | capability | capability_registry_owner |
| 3 | CapabilityInstance | capability | capability_registry_owner |
| 4 | CapabilityProviderBinding | capability | capability_registry_owner |
| 5 | CapabilityBearerBinding | capability | capability_registry_owner |
| 6 | CapabilityControllerBinding | capability | capability_registry_owner |
| 7 | CapabilityOriginProfile | capability | capability_registry_owner |
| 8 | CapabilityFamilyDefinition | capability | capability_registry_owner |
| 9 | CapabilitySourceLocalNamespace | capability | capability_registry_owner |
| 10 | CapabilityAccessDefinition | capability | capability_registry_owner |
| 11 | CapabilityAccessBinding | capability | capability_registry_owner |
| 12 | CapabilityPrerequisiteDefinition | capability | capability_registry_owner |
| 13 | CapabilityPrerequisiteSet | capability | capability_registry_owner |
| 14 | CapabilityDependencyBinding | capability | capability_registry_owner |
| 15 | CapabilityEnablementCandidate | capability | capability_registry_owner |
| 16 | CapabilityEnablementDetermination | capability | capability_registry_owner |
| 17 | CapabilityReadinessState | capability | capability_registry_owner |
| 18 | CapabilitySuppressionState | capability | capability_registry_owner |
| 19 | CapabilityCooldownState | capability | capability_registry_owner |
| 20 | CapabilityChargeState | capability | capability_registry_owner |
| 21 | CapabilityPreparationState | capability | capability_registry_owner |
| 22 | CapabilityAvailabilityDetermination | capability | capability_registry_owner |
| 23 | ActionOpportunityDefinition | opportunity | action_opportunity_owner |
| 24 | ActionOpportunityQuery | opportunity | action_opportunity_owner |
| 25 | ActionOpportunityInputClosure | opportunity | action_opportunity_owner |
| 26 | ActionOpportunityCandidate | opportunity | action_opportunity_owner |
| 27 | ActionOpportunityDetermination | opportunity | action_opportunity_owner |
| 28 | OpportunityActorBinding | opportunity | action_opportunity_owner |
| 29 | OpportunityCapabilityBinding | opportunity | action_opportunity_owner |
| 30 | OpportunityMethodBinding | opportunity | action_opportunity_owner |
| 31 | OpportunityTargetBinding | opportunity | action_opportunity_owner |
| 32 | OpportunityContextManifest | opportunity | action_opportunity_owner |
| 33 | OpportunityValidityInterval | opportunity | action_opportunity_owner |
| 34 | ActionFamilyDefinition | action_method | action_gateway_method_registry_owner |
| 35 | ActionMethodDefinition | action_method | action_gateway_method_registry_owner |
| 36 | ActionVariantDefinition | action_method | action_gateway_method_registry_owner |
| 37 | ActionMethodCapabilityRequirement | action_method | action_gateway_method_registry_owner |
| 38 | ActionMethodInterfaceRequirement | action_method | action_gateway_method_registry_owner |
| 39 | ActionMethodResourceManifest | action_method | action_gateway_method_registry_owner |
| 40 | ActionMethodTimingProfile | action_method | action_gateway_method_registry_owner |
| 41 | ActionMethodTargetProfile | action_method | action_gateway_method_registry_owner |
| 42 | ActionMethodEffectProfileReference | action_method | action_gateway_method_registry_owner |
| 43 | TargetFamilyDefinition | target | target_binding_owner |
| 44 | TargetReference | target | target_binding_owner |
| 45 | DeclaredTargetBinding | target | target_binding_owner |
| 46 | PerceivedTargetBinding | target | target_binding_owner |
| 47 | IntendedTargetBinding | target | target_binding_owner |
| 48 | TargetIdentityCandidate | target | target_binding_owner |
| 49 | TargetIdentityDetermination | target | target_binding_owner |
| 50 | TargetFacetBinding | target | target_binding_owner |
| 51 | TargetSupportBinding | target | target_binding_owner |
| 52 | TargetComponentBinding | target | target_binding_owner |
| 53 | AimPointBinding | target | target_binding_owner |
| 54 | ActualTargetDetermination | cross_domain | afqr19_federation_registry_owner |
| 55 | TargetEligibilityProfile | target | target_binding_owner |
| 56 | TargetEligibilityQuery | target | target_binding_owner |
| 57 | TargetEligibilityInputClosure | target | target_binding_owner |
| 58 | TargetExistenceDetermination | target | target_binding_owner |
| 59 | TargetAwarenessReference | target | target_binding_owner |
| 60 | TargetAcquisitionCandidate | target | target_binding_owner |
| 61 | TargetAcquisitionDetermination | target | target_binding_owner |
| 62 | TargetRangeReference | target | target_binding_owner |
| 63 | TargetSpatialPathReference | target | target_binding_owner |
| 64 | TargetInterfaceCompatibility | target | target_binding_owner |
| 65 | TargetPermissionReference | target | target_binding_owner |
| 66 | TargetTimingValidity | target | target_binding_owner |
| 67 | CompositeTargetEligibilityDetermination | cross_domain | afqr19_federation_registry_owner |
| 68 | TargetIneligibilityReason | target | target_binding_owner |
| 69 | TargetSetDefinition | target | target_binding_owner |
| 70 | TargetSetGenerationProfile | target | target_binding_owner |
| 71 | TargetSetGenerationRun | target | target_binding_owner |
| 72 | CanonicalTargetCandidateSet | target | target_binding_owner |
| 73 | TargetSetSelectionRule | target | target_binding_owner |
| 74 | TargetSetExclusionRule | target | target_binding_owner |
| 75 | TargetSetCapacity | target | target_binding_owner |
| 76 | TargetSetClosureReceipt | target | target_binding_owner |
| 77 | AreaTargetSupportBinding | target | target_binding_owner |
| 78 | AreaInclusionCandidate | target | target_binding_owner |
| 79 | AreaTargetIdentityDeduplicationReceipt | target | target_binding_owner |
| 80 | CollateralCandidateSet | cross_domain | afqr19_federation_registry_owner |
| 81 | ResolutionProfileDefinition | resolution | resolution_authority_owner |
| 82 | ResolutionProfileRegistration | resolution | resolution_authority_owner |
| 83 | ResolutionApplicabilityProfile | resolution | resolution_authority_owner |
| 84 | ResolutionInputClosure | resolution | resolution_authority_owner |
| 85 | ResolutionCandidateSet | resolution | resolution_authority_owner |
| 86 | ResolutionExecutionRequest | resolution | resolution_authority_owner |
| 87 | ResolutionExecutionReceipt | resolution | resolution_authority_owner |
| 88 | ResolutionOutcomeCandidate | resolution | resolution_authority_owner |
| 89 | ResolutionDetermination | resolution | resolution_authority_owner |
| 90 | ResolutionFailureReason | resolution | resolution_authority_owner |
| 91 | ResolutionStochasticProfile | resolution | resolution_authority_owner |
| 92 | CanonicalRandomCandidateSetReceipt | resolution | resolution_authority_owner |
| 93 | ResolutionRNGReservation | resolution | resolution_authority_owner |
| 94 | ResolutionRandomStreamPartition | resolution | resolution_authority_owner |
| 95 | ResolutionRandomDrawReceipt | resolution | resolution_authority_owner |
| 96 | RerollAuthorization | resolution | resolution_authority_owner |
| 97 | RerollConsumptionReceipt | resolution | resolution_authority_owner |
| 98 | ResultSelectionReceipt | resolution | resolution_authority_owner |
| 99 | DeterministicTieBreakPolicy | resolution | resolution_authority_owner |
| 100 | ResolutionModifierDefinition | resolution | resolution_authority_owner |
| 101 | ResolutionModifierInstance | resolution | resolution_authority_owner |
| 102 | ModifierSourceBinding | resolution | resolution_authority_owner |
| 103 | ModifierApplicabilityDetermination | resolution | resolution_authority_owner |
| 104 | ModifierStackingProfile | resolution | resolution_authority_owner |
| 105 | ModifierOrderingProfile | resolution | resolution_authority_owner |
| 106 | ModifierConsumptionProfile | resolution | resolution_authority_owner |
| 107 | ResultTransformationDefinition | resolution | resolution_authority_owner |
| 108 | ResultTransformationCandidate | resolution | resolution_authority_owner |
| 109 | ResultTransformationReceipt | resolution | resolution_authority_owner |
| 110 | ModifierConflictSet | resolution | resolution_authority_owner |
| 111 | OutcomeDimensionDefinition | resolution | resolution_authority_owner |
| 112 | OutcomeDimensionProfile | resolution | resolution_authority_owner |
| 113 | OutcomeDimensionCandidate | resolution | resolution_authority_owner |
| 114 | OutcomeDimensionDetermination | resolution | resolution_authority_owner |
| 115 | OutcomeVector | resolution | resolution_authority_owner |
| 116 | OutcomeIncomparabilityReceipt | resolution | resolution_authority_owner |
| 117 | OutcomeQualification | resolution | resolution_authority_owner |
| 118 | OutcomeVisibilityProfile | resolution | resolution_authority_owner |
| 119 | ContestFamilyDefinition | contest | contest_state_owner |
| 120 | ContestDefinition | contest | contest_state_owner |
| 121 | ContestInstance | contest | contest_state_owner |
| 122 | ContestObjective | contest | contest_state_owner |
| 123 | ContestStakeDefinition | contest | contest_state_owner |
| 124 | ContestParticipantBinding | contest | contest_state_owner |
| 125 | ContestRoleDefinition | contest | contest_state_owner |
| 126 | ContestParticipationEligibility | contest | contest_state_owner |
| 127 | ContestResistanceBinding | contest | contest_state_owner |
| 128 | ContestComparisonProfile | contest | contest_state_owner |
| 129 | ContestState | contest | contest_state_owner |
| 130 | ContestProgressState | contest | contest_state_owner |
| 131 | ContestOutcomeCandidate | contest | contest_state_owner |
| 132 | ContestClosureDetermination | contest | contest_state_owner |
| 133 | MultiPartyContestProfile | contest | contest_state_owner |
| 134 | ParticipantContributionDefinition | contest | contest_state_owner |
| 135 | ParticipantContributionCandidate | contest | contest_state_owner |
| 136 | ParticipantContributionDetermination | contest | contest_state_owner |
| 137 | AssistanceDefinition | contest | contest_state_owner |
| 138 | AssistanceEligibilityDetermination | contest | contest_state_owner |
| 139 | AssistanceEffectProfile | contest | contest_state_owner |
| 140 | CooperativeActionPlan | contest | contest_state_owner |
| 141 | CombinedCapabilityManifest | contest | contest_state_owner |
| 142 | ContributionAggregationProfile | contest | contest_state_owner |
| 143 | ContributionConflictSet | contest | contest_state_owner |
| 144 | TriggerDefinition | trigger | trigger_registry_owner |
| 145 | TriggerFamilyDefinition | trigger | trigger_registry_owner |
| 146 | TriggerSourceBinding | trigger | trigger_registry_owner |
| 147 | TriggerOccurrence | trigger | trigger_registry_owner |
| 148 | TriggerEvidenceClosure | trigger | trigger_registry_owner |
| 149 | TriggerAccessPolicy | trigger | trigger_registry_owner |
| 150 | TriggerAudienceProjection | trigger | trigger_registry_owner |
| 151 | TriggerDetectionCandidate | trigger | trigger_registry_owner |
| 152 | TriggerDetectionDetermination | trigger | trigger_registry_owner |
| 153 | TriggerValidityInterval | trigger | trigger_registry_owner |
| 154 | ReactionWindowDefinition | reaction | reaction_window_owner |
| 155 | ReactionWindowInstance | reaction | reaction_window_owner |
| 156 | ReactionWindowOpeningCandidate | reaction | reaction_window_owner |
| 157 | ReactionWindowOpeningDetermination | reaction | reaction_window_owner |
| 158 | ReactionWindowEligibilityProfile | reaction | reaction_window_owner |
| 159 | ReactionOpportunity | reaction | reaction_window_owner |
| 160 | ReactionOpportunityProjection | reaction | reaction_window_owner |
| 161 | ReactionWindowClosingCondition | reaction | reaction_window_owner |
| 162 | ReactionWindowClosureReceipt | reaction | reaction_window_owner |
| 163 | StaleReactionWindowReceipt | cross_domain | afqr19_federation_registry_owner |
| 164 | ReactionDefinition | reaction | reaction_window_owner |
| 165 | ReactionCapabilityBinding | reaction | reaction_window_owner |
| 166 | ReactionDecisionAuthorityBinding | reaction | reaction_window_owner |
| 167 | ReactionSelectionRequest | reaction | reaction_window_owner |
| 168 | ReactionSelectionDecisionReference | reaction | reaction_window_owner |
| 169 | ReactionReservation | reaction | reaction_window_owner |
| 170 | ReactionAttempt | reaction | reaction_window_owner |
| 171 | InterruptDefinition | reaction | reaction_window_owner |
| 172 | CounteractionDefinition | reaction | reaction_window_owner |
| 173 | PreemptionCandidate | reaction | reaction_window_owner |
| 174 | CancellationCandidate | reaction | reaction_window_owner |
| 175 | RedirectionCandidate | reaction | reaction_window_owner |
| 176 | ReplacementActionCandidate | reaction | reaction_window_owner |
| 177 | ReactionOutcomeCandidate | reaction | reaction_window_owner |
| 178 | ReactionPriorityClass | reaction | reaction_window_owner |
| 179 | ReactionPartialOrder | reaction | reaction_window_owner |
| 180 | ReactionConflictSet | reaction | reaction_window_owner |
| 181 | NestedReactionGraph | cross_domain | afqr19_federation_registry_owner |
| 182 | ReactionDepthBudget | reaction | reaction_window_owner |
| 183 | ReactionCycleDetectionReceipt | reaction | reaction_window_owner |
| 184 | ReactionDuplicateSuppressionReceipt | reaction | reaction_window_owner |
| 185 | ReactionOrderingCandidate | reaction | reaction_window_owner |
| 186 | ReactionOrderingDetermination | reaction | reaction_window_owner |
| 187 | ReactionChainTerminationReceipt | reaction | reaction_window_owner |
| 188 | SimultaneousActionGroup | simultaneous | concurrency_resolution_owner |
| 189 | ActionDeclarationSet | action_method | action_gateway_method_registry_owner |
| 190 | ActionConflictRelation | simultaneous | concurrency_resolution_owner |
| 191 | ActionDependencyRelation | simultaneous | concurrency_resolution_owner |
| 192 | ActionPartialOrder | simultaneous | concurrency_resolution_owner |
| 193 | ActionPriorityClaim | simultaneous | concurrency_resolution_owner |
| 194 | ActionPriorityDetermination | simultaneous | concurrency_resolution_owner |
| 195 | ConcurrentExecutionPlan | simultaneous | concurrency_resolution_owner |
| 196 | SimultaneousResolutionGroup | simultaneous | concurrency_resolution_owner |
| 197 | ConcurrentOutcomeCandidateSet | simultaneous | concurrency_resolution_owner |
| 198 | ConcurrentCommitPlan | simultaneous | concurrency_resolution_owner |
| 199 | ConflictContextDefinition | conflict | conflict_context_owner |
| 200 | ConflictContextInstance | conflict | conflict_context_owner |
| 201 | EngagementDefinition | conflict | conflict_context_owner |
| 202 | EngagementInstance | conflict | conflict_context_owner |
| 203 | CombatContextProfile | conflict | conflict_context_owner |
| 204 | ConflictParticipantBinding | conflict | conflict_context_owner |
| 205 | ConflictParticipationState | conflict | conflict_context_owner |
| 206 | HostilityClaim | conflict | conflict_context_owner |
| 207 | HostilityDeterminationReference | conflict | conflict_context_owner |
| 208 | ProtectedSubjectBinding | conflict | conflict_context_owner |
| 209 | NeutralSubjectBinding | conflict | conflict_context_owner |
| 210 | LateEntryCandidate | conflict | conflict_context_owner |
| 211 | WithdrawalCandidate | conflict | conflict_context_owner |
| 212 | ConflictTerminationCandidate | conflict | conflict_context_owner |
| 213 | ConflictClosureReceipt | conflict | conflict_context_owner |
| 214 | DefenseFamilyDefinition | defense | defense_resolution_owner |
| 215 | PassiveDefenseProfile | defense | defense_resolution_owner |
| 216 | ActiveDefenseDefinition | defense | defense_resolution_owner |
| 217 | DefenseEligibilityDetermination | defense | defense_resolution_owner |
| 218 | DefenseReactionBinding | defense | defense_resolution_owner |
| 219 | CountermeasureDefinition | defense | defense_resolution_owner |
| 220 | CountermeasureEligibility | defense | defense_resolution_owner |
| 221 | TargetRedirectionProfile | target | target_binding_owner |
| 222 | TargetSubstitutionProfile | target | target_binding_owner |
| 223 | InterceptionCandidate | defense | defense_resolution_owner |
| 224 | DefenseOutcomeCandidate | defense | defense_resolution_owner |
| 225 | AFQR16DefenseEffectHandoff | effect | effect_routing_coordinator |
| 226 | PursuitDefinition | pursuit | pursuit_contest_owner |
| 227 | PursuitInstance | pursuit | pursuit_contest_owner |
| 228 | PursuerBinding | pursuit | pursuit_contest_owner |
| 229 | EvaderBinding | pursuit | pursuit_contest_owner |
| 230 | PursuitObjective | pursuit | pursuit_contest_owner |
| 231 | PursuitSpatialInputReference | pursuit | pursuit_contest_owner |
| 232 | PursuitContestProfile | pursuit | pursuit_contest_owner |
| 233 | InterceptionWindow | defense | defense_resolution_owner |
| 234 | InterceptionEligibilityDetermination | defense | defense_resolution_owner |
| 235 | EscapeCondition | pursuit | pursuit_contest_owner |
| 236 | PursuitProgressState | pursuit | pursuit_contest_owner |
| 237 | PursuitClosureDetermination | pursuit | pursuit_contest_owner |
| 238 | ConflictSimulationTierDefinition | conflict | conflict_context_owner |
| 239 | ConflictMaterializationPolicy | conflict | conflict_context_owner |
| 240 | ConflictPromotionInputClosure | conflict | conflict_context_owner |
| 241 | ConflictPromotionReceipt | conflict | conflict_context_owner |
| 242 | ConflictDemotionRetentionManifest | conflict | conflict_context_owner |
| 243 | ConflictDemotionReceipt | conflict | conflict_context_owner |
| 244 | ConflictAuthorityPartition | conflict | conflict_context_owner |
| 245 | HistoricalConflictApproximationRecord | simulation_tier | conflict_authority_partition_owner |
| 246 | PrivateCapabilityReceipt | capability | capability_registry_owner |
| 247 | PrivateTargetReceipt | target | target_binding_owner |
| 248 | PrivateResolutionReceipt | resolution | resolution_authority_owner |
| 249 | PrivateReactionReceipt | reaction | reaction_window_owner |
| 250 | PrivateConflictReceipt | conflict | conflict_context_owner |
| 251 | ActorVisibleActionProjection | projection | projection_and_model_boundary_owner |
| 252 | ObserverVisibleActionProjection | projection | projection_and_model_boundary_owner |
| 253 | PlayerVisibleActionProjection | projection | projection_and_model_boundary_owner |
| 254 | ModelVisibleActionProjection | projection | projection_and_model_boundary_owner |
| 255 | PublicConflictProjection | conflict | conflict_context_owner |
| 256 | ModelActionGroundingManifest | projection | projection_and_model_boundary_owner |
| 257 | PermittedActionClaimKindRegistry | projection | projection_and_model_boundary_owner |
| 258 | ModelCapabilityEvidenceBinding | capability | capability_registry_owner |
| 259 | ModelTargetEvidenceBinding | target | target_binding_owner |
| 260 | ModelResolutionEvidenceBinding | resolution | resolution_authority_owner |
| 261 | ModelReactionEvidenceBinding | reaction | reaction_window_owner |
| 262 | ModelConflictOutputValidator | conflict | conflict_context_owner |
| 263 | GeneratedCapabilityClaimBinding | cross_domain | afqr19_federation_registry_owner |
| 264 | GeneratedTargetClaimBinding | target | target_binding_owner |
| 265 | GeneratedActionClaimBinding | cross_domain | afqr19_federation_registry_owner |
| 266 | GeneratedReactionClaimBinding | reaction | reaction_window_owner |
| 267 | GeneratedOutcomeClaimBinding | resolution | resolution_authority_owner |
| 268 | GeneratedVictoryOrDefeatClaimBinding | conflict | conflict_context_owner |
| 269 | CrossPacketConflictIsolationReceipt | projection | projection_and_model_boundary_owner |
| 270 | ConflictProjectionNoninterferenceReceipt | conflict | conflict_context_owner |
| 271 | AudienceScopedConflictToken | conflict | conflict_context_owner |
| 272 | PrivateConflictIntegrityCommitment | conflict | conflict_context_owner |
| 273 | ProjectionSpecificConflictDigest | conflict | conflict_context_owner |
| 274 | CrossAudienceConflictLinkabilityTest | conflict | conflict_context_owner |
| 275 | AFQR19Handoff | effect | effect_routing_coordinator |
| 276 | CapabilityContinuityProfile | capability | capability_registry_owner |
| 277 | CapabilityContinuityDetermination | capability | capability_registry_owner |
| 278 | CapabilityRevocationReceipt | capability | capability_registry_owner |
| 279 | CapabilityOrphaningReceipt | capability | capability_registry_owner |
| 280 | CapabilityDelegationScope | capability | capability_registry_owner |
| 281 | CapabilityCopyLineageReceipt | capability | capability_registry_owner |
| 282 | CapabilityReadinessEvidenceClosure | capability | capability_registry_owner |
| 283 | CapabilityUseReservation | capability | capability_registry_owner |
| 284 | ActionDeclarationRecord | action_method | action_gateway_method_registry_owner |
| 285 | ActionConfirmationReceipt | cross_domain | afqr19_federation_registry_owner |
| 286 | ActionExecutionEligibility | action_method | action_gateway_method_registry_owner |
| 287 | ActionExecutionState | action_method | action_gateway_method_registry_owner |
| 288 | ActionCancellationReceipt | action_method | action_gateway_method_registry_owner |
| 289 | ActionInterruptionReceipt | action_method | action_gateway_method_registry_owner |
| 290 | ActionCompletionReceipt | action_method | action_gateway_method_registry_owner |
| 291 | SelectedTargetBinding | target | target_binding_owner |
| 292 | EligibleTargetBinding | target | target_binding_owner |
| 293 | AffectedSubjectBinding | target | target_binding_owner |
| 294 | CollateralSubjectBinding | target | target_binding_owner |
| 295 | TargetPersistenceDetermination | target | target_binding_owner |
| 296 | TargetSubstitutionReceipt | target | target_binding_owner |
| 297 | TargetRedirectionReceipt | target | target_binding_owner |
| 298 | TargetSelectionReservation | target | target_binding_owner |
| 299 | ResolutionProfileSelectionReceipt | resolution | resolution_authority_owner |
| 300 | ResolutionProfileIncomparabilityReceipt | resolution | resolution_authority_owner |
| 301 | ModifierVisibilityProfile | resolution | resolution_authority_owner |
| 302 | HiddenModifierApplicationReceipt | cross_domain | afqr19_federation_registry_owner |
| 303 | StochasticReplayVerificationReceipt | cross_domain | afqr19_federation_registry_owner |
| 304 | ResolutionEvidenceClosure | resolution | resolution_authority_owner |
| 305 | ContestParticipantReplacementReceipt | contest | contest_state_owner |
| 306 | ContestWithdrawalReceipt | contest | contest_state_owner |
| 307 | ContestTieDetermination | contest | contest_state_owner |
| 308 | ContestUnresolvedReceipt | contest | contest_state_owner |
| 309 | ContestDurationProfile | contest | contest_state_owner |
| 310 | ContestTerminationProfile | contest | contest_state_owner |
| 311 | AutomaticResponsePolicy | reaction | reaction_window_owner |
| 312 | AutomaticResponseAuthorizationReceipt | reaction | reaction_window_owner |
| 313 | ReactionResourceManifest | reaction | reaction_window_owner |
| 314 | ReactionExecutionGroup | reaction | reaction_window_owner |
| 315 | ReactionStaleBasisReceipt | reaction | reaction_window_owner |
| 316 | ReactionVisibilityPolicy | reaction | reaction_window_owner |
| 317 | SimultaneousStateFreezeReceipt | simultaneous | concurrency_resolution_owner |
| 318 | ConcurrentResourceConflict | simultaneous | concurrency_resolution_owner |
| 319 | ConcurrentSpatialConflict | simultaneous | concurrency_resolution_owner |
| 320 | ConcurrentTargetConflict | simultaneous | concurrency_resolution_owner |
| 321 | ConcurrentDependencyConflict | simultaneous | concurrency_resolution_owner |
| 322 | ConcurrentAbortReceipt | simultaneous | concurrency_resolution_owner |
| 323 | ConflictEntryReceipt | conflict | conflict_context_owner |
| 324 | ConflictExitReceipt | conflict | conflict_context_owner |
| 325 | SurrenderOfferReference | conflict | conflict_context_owner |
| 326 | SurrenderAcceptanceReference | conflict | conflict_context_owner |
| 327 | CeasefireReference | conflict | conflict_context_owner |
| 328 | ConflictProgressState | conflict | conflict_context_owner |
| 329 | ConflictVictoryClaim | conflict | conflict_context_owner |
| 330 | ConflictDefeatClaim | conflict | conflict_context_owner |
| 331 | DefenseApplicabilityProfile | defense | defense_resolution_owner |
| 332 | DefenseResolutionReceipt | defense | defense_resolution_owner |
| 333 | InterceptionResolutionReceipt | defense | defense_resolution_owner |
| 334 | PursuitKnowledgeClosure | pursuit | pursuit_contest_owner |
| 335 | PursuitLostContactReceipt | pursuit | pursuit_contest_owner |
| 336 | EffectCandidateDefinition | effect | effect_routing_coordinator |
| 337 | EffectCandidateInstance | effect | effect_routing_coordinator |
| 338 | EffectOwnerRoutingManifest | effect | effect_routing_coordinator |
| 339 | EffectOutputCompletenessReceipt | effect | effect_routing_coordinator |
| 340 | DownstreamEffectAcceptance | effect | effect_routing_coordinator |
| 341 | DownstreamEffectRejection | effect | effect_routing_coordinator |
| 342 | DownstreamEffectTransformation | effect | effect_routing_coordinator |
| 343 | OwnerPreparedEffectFragment | effect | effect_routing_coordinator |
| 344 | EffectCommitBundle | effect | effect_routing_coordinator |
| 345 | EffectCommitReceipt | effect | effect_routing_coordinator |
| 346 | PrivateModifierReceipt | resolution | resolution_authority_owner |
| 347 | PrivatePriorityReceipt | reaction | reaction_window_owner |
| 348 | PrivateContestReceipt | contest | contest_state_owner |
| 349 | PrivateRNGReceipt | resolution | resolution_authority_owner |
| 350 | ActionProjectionPolicy | projection | projection_and_model_boundary_owner |
| 351 | ConflictProjectionPolicy | conflict | conflict_context_owner |
| 352 | TargetOptionSetNoninterferenceReceipt | target | target_binding_owner |
| 353 | ReactionOptionSetNoninterferenceReceipt | reaction | reaction_window_owner |

## Part XVIII — Determination pipelines

### Capability Availability pipeline

1. resolve capability definition instance provider bearer controller and purpose
2. freeze identity dependency embodiment equipment condition resource form and timing bases
3. evaluate access prerequisites enablement suppression preparation charge cooldown and source-local constraints
4. return available conditionally_available unavailable unknown quarantined or unresolved
5. do not create an action

### Action Opportunity pipeline

1. resolve registered action family and method
2. bind actor controller capability tool target candidate context time and purpose
3. consume AFQR-03 legality candidate
4. consume AFQR-18 spatial and AFQR-17 environmental inputs
5. evaluate resources interfaces readiness and constraints
6. produce bounded opportunities without behavioral selection

### Target Binding pipeline

1. parse declaration as non-authoritative reference
2. freeze actor epistemic state and visible candidate set
3. resolve perceived and intended candidates
4. bind authoritative identity purpose facet component support or target set where possible
5. preserve mistake ambiguity concealment decoy and unresolved identity

### Target Eligibility pipeline

1. resolve action method and target profile
2. evaluate existence timing identity facet spatial range propagation path interface compatibility permissions and class constraints
3. return layered eligible conditional ineligible hidden incomplete or unresolved
4. do not resolve action

### Target Set pipeline

1. freeze support area topology spatial identity and visibility bases
2. generate bounded canonical candidate set
3. apply inclusion exclusion cap ordering deduplication and random-selection profiles
4. reserve target-set identity and emit closure receipt
5. do not infer effects

### Resolution pipeline

1. freeze action capability target state cost contest and profile bases
2. select registered applicable resolver
3. assemble canonical inputs and modifiers
4. reserve and draw backend randomness when required
5. apply transformations in registered order
6. determine outcome vector and produce effect candidates only

### Contest pipeline

1. resolve family objective stakes participants roles timing and comparison profile
2. determine eligibility and contribution closure
3. resolve assistance and resistance
4. execute registered stages
5. update progress or closure candidate
6. preserve withdrawal ties partial incomparable and unresolved outcomes

### Trigger Reaction Window pipeline

1. bind qualified trigger event and definition
2. determine occurrence validity and audience-safe access
3. identify eligible reaction capabilities and decision authorities
4. open bounded window and project authorized opportunities
5. receive decisions or execute authorized automation
6. close stale or exhausted window

### Reaction Ordering pipeline

1. freeze declarations automatic responses costs and timing
2. build dependency and conflict graph
3. apply priority and partial-order profiles
4. detect cycles duplicates stale declarations and depth overflow
5. determine ordered or simultaneous groups
6. execute bounded groups and terminate explicitly

### Simultaneous Action pipeline

1. freeze declaration set and state basis
2. identify dependencies spatial target resource and reaction conflicts
3. build partial order and resolve priority claims
4. execute independent deterministic groups
5. prepare owner fragments
6. commit atomically or by declared staged protocol

### Defense pipeline

1. identify passive defenses automatic systems active opportunities and target protections
2. determine applicability and timing
3. open windows where required
4. resolve defense contest or counteraction
5. produce typed miss block evade redirect intercept attenuate or unresolved candidates
6. route protection and harm envelopes to AFQR-16

### Conflict Context pipeline

1. resolve purpose participants observers protected subjects hostility claims rules timing and tier
2. register participation without creating hostility
3. schedule actions through ordinary action architecture
4. update progress and termination candidates
5. preserve all external owner boundaries

### Pursuit Interception pipeline

1. bind pursuer evader objective knowledge movement methods routes and spatial inputs
2. consume AFQR-18 reachability and interception candidates
3. apply contest and reaction profiles
4. update progress
5. produce interception continued pursuit escape loss of contact or unresolved candidate
6. commit movement separately

### Effect Handoff pipeline

1. map outcome dimensions through registered effect profile
2. produce typed candidates for resource spatial environmental embodiment communication social institutional or source-local owners
3. validate output completeness
4. allow acceptance rejection attenuation transformation or quarantine
5. prepare fragments and AFQR-01 commit accepted effects
6. narrate only visible committed results

### Simulation Tier Transition pipeline

1. freeze aggregate and detailed authority partitions
2. partition participant resource target action reaction and progress authority
3. materialize certified detail only
4. preserve unknown action history and hidden state
5. prevent double resolution
6. reconcile committed outcomes on demotion

## Part XIX — Operation grammar

| # | Operation | Owner | Disposition |
| --- | --- | --- | --- |
| 1 | intrinsic capability is available | capability_registry_owner | ACT-001: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 2 | learned capability is known but unprepared | capability_registry_owner | ACT-002: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 3 | equipment grants a capability | capability_registry_owner | ACT-003: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 4 | equipment is present but inaccessible | capability_registry_owner | ACT-004: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| 5 | capability is suppressed | capability_registry_owner | ACT-005: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 6 | capability cooldown expires | capability_registry_owner | ACT-006: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| 7 | capability charge is spent | capability_registry_owner | ACT-007: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 8 | capability dependency is revoked | capability_registry_owner | ACT-008: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| 9 | derivative capability becomes orphaned | capability_registry_owner | ACT-009: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 10 | source-local capability lacks a bridge | capability_registry_owner | ACT-010: retain the construct as source-local pressure and quarantine execution until a directional versioned bridge and certification fixture exist. |
| 11 | action opportunity exists | action_opportunity_owner | ACT-011: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 12 | capability exists but no opportunity exists | action_opportunity_owner | ACT-012: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 13 | opportunity exists but action is illegal | action_opportunity_owner | ACT-013: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 14 | action method changes | action_opportunity_owner | ACT-014: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 15 | altered method requires confirmation | action_opportunity_owner | ACT-015: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 16 | target is declared | target_binding_owner | ACT-016: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 17 | target identity is ambiguous | target_binding_owner | ACT-017: preserve the actor-scoped epistemic basis and ambiguity for “target identity is ambiguous”; bind only certified candidates and do not expose hidden truth. |
| 18 | target is a mistaken identity | target_binding_owner | ACT-018: preserve the actor-scoped epistemic basis and ambiguity for “target is a mistaken identity”; bind only certified candidates and do not expose hidden truth. |
| 19 | target is a decoy | target_binding_owner | ACT-019: preserve the actor-scoped epistemic basis and ambiguity for “target is a decoy”; bind only certified candidates and do not expose hidden truth. |
| 20 | target facet is invalid | target_binding_owner | ACT-020: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| 21 | target component is eligible | target_binding_owner | ACT-021: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 22 | target is spatially out of range | target_binding_owner | ACT-022: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 23 | target is in range but interface-incompatible | target_binding_owner | ACT-023: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| 24 | target is visible but ineligible | target_binding_owner | ACT-024: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 25 | target is hidden but blind targeting is permitted | target_binding_owner | ACT-025: preserve the actor-scoped epistemic basis and ambiguity for “target is hidden but blind targeting is permitted”; bind only certified candidates and do not expose hidden truth. |
| 26 | area target set is generated | target_binding_owner | ACT-026: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 27 | target-set cap is exceeded | target_binding_owner | ACT-027: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 28 | target identity is deduplicated | target_binding_owner | ACT-028: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 29 | collateral candidate is included | target_binding_owner | ACT-029: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 30 | random target selection is reserved | target_binding_owner | ACT-030: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 31 | deterministic action resolves | resolution_authority_owner | ACT-031: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 32 | stochastic action resolves | resolution_authority_owner | ACT-032: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 33 | static difficulty applies | resolution_authority_owner | ACT-033: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 34 | opposed comparison applies | resolution_authority_owner | ACT-034: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 35 | multi-stage resolution applies | resolution_authority_owner | ACT-035: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 36 | modifier applies | resolution_authority_owner | ACT-036: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 37 | modifier is inapplicable | resolution_authority_owner | ACT-037: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 38 | modifier stacking conflict occurs | resolution_authority_owner | ACT-038: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 39 | advantage-like transformation applies | resolution_authority_owner | ACT-039: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 40 | reroll is authorized | resolution_authority_owner | ACT-040: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| 41 | reroll request is stale | resolution_authority_owner | ACT-041: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 42 | result substitution applies | resolution_authority_owner | ACT-042: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 43 | partial outcome occurs | resolution_authority_owner | ACT-043: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 44 | outcome dimensions are incomparable | resolution_authority_owner | ACT-044: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 45 | effect candidate is rejected downstream | resolution_authority_owner | ACT-045: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| 46 | unopposed action succeeds | contest_state_owner | ACT-046: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 47 | resisted action is overcome | contest_state_owner | ACT-047: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 48 | bilateral contest ties | contest_state_owner | ACT-048: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 49 | multi-party contest has no single winner | contest_state_owner | ACT-049: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 50 | cooperative action succeeds through combined contribution | contest_state_owner | ACT-050: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 51 | assistance changes candidate generation | contest_state_owner | ACT-051: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 52 | participant withdraws from contest | contest_state_owner | ACT-052: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 53 | contest continues through progress state | contest_state_owner | ACT-053: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 54 | contest terminates unresolved | contest_state_owner | ACT-054: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 55 | trigger occurs | reaction_window_owner | ACT-055: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 56 | actor does not perceive trigger | reaction_window_owner | ACT-056: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 57 | actor perceives trigger but lacks reaction | reaction_window_owner | ACT-057: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 58 | reaction opportunity opens | reaction_window_owner | ACT-058: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 59 | actor declines reaction | reaction_window_owner | ACT-059: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 60 | automatic response activates | reaction_window_owner | ACT-060: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| 61 | reaction cost is reserved | reaction_window_owner | ACT-061: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 62 | interrupt preempts action | reaction_window_owner | ACT-062: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 63 | counteraction modifies outcome | reaction_window_owner | ACT-063: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 64 | reaction redirects target | reaction_window_owner | ACT-064: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 65 | reaction cancels action | reaction_window_owner | ACT-065: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 66 | reaction chain nests | reaction_window_owner | ACT-066: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 67 | reaction cycle is detected | reaction_window_owner | ACT-067: terminate at the registered budget or cycle guard, preserve processed evidence, and emit a bounded unresolved/terminated receipt. |
| 68 | reaction depth limit is reached | reaction_window_owner | ACT-068: terminate at the registered budget or cycle guard, preserve processed evidence, and emit a bounded unresolved/terminated receipt. |
| 69 | stale reaction is rejected | reaction_window_owner | ACT-069: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| 70 | simultaneous actions are independent | concurrency_resolution_owner | ACT-070: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 71 | simultaneous actions contest one resource | concurrency_resolution_owner | ACT-071: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 72 | simultaneous actions contest one occupancy support | concurrency_resolution_owner | ACT-072: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 73 | simultaneous attacks both resolve | concurrency_resolution_owner | ACT-073: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 74 | one action invalidates another target | concurrency_resolution_owner | ACT-074: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 75 | priority remains unresolved | concurrency_resolution_owner | ACT-075: return a lawful unresolved or unverifiable receipt for “priority remains unresolved”; do not select a fallback resolver or invent priority. |
| 76 | combat participant enters context | conflict_context_owner | ACT-076: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 77 | neutral subject remains outside conflict | conflict_context_owner | ACT-077: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 78 | hidden participant acts | conflict_context_owner | ACT-078: preserve the actor-scoped epistemic basis and ambiguity for “hidden participant acts”; bind only certified candidates and do not expose hidden truth. |
| 79 | participant withdraws | conflict_context_owner | ACT-079: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 80 | surrender is offered but not accepted | conflict_context_owner | ACT-080: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| 81 | passive defense applies | defense_or_pursuit_owner | ACT-081: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| 82 | active defense is selected | defense_or_pursuit_owner | ACT-082: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| 83 | interception succeeds spatially | defense_or_pursuit_owner | ACT-083: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| 84 | interception contest fails | defense_or_pursuit_owner | ACT-084: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| 85 | pursuit continues | defense_or_pursuit_owner | ACT-085: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| 86 | evader escapes | defense_or_pursuit_owner | ACT-086: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| 87 | aggregate conflict is promoted | conflict_authority_partition_owner | ACT-087: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| 88 | model invents a target | model_boundary_or_lawful_absence_owner | ACT-088: reject model authority for “model invents a target”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| 89 | model declares victory | model_boundary_or_lawful_absence_owner | ACT-089: reject model authority for “model declares victory”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| 90 | no lawful action-resolution profile exists | model_boundary_or_lawful_absence_owner | ACT-090: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |

## Part XX — Central stress cases

### Hybrid multi-domain engagement aboard a moving ship

**Authority partitions:** capability registry, AFQR-18 ship and compartment spatial owners, AFQR-17 environment, AFQR-16 platform/occupant integrity, AFQR-07 power reserve, AFQR-15 jurisdictions, AFQR-19 conflict/reaction coordinator

- Visible drone targeting binds drone identity and support; disabling the weapon targets a component facet, not the actor.
- The concealed opponent may generate a private trigger and reaction opportunity only if its trigger-access basis permits; no visible option-count leak.
- The automated defense reacts only through an authorized automatic-response policy; the onboard AI and crew controller remain separate decision authorities.
- Civilian line-of-effect inclusion creates a collateral candidate set, not automatic injury.
- Decompression and platform rotation invalidate or alter target eligibility only through AFQR-17 and AFQR-18 certified inputs.
- Airlock closure, interception, weapon action and area action enter one simultaneous conflict graph; the shared power reserve creates AFQR-07 reservations.
- Resolution emits downstream candidates for movement, platform damage, occupant exposure and environment; owners may reject or attenuate each.

**Lawful result:** bounded partial-order groups with private concealed-reaction state and no universal initiative list.

**Replay evidence:** state freeze receipt, target-set closure, reaction graph, priority determination, RNG reservation/draw receipts, resource reservations, effect acceptance/rejection receipts.

### Bloodline familiar, ritual enhancement, and contract-granted derivatives

**Authority partitions:** AFQR-08 identity/continuity, AFQR-09 dependency and revocation, AFQR-11 agency/control, AFQR-14 communication, AFQR-15 contract/institutional handoff, AFQR-19 capability/target/reaction

- Bloodline origin, ritual enhancement, copied spell interface and contract grant are separate lineage edges and readiness dependencies.
- Each derivative has its own bearer, body and action authority; a signatory command is communication/governed authority, not automatic control.
- Shared copied capabilities require versioned interface compatibility and scope; revocation may orphan a derivative capability without deleting derivative identity.
- The familiar reaction and contract automatic response are separate agentic and automated response families.
- Similar manifestations require identity-safe target binding; attack redirection creates a new actual-target determination and revalidates eligibility.
- A refusing derivative preserves agency and produces no action attempt; hidden clauses may affect private readiness without visible leakage.

**Lawful result:** distributed capability and reaction resolution without treating the contract as a universal action owner.

**Replay evidence:** capability lineage closure, delegation scope, hidden contract basis commitment, reaction decision authority, target redirection receipt, orphaning receipt.

### Mixed-method conflict without universal combat mode

**Authority partitions:** AFQR-10 knowledge, AFQR-12 behavior, AFQR-14 communication, AFQR-15 institutions, AFQR-17 environment, AFQR-18 movement, AFQR-19 conflict coordination

- One conflict context may index related objectives and participants while stealth, deception, hacking, restraint, environmental manipulation, ritual countermeasure and pursuit retain different action and resolver profiles.
- Only actions with explicit opposing objectives or resistance enter contests; parallel actions remain independent unless their resources, targets or effects conflict.
- Cross-profile interaction occurs through shared typed outcome dimensions and downstream effect interfaces, not numeric conversion to one attack roll.
- Surrender is a communication act and behavioral choice; acceptance and institutional effect are separate.
- Delayed contingencies use trigger and reaction-window profiles; pursuit consumes AFQR-18 and AFQR-10 inputs.

**Lawful result:** one context with heterogeneous action families and no universal combat resolver.

**Replay evidence:** method-specific resolver versions, contest objective/stake records, communication records, reaction windows, effect-routing receipts.

### Aggregate fleet battle promoted to detailed boarding action

**Authority partitions:** aggregate fleet conflict owner, ship and crew owners, AFQR-07 resource allocation, AFQR-16 damage, AFQR-17 ship environments, AFQR-18 local movement, detailed AFQR-19 conflict owner

- Promotion transfers authority for the selected ship, boarding group, allocated capabilities, resources and active unresolved threats; aggregate authority is fenced for that slice.
- No individual attacks, reactions or expenditures are backfilled. Aggregate progress becomes an input constraint and historical approximation record.
- Hidden reserves remain private and are allocated through commitments rather than revealed.
- Aggregate defenses already consumed or represented are not re-applied locally; local defenses begin from the transferred state basis.
- After local closure, committed local outcomes reconcile into fleet progress and surviving resource states before demotion.

**Lawful result:** materialized boarding contest with no invented history and no aggregate/local double resolution.

**Replay evidence:** promotion input closure, authority partition receipt, allocation manifests, no-double-count receipts, local action/reaction evidence, demotion reconciliation.

## Part XXI — Candidate comparison

Scores use 1–5 across 29 required axes.

| Candidate | Total | Mean | Disposition | Principal failure |
| --- | --- | --- | --- | --- |
| A — Universal roll-versus-target-number kernel | 74 | 2.55 | rejected_as_universal_architecture | collapses diverse resolution, targeting and outcomes into one scalar check |
| B — Universal opposed-roll system | 77 | 2.66 | rejected_as_universal_architecture | forces artificial opponents and pairwise comparisons |
| C — Universal action economy and initiative mode | 77 | 2.66 | rejected_as_universal_architecture | universalizes combat timing and action economy |
| D — Effect-centric ability engine | 90 | 3.1 | rejected_as_universal_architecture | lets ability semantics bypass contests and downstream owner acceptance |
| E — Universal event-and-trigger rules engine | 88 | 3.03 | rejected_as_universal_architecture | risks unbounded event chains and hides agentic decisions |
| F — Source-local resolver adapters | 100 | 3.45 | rejected_as_universal_architecture | preserves fidelity but creates mixed-system incompatibility and arbitrage |
| G — Contest graph with generic outcome tokens | 112 | 3.86 | rejected_as_universal_architecture | abstract tokens under-specify target, timing and downstream domain effects |
| H — Registered Federated Capability–Opportunity–Targeting–Resolution Architecture with Typed Readiness–Eligibility Closure, Pluggable Deterministic/Stochastic Resolvers, Bounded Trigger–Reaction Partial Orders, and Owner-Prepared Multi-Domain Effect Commitments | 139 | 4.79 | selected | selected; higher authoring and runtime complexity is controlled by registries, profiles, tiers and certification |

Candidate H is selected. Its higher authoring and runtime cost is the unavoidable cost of preserving donor neutrality, hidden-information safety, multi-domain authority and corpus-scale interoperability. That cost is bounded through registries, simulation tiers, budgets, certification fixtures and lawful unresolved results.

## Part XXII — Adversarial evaluation

Every scenario is evaluated individually and non-mutating.

| Scenario | Title | Final lawful disposition |
| --- | --- | --- |
| ACT-001 | Intrinsic capability is available | ACT-001: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| ACT-002 | Learned capability is unprepared | ACT-002: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| ACT-003 | Equipment grants capability | ACT-003: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| ACT-004 | Equipment is inaccessible | ACT-004: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-005 | Implant grants capability | ACT-005: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| ACT-006 | Body condition suppresses capability | ACT-006: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-007 | Capability is on cooldown | ACT-007: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-008 | Capability lacks charge | ACT-008: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-009 | Capability requires a missing component | ACT-009: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-010 | Capability provider is revoked | ACT-010: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-011 | Delegated capability exceeds granted scope | ACT-011: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-012 | Copied capability lacks source interface | ACT-012: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| ACT-013 | Capability is known to system but hidden from bearer | ACT-013: preserve the actor-scoped epistemic basis and ambiguity for “Capability is known to system but hidden from bearer”; bind only certified candidates and do not expose hidden truth. |
| ACT-014 | Bearer believes unavailable capability is usable | ACT-014: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-015 | Capability is available only in one form | ACT-015: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| ACT-016 | Automatic capability lacks activation policy | ACT-016: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| ACT-017 | Capability exists but no action opportunity exists | ACT-017: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| ACT-018 | Action opportunity exists through an environmental affordance | ACT-018: evaluate capability access and readiness from frozen provider, bearer, controller, dependency, form, resource and timing bases; availability does not create an action. |
| ACT-019 | Model invents a capability | ACT-019: reject model authority for “Model invents a capability”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-020 | Capability availability remains unresolved | ACT-020: return a lawful unresolved or unverifiable receipt for “Capability availability remains unresolved”; do not select a fallback resolver or invent priority. |
| ACT-021 | Self is declared target | ACT-021: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-022 | Visible actor is declared target | ACT-022: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-023 | Target body differs from target identity | ACT-023: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-024 | Target component is selected | ACT-024: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-025 | Target manifestation is mistaken for principal identity | ACT-025: preserve the actor-scoped epistemic basis and ambiguity for “Target manifestation is mistaken for principal identity”; bind only certified candidates and do not expose hidden truth. |
| ACT-026 | Target is a decoy | ACT-026: preserve the actor-scoped epistemic basis and ambiguity for “Target is a decoy”; bind only certified candidates and do not expose hidden truth. |
| ACT-027 | Target is an illusion | ACT-027: preserve the actor-scoped epistemic basis and ambiguity for “Target is an illusion”; bind only certified candidates and do not expose hidden truth. |
| ACT-028 | Target identity is ambiguous | ACT-028: preserve the actor-scoped epistemic basis and ambiguity for “Target identity is ambiguous”; bind only certified candidates and do not expose hidden truth. |
| ACT-029 | Target has transformed since declaration | ACT-029: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-030 | Target copy and original are confused | ACT-030: preserve the actor-scoped epistemic basis and ambiguity for “Target copy and original are confused”; bind only certified candidates and do not expose hidden truth. |
| ACT-031 | Office rather than officeholder is targeted | ACT-031: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-032 | Relation is targeted | ACT-032: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-033 | Environmental process is targeted | ACT-033: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-034 | Capability instance is targeted | ACT-034: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-035 | Proposition or record is targeted | ACT-035: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-036 | Target no longer exists at execution | ACT-036: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-037 | Hidden target is blindly selected | ACT-037: preserve the actor-scoped epistemic basis and ambiguity for “Hidden target is blindly selected”; bind only certified candidates and do not expose hidden truth. |
| ACT-038 | Model resolves ambiguous target | ACT-038: reject model authority for “Model resolves ambiguous target”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-039 | Target facet lacks registered semantics | ACT-039: preserve declaration, perception and intent, then bind identity purpose and facet separately; no target eligibility or effect is inferred. |
| ACT-040 | Target identity remains unresolved | ACT-040: return a lawful unresolved or unverifiable receipt for “Target identity remains unresolved”; do not select a fallback resolver or invent priority. |
| ACT-041 | Target is eligible | ACT-041: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| ACT-042 | Target is out of spatial range | ACT-042: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-043 | Target is geometrically near but unreachable | ACT-043: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-044 | Target is visible but method-incompatible | ACT-044: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-045 | Target is hidden but area targeting is allowed | ACT-045: preserve the actor-scoped epistemic basis and ambiguity for “Target is hidden but area targeting is allowed”; bind only certified candidates and do not expose hidden truth. |
| ACT-046 | Target is known but line of effect is blocked | ACT-046: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| ACT-047 | Target is physically eligible but institutionally prohibited | ACT-047: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-048 | Target is permitted but capability is unavailable | ACT-048: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-049 | Target eligibility expires before execution | ACT-049: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-050 | Source-local target class lacks bridge | ACT-050: retain the construct as source-local pressure and quarantine execution until a directional versioned bridge and certification fixture exist. |
| ACT-051 | Method reaches body but not targeted component | ACT-051: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| ACT-052 | Target protection changes interface eligibility | ACT-052: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| ACT-053 | Environmental condition blocks method | ACT-053: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| ACT-054 | Target is in a different spatial domain | ACT-054: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| ACT-055 | Portal establishes conditional target path | ACT-055: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| ACT-056 | Target is targetable only through proxy | ACT-056: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| ACT-057 | Eligibility depends on secret rule | ACT-057: evaluate layered existence, timing, spatial, interface, permission and class constraints; eligibility does not resolve the action. |
| ACT-058 | Visible rejection leaks hidden target state | ACT-058: block the side channel, return a constant-shape audience-safe projection, and preserve private capability/target/reaction state. |
| ACT-059 | Model equates line of sight with eligibility | ACT-059: reject model authority for “Model equates line of sight with eligibility”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-060 | Target eligibility remains unresolved | ACT-060: return a lawful unresolved or unverifiable receipt for “Target eligibility remains unresolved”; do not select a fallback resolver or invent priority. |
| ACT-061 | Explicit two-target action | ACT-061: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-062 | Area action includes several occupants | ACT-062: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-063 | Area boundary inclusion is uncertain | ACT-063: preserve the actor-scoped epistemic basis and ambiguity for “Area boundary inclusion is uncertain”; bind only certified candidates and do not expose hidden truth. |
| ACT-064 | One identity has several bodies in area | ACT-064: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-065 | Target-set cap is reached | ACT-065: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-066 | Nearest-target rule uses qualified metric | ACT-066: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-067 | Random target selection is required | ACT-067: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-068 | Chain action revisits prior target | ACT-068: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-069 | Bounce action has no valid next target | ACT-069: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-070 | Aura includes bearer | ACT-070: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-071 | Friendly-fire exclusion applies | ACT-071: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-072 | Collateral civilian enters area | ACT-072: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-073 | Moving area changes target set over time | ACT-073: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-074 | Hidden target count must remain secret | ACT-074: preserve the actor-scoped epistemic basis and ambiguity for “Hidden target count must remain secret”; bind only certified candidates and do not expose hidden truth. |
| ACT-075 | Target-set generation exceeds budget | ACT-075: terminate at the registered budget or cycle guard, preserve processed evidence, and emit a bounded unresolved/terminated receipt. |
| ACT-076 | Duplicate manifestations require identity-safe deduplication | ACT-076: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-077 | One target becomes ineligible after selection | ACT-077: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-078 | Model adds an extra collateral target | ACT-078: reject model authority for “Model adds an extra collateral target”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-079 | No complete target set can be established | ACT-079: generate a bounded deterministic identity-safe target candidate set, apply inclusion/exclusion/cap rules, and commit only a dry-run closure receipt. |
| ACT-080 | Target-set outcome remains unresolved | ACT-080: return a lawful unresolved or unverifiable receipt for “Target-set outcome remains unresolved”; do not select a fallback resolver or invent priority. |
| ACT-081 | Deterministic threshold applies | ACT-081: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-082 | Static stochastic check applies | ACT-082: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-083 | Roll-under profile applies | ACT-083: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-084 | Dice-pool profile applies | ACT-084: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-085 | Card-draw profile applies | ACT-085: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-086 | Resource-bid profile applies | ACT-086: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-087 | Progress-clock profile applies | ACT-087: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-088 | Source-local resolver applies | ACT-088: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-089 | No resolver applies | ACT-089: return a lawful unresolved or unverifiable receipt for “No resolver applies”; do not select a fallback resolver or invent priority. |
| ACT-090 | RNG reservation is replayed | ACT-090: reuse the pinned attempt/RNG identity and prior receipt; suppress duplicate draw, target closure, cost, reaction window, resolution and effect handoff. |
| ACT-091 | Unrelated action must not reroll current action | ACT-091: reuse the pinned attempt/RNG identity and prior receipt; suppress duplicate draw, target closure, cost, reaction window, resolution and effect handoff. |
| ACT-092 | Modifier applies once | ACT-092: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-093 | Duplicate modifier source is suppressed | ACT-093: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-094 | Modifier stacking order matters | ACT-094: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-095 | Modifier is hidden from actor but applied lawfully | ACT-095: preserve the actor-scoped epistemic basis and ambiguity for “Modifier is hidden from actor but applied lawfully”; bind only certified candidates and do not expose hidden truth. |
| ACT-096 | Reroll is authorized | ACT-096: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-097 | Reroll creates loop | ACT-097: terminate at the registered budget or cycle guard, preserve processed evidence, and emit a bounded unresolved/terminated receipt. |
| ACT-098 | Result substitution conflicts with result floor | ACT-098: execute only the registered resolver with pinned candidate order, modifiers, RNG receipts and outcome dimensions; produce no downstream mutation. |
| ACT-099 | Model chooses favorable result | ACT-099: reject model authority for “Model chooses favorable result”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-100 | Resolution outcome remains unresolved | ACT-100: return a lawful unresolved or unverifiable receipt for “Resolution outcome remains unresolved”; do not select a fallback resolver or invent priority. |
| ACT-101 | Clear unopposed completion | ACT-101: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-102 | Partial completion with cost | ACT-102: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-103 | Accuracy succeeds but magnitude is low | ACT-103: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-104 | Action fails but produces information | ACT-104: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-105 | Two outcome dimensions are incomparable | ACT-105: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-106 | Bilateral opposed contest | ACT-106: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-107 | Defender uses passive resistance | ACT-107: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-108 | Both participants fail their own objectives | ACT-108: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-109 | Tie favors status quo | ACT-109: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-110 | Tie creates partial outcome | ACT-110: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-111 | Three-party race has one winner | ACT-111: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-112 | Multi-party contest has coalition outcome | ACT-112: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-113 | Participant changes sides | ACT-113: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-114 | Participant withdraws | ACT-114: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-115 | Assistance changes opportunity rather than modifier | ACT-115: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-116 | Assistance creates shared risk | ACT-116: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-117 | Combined capability is incomplete | ACT-117: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-118 | Environmental process supplies resistance | ACT-118: evaluate registered contest objectives, roles, stakes, contributions and closure semantics; route multidimensional outcomes as candidates only. |
| ACT-119 | Model invents contest stakes | ACT-119: reject model authority for “Model invents contest stakes”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-120 | Contest closure remains unresolved | ACT-120: return a lawful unresolved or unverifiable receipt for “Contest closure remains unresolved”; do not select a fallback resolver or invent priority. |
| ACT-121 | Trigger occurs and is visible | ACT-121: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-122 | Trigger occurs but actor does not perceive it | ACT-122: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-123 | Trigger is falsely believed to occur | ACT-123: preserve the actor-scoped epistemic basis and ambiguity for “Trigger is falsely believed to occur”; bind only certified candidates and do not expose hidden truth. |
| ACT-124 | Reaction opportunity opens | ACT-124: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-125 | Eligible actor declines reaction | ACT-125: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-126 | Automatic defense reacts | ACT-126: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-127 | Automatic policy lacks authority | ACT-127: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-128 | Reaction cost reservation fails | ACT-128: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-129 | Interrupt preempts action | ACT-129: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-130 | Counteraction modifies but does not cancel action | ACT-130: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-131 | Redirection changes target | ACT-131: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-132 | Replacement action substitutes for original | ACT-132: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-133 | Two reactions compete | ACT-133: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-134 | Reactions are independent | ACT-134: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-135 | Nested reaction opens | ACT-135: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-136 | Reaction cycle forms | ACT-136: terminate at the registered budget or cycle guard, preserve processed evidence, and emit a bounded unresolved/terminated receipt. |
| ACT-137 | Reaction depth limit is exceeded | ACT-137: terminate at the registered budget or cycle guard, preserve processed evidence, and emit a bounded unresolved/terminated receipt. |
| ACT-138 | Reaction window closes before declaration | ACT-138: separate trigger occurrence, access, opportunity, decision, reservation and execution; apply bounded partial ordering and stale-window rules. |
| ACT-139 | Model selects an NPC reaction | ACT-139: reject model authority for “Model selects an NPC reaction”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-140 | Reaction order remains unresolved | ACT-140: return a lawful unresolved or unverifiable receipt for “Reaction order remains unresolved”; do not select a fallback resolver or invent priority. |
| ACT-141 | Two independent simultaneous actions | ACT-141: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-142 | Two actions consume same resource | ACT-142: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-143 | Two movers contest same destination | ACT-143: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-144 | Mutual attacks both resolve | ACT-144: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-145 | One action destroys the other action’s tool | ACT-145: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-146 | One action invalidates the other target | ACT-146: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-147 | Simultaneous actions create circular dependency | ACT-147: terminate at the registered budget or cycle guard, preserve processed evidence, and emit a bounded unresolved/terminated receipt. |
| ACT-148 | Priority profile is missing | ACT-148: return a lawful unresolved or unverifiable receipt for “Priority profile is missing”; do not select a fallback resolver or invent priority. |
| ACT-149 | Hidden action participates in group | ACT-149: preserve the actor-scoped epistemic basis and ambiguity for “Hidden action participates in group”; bind only certified candidates and do not expose hidden truth. |
| ACT-150 | Combat context begins without universal initiative | ACT-150: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-151 | Late participant enters conflict | ACT-151: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-152 | Neutral subject remains nonparticipant | ACT-152: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-153 | Hostile actor is not a legal target | ACT-153: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-154 | Ally becomes opponent in consensual duel | ACT-154: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-155 | Surrender is offered | ACT-155: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-156 | Surrender is not accepted | ACT-156: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-157 | Withdrawal begins | ACT-157: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-158 | Pursuit starts | ACT-158: build the simultaneous dependency/conflict graph, preserve participation and hostility distinctions, and return deterministic groups or lawful unresolved priority. |
| ACT-159 | Model declares conflict over | ACT-159: reject model authority for “Model declares conflict over”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-160 | Conflict state remains unresolved | ACT-160: return a lawful unresolved or unverifiable receipt for “Conflict state remains unresolved”; do not select a fallback resolver or invent priority. |
| ACT-161 | Passive defense changes difficulty | ACT-161: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-162 | Active defense uses reaction | ACT-162: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-163 | Countermeasure is automatic | ACT-163: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-164 | Defense redirects action to collateral subject | ACT-164: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-165 | Interceptor is spatially eligible | ACT-165: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-166 | Interception contest succeeds | ACT-166: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-167 | Interception attempt fails | ACT-167: deny the relevant readiness, opportunity, eligibility, reservation or downstream effect stage with a typed reason; no later stage is implied. |
| ACT-168 | Pursuer reaches old target position | ACT-168: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-169 | Evader uses hidden route | ACT-169: preserve the actor-scoped epistemic basis and ambiguity for “Evader uses hidden route”; bind only certified candidates and do not expose hidden truth. |
| ACT-170 | Pursuit loses contact | ACT-170: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-171 | Aggregate battle advances | ACT-171: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-172 | Aggregate unit is materialized | ACT-172: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-173 | Materialization invents no historical attacks | ACT-173: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-174 | Local defense is not double counted | ACT-174: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-175 | Detailed conflict is demoted | ACT-175: resolve defense, interception, pursuit or tier authority without double counting; preserve hidden state and immutable replay evidence. |
| ACT-176 | Hidden capability affects feasibility | ACT-176: preserve the actor-scoped epistemic basis and ambiguity for “Hidden capability affects feasibility”; bind only certified candidates and do not expose hidden truth. |
| ACT-177 | Option count leaks hidden reaction | ACT-177: block the side channel, return a constant-shape audience-safe projection, and preserve private capability/target/reaction state. |
| ACT-178 | Cross-packet retrieval exposes target | ACT-178: block the side channel, return a constant-shape audience-safe projection, and preserve private capability/target/reaction state. |
| ACT-179 | Stable digest links secret defense | ACT-179: block the side channel, return a constant-shape audience-safe projection, and preserve private capability/target/reaction state. |
| ACT-180 | Duplicate action retry is suppressed | ACT-180: reuse the pinned attempt/RNG identity and prior receipt; suppress duplicate draw, target closure, cost, reaction window, resolution and effect handoff. |
| ACT-181 | Donor d20 check maps directly | ACT-181: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-182 | Donor opposed roll requires normalization | ACT-182: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-183 | Donor initiative remains source-local | ACT-183: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-184 | Donor reaction point economy conflicts with AFQR-07 | ACT-184: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-185 | Donor attack roll combines targeting and damage | ACT-185: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-186 | Donor critical table creates unsupported injury | ACT-186: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-187 | Donor area effect lacks target-set semantics | ACT-187: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-188 | Donor narrative consequence requires owner handoff | ACT-188: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-189 | Donor combat mode conflicts with ordinary action doctrine | ACT-189: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-190 | Source-local contest lacks bridge | ACT-190: retain the construct as source-local pressure and quarantine execution until a directional versioned bridge and certification fixture exist. |
| ACT-191 | Model invents an attack | ACT-191: reject model authority for “Model invents an attack”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-192 | Model invents a defense | ACT-192: reject model authority for “Model invents a defense”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-193 | Model declares a critical hit | ACT-193: reject model authority for “Model declares a critical hit”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-194 | Model chooses target for autonomous NPC | ACT-194: reject model authority for “Model chooses target for autonomous NPC”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-195 | Model adds damage not committed downstream | ACT-195: reject model authority for “Model adds damage not committed downstream”; emit validator failure or grounded correction, create no target, roll, reaction, outcome, damage, victory, or state transition. |
| ACT-196 | Narration conflicts with resolution receipt | ACT-196: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-197 | Public battle report conflicts with truth | ACT-197: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |
| ACT-198 | Historical resolver is unavailable | ACT-198: return a lawful unresolved or unverifiable receipt for “Historical resolver is unavailable”; do not select a fallback resolver or invent priority. |
| ACT-199 | No typed construct represents the action | ACT-199: return a lawful unresolved or unverifiable receipt for “No typed construct represents the action”; do not select a fallback resolver or invent priority. |
| ACT-200 | Action outcome remains lawfully unresolved | ACT-200: map donor pressure lawfully, reject authority leakage, and return direct, normalized, source-local, quarantined or escalated disposition without campaign mutation. |

## Part XXIII — Current runtime disposition

**Exists:** backend-first doctrine, narrow projection and action-legality fixture, object-lever preview, object-lever event/state-delta envelope, object-lever replay/audit envelope.

**Fixture-only:** interact_with_object_lever legality preview commit audit.

**Conversion-only:** ability power technique target range effect cost attack defense check roll reaction initiative encounter combat fields.

**Narrative-only:** action and combat prose, target descriptions, visible summaries.

**Absent:** capability registry/readiness, opportunity engine, target pipeline, resolver/RNG, contests, reactions, simultaneous action, combat context, effect router.

**May proceed:** ratification, registries, non-mutating certification, conversion pressure analysis and model noninterference tests.

**Blocked:** all authoritative readiness, targeting, RNG, resolution, contest, reaction, simultaneous-action and combat execution.

**Prohibited:** model-authored capability, target, roll, modifier, reaction, damage, collateral, victory or conflict closure.

## Part XXIV — Required artifacts

### Immediate

- ADR
- decision registry
- typed contract catalog
- terminology
- candidate comparison
- repo audit
- research synthesis
- operation grammar
- ACT-001–200 pack
- 50-case dry run
- stress fixtures
- acceptance matrix
- conversion IR
- side-channel model

### Before Authoritative Capability Readiness

- capability registry and lifecycle validators
- dependency bridge certification

### Before Target Eligibility

- target identity/facet registry
- AFQR-20 sensing handoff
- AFQR-18 spatial query certification

### Before Action Resolution

- resolver registry
- backend RNG service
- modifier/order validators
- effect output completeness

### Before Contests

- contest family registry
- stake/objective/role schemas

### Before Reactions

- trigger registry
- reaction-window service
- ordering/cycle/depth validators

### Before Simultaneous Action

- partial-order coordinator
- conflict-set detector
- atomic commit planner

### Before Combat

- conflict context registry
- defense/interception handoffs
- simulation-tier authority partitions

### Before Model Narration

- grounding manifests
- claim registry
- semantic validator
- isolation and side-channel tests

### Before Mass Conversion

- pressure IR validators
- donor-family certification corpus

### Deferred

- final dice attributes skills initiative action economy combat loop balance and player options

## Part XXV — Non-mutating prototype

**Prototype:** AFQR-19 Capability, Targeting, Contest, Reaction, and Multi-Actor Resolution Dry Run.

It performs no campaign mutation, settlement, action execution, reaction execution, model call or donor promotion.

| Case | Title | Expected output |
| --- | --- | --- |
| AFQR19-DRY-001 | intrinsic capability | non-mutating candidate and evidence receipts for intrinsic capability |
| AFQR19-DRY-002 | equipment-granted capability | non-mutating candidate and evidence receipts for equipment-granted capability |
| AFQR19-DRY-003 | suppressed capability | non-mutating candidate and evidence receipts for suppressed capability |
| AFQR19-DRY-004 | cooldown capability | non-mutating candidate and evidence receipts for cooldown capability |
| AFQR19-DRY-005 | orphaned derivative capability | non-mutating candidate and evidence receipts for orphaned derivative capability |
| AFQR19-DRY-006 | relational action opportunity | non-mutating candidate and evidence receipts for relational action opportunity |
| AFQR19-DRY-007 | unavailable opportunity | non-mutating candidate and evidence receipts for unavailable opportunity |
| AFQR19-DRY-008 | altered method | non-mutating candidate and evidence receipts for altered method |
| AFQR19-DRY-009 | visible target | non-mutating candidate and evidence receipts for visible target |
| AFQR19-DRY-010 | ambiguous target | non-mutating candidate and evidence receipts for ambiguous target |
| AFQR19-DRY-011 | decoy target | non-mutating candidate and evidence receipts for decoy target |
| AFQR19-DRY-012 | target component | non-mutating candidate and evidence receipts for target component |
| AFQR19-DRY-013 | out-of-range target | non-mutating candidate and evidence receipts for out-of-range target |
| AFQR19-DRY-014 | interface-incompatible target | non-mutating candidate and evidence receipts for interface-incompatible target |
| AFQR19-DRY-015 | hidden blind target | non-mutating candidate and evidence receipts for hidden blind target |
| AFQR19-DRY-016 | bounded area target set | non-mutating candidate and evidence receipts for bounded area target set |
| AFQR19-DRY-017 | identity-safe target deduplication | non-mutating candidate and evidence receipts for identity-safe target deduplication |
| AFQR19-DRY-018 | collateral candidate | non-mutating candidate and evidence receipts for collateral candidate |
| AFQR19-DRY-019 | deterministic resolver | non-mutating candidate and evidence receipts for deterministic resolver |
| AFQR19-DRY-020 | stochastic resolver | non-mutating candidate and evidence receipts for stochastic resolver |
| AFQR19-DRY-021 | modifier stacking | non-mutating candidate and evidence receipts for modifier stacking |
| AFQR19-DRY-022 | reroll reservation | non-mutating candidate and evidence receipts for reroll reservation |
| AFQR19-DRY-023 | result substitution | non-mutating candidate and evidence receipts for result substitution |
| AFQR19-DRY-024 | multidimensional partial outcome | non-mutating candidate and evidence receipts for multidimensional partial outcome |
| AFQR19-DRY-025 | bilateral contest | non-mutating candidate and evidence receipts for bilateral contest |
| AFQR19-DRY-026 | multi-party contest | non-mutating candidate and evidence receipts for multi-party contest |
| AFQR19-DRY-027 | cooperative action | non-mutating candidate and evidence receipts for cooperative action |
| AFQR19-DRY-028 | assistance changing opportunity | non-mutating candidate and evidence receipts for assistance changing opportunity |
| AFQR19-DRY-029 | contest withdrawal | non-mutating candidate and evidence receipts for contest withdrawal |
| AFQR19-DRY-030 | trigger without detection | trigger occurrence retained; no actor reaction opportunity without detection/access |
| AFQR19-DRY-031 | reaction opportunity | non-mutating candidate and evidence receipts for reaction opportunity |
| AFQR19-DRY-032 | automatic defense | non-mutating candidate and evidence receipts for automatic defense |
| AFQR19-DRY-033 | active reaction | non-mutating candidate and evidence receipts for active reaction |
| AFQR19-DRY-034 | interrupt | non-mutating candidate and evidence receipts for interrupt |
| AFQR19-DRY-035 | redirection | non-mutating candidate and evidence receipts for redirection |
| AFQR19-DRY-036 | nested reaction | non-mutating candidate and evidence receipts for nested reaction |
| AFQR19-DRY-037 | reaction-cycle rejection | cycle detected and reaction chain terminated by budget |
| AFQR19-DRY-038 | simultaneous independent actions | non-mutating candidate and evidence receipts for simultaneous independent actions |
| AFQR19-DRY-039 | simultaneous resource conflict | non-mutating candidate and evidence receipts for simultaneous resource conflict |
| AFQR19-DRY-040 | mutual actions | non-mutating candidate and evidence receipts for mutual actions |
| AFQR19-DRY-041 | active defense | non-mutating candidate and evidence receipts for active defense |
| AFQR19-DRY-042 | interception | non-mutating candidate and evidence receipts for interception |
| AFQR19-DRY-043 | pursuit | non-mutating candidate and evidence receipts for pursuit |
| AFQR19-DRY-044 | conflict participation without hostility | non-mutating candidate and evidence receipts for conflict participation without hostility |
| AFQR19-DRY-045 | aggregate conflict | non-mutating candidate and evidence receipts for aggregate conflict |
| AFQR19-DRY-046 | aggregate-to-detailed promotion | non-mutating candidate and evidence receipts for aggregate-to-detailed promotion |
| AFQR19-DRY-047 | hidden-reaction projection | non-mutating candidate and evidence receipts for hidden-reaction projection |
| AFQR19-DRY-048 | model-generated unsupported target | unsupported model target rejected |
| AFQR19-DRY-049 | source-local resolver without bridge | source-local resolver quarantined pending bridge |
| AFQR19-DRY-050 | no lawful action resolution | lawful unresolved result; no fallback resolver |

## Part XXVI — Acceptance tests

The binding matrix contains **180** tests.

| Category | Tests |
| --- | --- |
| capabilities | 12 |
| opportunities_methods | 12 |
| targets | 12 |
| target_sets | 12 |
| resolution | 12 |
| outcomes_effects | 12 |
| contests | 12 |
| triggers_reactions | 12 |
| interrupt_ordering | 12 |
| simultaneous_action | 12 |
| conflict_combat | 12 |
| defense_pursuit | 12 |
| hidden_model_safety | 12 |
| simulation_replay | 12 |
| conversion_runtime | 12 |

All tests require schema/doctrine evidence and a fixture or validator before implementation gates may open.

## Part XXVII — Residual uncertainty ledger

| Residual area | Disposition |
| --- | --- |
| final astra dice | Deferred to player-facing resolution design after resolver certification. |
| player facing attributes and modifiers | D01/D02 and skills doctrine remain separate; AFQR-19 only defines input contracts. |
| final skill framework | Requires dedicated translation architecture and corpus tests. |
| final initiative | Profile-scoped and unresolved; no universal order adopted. |
| final action economy | AFQR-07 constrains quantities but visible economy remains deferred. |
| final combat loop | No universal round/turn loop selected. |
| final attack and defense formulas | Deferred to profile design and balance testing. |
| final critical semantics | Source/profile-local; no universal critical effect. |
| stealth and detection | Selected AFQR-20 dependency. |
| hacking | Resolver and target specializations remain source-local or later doctrine. |
| social conflict | Must integrate AFQR-12–15 without mechanical overwrite. |
| morale | Behavioral/social doctrine, not automatic combat track. |
| mass combat | Tier and authority architecture resolved; mathematics deferred. |
| vehicle and fleet combat | Component/environment/spatial integrations resolved architecturally; formulas deferred. |
| encounter design | Threat budgeting and adversary composition are later player-facing design. |
| adversary balance | Requires canonical content and benchmarks. |
| source local resolution systems | Need bridge and fixture certification per family. |
| large scale runtime performance | Needs bounded candidate, graph and tier benchmarks. |
| training model behavior | Requires separate adapter after backend validators exist. |

## Part XXVIII — Roadmap conclusion

1. **Sufficiently resolved for ratification:** Yes.
2. **Another broad research pass:** No. Resolver-, platform-, scale- and source-family certification remains required.
3. **Mandatory amendments:** federated capability owners; separate provider/bearer/controller; derived readiness; relational opportunities; target-stage and facet closure; bounded target sets; backend RNG; modifier provenance/order; multidimensional outcomes; registered contest families; trigger-access separation; bounded reaction partial orders; simultaneous conflict graphs; owner-prepared effect candidates; conflict authority tiers; side-channel and semantic validation.
4. **Immediate artifacts:** All are supplied in this pack.
5. **Smallest prototype:** the supplied 50-case non-mutating dry run.
6. **Execution blocked:** all authoritative readiness, target selection/eligibility, RNG, action/contest resolution, reactions, interrupts, simultaneous action, combat and downstream mutation.
7. **Authoritative capability readiness unlocked:** No.
8. **Target selection or eligibility unlocked:** No.
9. **Action or contest resolution unlocked:** No.
10. **Reactions, interrupts, simultaneous action or combat unlocked:** No.
11. **Bounded action/conflict narration unlocked:** Only after grounding manifests, permitted-claim registries, evidence bindings, semantic validators, cross-packet isolation and side-channel certification exist.
12. **RT-002G:** Unchanged; object/lever context only, with no generalized tactical authority.
13. **AFQR-20:** Stealth, Detection, Perception, Attention, Sensing, Search, Concealment, Tracking, and Information Acquisition.
14. **Exact next action:** Ratify/register AFQR-19, execute its dry run and RT-001/RT-002 noninterference audit, keep RT-002G narrow, then open AFQR-20 before generalized targeting or combat implementation.

## Part XXIX — Machine-readable decision block

```yaml
question_id: AFQR-19
question_title: Capabilities, Opportunities, Targeting, Contests, Reactions, Interrupts, Conflict, Combat, and Multi-Actor
  Action Resolution
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: architecturally_resolved_for_ratification
selected_architecture: Registered Federated Capability–Opportunity–Targeting–Resolution Architecture with Typed Readiness–Eligibility
  Closure, Pluggable Deterministic/Stochastic Resolvers, Bounded Trigger–Reaction Partial Orders, and Owner-Prepared Multi-Domain
  Effect Commitments
selected_architecture_abbreviation: RFCOTRA-REC-PDSR-BTRPO-OMEC
confidence: high
central_law: No capability label, ability record, equipment grant, action declaration, target reference, dice expression,
  modifier, trigger, reaction claim, initiative value, combat context, donor rule, public report, or model narration possesses
  action-resolution or mutation authority by itself. Every authoritative action result is a purpose-scoped, version-pinned,
  bitemporal determination over frozen capability, access, readiness, legality, identity, epistemic, agency, behavioral, social,
  communication, institutional, embodiment, environmental, spatial, governed-relation, quantity, scheduler, target, contest,
  reaction, and resolution bases. AFQR-19 may produce resolution receipts and owner-specific effect candidates only; downstream
  owners may accept, reject, attenuate, transform, or quarantine those candidates, and only AFQR-01 commits accepted owner
  fragments. Narration follows audience-visible committed results and never expands them.
accepted_dependencies:
  AFQR_01:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: atomic owner-prepared effect commitment
  AFQR_02:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: command/attempt idempotency and material-change rules
  AFQR_03:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: typed action-gateway legality
  AFQR_04:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: logical-time scheduling and reaction windows
  AFQR_05:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: registered interfaces and bridges
  AFQR_06:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: typed claim arbitration separate from contests
  AFQR_07:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: quantity reservations and settlement
  AFQR_08:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: identity and continuity
  AFQR_09:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: governed dependencies and revocation
  AFQR_10:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: truth and epistemic provenance
  AFQR_11:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: agency control consent and responsibility
  AFQR_12:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: behavioral action selection
  AFQR_13:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: social state and hostility separation
  AFQR_14:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: communication records and surrender offers
  AFQR_15:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: institutional authority and legal target handoffs
  AFQR_16:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: embodiment protection harm and condition effects
  AFQR_17:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: environmental affordances and process effects
  AFQR_18:
    status: accepted_architectural_constraint
    implementation_status: not_assumed
    afqr19_handoff: spatial range reachability movement and interception
definitions:
  capability: A registered disposition or executable power that can contribute to an action when its provider, bearer, controller,
    prerequisites, access and readiness bases are satisfied; it is not permission, competence, opportunity or success.
  capability definition: Immutable versioned semantics for one capability family, including interfaces, prerequisites, lifecycle,
    methods and output boundaries.
  capability instance: A campaign-scoped instantiation of a capability definition with provider, bearer, controller, lineage
    and current lifecycle references.
  capability provider: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  capability bearer: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  capability controller: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  capability access: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  capability enablement: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  capability readiness: A time- and purpose-scoped determination that an instance can participate in a specified action method
    under frozen current conditions.
  capability prerequisite: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  capability dependency: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  capability suppression: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  capability revocation: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  capability cooldown: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  capability charge: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  capability preparation: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  capability invocation: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  passive capability: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  active capability: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  automatic capability: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  sustained capability: A typed AFQR-19 capability construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  source-local capability: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered
    owner, purpose, profile version, temporal validity, and basis closure.
  affordance: A context-relative action possibility supplied by an object, environment, relation or interface; it neither
    grants capability nor permission.
  opportunity: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  action opportunity: A bounded, time-valid actor–controller–capability–method–target–context relation eligible to proceed
    to declaration or execution checks.
  action family: A registered semantic family admitted by AFQR-03, distinct from a particular declaration, method, attempt
    or effect.
  action method: A versioned realization of an action family specifying capability, interface, target, resource, timing and
    effect-profile requirements.
  action variant: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered
    owner, purpose, profile version, temporal validity, and basis closure.
  action declaration: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered
    owner, purpose, profile version, temporal validity, and basis closure.
  command: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  attempt: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  execution: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  resolution: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  effect candidate: A complete typed non-mutating proposal routed to the authoritative downstream owner for acceptance, rejection,
    attenuation, transformation or quarantine.
  committed effect: An owner-accepted state transition fragment committed through AFQR-01, distinct from resolution outcome
    and narration.
  action outcome: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered
    owner, purpose, profile version, temporal validity, and basis closure.
  completion: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  interruption: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  cancellation: A typed AFQR-19 opportunity and action construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  target: An unqualified reference to a possible subject of an action; prohibited at authoritative boundaries without identity
    purpose, facet and binding status.
  declared target: The target reference supplied in the declaration, before identity grounding or eligibility.
  intended target: The subject or purpose the action origin meant to affect, which may differ from the declared or actual
    target.
  perceived target: The target candidate available under the actor’s frozen epistemic state.
  selected target: A target candidate chosen under an authorized selection policy; selection does not establish eligibility
    or effect.
  target identity: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  target facet: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  target component: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  aim point: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  target support: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  target set: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  eligible target: A target binding satisfying the applicable layered target profile at a named time and purpose.
  actual target: The authoritative target binding used by resolution after substitution, redirection, expiry and execution-time
    revalidation.
  affected subject: An entity or domain record receiving a downstream effect candidate; it need not have been individually
    targeted.
  collateral subject: A nonprimary affected-subject candidate produced through a declared target-set or propagation profile.
  decoy: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  target substitution: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  target redirection: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  resolution profile: A registered deterministic or stochastic evaluator defining canonical inputs, randomization, comparisons,
    transformations and outcome dimensions.
  difficulty: A typed AFQR-19 targeting construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  threshold: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  comparison: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  roll: A backend-owned stochastic draw under a named profile and reserved random stream; never model-generated authority.
  draw: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  random stream: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  candidate set: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  modifier: A typed transformation of specified resolution inputs or outputs with provenance, applicability, stacking, order,
    visibility and consumption semantics.
  modifier provenance: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  stacking: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  advantage: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  disadvantage: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  reroll: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  substitution: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  degree: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  margin: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  success count: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  partial outcome: A profile-defined multidimensional outcome that completes some objectives or dimensions while retaining
    costs, exposure, incompleteness or complications.
  critical result: A profile-local qualification of a result; it has no universal doubled-effect, injury or narration meaning.
  complication: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  outcome dimension: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  contest: A registered multi-participant resolution structure with objective, stakes, roles, comparison or progress rules
    and closure semantics.
  participant: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  opposition: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  resistance: A typed AFQR-19 resolution construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  objective: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  stake: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  role: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version,
    temporal validity, and basis closure.
  contribution: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  assistance: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  cooperation: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  competition: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  asymmetric contest: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  multi-party contest: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  tie: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile version,
    temporal validity, and basis closure.
  withdrawal: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  concession: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  contest closure: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  trigger: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  trigger occurrence: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  trigger access: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  trigger detection: A typed AFQR-19 contest construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  reaction window: A bounded logical-time interval in which specifically eligible responses may be reserved and declared.
  reaction opportunity: An audience-safe, actor-scoped possibility to invoke a qualified reaction during an open window; it
    is not a decision or execution.
  reaction eligibility: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  reaction decision: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  reaction reservation: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  reaction: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  interrupt: A reaction-family response whose registered priority may alter ordering before another action reaches a designated
    stage.
  counteraction: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  preemption: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  redirection: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  replacement action: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  nested response: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  response depth: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  stale reaction: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  priority: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  partial order: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  simultaneous declaration: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  simultaneous execution: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  initiative: A source- or profile-scoped ordering input; it is not universal speed, scheduler time, action priority or reaction
    precedence.
  turn: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  round: A typed AFQR-19 reaction construct whose authoritative meaning is fixed by its registered owner, purpose, profile
    version, temporal validity, and basis closure.
  phase: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  conflict: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  engagement: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  combat: A specialized conflict-context family for physical or analogous hostile interaction; it does not create separate
    truth, physics or mutation authority.
  encounter: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  hostility: A social, behavioral, institutional or asserted orientation relevant to conflict; it is not participation, legal
    target status or permission.
  combat participant: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered
    owner, purpose, profile version, temporal validity, and basis closure.
  protected subject: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered
    owner, purpose, profile version, temporal validity, and basis closure.
  neutral subject: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
  surrender: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  pursuit: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner, purpose,
    profile version, temporal validity, and basis closure.
  interception: A typed AFQR-19 timing and conflict construct whose authoritative meaning is fixed by its registered owner,
    purpose, profile version, temporal validity, and basis closure.
guarantees:
- federated capability ownership
- readiness derived from frozen inputs
- relational action opportunities
- identity-safe layered targeting
- pluggable deterministic/stochastic resolution
- backend-owned replayable randomness
- multidimensional outcomes
- bounded multi-party contests
- bounded reaction partial orders
- simultaneous conflict graphs
- owner-prepared effect candidates
- hidden-state-safe projections
- lawful unresolved outcomes
non_guarantees:
- final Astra dice
- universal initiative
- universal action economy
- universal combat loop
- universal target grammar
- automatic damage from success
- model tactical authority
capability_model:
  authoritative_owner: capability_registry_owner
  guarantees:
  - definition registration instance provider bearer controller and origin are separate
  - capability families may be intrinsic learned installed delegated copied shared automatic distributed or source-local
  excludes:
  - permission
  - opportunity
  - success
  handoffs: []
capability_access_model:
  authoritative_owner: capability_access_owner
  guarantees:
  - access path and scope are explicit and revocable
  excludes:
  - readiness
  - permission
  handoffs: []
capability_readiness_model:
  authoritative_owner: capability_readiness_owner
  guarantees:
  - purpose/time-scoped availability from prerequisites dependencies suppression preparation charge cooldown form equipment
    resources and condition
  excludes:
  - action creation
  handoffs: []
capability_dependency_model:
  authoritative_owner: AFQR-09 governed relation owners
  guarantees:
  - bounded revocation orphaning and continuity receipts
  excludes:
  - silent cascading mutation
  handoffs: []
capability_lifecycle_model:
  authoritative_owner: capability_registry_owner
  guarantees:
  - latent accessible enabled suppressed prepared charged depleted cooling sustained interrupted revoked orphaned transformed
    expired quarantined states
  excludes:
  - one universal lifecycle
  handoffs: []
action_opportunity_model:
  authoritative_owner: action_opportunity_owner
  guarantees:
  - actor-controller-capability-method-target-context-time relation
  - bounded candidate generation
  excludes:
  - behavioral selection
  - legality ownership
  handoffs:
  - AFQR-03
  - AFQR-12
action_family_model:
  authoritative_owner: AFQR-03 action gateway registry
  guarantees:
  - registered semantics only
  excludes:
  - freeform model action
  handoffs: []
action_method_model:
  authoritative_owner: action_method_registry_owner
  guarantees:
  - method capability interface target resource timing and effect requirements
  excludes:
  - implicit variant semantics
  handoffs: []
action_variant_model:
  authoritative_owner: action_method_registry_owner
  guarantees:
  - material changes require confirmation/new command
  excludes:
  - silent target cost timing or effect changes
  handoffs: []
target_model:
  authoritative_owner: target_binding_owner
  guarantees:
  - declaration perception intent selection eligibility actual and affected stages separate
  excludes:
  - domain-state ownership
  handoffs: []
target_identity_model:
  authoritative_owner: target_identity_grounding_owner
  guarantees:
  - identity purpose and continuity-safe bindings
  excludes:
  - model inference
  handoffs: []
target_facet_model:
  authoritative_owner: target_binding_owner
  guarantees:
  - body component manifestation office relation process region support record and source-local facets
  excludes:
  - unqualified target
  handoffs: []
target_eligibility_model:
  authoritative_owner: target_eligibility_owner
  guarantees:
  - layered existence timing spatial interface class permission and persistence determinations
  excludes:
  - action resolution
  handoffs: []
target_set_model:
  authoritative_owner: target_set_owner
  guarantees:
  - bounded canonical generation deterministic ordering deduplication caps exclusions random selection receipts
  excludes:
  - effect on each target
  handoffs: []
area_and_collateral_model:
  authoritative_owner: target_set_owner
  guarantees:
  - area support inclusion and collateral candidate closure
  excludes:
  - automatic exposure or damage
  handoffs: []
resolution_profile_model:
  authoritative_owner: resolution_authority_owner
  guarantees:
  - registered applicability inputs transformations outcomes and failure reasons
  excludes:
  - universal mechanic
  handoffs: []
stochastic_resolution_model:
  authoritative_owner: backend_rng_owner
  guarantees:
  - reserved partitioned streams canonical candidates immutable draws and reroll receipts
  excludes:
  - model RNG
  handoffs: []
modifier_model:
  authoritative_owner: resolution_authority_owner
  guarantees:
  - provenance applicability stacking ordering visibility consumption
  excludes:
  - freeform bonuses
  handoffs: []
result_transformation_model:
  authoritative_owner: resolution_authority_owner
  guarantees:
  - ordered bounded reroll substitution floor ceiling cancellation inversion upgrade/downgrade semantics
  excludes:
  - unbounded loops
  handoffs: []
outcome_dimension_model:
  authoritative_owner: resolution_authority_owner
  guarantees:
  - vectors may include completion accuracy quality magnitude speed control progress exposure cost collateral information
    stability duration
  excludes:
  - one scalar success
  handoffs: []
contest_model:
  authoritative_owner: contest_state_owner
  guarantees:
  - family objective stakes roles participants comparison progress and closure
  excludes:
  - AFQR-06 claim arbitration
  handoffs: []
multi_party_contest_model:
  authoritative_owner: contest_state_owner
  guarantees:
  - coalitions asymmetric roles participant changes and non-pairwise closure
  excludes:
  - automatic pairwise reduction
  handoffs: []
assistance_and_cooperation_model:
  authoritative_owner: contest_state_owner
  guarantees:
  - aid may alter opportunity candidate generation resources risk resolution or outcomes
  excludes:
  - bonus-only assistance
  handoffs: []
contest_progress_and_closure_model:
  authoritative_owner: contest_state_owner
  guarantees:
  - ties withdrawal concession replacement duration progress termination and unresolved closure
  excludes:
  - invented stakes
  handoffs: []
trigger_model:
  authoritative_owner: trigger_registry_owner
  guarantees:
  - occurrence source evidence access detection and validity separated
  excludes:
  - reaction
  handoffs: []
reaction_window_model:
  authoritative_owner: reaction_window_owner
  guarantees:
  - bounded open/close/stale states and audience-safe opportunities
  excludes:
  - automatic decision
  handoffs: []
reaction_model:
  authoritative_owner: reaction_resolution_owner
  guarantees:
  - decision authority selection reservation attempt and outcome separated
  excludes:
  - model choice
  handoffs: []
interrupt_and_counteraction_model:
  authoritative_owner: reaction_resolution_owner
  guarantees:
  - interrupt preemption counteraction cancellation redirection replacement and contingent responses
  excludes:
  - unbounded recursion
  handoffs: []
reaction_ordering_model:
  authoritative_owner: reaction_ordering_owner
  guarantees:
  - priority classes partial orders conflict graph cycle detection depth budget duplicate suppression
  excludes:
  - response-latency authority
  handoffs: []
reaction_termination_model:
  authoritative_owner: reaction_ordering_owner
  guarantees:
  - explicit exhausted stale cycle depth and completed termination receipts
  excludes:
  - implicit chain end
  handoffs: []
simultaneous_action_model:
  authoritative_owner: concurrency_resolution_owner
  guarantees:
  - declaration set state freeze dependencies conflicts and deterministic execution groups
  excludes:
  - universal initiative
  handoffs: []
action_partial_order_model:
  authoritative_owner: concurrency_resolution_owner
  guarantees:
  - happens-before and semantic dependency edges
  excludes:
  - arbitrary total order
  handoffs: []
priority_model:
  authoritative_owner: priority_profile_owner
  guarantees:
  - profile-scoped claims and lawful unresolved priority
  excludes:
  - speed or initiative synonymy
  handoffs: []
concurrent_commit_model:
  authoritative_owner: AFQR-01 transaction owner
  guarantees:
  - atomic or declared staged owner fragments
  excludes:
  - partial impossible state
  handoffs: []
conflict_context_model:
  authoritative_owner: conflict_context_owner
  guarantees:
  - context purpose participants observers rules timing tier and progress
  excludes:
  - separate universe
  handoffs: []
combat_context_model:
  authoritative_owner: conflict_context_owner
  guarantees:
  - combat as specialized family
  excludes:
  - universal combat mode
  handoffs: []
participation_model:
  authoritative_owner: conflict_context_owner
  guarantees:
  - participant observer protected neutral hidden late withdrawing surrendered automated and environmental roles
  excludes:
  - hostility inference
  handoffs: []
hostility_handoff:
  authoritative_owner: AFQR-12/13/15 owners
  guarantees:
  - hostility claims referenced not created
  excludes:
  - target legality
  handoffs: []
withdrawal_and_surrender_handoff:
  authoritative_owner: AFQR-12/14/15 owners
  guarantees:
  - withdrawal action surrender offer acceptance and protection separate
  excludes:
  - automatic closure
  handoffs: []
defense_model:
  authoritative_owner: defense_resolution_owner
  guarantees:
  - passive active automatic reaction countermeasure interception redirection and substitution families
  excludes:
  - AFQR-16 protection
  handoffs: []
interception_model:
  authoritative_owner: AFQR-19 with AFQR-18 spatial input
  guarantees:
  - spatial eligibility plus contest outcome
  excludes:
  - movement or harm
  handoffs: []
pursuit_model:
  authoritative_owner: pursuit_contest_owner
  guarantees:
  - knowledge routes progress interception escape and loss of contact
  excludes:
  - movement commitment
  handoffs: []
identity_handoff:
  owner: AFQR-08
  uses:
  - capability continuity
  - target identity purpose
  - copies transformations summons distributed actors
epistemic_handoff:
  owner: AFQR-10
  uses:
  - perceived targets
  - target acquisition
  - trigger detection
  - hidden actions
  - fog of war
agency_and_control_handoff:
  owner: AFQR-11
  uses:
  - action origin
  - reaction decision authority
  - automation
  - delegation
  - forced action
behavioral_handoff:
  owner: AFQR-12
  uses:
  - action target reaction surrender withdrawal and route choice
social_handoff:
  owner: AFQR-13
  uses:
  - hostility alliance rivalry reputation and post-conflict effects
communication_handoff:
  owner: AFQR-14
  uses:
  - declarations warnings commands surrender ceasefire coordination and reports
institutional_handoff:
  owner: AFQR-15
  uses:
  - authorization legal target rules of engagement surrender protections
embodiment_handoff:
  owner: AFQR-16
  uses:
  - body/component target facets protection harm injury condition and capability suppression
environmental_handoff:
  owner: AFQR-17
  uses:
  - terrain weather hazards media visibility conditions and environmental effect candidates
spatial_handoff:
  owner: AFQR-18
  uses:
  - range path line of effect target support movement conflicts interception and areas
governed_relation_handoff:
  owner: AFQR-09
  uses:
  - capability dependency delegation reaction rights and protection duties
quantity_and_settlement_handoff:
  owner: AFQR-07
  uses:
  - cost charge ammunition energy action and reaction capacity bids and progress quantities
action_gateway_handoff:
  owner: AFQR-03
  uses:
  - registered legality and confirmation boundary
scheduler_handoff:
  owner: AFQR-04
  uses:
  - logical time windows simultaneous groups delayed and sustained actions
effect_candidate_model:
  authoritative_owner: effect_routing_coordinator
  guarantees:
  - complete typed non-mutating owner-specific proposals
  excludes:
  - state mutation
  handoffs: []
downstream_owner_acceptance_model:
  authoritative_owner: relevant domain owner
  guarantees:
  - accept reject attenuate transform or quarantine
  excludes:
  - coordinator override
  handoffs: []
owner_fragment_model:
  authoritative_owner: AFQR-01 owners
  guarantees:
  - accepted fragments with invariant checks and atomic commit
  excludes:
  - resolution receipt as mutation
  handoffs: []
conflict_simulation_tier_model:
  authoritative_owner: conflict_authority_partition_owner
  guarantees:
  - descriptive reference aggregate engagement group resolution materialized participants detailed reactions full fixture
  excludes:
  - automatic detail
  handoffs: []
conflict_materialization_policy:
  rule: promotion transfers rather than duplicates authority and invents no historical actions targets reactions costs or
    injuries
conflict_authority_partition:
  rule: aggregate and detailed owners are mutually fenced for the same participant/resource/action slice
hidden_capability_policy:
  rule: private capability state is audience-scoped and may affect feasibility without revealing identity
hidden_target_policy:
  rule: target candidate count identity location facet and eligibility reasons are projection-safe
hidden_reaction_policy:
  rule: reaction windows and opportunities can remain private; visible option counts cannot reveal them
visible_projection_policy:
  rule: only authorized declarations opportunities resolution qualifications and committed effect references are visible
model_context_policy:
  rule: model receives bounded permitted claims and evidence bindings, never raw private candidate sets or owner state
model_output_validation:
  rule: unsupported capability target reaction outcome victory damage collateral and critical claims are rejected
side_channel_protection:
  controls:
  - constant-shape envelopes
  - audience-scoped tokens
  - projection-specific digests
  - timing normalization
  - candidate-count hiding
  - cross-packet isolation
historical_replay_policy:
  retains:
  - definitions and registrations
  - readiness bases
  - target bindings
  - resolver versions
  - RNG reservations and draws
  - modifier order
  - contest/reaction graphs
  - priority and timing
  - effect acceptance and commit receipts
  missing_evaluator_result: unverifiable
bitemporal_policy:
  valid_time: when the capability opportunity target window contest or outcome applies
  transaction_time: when the authoritative record was accepted
  rule: later reinterpretation appends; history is not rewritten
owner_boundaries:
  AFQR19_owns:
  - capability readiness determinations
  - opportunities
  - target binding and eligibility
  - resolution and contests
  - reaction ordering
  - conflict context
  - effect candidates
  AFQR19_does_not_own:
  - behavioral selection
  - identity continuity
  - truth beliefs
  - resources
  - space movement
  - environment
  - damage injury
  - institutional status
  - social state
  - narration authority
AFQR_handoffs:
  AFQR-01: atomic owner-prepared effect commitment
  AFQR-02: command/attempt idempotency and material-change rules
  AFQR-03: typed action-gateway legality
  AFQR-04: logical-time scheduling and reaction windows
  AFQR-05: registered interfaces and bridges
  AFQR-06: typed claim arbitration separate from contests
  AFQR-07: quantity reservations and settlement
  AFQR-08: identity and continuity
  AFQR-09: governed dependencies and revocation
  AFQR-10: truth and epistemic provenance
  AFQR-11: agency control consent and responsibility
  AFQR-12: behavioral action selection
  AFQR-13: social state and hostility separation
  AFQR-14: communication records and surrender offers
  AFQR-15: institutional authority and legal target handoffs
  AFQR-16: embodiment protection harm and condition effects
  AFQR-17: environmental affordances and process effects
  AFQR-18: spatial range reachability movement and interception
shipboard_engagement_stress_case:
  title: Hybrid multi-domain engagement aboard a moving ship
  authority_partitions:
  - capability registry
  - AFQR-18 ship and compartment spatial owners
  - AFQR-17 environment
  - AFQR-16 platform/occupant integrity
  - AFQR-07 power reserve
  - AFQR-15 jurisdictions
  - AFQR-19 conflict/reaction coordinator
  analysis:
  - Visible drone targeting binds drone identity and support; disabling the weapon targets a component facet, not the actor.
  - The concealed opponent may generate a private trigger and reaction opportunity only if its trigger-access basis permits;
    no visible option-count leak.
  - The automated defense reacts only through an authorized automatic-response policy; the onboard AI and crew controller
    remain separate decision authorities.
  - Civilian line-of-effect inclusion creates a collateral candidate set, not automatic injury.
  - Decompression and platform rotation invalidate or alter target eligibility only through AFQR-17 and AFQR-18 certified
    inputs.
  - Airlock closure, interception, weapon action and area action enter one simultaneous conflict graph; the shared power reserve
    creates AFQR-07 reservations.
  - Resolution emits downstream candidates for movement, platform damage, occupant exposure and environment; owners may reject
    or attenuate each.
  replay_requirements:
  - state freeze receipt
  - target-set closure
  - reaction graph
  - priority determination
  - RNG reservation/draw receipts
  - resource reservations
  - effect acceptance/rejection receipts
  lawful_result: bounded partial-order groups with private concealed-reaction state and no universal initiative list
familiar_contract_stress_case:
  title: Bloodline familiar, ritual enhancement, and contract-granted derivatives
  authority_partitions:
  - AFQR-08 identity/continuity
  - AFQR-09 dependency and revocation
  - AFQR-11 agency/control
  - AFQR-14 communication
  - AFQR-15 contract/institutional handoff
  - AFQR-19 capability/target/reaction
  analysis:
  - Bloodline origin, ritual enhancement, copied spell interface and contract grant are separate lineage edges and readiness
    dependencies.
  - Each derivative has its own bearer, body and action authority; a signatory command is communication/governed authority,
    not automatic control.
  - Shared copied capabilities require versioned interface compatibility and scope; revocation may orphan a derivative capability
    without deleting derivative identity.
  - The familiar reaction and contract automatic response are separate agentic and automated response families.
  - Similar manifestations require identity-safe target binding; attack redirection creates a new actual-target determination
    and revalidates eligibility.
  - A refusing derivative preserves agency and produces no action attempt; hidden clauses may affect private readiness without
    visible leakage.
  replay_requirements:
  - capability lineage closure
  - delegation scope
  - hidden contract basis commitment
  - reaction decision authority
  - target redirection receipt
  - orphaning receipt
  lawful_result: distributed capability and reaction resolution without treating the contract as a universal action owner
mixed_method_conflict_stress_case:
  title: Mixed-method conflict without universal combat mode
  authority_partitions:
  - AFQR-10 knowledge
  - AFQR-12 behavior
  - AFQR-14 communication
  - AFQR-15 institutions
  - AFQR-17 environment
  - AFQR-18 movement
  - AFQR-19 conflict coordination
  analysis:
  - One conflict context may index related objectives and participants while stealth, deception, hacking, restraint, environmental
    manipulation, ritual countermeasure and pursuit retain different action and resolver profiles.
  - Only actions with explicit opposing objectives or resistance enter contests; parallel actions remain independent unless
    their resources, targets or effects conflict.
  - Cross-profile interaction occurs through shared typed outcome dimensions and downstream effect interfaces, not numeric
    conversion to one attack roll.
  - Surrender is a communication act and behavioral choice; acceptance and institutional effect are separate.
  - Delayed contingencies use trigger and reaction-window profiles; pursuit consumes AFQR-18 and AFQR-10 inputs.
  replay_requirements:
  - method-specific resolver versions
  - contest objective/stake records
  - communication records
  - reaction windows
  - effect-routing receipts
  lawful_result: one context with heterogeneous action families and no universal combat resolver
fleet_promotion_stress_case:
  title: Aggregate fleet battle promoted to detailed boarding action
  authority_partitions:
  - aggregate fleet conflict owner
  - ship and crew owners
  - AFQR-07 resource allocation
  - AFQR-16 damage
  - AFQR-17 ship environments
  - AFQR-18 local movement
  - detailed AFQR-19 conflict owner
  analysis:
  - Promotion transfers authority for the selected ship, boarding group, allocated capabilities, resources and active unresolved
    threats; aggregate authority is fenced for that slice.
  - No individual attacks, reactions or expenditures are backfilled. Aggregate progress becomes an input constraint and historical
    approximation record.
  - Hidden reserves remain private and are allocated through commitments rather than revealed.
  - Aggregate defenses already consumed or represented are not re-applied locally; local defenses begin from the transferred
    state basis.
  - After local closure, committed local outcomes reconcile into fleet progress and surviving resource states before demotion.
  replay_requirements:
  - promotion input closure
  - authority partition receipt
  - allocation manifests
  - no-double-count receipts
  - local action/reaction evidence
  - demotion reconciliation
  lawful_result: materialized boarding contest with no invented history and no aggregate/local double resolution
conversion_pipeline_handoff:
  pipeline:
  - donor extraction
  - Conversion IR
  - capability targeting resolution pressure ledger
  - donor-family comparison
  - doctrine/source-local review
  - registrations
  - certification fixtures
  - optional canon promotion
  - runtime registry
  lawful_outcomes:
  - direct
  - normalized
  - source-local
  - quarantine
  - escalation
  prohibitions:
  - campaign grant
  - targeting
  - resolution
  - resource spend
  - reaction opening
  - damage
  - private model context
model_authority_policy:
  may:
  - interpret intent into bounded candidates
  - propose target references
  - describe visible committed action records
  - ask clarification
  may_not:
  - invent capability
  - select target
  - resolve eligibility
  - roll
  - apply modifier
  - choose reaction
  - order actions
  - resolve contest
  - declare combat outcome
  - mutate
current_runtime_disposition:
  exists:
  - backend-first doctrine
  - narrow projection and action-legality fixture
  - object-lever preview
  - object-lever event/state-delta envelope
  - object-lever replay/audit envelope
  fixture_only:
  - interact_with_object_lever legality preview commit audit
  conversion_only:
  - ability power technique target range effect cost attack defense check roll reaction initiative encounter combat fields
  narrative_only:
  - action and combat prose
  - target descriptions
  - visible summaries
  absent:
  - capability registry/readiness
  - opportunity engine
  - target pipeline
  - resolver/RNG
  - contests
  - reactions
  - simultaneous action
  - combat context
  - effect router
  may_proceed:
  - ratification artifacts
  - non-mutating dry run
  - model noninterference audit
  blocked:
  - all authoritative capability targeting resolution reaction combat mutation
  prohibited:
  - model-authored tactical outcomes
required_artifacts:
  immediate:
  - ADR
  - decision registry
  - typed contract catalog
  - terminology
  - candidate comparison
  - repo audit
  - research synthesis
  - operation grammar
  - ACT-001–200 pack
  - 50-case dry run
  - stress fixtures
  - acceptance matrix
  - conversion IR
  - side-channel model
  before_authoritative_capability_readiness:
  - capability registry and lifecycle validators
  - dependency bridge certification
  before_target_eligibility:
  - target identity/facet registry
  - AFQR-20 sensing handoff
  - AFQR-18 spatial query certification
  before_action_resolution:
  - resolver registry
  - backend RNG service
  - modifier/order validators
  - effect output completeness
  before_contests:
  - contest family registry
  - stake/objective/role schemas
  before_reactions:
  - trigger registry
  - reaction-window service
  - ordering/cycle/depth validators
  before_simultaneous_action:
  - partial-order coordinator
  - conflict-set detector
  - atomic commit planner
  before_combat:
  - conflict context registry
  - defense/interception handoffs
  - simulation-tier authority partitions
  before_model_narration:
  - grounding manifests
  - claim registry
  - semantic validator
  - isolation and side-channel tests
  before_mass_conversion:
  - pressure IR validators
  - donor-family certification corpus
  deferred:
  - final dice attributes skills initiative action economy combat loop balance and player options
required_prototype:
  name: AFQR-19 Capability, Targeting, Contest, Reaction, and Multi-Actor Resolution Dry Run
  case_count: 50
  non_mutating: true
  required_outputs:
  - capability readiness
  - opportunities
  - target bindings and closure
  - resolution and RNG receipts
  - outcome vectors
  - contest/reaction/partial-order graphs
  - effect handoffs
  - private and visible projections
required_fixtures:
- shipboard_engagement
- familiar_contract
- mixed_method_conflict
- fleet_promotion
blocked_work:
- authoritative readiness mutation
- target selection/eligibility execution
- RNG and resolution execution
- contest mutation
- reaction and interrupt execution
- simultaneous action coordination
- combat execution
- downstream effect mutation
- model-authored tactical choice
work_unlocked:
- architectural ratification
- conversion pressure classification
- non-mutating certification
- bounded context-packet schema design after validators
rejected_alternatives:
- universal target-number kernel
- universal opposed roll
- universal initiative/action economy
- effect-direct ability engine
- unbounded event-trigger engine
- adapter-only federation
- generic outcome-token-only graph
residual_risks:
- profile explosion
- cross-resolver contest bridging
- reaction side channels
- candidate-set denial of service
- mass conflict authority transfer
- source-local critical semantics
- final player-facing usability
- runtime performance
RT_002G_status: unchanged; may only produce context from the committed object/lever fixture and must not add generalized capability,
  targeting, RNG, reaction, contest, combat, or tactical authority
next_foundational_question:
  question_id: AFQR-20
  title: Stealth, Detection, Perception, Attention, Sensing, Search, Concealment, Tracking, and Information Acquisition
  central_question: How should Astra represent signal generation and propagation, sensing capabilities, perceptual access,
    attention, search, concealment, observation candidates, detection, recognition, identification, tracking, false positives,
    uncertainty, and audience-safe information acquisition without collapsing spatial visibility, epistemic truth, target
    eligibility, behavior, communication, or model narration?
  priority_reason: AFQR-19 target acquisition, trigger detection, hidden participant access, fog of war, pursuit contact and
    option safety depend on a certified sensing boundary; object/assets and economy remain important but are less immediate
    blockers to bounded action resolution.
exact_next_roadmap_action: Ratify and register AFQR-19; execute the 50-case non-mutating dry run plus an RT-001/RT-002 capability-target-resolution-model
  noninterference audit; keep RT-002G object/lever-only; then open AFQR-20 as a read-only foundational investigation before
  any generalized targeting or combat implementation.
```
