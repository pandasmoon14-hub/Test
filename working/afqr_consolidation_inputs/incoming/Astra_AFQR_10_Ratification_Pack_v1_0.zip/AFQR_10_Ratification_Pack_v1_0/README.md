# Astra AFQR-10 Ratification Pack v1.0

This pack resolves AFQR-10: epistemic state, perception, evidence, knowledge, belief, uncertainty, secrecy, deception, memory, discovery, and observer-relative truth.

## Decision

Astra adopts **Typed Bitemporal Truth–Epistemic Provenance Architecture with Profiled Revision and Visibility-Safe Projection (TTEP-PRV)**.

The pack is architecture and specification only. It does not modify the repository or authorize generalized runtime state mutation.

## Contents

- `master/Astra_AFQR_10_Master_Ratification_v1_0.md` — integrated 27-part answer ending in the machine-readable decision block.
- `adrs/AFQR-10_Epistemic_State_Observer_Relative_Truth.md` — compact ADR.
- `registries/afqr_10_decision_registry.yaml` — comprehensive decision YAML.
- `registries/repository_audit_50_questions.yaml` — explicit repository diagnosis.
- `registries/canonical_terminology.yaml` — canonical vocabulary and prohibited unqualified terms.
- `registries/candidate_comparison.csv` — candidates A–H scored across twenty dimensions.
- `registries/hidden_information_side_channel_threat_model.yaml` — leakage and noninterference controls.
- `contracts/afqr_10_typed_contract_catalog.yaml` — 36 requested typed contracts.
- `contracts/conversion_epistemic_pressure_ir_amendment.yaml` — 23 candidate-only conversion IR records.
- `operations/afqr_10_operation_grammar.yaml` — all 90 required operations.
- `evaluation/afqr_10_adversarial_scenarios_A_FZ.yaml` — all 182 scenarios, each with a distinct disposition.
- `fixtures/afqr_10_non_mutating_dry_run.yaml` — 45-case minimum dry run.
- `fixtures/concealed_familiar_network_typed_graph.yaml` — integrated stress-case graph.
- `sources/external_research_synthesis.yaml` and `sources/source_manifest.yaml` — research and evidence basis.

## Runtime disposition

Narrow RT-002G may resume only after AFQR-01–10 artifact ratification and the AFQR-10 side-channel amendment/audit. Generalized context packets, dialogue knowledge, observation/evidence/belief/memory mutation, rumor/deception, investigation/discovery, and institutional/common knowledge remain blocked.
