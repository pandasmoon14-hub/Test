# Astra Foundational Question Resolution 10

## Epistemic State, Perception, Evidence, Knowledge, Belief, Uncertainty, Secrecy, Deception, Memory, Discovery, and Observer-Relative Truth

**Artifact status:** architecture ratification candidate  
**Version:** 1.0  
**Repository inspected:** `pandasmoon14-hub/Test@928bb79ce00a2de749d127dcc5cb8299de788a15`  
**Repository mode:** read-only  
**Implementation authority:** none beyond the existing narrow RT-001/RT-002 fixtures  
**Corpus posture:** designed for the stated 200–400 heterogeneous donor requirement and the current project brief’s larger planning scale of roughly 1,900 PDFs.

## Part I — Executive decision

### Selected architecture

**Typed Bitemporal Truth–Epistemic Provenance Architecture with Profiled Revision and Visibility-Safe Projection**  
Abbreviation: **TTEP-PRV**

> Authoritative world truth and every observer-relative epistemic state are separately owned, versioned, and append-only. They may be connected only by registered observation, evidence, testimony, communication, inference, memory, and disclosure receipts. No observation, belief, memory, rumor, map, official record, or model output changes truth; no truth enters an observer or model projection without a registered visibility-safe path.

**Confidence:** High. The architecture can be ratified now. A second broad research pass is not required before ratification; focused implementation research remains necessary for performance, storage, and evaluator design.

### What it is

A federated, typed, bitemporal architecture that keeps authoritative facts, observations, evidence, testimony, communications, subject beliefs, knowledge determinations, memory traces, secrecy/disclosure state, deception outcomes, rumor lineages, group knowledge, and model-facing projections as separate owner-controlled records connected by append-only provenance and update receipts.

### What it is not

It is not a global discovered flag, a global list of facts, a probability table, a transcript-derived memory system, a possible-world database, a BDI cognition engine, a visibility Boolean, a map-reveal system, or an LLM context convention. Those can exist only as scoped mechanisms beneath the architecture.

## Part II — Repository-grounded diagnosis

The current head of `main` is unchanged from the supplied baseline: `928bb79ce00a2de749d127dcc5cb8299de788a15`, the merge of PR #325 / RT-002F. The repository establishes backend truth authority, model non-authority, owner interfaces, visibility tiers, redacted hidden-fact references, deterministic serialization, one narrow object/lever legality-preview-commit-audit path, and conversion-stage provenance. It does not contain a generalized epistemic runtime.

### Current executable and doctrine surfaces

- `state_owner_interface_contract_skeleton.py`: reference-only owner families, visibility tiers, hidden-information policies, and deterministic envelopes; no state reads or projection materialization.
- `read_only_vertical_slice_state_owner_facade.py`: exactly one scene, actor, NPC/target, object/lever, hazard clock, visible condition, and hidden-fact reference.
- `projection_visibility_adapter_v0_1.py`: reference-only backend-safe, visible-safe, redacted, unavailable, deferred, and unknown projection packets.
- `object_lever_interaction_legality_reader.py`: one command family, requiring scene/actor/object projections and recording optional kinds including hidden-fact references.
- `object_lever_transaction_preview_bridge.py`: non-mutating preview candidate only.
- `object_lever_event_commit_state_delta_path.py`: narrow committed-event record and bounded delta receipt; not a general event or state engine.
- `object_lever_replay_audit_check.py`: deterministic in-memory identity/coherence audit; not historical visibility/belief replay.
- Conversion IR and Batch C records: source evidence, provenance, source reliability, translation confidence, maps, source-local claims, and content schemas; these are conversion-stage evidence, not campaign epistemic state.

### Repository audit answers

| # | Question | Finding | Disposition |
|---:|---|---|---|
| 1 | What currently represents authoritative world truth? | Doctrine assigns truth to backend current state and committed event history; executable support is only the narrow RT-002E object/lever fixture, not a generalized truth/fact service. | `partial_doctrine_fixture_only` |
| 2 | What currently represents a visible projection? | RT-001H visibility descriptors and RT-002B reference-only projection packets/serializers. They carry safe references, not a generalized observer epistemic view. | `fixture_only` |
| 3 | What currently represents hidden information? | Visibility tiers, hidden-information policy labels, redacted hidden-fact references, and forbidden metadata keys. No generalized hidden proposition/fact store exists. | `fixture_only` |
| 4 | Are player-visible, actor-visible, backend-visible, and model-visible states separated? | Player/actor/backend tiers exist nominally; model-visible appears as a downstream consumer, not a complete independent projection plane with audience and purpose enforcement. | `partial` |
| 5 | Are observation and truth separated? | Doctrine implies the need, but no generalized ObservationRecord or acquisition pipeline is implemented. | `absent_runtime` |
| 6 | Are discovery and truth separated? | Conversion and roadmap language distinguish discovery-like content from runtime truth, but executable discovery state is absent. | `broad_doctrine_only` |
| 7 | Are known state and actual state separated? | Some Batch B doctrine warns that known state is not actual state; runtime lacks actor-owned known/belief state. | `broad_doctrine_only` |
| 8 | Are maps treated as claims or authority? | Conversion schemas treat map annotations as source-grounded records and prohibit inferred geometry. Mature runtime map knowledge is absent; maps are not current world authority. | `conversion_only` |
| 9 | Are rumors represented? | Only named as future/generated content risk. No runtime rumor identity, branch, transmission, or belief model. | `absent` |
| 10 | Is testimony represented? | No generalized speaker/content/intent/delivery contract. | `absent` |
| 11 | Is evidence represented? | Conversion IR has SourceEvidenceIR and provenance for donor evidence; no campaign EvidenceItem exists. | `conversion_only` |
| 12 | Is provenance attached to evidence? | Yes for extraction/conversion evidence. Runtime observation/evidence provenance is absent. | `conversion_only` |
| 13 | Are beliefs represented per actor? | No. | `absent` |
| 14 | Are false beliefs representable? | No executable actor belief model. | `absent` |
| 15 | Are contradictory beliefs representable? | No. | `absent` |
| 16 | Is uncertainty representable without a scalar? | Conversion confidence is categorical, but runtime uncertainty has no tagged union. | `partial_conversion_only` |
| 17 | Is source reliability represented? | Batch C conversion records include source reliability tiers; not runtime testimony/evidence reliability. | `conversion_only` |
| 18 | Are memory and event history separated? | Doctrine says runtime state is not model memory, but event ledger is loosely called world memory. No character MemoryTrace layer exists. | `partial_doctrine_only` |
| 19 | Is forgetting represented? | No. | `absent` |
| 20 | Are false or altered memories representable? | No. | `absent` |
| 21 | Is player knowledge distinct from character knowledge? | Required by doctrine intent but not represented by independent runtime subject/projection records. | `not_implemented` |
| 22 | Is institutional or group knowledge represented? | Faction records exist as content/runtime pressure, but institutional knowledge state is absent. | `absent_runtime` |
| 23 | Is common knowledge represented? | No. | `absent` |
| 24 | Are languages and translation epistemic bridges? | Translation fields exist in conversion IR; no registered runtime language/translation bridge. | `conversion_only` |
| 25 | Can observation be partial or noisy? | No generalized observation schema; only projection availability/redaction statuses. | `absent_runtime` |
| 26 | Can an illusion create a false observation without changing truth? | No executable architecture before AFQR-10. | `absent_runtime` |
| 27 | Can a disguise create observer-specific identity belief? | Identity can be referenced, but observer-specific identity belief is absent. | `absent_runtime` |
| 28 | Can a hidden fact safely affect action legality? | Narrowly, hidden information can produce unavailable/redacted projection states and block the RT-002C fixture. No general hidden-predicate legality contract exists. | `narrow_fixture_only` |
| 29 | Can a context packet accidentally expose hidden truth? | Yes in principle; the compiler is not implemented, and reference IDs, metadata, status shape, retrieval, or mixed audience data remain risks. | `open_risk` |
| 30 | Can option count or blocker wording leak secrets? | Yes. Current fixture status/reason vocabulary and per-kind requirement rows are not a complete constant-shape side-channel defense. | `open_risk` |
| 31 | Can the model infer hidden facts from raw references? | The narrow adapter tries to prevent raw truth, but safe-reference semantics and cross-packet inference are not generalized or audience-bounded. | `open_risk` |
| 32 | Does current replay preserve what was visible at the time? | RT-002F audits deterministic fixture serialization, not historical audience visibility state. | `no` |
| 33 | Does current replay preserve what an actor believed at the time? | No belief state exists. | `no` |
| 34 | Are truth changes and knowledge changes separate events? | Architecturally required by AFQR-10, not currently implemented. | `absent_runtime` |
| 35 | Can a delayed message be represented? | Logical-time doctrine can schedule it conceptually; no communication delivery record exists. | `broad_doctrine_only` |
| 36 | Can outdated information remain believed? | No belief model; not executable. | `absent_runtime` |
| 37 | Can an observer learn that prior evidence was forged? | No evidence or belief-revision runtime. | `absent_runtime` |
| 38 | Can a source-local divination rule be contained? | Conversion/source-local doctrine can quarantine or retain the construct; runtime evaluator/profile is absent. | `conversion_ready_runtime_absent` |
| 39 | Can institutional records conflict with actual truth? | Content records can be source-local claims, but no runtime institutional-record-versus-truth architecture exists. | `absent_runtime` |
| 40 | Are evidence and claim conflict routed through AFQR-06 correctly? | AFQR-06 handles authoritative typed claim arbitration; ordinary belief/evidence conflict needs AFQR-10 and must not be reduced to winner selection. | `requires_afqr10_boundary` |
| 41 | Are generic metadata fields at risk of carrying hidden truth? | Yes. Recursive blacklist checks help narrow fixtures but are not sufficient against aliases, encoded values, semantic leakage, IDs, hashes, counts, or new keys. | `high_risk` |
| 42 | Which knowledge-like fields are conversion-only? | SourceEvidenceIR, translation confidence/status, source reliability, map annotations, source-local facts/claims, discovery/investigation pressure, provenance, and conversion confidence. | `conversion_only` |
| 43 | Which are fixture-only? | Visibility tiers, hidden fact references, projection packets, RT-002C requirement readings, safe reference IDs, object/lever blocker reasons, and RT-002F in-memory audit identity. | `fixture_only` |
| 44 | Which are broad doctrine rather than executable runtime law? | Backend truth ownership, hidden partitions, context packets, event sourcing, logical time, investigation/discovery ownership, map non-authority, and model non-authority. | `broad_doctrine_only` |
| 45 | What useful foundations already exist? | Backend/model authority separation; owner routing; visibility tiers; redacted references; metadata containment; deterministic serializers; logical time; append-only event posture; conversion provenance; source-local containment. | `useful_foundation` |
| 46 | What must be generalized? | Fact/proposition ownership, subject registry, observation/evidence/testimony, belief/knowledge/uncertainty, inference/revision, memory, disclosure, rumor, group/common knowledge, projections, and historical replay. | `required_generalization` |
| 47 | What remains entirely absent? | Actor belief and memory state, testimony, rumor propagation, deception outcomes, institutional/common knowledge, runtime evidence chains, and historical epistemic packet replay. | `absent` |
| 48 | What runtime work remains blocked? | Generalized epistemic mutation; investigation/discovery outcomes; NPC knowledge/dialogue; rumor/deception; institutional knowledge; context packets; perception/divination; memory mutation; shared knowledge. | `blocked` |
| 49 | Does AFQR-10 change the narrow RT-002G prerequisite? | Yes. It adds a mandatory side-channel/epistemic-containment amendment before narrow RT-002G, but does not require implementing the full epistemic system inside that fixture. | `amended_resume_after_ratification` |
| 50 | Should generalized context-packet or dialogue work remain blocked? | Yes, until typed subjects, beliefs, visible memory/evidence, projection policy, audience/purpose separation, side-channel tests, and historical packet basis exist. | `blocked` |

### Unsafe assumptions and implementation blockers

- Blacklist-only metadata filtering is insufficient: aliases, encoded values, semantic payloads, reference existence, counts, order, timing, hashes, confidence precision, source reliability, and retrieval rank can leak hidden state.
- Current `safe_reference_ids`, per-entity requirement rows, option/status shapes, and blocker reasons are safe only as narrow fixtures; they must not be generalized unchanged.
- Player-visible, actor-visible, backend-visible, and model-purpose visibility require independent audience projections. A model consumer label is not an epistemic subject or complete security boundary.
- No generalized proposition/fact registry, observation/evidence/testimony system, belief state, memory, rumor, deception, institutional/common knowledge, or historical packet replay exists.
- Generalized context packet and dialogue work remain blocked. Narrow RT-002G may continue only after AFQR-10 ratification and the side-channel amendment defined here.
## Part III — External research synthesis

No single external formalism is adopted as universal law. The architecture extracts durable mechanisms and contains their assumptions.

| Research family | Mechanism established | Astra lesson | Limitation | Disposition |
|---|---|---|---|---|
| **epistemic_logic**<br>Fagin, Halpern, Moses, and Vardi — Reasoning About Knowledge; Halpern and Moses — Knowledge and Common Knowledge in a Distributed Environment; Baltag, Moss, and Solecki — The Logic of Public Announcements, Common Knowledge, and Private Suspicions | Modal accessibility relations represent what worlds an agent considers possible; group operators distinguish everyone-knows, distributed knowledge, and common knowledge; dynamic epistemic logic models public/private information updates. | Use explicit subject-relative alternatives and finite group-knowledge certificates where valuable; distinguish private/public announcements and knowledge of ignorance. | Standard systems often assume logically omniscient, introspective, consistent agents and can cause possible-world explosion. | Adapt concepts and vocabulary; reject universal Kripke-state materialization and perfect-agent axioms. |
| **belief_revision**<br>Alchourrón, Gärdenfors, and Makinson — On the Logic of Theory Change; Doyle — A Truth Maintenance System; de Kleer — An Assumption-based Truth Maintenance System | AGM distinguishes expansion, contraction, and revision; truth-maintenance systems record justifications and dependencies, retracting conclusions when assumptions fail. | Make revision operations explicit, preserve justification history, and support defeasible conclusions, assumption invalidation, and contradiction retention. | AGM is idealized and usually assumes a coherent belief set; TMS/ATMS can grow expensive and do not model psychology or trust automatically. | Adapt as versioned revision profiles and justification receipts; reject one universal rationality policy. |
| **evidence_and_provenance**<br>W3C PROV-DM: The PROV Data Model; W3C PROV-O: The PROV Ontology; NIST digital evidence and chain-of-custody guidance | PROV represents entities, activities, agents, generation, use, derivation, attribution, and association; chain-of-custody records custody transitions and integrity evidence. | Evidence needs independent identity, lineage, versioning, custody, authenticity and integrity state; provenance must be queryable and replayable. | Provenance establishes lineage, not truth, relevance, credibility, or evidentiary weight. | Adopt a compact PROV-like core and explicit custody events; reject provenance-as-credibility. |
| **uncertainty_models**<br>NIST Technical Note 1297 — Guidelines for Evaluating and Expressing the Uncertainty of NIST Measurement Results; Dempster — Upper and Lower Probabilities Induced by a Multivalued Mapping; Shafer — A Mathematical Theory of Evidence; Dubois and Prade — Possibility Theory; Walley — Statistical Reasoning with Imprecise Probabilities | Different traditions represent calibrated probability, intervals, belief/plausibility, possibility/necessity, qualitative confidence, or sets of distributions. | Use a tagged union and explicit comparison/conversion profiles; preserve ignorance, ambiguity, support, opposition, and imprecision. | The formalisms are not interchangeable, combination rules can be controversial, and precise calibration is often unavailable in authored fiction. | Adopt plural typed uncertainty; contain mathematical models in registered profiles; reject a universal 0–1 confidence field. |
| **sensor_fusion_and_observation**<br>Hall and Llinas — An Introduction to Multisensor Data Fusion; NIST metrology traceability and measurement uncertainty materials; Bar-Shalom and Fortmann — Tracking and Data Association | Observation systems model calibration, noise, false positives/negatives, occlusion, delayed measurements, data association, and fusion across sensors. | Separate raw interface output, interpreted observation, target association, calibration, delay, and fusion; preserve disagreement and unknown association. | Engineering sensor math is too narrow for fantasy senses, testimony, social perception, and symbolic divination. | Adapt the record boundaries and failure taxonomy; contain numerical filters in source/domain profiles. |
| **information_flow_security**<br>Denning — A Lattice Model of Secure Information Flow; Goguen and Meseguer — Security Policies and Security Models; NIST SP 800-53 and information-flow enforcement controls | Labels, compartments, noninterference, declassification, access control, and policy-enforced flows constrain what outputs may depend on secret inputs. | Use deny-by-default allowlists, purpose/audience labels, explicit declassification, noninterference testing, and side-channel threat modeling. | Strict noninterference can be impractical where intended gameplay reveals partial information; covert channels and semantic inference remain hard. | Adopt projection-level information-flow control and declassification; adapt to intentional partial revelation; reject blacklist-only security. |
| **distributed_systems_and_knowledge**<br>Lamport — Time, Clocks, and the Ordering of Events in a Distributed System; Chandy and Lamport — Distributed Snapshots; Halpern and Moses — Knowledge and Common Knowledge in a Distributed Environment | Happened-before and logical clocks capture causal order without a single global time; delayed/reordered messages yield local views; reliable common knowledge is limited by communication assumptions. | Separate event occurrence, send, delivery, observation, update, and narration times; preserve local state and stale beliefs; common knowledge certificates must state communication assumptions. | A single-process game runtime may not need vector clocks everywhere; network failure assumptions are not universal setting law. | Adopt logical-time and local-view concepts; use vector/causal metadata only where concurrency or distribution requires it. |
| **temporal_and_bitemporal_data**<br>Snodgrass — Developing Time-Oriented Database Applications in SQL; Jensen and Snodgrass — Temporal Data Management; SQL:2011 temporal database features | Valid time records when a statement applies in the modeled world; transaction time records when the database knew or stored it; as-of queries reconstruct historical versions and corrections. | Every fact and epistemic receipt needs effective/valid time and recorded/transaction time, plus logical causal time; repairs append rather than overwrite. | Bitemporal storage and queries increase schema and index complexity; future/counterfactual branches require additional timeline scope. | Adopt bitemporal records as core doctrine and add explicit timeline/world scope. |
| **cognitive_and_agent_memory**<br>Tulving — Episodic and Semantic Memory; Johnson, Hashtroudi, and Lindsay — Source Monitoring; Anderson and colleagues — ACT-R memory mechanisms | Research distinguishes episodic, semantic, working, and external memory; retrieval is cue-dependent; source monitoring can fail; memory is reconstructive and subject to forgetting and distortion. | Memory traces require kind, source attribution, accessibility, retrieval conditions, confidence, alteration lineage, and separation from event history. | Cognitive models are contested, population-dependent, and unsuitable as universal NPC psychology or exact forgetting formula. | Adapt boundaries and trace states only; defer full cognition and final memory psychology. |
| **testimony_rumor_and_reliability**<br>Daley and Kendall — Epidemics and Rumours; DeGroot — Reaching a Consensus; formal/computational trust and source-reliability literature | Rumor models track transmission and stifling; opinion models track social updating; trust systems distinguish source reputation, statement evidence, and network effects. | Use branch/retelling identity, audience and mutation history; treat source reliability as profile-specific evidence, not truth; official adoption and repetition affect belief opportunities only. | Population-level diffusion models flatten semantics, intent, power, institutions, and individual memory; trust scores invite circular authority. | Adapt lineage and propagation mechanics; defer social trust/reputation; reject global reliability scores and popularity-as-truth. |
| **deception_and_adversarial_information**<br>Liu, Ning, and Reiter — False Data Injection Attacks against State Estimation in Electric Power Grids; Goodfellow, Shlens, and Szegedy — Explaining and Harnessing Adversarial Examples; security literature on spoofing, impersonation, tamper evidence, and provenance attacks | Adversaries manipulate measurements, identities, inputs, provenance, or model perception while underlying state remains unchanged or separately affected. | Represent deception at the attacked interface/evidence/provenance layer, retain manipulation lineage, and require separate detection and belief-update paths. | Adversarial ML and cyberphysical attacks do not cover intention, omission, misleading truths, illusion metaphysics, or false memory by themselves. | Adapt the attack-surface and receipt model; combine with typed testimony/intent and source-local illusion rules. |
| **games_and_simulations**<br>Unreal Engine official AI Perception documentation; Unreal Engine official Blackboard/Behavior Tree documentation; official fog-of-war, visibility, and dialogue-condition documentation where available | Game engines typically separate sensory events, perception components, remembered stimuli/blackboards, line of sight, affiliations, and behavior conditions; quest/dialogue systems gate content on explicit variables. | Use event-driven observations and explicit blackboard-like projections, but keep the backend fact/belief/memory distinction and never treat AI working state as world truth. | Most game systems optimize one genre and use binary/short-lived perception, global quest flags, or designer-authored shortcuts; they do not solve contradictory beliefs or institutional knowledge. | Adapt event-driven and explicit-condition patterns; reject any single game’s fog-of-war or blackboard as universal epistemic law. |

The decisive synthesis is: use typed provenance and bitemporal records; explicit local views and causal delivery; profile-scoped, bounded inference and revision; plural uncertainty; finite group-knowledge certificates; and allowlisted information-flow projections. Reject perfect logical agents, universal probabilities, full possible-world materialization, provenance-as-credibility, popularity-as-truth, and model-owned inference.

## Part IV — Canonical terminology

The canonical terminology registry contains **147 terms** and **18 prohibited unqualified boundary terms** in `registries/canonical_terminology.yaml`. The following distinctions are binding:

```text
authoritative truth ≠ observation ≠ evidence ≠ testimony ≠ belief ≠ knowledge ≠ memory ≠ rumor ≠ public record ≠ model context
not observed ≠ observed false ≠ believed false ≠ proven false ≠ unresolved ≠ impossible
confidence ≠ probability ≠ truth ≠ evidence quality ≠ source reliability ≠ justification ≠ certainty
secret ≠ unknown ≠ unknowable ≠ undiscovered ≠ forgotten ≠ redacted ≠ encrypted ≠ classified ≠ source-local hidden
lie ≠ false statement made unknowingly ≠ mistake ≠ illusion ≠ forgery ≠ omission ≠ misleading truth ≠ false memory ≠ outdated information
player knows ≠ player character knows ≠ party knows ≠ organization knows ≠ model may receive ≠ backend truth owner records
```

### Prohibited without qualification at runtime boundaries

- **knows** — Must specify KnowledgeProfile, subject, proposition, basis, and time.
- **fact** — Must specify authoritative, historical, canon, campaign, source-local, or claimed fact.
- **truth** — Must specify truth domain, world/timeline scope, status, and as-of basis.
- **visible** — Must specify audience, purpose, projection kind, and basis.
- **hidden** — Must specify classification/concealment/unknown/undiscovered/unknowable/redacted distinction and owner.
- **evidence** — Must specify item identity, provenance, and relation profile.
- **proof** — Must specify proof/knowledge standard.
- **confidence** — Must specify uncertainty kind and profile.
- **certainty** — Must specify profile and semantics.
- **reliable** — Must specify domain, evaluator, evidence, and period.
- **public** — Must specify audience selector and delivery assumptions.
- **memory** — Must distinguish trace, access result, event history, transcript, and external record.
- **discovered** — Must specify observation/evidence/knowledge result; discovery is not truth.
- **identified** — Must specify classification, identity hypothesis, or certified identity profile.
- **common knowledge** — Must reference a CommonKnowledgeCertificate and assumptions.
- **lie** — Must establish speaker belief and intent under a deception profile.
- **omniscient** — Must specify source-local scope, knowledge profile, limitations, and truth access mechanism.
- **unknown** — Must specify whether truth unresolved, subject ignorant, record absent, interface failed, or disclosure unauthorized.

The complete definitions are normative in `registries/canonical_terminology.yaml`.

## Part V — Truth and proposition doctrine

### Federated proposition registry

Proposition schemas are registered by domain and source-local namespace. There is no ontology megafile. Each schema declares predicate identity, typed argument roles, allowed reference types, temporal scope grammar, world/timeline scope, polarity, bounded quantification, absence semantics, and canonical serialization. Open-ended donor statements first become candidate pressure records. They receive a direct/normalized mapping, source-local schema, quarantine, or doctrine escalation; they never become freeform runtime truth.

Future and counterfactual claims are proposition instances in explicit future/counterfactual contexts. They are not current authoritative facts. Hidden propositions remain normal propositions protected by secrecy/projection policy; secrecy is not encoded in the predicate name or identifier.

### Authoritative fact layer

- Truth statuses: `true`, `false`, `unresolved`, `indeterminate`, `inapplicable`.
- Default absence semantics: open world. Closed-world inference requires a registered completeness boundary, owner, version, and interval.
- Fact identity and proposition identity are stable across append-only versions.
- Every fact version records valid/effective time and transaction/recorded time, plus world, timeline, source transition, and supersession references.
- Administrative repair appends a correction. It never changes what was recorded or visible at an earlier checkpoint.
- Canon truth, campaign truth, historical truth, and source-local truth are separate scopes.
- Fact records prohibit observer, confidence, evidence-weight, belief, memory, and model-context fields.
## Part VI — Observer and epistemic-subject architecture

An `EpistemicSubjectReference` identifies an actor, player interface recipient, party, organization, office, institution, collective, swarm, AI, spirit, proxy manifestation, public audience, or model projection target. Individual in-world subjects normally reference AFQR-08 identities; bounded aggregates may be epistemic-only subjects with explicit membership/audience selectors.

Body, mind, memory, persona, office, institution, collective, and manifestation are not silently equivalent. Proxy observation, copied minds, fusion/fission, possession, resurrection, office succession, and archive continuity route first through AFQR-08 and AFQR-09. A model projection target is not an in-world knower unless a source-local system explicitly instantiates one as an actor.

## Part VII — Observation and evidence architecture

Observation records what an interface produced, not what is true. Interfaces include ordinary senses, sensors, scans, documents, archives, witnesses, languages, translation, telepathy, shared senses, AI fusion, divination, and retrocognition. Each interface is registered, typed, versioned, pure, bounded, and explicit about calibration, uncertainty, occlusion, manipulation, delay, and source-local law.

Evidence has independent identity and provenance. Authenticity, integrity, chain of custody, relevance, source reliability, evidentiary strength, and conclusion are separate. Evidence relations are typed as support, opposition, qualification, context, or irrelevance under a named inference profile. Copying or destroying evidence changes availability/custody; historical identity and provenance remain.

Testimony separates speaker, content, speaker belief where known, intent where relevant, language, translation, channel, intended and actual recipients, delivery status, interception/alteration, time, authority, and visibility. A false statement is a lie only under a registered deception profile that establishes speaker belief and intent.

## Part VIII — Belief and knowledge architecture

Beliefs are observer-owned entries. They may be true or false, accepted or rejected, suspected or doubted, role-scoped, outdated, contradictory, source-misattributed, or suspended. The runtime does not compute full logical closure and does not select a belief because it was newest or repeated. `BeliefAlternativeSet` stores bounded competing hypotheses without materializing complete possible worlds.

Knowledge is never a universal Boolean. Every authoritative check names a `KnowledgeProfile`, such as direct observation, backend certification, institutional certification, legal notice, practical operational knowledge, source-local revelation, public knowledge, shared knowledge, distributed knowledge, common knowledge, or knowledge of ignorance.

Uncertainty is the tagged union `categorical | ordinal | exact_probability | probability_interval | weighted_alternatives | support_opposition | possibility_set | assurance_class | source_local | unquantified`. Unlike kinds are incomparable unless a registered conversion/comparison profile exists. Projections may deliberately coarsen precision to prevent leakage.

## Part IX — Inference and belief revision

Inference profiles are registered, deterministic, versioned, pure, bounded, typed, source-scoped, replayable, and prohibited from calling models or mutating state. Deduction, defeasible inference, abduction, probabilistic update, classification, pattern recognition, source-local revelation, and memory retrieval remain distinct.

Inference applications produce candidate outputs and receipts. Only the subject owner may prepare a belief mutation. Missing profiles return `unresolved`; incomparable or conflicting profiles coexist. File order, source frequency, donor popularity, model confidence, and graph proximity are never precedence.

Revision operations are explicit: expansion, contraction, revision, suspension, contradiction retention, source re-evaluation, evidence invalidation, forgery discovery, memory correction, institutional correction, supersession, and refusal. An observer need not be rational or willing to update.

## Part X — Memory architecture

A `MemoryTrace` is subject-owned encoded content with origin references, kind, encoding time, accessibility, retrieval conditions, consolidation, decay, alteration lineage, source attribution, confidence, external-store links, and copied/implanted lineage. Episodic, semantic, working, and external memory are distinct.

Accurate, partial, reconstructed, altered, false, implanted, copied, decayed, inaccessible, erased, and source-misattributed states are representable. A transcript, event log, observation, or fact does not become memory automatically. Forgetting, failed retrieval, inaccessibility, erasure, and loss of external access are separate transitions. Restoration never rewrites the originating event.

## Part XI — Secrecy, disclosure, and information flow

Secrecy has an owner, classification, compartments, need-to-know policy, existence visibility, encryption/encoding state, source-local constraints, and governed obligations. Secret, unknown, unknowable, undiscovered, forgotten, redacted, encrypted, and classified are not aliases.

Disclosure is a transition with authority, source, recipient selector, content projection, scope, timing, redaction, delivery, interception, and visibility. Publication, notification, private revelation, declassification, and accidental disclosure are distinct. Disclosure creates an epistemic opportunity; it does not itself establish reading, belief, knowledge, public reach, common knowledge, or truth.

### Side-channel law

Visible and model packets use deny-by-default allowlists, opaque audience-scoped tokens, constant-shape or shape-normalized envelopes, hidden-independent option order/count, stable generic blocker classes, timing normalization/buckets, separate private and visible hashes, precision coarsening, and cross-packet noninterference tests. Blacklists remain defense-in-depth only.

## Part XII — Deception and rumor

Deception acts on claims, presentation, interfaces, signals, observations, evidence, provenance, source attribution, visibility, or—through separately authorized memory operations—memory traces. It never directly changes truth or forces target belief. The system distinguishes false assertion, lie, mistake, omission, misdirection, misleading truth, disguise, impersonation, illusion, hallucination, forgery, fabricated evidence, tampering, spoofing, false trail, propaganda, misinformation, and disinformation.

Rumors have identity, proposition content, source chain, branches, variants, retellings, mutation/merge history, audience, confidence expression, source attribution, corroboration, suppression, correction, institutional adoption, retraction, and visibility. Repetition, popularity, suppression, correction, and official status can affect transmission or beliefs but not authoritative truth.

## Part XIII — Group and common knowledge

The architecture separates personal knowledge, shared knowledge, distributed knowledge, institutional knowledge, collective memory, role access, public information, common belief, and common knowledge. An institution may preserve records after all members change; a member can know something the institution does not record; a role can have access without the occupant having read; an institution can publish a claim it rejects internally.

Common knowledge is represented by a finite `CommonKnowledgeCertificate` containing audience selector, proposition, creation event, profile, communication/reach assumptions, validity interval, exceptions, and revocation. No infinite nested knowledge statements are materialized.

## Part XIV — Context-packet boundary

```text
backend truth
  -> private owner receipts
  -> observer eligibility and observations
  -> evidence/testimony/communications
  -> observer belief and accessible memory
  -> player/actor/public visible projections
  -> purpose-specific narration/dialogue/summary packet
  -> model output proposal or narration
```

The packet compiler performs projection only. It does not infer missing beliefs, assume memory from transcripts, merge player and character knowledge, borrow clues from other audiences, resolve contradictions, or expose raw truth. A packet must identify intended audience, model purpose, actor/dialogue subject, visible beliefs and uncertainty, accessible memory/evidence, allowed and forbidden inferences, state basis, compiler/profile versions, and deterministic packet hash. Model output has no authority to create facts, observations, beliefs, memories, disclosures, or consequences.

## Part XV — Typed contracts

The normative catalog defines **36 contracts** in `contracts/afqr_10_typed_contract_catalog.yaml`. Every contract specifies required, optional, hidden, derived, and prohibited fields; owner route; times; profile versions; state basis; hashes; and AFQR handoffs.

| Contract | Owner route | Essential distinction |
|---|---|---|
| `PropositionDefinition` | `proposition_registry_owner` | Defines a predicate grammar; it does not assert truth. |
| `PropositionInstance` | `proposition_registry_owner` | Canonical proposition token shared by facts, evidence, beliefs, testimony, and rumor. |
| `AuthoritativeFactRecord` | `truth_domain_owner` | Owns authoritative truth only; observer state is forbidden. |
| `TruthDomainDefinition` | `truth_domain_registry_owner` | Typed owner-controlled AFQR-10 record. |
| `EpistemicSubjectReference` | `epistemic_subject_registry_owner` | Typed owner-controlled AFQR-10 record. |
| `ObservationInterfaceDefinition` | `observation_interface_registry_owner` | Typed owner-controlled AFQR-10 record. |
| `ObservationRecord` | `observation_owner` | Typed owner-controlled AFQR-10 record. |
| `EvidenceItem` | `evidence_owner` | Typed owner-controlled AFQR-10 record. |
| `EvidenceRelation` | `evidence_relation_owner` | Typed owner-controlled AFQR-10 record. |
| `TestimonyRecord` | `testimony_owner` | Typed owner-controlled AFQR-10 record. |
| `CommunicationDeliveryRecord` | `communication_owner` | Typed owner-controlled AFQR-10 record. |
| `BeliefStateEntry` | `epistemic_subject_owner` | Typed owner-controlled AFQR-10 record. |
| `BeliefAlternativeSet` | `epistemic_subject_owner` | Typed owner-controlled AFQR-10 record. |
| `KnowledgeProfile` | `knowledge_profile_registry_owner` | Typed owner-controlled AFQR-10 record. |
| `KnowledgeDetermination` | `knowledge_determination_owner` | Typed owner-controlled AFQR-10 record. |
| `UncertaintyValue` | `uncertainty_registry_owner` | Tagged union: categorical, ordinal, exact_probability, probability_interval, weighted_alternatives, support_opposition, possibility_set, assurance_class, source_local, unquantified. |
| `InferenceProfile` | `inference_registry_owner` | Typed owner-controlled AFQR-10 record. |
| `InferenceApplicationReceipt` | `inference_coordinator_owner` | Typed owner-controlled AFQR-10 record. |
| `BeliefRevisionPolicy` | `belief_revision_registry_owner` | Typed owner-controlled AFQR-10 record. |
| `BeliefRevisionReceipt` | `epistemic_subject_owner` | Typed owner-controlled AFQR-10 record. |
| `MemoryTrace` | `memory_owner` | Typed owner-controlled AFQR-10 record. |
| `MemoryAccessResult` | `memory_owner` | Typed owner-controlled AFQR-10 record. |
| `DisclosurePolicy` | `disclosure_registry_owner` | Typed owner-controlled AFQR-10 record. |
| `DisclosureTransition` | `disclosure_owner` | Typed owner-controlled AFQR-10 record. |
| `SecrecyClassification` | `secrecy_owner` | Typed owner-controlled AFQR-10 record. |
| `DeceptionActionDeclaration` | `deception_action_owner` | Typed owner-controlled AFQR-10 record. |
| `DeceptionOutcomeReceipt` | `deception_outcome_owner` | Typed owner-controlled AFQR-10 record. |
| `RumorRecord` | `rumor_owner` | Typed owner-controlled AFQR-10 record. |
| `RumorTransmissionRecord` | `rumor_owner` | Typed owner-controlled AFQR-10 record. |
| `GroupKnowledgeRecord` | `group_epistemic_owner` | Typed owner-controlled AFQR-10 record. |
| `CommonKnowledgeCertificate` | `common_knowledge_owner` | Typed owner-controlled AFQR-10 record. |
| `EpistemicDiscoveryReceipt` | `epistemic_coordinator_owner` | Typed owner-controlled AFQR-10 record. |
| `PrivateEpistemicReceipt` | `private_receipt_owner` | Typed owner-controlled AFQR-10 record. |
| `VisibleEpistemicProjection` | `projection_owner` | Typed owner-controlled AFQR-10 record. |
| `ModelContextEpistemicProjection` | `context_packet_owner` | Typed owner-controlled AFQR-10 record. |
| `AFQR10Handoff` | `afqr_handoff_owner` | Typed owner-controlled AFQR-10 record. |

Common contract law: effective time, recorded time, and logical time are distinct; hashes prove byte identity/linkage rather than truth; evaluators are pure; only declared owners prepare AFQR-01 fragments; private and visible serializers are independently canonicalized.

## Part XVI — Determination and update pipeline

```text
world event or information action
→ truth-state evaluation
→ observer/interface eligibility
→ observation generation
→ evidence registration
→ testimony or communication delivery
→ observer-specific interpretation
→ inference-profile application
→ belief-update candidate
→ contradiction and revision evaluation
→ memory-encoding candidate
→ disclosure and visibility projection
→ owner-fragment preparation
→ AFQR-01 commitment
→ context-packet projection
→ replay receipt
```

All stages before owner-fragment preparation are non-mutating. AFQR-06 is invoked only for typed authoritative claim conflicts defined by a domain, not ordinary belief disagreement. AFQR-07 handles explicit storage, bandwidth, credentials, copying costs, or sale, never generic confidence. AFQR-08 resolves identity references and continuity. AFQR-09 resolves notice, access, roles, obligations, secrecy duties, and relation effectiveness. Player confirmation is needed only when an action/command changes declared method, authorizes a disclosure, accepts a risk/cost, or uses a player-authored claim path under AFQR-02/03. Lawful indeterminacy halts at the relevant stage and returns `truth unresolved`, `observation inconclusive`, `knowledge not established`, or `disclosure unauthorized`.

## Part XVII — Operation grammar

The normative operation grammar contains all **90 required operations** in `operations/afqr_10_operation_grammar.yaml`. Each operation defines truth effect, owner routes, candidate records, uncertainty, failure semantics, hidden-information rules, commit rules, replay, and AFQR handoffs.

OP-01. **ordinary visual observation** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-02. **hearing a sound** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-03. **sensing a hidden entity** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-04. **scanning an object** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-05. **identifying an item** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-06. **assessing an opponent** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-07. **investigating a scene** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-08. **searching an archive** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-09. **recalling a memory** — Change only memory-owner accessibility/content lineage; originating facts, events, observations, and earlier receipts remain immutable.
OP-10. **researching a topic** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-11. **asking a witness** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-12. **receiving testimony** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-13. **receiving translated testimony** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-14. **reading a document** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-15. **reading a forged document** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-16. **reading an outdated map** — The map remains an evidence/document claim with valid-time scope; updating it changes the map record and possibly beliefs, never terrain truth.
OP-17. **updating a map** — The map remains an evidence/document claim with valid-time scope; updating it changes the map record and possibly beliefs, never terrain truth.
OP-18. **publishing a notice** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-19. **privately disclosing a secret** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-20. **public announcement** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-21. **intercepted message** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-22. **altered message** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-23. **delayed message** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-24. **lost message** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-25. **encrypted message** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-26. **failed decryption** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-27. **disguise** — The operation changes presented interfaces, signals, evidence, or attribution; it does not change underlying identity or world truth and does not force a belief.
OP-28. **impersonation** — The operation changes presented interfaces, signals, evidence, or attribution; it does not change underlying identity or world truth and does not force a belief.
OP-29. **illusion** — The operation changes presented interfaces, signals, evidence, or attribution; it does not change underlying identity or world truth and does not force a belief.
OP-30. **hallucination** — The operation changes presented interfaces, signals, evidence, or attribution; it does not change underlying identity or world truth and does not force a belief.
OP-31. **false sensory signal** — The operation changes presented interfaces, signals, evidence, or attribution; it does not change underlying identity or world truth and does not force a belief.
OP-32. **lie** — Create testimony/deception records according to speaker belief and intent; target belief changes require a separate registered update policy.
OP-33. **honest mistake** — Create testimony/deception records according to speaker belief and intent; target belief changes require a separate registered update policy.
OP-34. **omission** — Create testimony/deception records according to speaker belief and intent; target belief changes require a separate registered update policy.
OP-35. **misleading truth** — Create testimony/deception records according to speaker belief and intent; target belief changes require a separate registered update policy.
OP-36. **planted evidence** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-37. **forged evidence** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-38. **evidence tampering** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-39. **evidence destruction** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-40. **evidence duplication** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-41. **rumor creation** — Create or revise a rumor branch/transmission; repetition, adoption, suppression, and correction do not directly set truth or recipient belief.
OP-42. **rumor retelling** — Create or revise a rumor branch/transmission; repetition, adoption, suppression, and correction do not directly set truth or recipient belief.
OP-43. **rumor mutation** — Create or revise a rumor branch/transmission; repetition, adoption, suppression, and correction do not directly set truth or recipient belief.
OP-44. **rumor correction** — Create or revise a rumor branch/transmission; repetition, adoption, suppression, and correction do not directly set truth or recipient belief.
OP-45. **institutional record creation** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-46. **institutional retraction** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-47. **secret identity discovery** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-48. **hidden body-swap discovery** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-49. **clone discovery** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-50. **possession discovery** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-51. **memory erasure** — Change only memory-owner accessibility/content lineage; originating facts, events, observations, and earlier receipts remain immutable.
OP-52. **memory implantation** — Change only memory-owner accessibility/content lineage; originating facts, events, observations, and earlier receipts remain immutable.
OP-53. **memory copy** — Change only memory-owner accessibility/content lineage; originating facts, events, observations, and earlier receipts remain immutable.
OP-54. **memory restoration** — Change only memory-owner accessibility/content lineage; originating facts, events, observations, and earlier receipts remain immutable.
OP-55. **memory-source correction** — Change only memory-owner accessibility/content lineage; originating facts, events, observations, and earlier receipts remain immutable.
OP-56. **telepathy** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-57. **shared sensory link** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-58. **hive-mind knowledge** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-59. **collective memory** — Change only memory-owner accessibility/content lineage; originating facts, events, observations, and earlier receipts remain immutable.
OP-60. **public common-knowledge event** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-61. **private group disclosure** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-62. **divination** — Contain the mechanism in a registered source-local observation/inference profile; output may be exact, symbolic, probabilistic, blocked, false, or unresolved without universalizing its metaphysics.
OP-63. **prophecy** — Contain the mechanism in a registered source-local observation/inference profile; output may be exact, symbolic, probabilistic, blocked, false, or unresolved without universalizing its metaphysics.
OP-64. **source-local omniscience claim** — Contain the mechanism in a registered source-local observation/inference profile; output may be exact, symbolic, probabilistic, blocked, false, or unresolved without universalizing its metaphysics.
OP-65. **retrocognition** — Contain the mechanism in a registered source-local observation/inference profile; output may be exact, symbolic, probabilistic, blocked, false, or unresolved without universalizing its metaphysics.
OP-66. **future prediction** — Contain the mechanism in a registered source-local observation/inference profile; output may be exact, symbolic, probabilistic, blocked, false, or unresolved without universalizing its metaphysics.
OP-67. **time-travel information** — Contain the mechanism in a registered source-local observation/inference profile; output may be exact, symbolic, probabilistic, blocked, false, or unresolved without universalizing its metaphysics.
OP-68. **cross-timeline message** — Contain the mechanism in a registered source-local observation/inference profile; output may be exact, symbolic, probabilistic, blocked, false, or unresolved without universalizing its metaphysics.
OP-69. **dream or vision** — Contain the mechanism in a registered source-local observation/inference profile; output may be exact, symbolic, probabilistic, blocked, false, or unresolved without universalizing its metaphysics.
OP-70. **AI sensor fusion** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-71. **distributed AI knowledge** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-72. **knowledge stolen from a database** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-73. **knowledge sold** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-74. **secret copied without source loss** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-75. **classified record declassified** — Generate typed candidate records under the active profile; truth, belief, memory, disclosure, and model projections remain separately owned.
OP-76. **observer forgets a fact** — Change only memory-owner accessibility/content lineage; originating facts, events, observations, and earlier receipts remain immutable.
OP-77. **observer loses access to external memory** — Change only memory-owner accessibility/content lineage; originating facts, events, observations, and earlier receipts remain immutable.
OP-78. **actor dies** — Apply AFQR-08 continuity and AFQR-09 relation policies first; epistemic inheritance, archive access, and copied memories are explicit, never automatic.
OP-79. **actor is resurrected** — Apply AFQR-08 continuity and AFQR-09 relation policies first; epistemic inheritance, archive access, and copied memories are explicit, never automatic.
OP-80. **actor is copied** — Apply AFQR-08 continuity and AFQR-09 relation policies first; epistemic inheritance, archive access, and copied memories are explicit, never automatic.
OP-81. **actor fuses** — Apply AFQR-08 continuity and AFQR-09 relation policies first; epistemic inheritance, archive access, and copied memories are explicit, never automatic.
OP-82. **actor fissions** — Apply AFQR-08 continuity and AFQR-09 relation policies first; epistemic inheritance, archive access, and copied memories are explicit, never automatic.
OP-83. **office changes occupant** — Apply AFQR-08 continuity and AFQR-09 relation policies first; epistemic inheritance, archive access, and copied memories are explicit, never automatic.
OP-84. **organization loses all members** — Apply AFQR-08 continuity and AFQR-09 relation policies first; epistemic inheritance, archive access, and copied memories are explicit, never automatic.
OP-85. **institution preserves archives** — Apply AFQR-08 continuity and AFQR-09 relation policies first; epistemic inheritance, archive access, and copied memories are explicit, never automatic.
OP-86. **belief becomes outdated because world truth changes** — Record the truth-owner change and observer belief revision as separate transitions; outdated belief may persist and historical knowledge is not rewritten.
OP-87. **evidence is later disproven** — Record the truth-owner change and observer belief revision as separate transitions; outdated belief may persist and historical knowledge is not rewritten.
OP-88. **source is exposed as unreliable** — Record the truth-owner change and observer belief revision as separate transitions; outdated belief may persist and historical knowledge is not rewritten.
OP-89. **two reliable sources conflict** — Record the truth-owner change and observer belief revision as separate transitions; outdated belief may persist and historical knowledge is not rewritten.
OP-90. **backend truth remains unresolved** — Emit unresolved AuthoritativeFactRecord status; no observation, inference, or popularity may strengthen it without a registered truth-owner transition.

## Part XVIII — Central stress case

The complete typed graph is `fixtures/concealed_familiar_network_typed_graph.yaml`. Its decisive structure is:

```text
world truth: M1 is derivative proxy; F0 is elsewhere; restriction R7 suspended grant
  ├─ independent notice state: S1 has not received notice
  ├─ independent identity graph: F0 / M1 / derivatives / later autonomous M1
  ├─ observations: public familiar-like shape; partial marker; symbolic divination
  ├─ evidence: marker; incorrect official record; disputed archive; mistranslation
  ├─ testimony: honest incorrect official identification; translated witness statement
  ├─ rumor branch: rival’s illegal-clone disinformation, persistent after retraction
  ├─ beliefs: public, marker witness, investigator alternatives, signer active-grant belief
  ├─ memory: selected proxy/shared traces; witness memories; later revisions
  ├─ institution: official retraction and restricted archive
  ├─ player/PC boundary: Player P knows F0 location; PC does not
  └─ model projections: audience-specific, no cross-packet clue combination
```

Authoritative suspension and notice are separate. Official identification is an institutional claim, not truth. The illusion affects marker observation, not proxy identity. The archive is evidence with disputed authenticity. Divination yields symbolic evidence under a source-local profile. The proxy’s copied/shared memories do not establish identity, and autonomy appends an AFQR-08/09 transition. Retraction changes the official record and offers public belief-revision evidence; it does not erase rumor branches or historical belief receipts. Common knowledge is not established merely because the official published and later retracted a statement. Replay preserves each truth, observation, evidence, delivery, belief, memory, disclosure, packet, profile, and time basis.

## Part XIX — Candidate comparison

Scores use 1–5 across twenty dimensions; maximum 100. Higher `authoring_burden_inverse` and `testing_burden_inverse` means lower burden.

| Candidate | Score | Disposition | Central failure or use |
|---|---:|---|---|
| A_Global_truth_table_plus_visibility_flags | 57/100 | `rejected_as_universal` | Good small-slice truth visibility; cannot represent false belief, memory, evidence, or institutions. |
| B_Per_observer_fact_sets | 60/100 | `rejected_as_universal` | Better false belief support; conflates knowledge/belief and loses provenance and revision. |
| C_Probabilistic_belief_state | 59/100 | `rejected_as_universal` | Useful optional uncertainty profile; universal use overburdens authors and misrepresents qualitative/magical certainty. |
| D_Event_log_derived_knowledge | 57/100 | `component_adopted` | Useful replay substrate; cannot derive forgetting, false belief, hidden evidence, or stale information by itself. |
| E_Evidence_and_justification_graph | 83/100 | `component_adopted` | Adopted as a major component; insufficient alone for truth ownership, memory, disclosure, and group knowledge. |
| F_BDI_or_cognitive_agent_state | 53/100 | `rejected_as_universal` | Useful later cognition layer; overreaches AFQR-10 and entangles desire/intention with epistemic authority. |
| G_Possible_world_epistemic_model | 67/100 | `component_adopted` | Useful bounded alternative-set concepts and formal group vocabulary; full runtime materialization explodes combinatorially. |
| H_Typed_hybrid_TTEP_PRV | 92/100 | `selected` | Selected; composes truth, evidence, belief, memory, information flow, group knowledge, and replay with scoped profiles. |

## Part XX — Adversarial evaluation

The normative adversarial registry `evaluation/afqr_10_adversarial_scenarios_A_FZ.yaml` contains **182 distinct dispositions**, A through FZ. Every entry records the authoritative proposition/fact, subject, interface, evidence, communication, uncertainty, belief update, knowledge profile, memory, secrecy, deception, logical/effective/recorded time, private receipt, visible projection, model projection, handoffs, and final lawful disposition.

- **A — A fact is true but no observer has detected it.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario A specifically records: A fact is true but no observer has detected it.
- **B — A fact is false but widely believed.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario B specifically records: A fact is false but widely believed.
- **C — The backend has insufficient doctrine to determine truth.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario C specifically records: The backend has insufficient doctrine to determine truth.
- **D — A closed-world registry omits an entity.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario D specifically records: A closed-world registry omits an entity.
- **E — An open-world domain contains no record.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario E specifically records: An open-world domain contains no record.
- **F — A negative fact is directly established.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario F specifically records: A negative fact is directly established.
- **G — A proposition was true yesterday and false today.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario G specifically records: A proposition was true yesterday and false today.
- **H — A source-local law makes the proposition inapplicable.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario H specifically records: A source-local law makes the proposition inapplicable.
- **I — Two timelines contain different truth values.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario I specifically records: Two timelines contain different truth values.
- **J — An administrator repairs an omitted historical fact.** `truth and absence`: Apply the registered truth-domain absence and bitemporal policy. Record a fact version, explicit absence, unresolved/inapplicable status, timeline-scoped value, or administrative repair; never infer observer knowledge. Scenario J specifically records: An administrator repairs an omitted historical fact.
- **K — An actor sees an unobstructed target.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario K specifically records: An actor sees an unobstructed target.
- **L — Darkness produces no observation.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario L specifically records: Darkness produces no observation.
- **M — Darkness produces a mistaken silhouette.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario M specifically records: Darkness produces a mistaken silhouette.
- **N — A sensor gives a false positive.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario N specifically records: A sensor gives a false positive.
- **O — A sensor gives a false negative.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario O specifically records: A sensor gives a false negative.
- **P — Two sensors disagree.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario P specifically records: Two sensors disagree.
- **Q — A sensor is miscalibrated.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario Q specifically records: A sensor is miscalibrated.
- **R — A signal arrives late.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario R specifically records: A signal arrives late.
- **S — An observer sees only part of an event.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario S specifically records: An observer sees only part of an event.
- **T — A witness observes the effect but not the cause.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario T specifically records: A witness observes the effect but not the cause.
- **U — A swarm’s members observe different fragments.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario U specifically records: A swarm’s members observe different fragments.
- **V — A collective fuses several observations.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario V specifically records: A collective fuses several observations.
- **W — A body observes while a possessing mind interprets.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario W specifically records: A body observes while a possessing mind interprets.
- **X — A proxy observes for its source.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario X specifically records: A proxy observes for its source.
- **Y — A recording device observes without a current viewer.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario Y specifically records: A recording device observes without a current viewer.
- **Z — A destroyed sensor’s earlier record survives.** `perception`: Create an immutable ObservationRecord for the interface output, including partial/noisy/delayed/calibration/occlusion state. Any evidence or belief update is separate; no observation rewrites truth. Scenario Z specifically records: A destroyed sensor’s earlier record survives.
- **AA — One clue supports two hypotheses.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AA specifically records: One clue supports two hypotheses.
- **AB — Several weak clues jointly support one hypothesis.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AB specifically records: Several weak clues jointly support one hypothesis.
- **AC — Evidence supports and opposes the same proposition.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AC specifically records: Evidence supports and opposes the same proposition.
- **AD — Evidence is authentic but irrelevant.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AD specifically records: Evidence is authentic but irrelevant.
- **AE — Evidence is relevant but of unknown authenticity.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AE specifically records: Evidence is relevant but of unknown authenticity.
- **AF — Evidence has a broken chain of custody.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AF specifically records: Evidence has a broken chain of custody.
- **AG — Evidence was copied exactly.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AG specifically records: Evidence was copied exactly.
- **AH — The original evidence was destroyed.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AH specifically records: The original evidence was destroyed.
- **AI — The evidence was altered after collection.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AI specifically records: The evidence was altered after collection.
- **AJ — The alteration is later detected.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AJ specifically records: The alteration is later detected.
- **AK — A registered deductive inference applies.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AK specifically records: A registered deductive inference applies.
- **AL — A defeasible inference is defeated by an exception.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AL specifically records: A defeasible inference is defeated by an exception.
- **AM — An abductive inference proposes several causes.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AM specifically records: An abductive inference proposes several causes.
- **AN — No inference profile applies.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AN specifically records: No inference profile applies.
- **AO — Two inference profiles produce incompatible conclusions.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AO specifically records: Two inference profiles produce incompatible conclusions.
- **AP — A source-local revelation rule conflicts with ordinary evidence.** `evidence and inference`: Preserve EvidenceItem identity, provenance, authenticity, relevance, custody, and opposing/supporting relations. Apply only registered bounded inference; incompatible or missing profiles return unresolved. Scenario AP specifically records: A source-local revelation rule conflicts with ordinary evidence.
- **AQ — An observer accepts two contradictory claims.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AQ specifically records: An observer accepts two contradictory claims.
- **AR — An observer knows the claims conflict.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AR specifically records: An observer knows the claims conflict.
- **AS — An observer does not recognize the conflict.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AS specifically records: An observer does not recognize the conflict.
- **AT — New evidence causes revision.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AT specifically records: New evidence causes revision.
- **AU — New evidence is ignored due to actor-specific policy.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AU specifically records: New evidence is ignored due to actor-specific policy.
- **AV — A character retains a false belief after official correction.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AV specifically records: A character retains a false belief after official correction.
- **AW — A character suspends judgment.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AW specifically records: A character suspends judgment.
- **AX — A character rejects a true proposition.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AX specifically records: A character rejects a true proposition.
- **AY — A character believes a proposition for the wrong reason.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AY specifically records: A character believes a proposition for the wrong reason.
- **AZ — The same actor has different role-scoped beliefs.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario AZ specifically records: The same actor has different role-scoped beliefs.
- **BA — A copied mind begins with copied beliefs.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario BA specifically records: A copied mind begins with copied beliefs.
- **BB — The two copies later revise differently.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario BB specifically records: The two copies later revise differently.
- **BC — A fused mind retains conflicting predecessor beliefs.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario BC specifically records: A fused mind retains conflicting predecessor beliefs.
- **BD — A fission produces two memories of one earlier event.** `belief and contradiction`: Store observer-owned stances and alternatives without global logical closure. Revision, refusal, suspension, contradiction recognition, copy/fusion/fission lineage, and later divergence receive append-only receipts. Scenario BD specifically records: A fission produces two memories of one earlier event.
- **BE — A truthful witness reports accurately.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BE specifically records: A truthful witness reports accurately.
- **BF — A truthful witness is mistaken.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BF specifically records: A truthful witness is mistaken.
- **BG — A witness lies knowingly.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BG specifically records: A witness lies knowingly.
- **BH — A witness omits a crucial detail.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BH specifically records: A witness omits a crucial detail.
- **BI — A witness states a misleading truth.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BI specifically records: A witness states a misleading truth.
- **BJ — A statement is translated accurately.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BJ specifically records: A statement is translated accurately.
- **BK — A translation loses ambiguity.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BK specifically records: A translation loses ambiguity.
- **BL — A translation reverses one relation.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BL specifically records: A translation reverses one relation.
- **BM — A message is intercepted.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BM specifically records: A message is intercepted.
- **BN — A message is altered in transit.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BN specifically records: A message is altered in transit.
- **BO — A message arrives after the recipient acts.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BO specifically records: A message arrives after the recipient acts.
- **BP — A message is delivered to a role rather than a person.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BP specifically records: A message is delivered to a role rather than a person.
- **BQ — The office changes occupant before delivery.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BQ specifically records: The office changes occupant before delivery.
- **BR — A public announcement reaches only part of the population.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BR specifically records: A public announcement reaches only part of the population.
- **BS — A telepathic broadcast reaches several minds.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BS specifically records: A telepathic broadcast reaches several minds.
- **BT — One recipient resists or blocks the broadcast.** `testimony and communication`: Separate statement content, speaker belief/intent, translation, channel, intended/actual recipients, delivery time, interception, alteration, and reading. Delivery does not imply awareness or belief. Scenario BT specifically records: One recipient resists or blocks the broadcast.
- **BU — A disguise changes appearance only.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario BU specifically records: A disguise changes appearance only.
- **BV — A disguise includes forged credentials.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario BV specifically records: A disguise includes forged credentials.
- **BW — An impersonator uses a stolen access token.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario BW specifically records: An impersonator uses a stolen access token.
- **BX — An illusion creates a false visual observation.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario BX specifically records: An illusion creates a false visual observation.
- **BY — The illusion is real energy but misrepresents identity.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario BY specifically records: The illusion is real energy but misrepresents identity.
- **BZ — A planted clue is authentic material placed deceptively.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario BZ specifically records: A planted clue is authentic material placed deceptively.
- **CA — A forged clue is fabricated.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario CA specifically records: A forged clue is fabricated.
- **CB — A true clue is presented with false provenance.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario CB specifically records: A true clue is presented with false provenance.
- **CC — An actor deliberately omits an alternative explanation.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario CC specifically records: An actor deliberately omits an alternative explanation.
- **CD — A source speaks a technically true but misleading statement.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario CD specifically records: A source speaks a technically true but misleading statement.
- **CE — Coordinated sources repeat the same falsehood.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario CE specifically records: Coordinated sources repeat the same falsehood.
- **CF — Repetition increases social acceptance but not truth.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario CF specifically records: Repetition increases social acceptance but not truth.
- **CG — A model-generated narration accidentally implies a hidden fact.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario CG specifically records: A model-generated narration accidentally implies a hidden fact.
- **CH — A model confidently states a false in-world claim.** `deception`: Represent the deceptive action and its effects on presentation, observations, evidence, provenance, or testimony. Do not alter truth or force target belief; model errors are rejected as authority and logged as boundary failures. Scenario CH specifically records: A model confidently states a false in-world claim.
- **CI — A rumor begins from one mistaken witness.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CI specifically records: A rumor begins from one mistaken witness.
- **CJ — The rumor is retold accurately.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CJ specifically records: The rumor is retold accurately.
- **CK — The rumor mutates during retelling.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CK specifically records: The rumor mutates during retelling.
- **CL — Two rumor branches merge.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CL specifically records: Two rumor branches merge.
- **CM — An official institution adopts the rumor.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CM specifically records: An official institution adopts the rumor.
- **CN — The institution later retracts it.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CN specifically records: The institution later retracts it.
- **CO — The public continues to believe it.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CO specifically records: The public continues to believe it.
- **CP — The rumor contains a hidden true component.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CP specifically records: The rumor contains a hidden true component.
- **CQ — A rumor is suppressed.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CQ specifically records: A rumor is suppressed.
- **CR — Suppression increases interest.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CR specifically records: Suppression increases interest.
- **CS — A rumor reaches an organization but not all members.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CS specifically records: A rumor reaches an organization but not all members.
- **CT — Everyone knows the rumor, but nobody knows that everyone knows.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CT specifically records: Everyone knows the rumor, but nobody knows that everyone knows.
- **CU — A public ritual creates common knowledge under a source-local rule.** `rumor and public information`: Maintain rumor identity, branches, retellings, mutation, adoption, suppression, correction, audience, and public/institutional projections. Popularity and official use do not establish truth or erase persistent belief. Scenario CU specifically records: A public ritual creates common knowledge under a source-local rule.
- **CV — A character accurately recalls an event.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario CV specifically records: A character accurately recalls an event.
- **CW — A character forgets a detail.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario CW specifically records: A character forgets a detail.
- **CX — A character remembers the event incorrectly.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario CX specifically records: A character remembers the event incorrectly.
- **CY — A character remembers content but misattributes the source.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario CY specifically records: A character remembers content but misattributes the source.
- **CZ — A memory is copied to another actor.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario CZ specifically records: A memory is copied to another actor.
- **DA — A memory is implanted.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario DA specifically records: A memory is implanted.
- **DB — A memory is erased.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario DB specifically records: A memory is erased.
- **DC — A memory becomes inaccessible but still exists.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario DC specifically records: A memory becomes inaccessible but still exists.
- **DD — An external journal restores lost information.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario DD specifically records: An external journal restores lost information.
- **DE — The journal is forged.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario DE specifically records: The journal is forged.
- **DF — A restored backup overwrites later memories.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario DF specifically records: A restored backup overwrites later memories.
- **DG — A resurrected actor retains memories.** `memory`: Mutate or access MemoryTrace lineage only. Accurate, false, implanted, copied, erased, inaccessible, restored, and externally sourced memories remain distinct from events, truth, and identity continuity. Scenario DG specifically records: A resurrected actor retains memories.
- **DH — A reincarnated actor has fragmentary past-life memories.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DH specifically records: A reincarnated actor has fragmentary past-life memories.
- **DI — A hive mind retains a member’s memory after that member dies.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DI specifically records: A hive mind retains a member’s memory after that member dies.
- **DJ — An organization archive survives complete membership replacement.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DJ specifically records: An organization archive survives complete membership replacement.
- **DK — A map accurately reflects yesterday’s terrain.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DK specifically records: A map accurately reflects yesterday’s terrain.
- **DL — The terrain has changed.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DL specifically records: The terrain has changed.
- **DM — A map contains an intentional false route.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DM specifically records: A map contains an intentional false route.
- **DN — Two maps disagree.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DN specifically records: Two maps disagree.
- **DO — A character marks an inferred location.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DO specifically records: A character marks an inferred location.
- **DP — Another character treats the inference as confirmed.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DP specifically records: Another character treats the inference as confirmed.
- **DQ — A mission record lists a target that moved.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DQ specifically records: A mission record lists a target that moved.
- **DR — A database record is authoritative only within one institution.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DR specifically records: A database record is authoritative only within one institution.
- **DS — A scan reveals a classification but not underlying identity.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DS specifically records: A scan reveals a classification but not underlying identity.
- **DT — An “identify” effect returns source-local interpretation.** `maps records and discovery`: Treat maps, mission records, databases, classifications, identify effects, and search results as temporally scoped evidence or institutional claims. Discovery may yield evidence or no evidence; it does not directly reveal truth unless a registered source-local profile certifies it. Scenario DT specifically records: An “identify” effect returns source-local interpretation.
- **DU — A discovery action reveals evidence but not truth.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario DU specifically records: A discovery action reveals evidence but not truth.
- **DV — A failed search produces no new evidence.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario DV specifically records: A failed search produces no new evidence.
- **DW — A failed search produces misleading evidence under a registered trap.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario DW specifically records: A failed search produces misleading evidence under a registered trap.
- **DX — A hidden fact affects legality but cannot be disclosed.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario DX specifically records: A hidden fact affects legality but cannot be disclosed.
- **DY — A blocker reveals that some hidden condition exists.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario DY specifically records: A blocker reveals that some hidden condition exists.
- **DZ — Option count reveals two hidden alternatives.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario DZ specifically records: Option count reveals two hidden alternatives.
- **EA — Response timing reveals a hidden graph search.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario EA specifically records: Response timing reveals a hidden graph search.
- **EB — A raw backend ID exposes a secret identity.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario EB specifically records: A raw backend ID exposes a secret identity.
- **EC — A context packet includes a hidden fact accidentally.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario EC specifically records: A context packet includes a hidden fact accidentally.
- **ED — A context packet omits a visible belief relevant to dialogue.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario ED specifically records: A context packet omits a visible belief relevant to dialogue.
- **EE — The model uses player metaknowledge absent from character state.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario EE specifically records: The model uses player metaknowledge absent from character state.
- **EF — The model invents that an NPC recognizes the player.** `hidden information and context packets`: Use constant-shape, allowlisted projections with opaque audience-scoped tokens. Normalize blocker text, option count/order, timing, IDs, hashes, confidence precision, and retrieval visibility; packet/model inference may use only the exact audience basis. Scenario EF specifically records: The model invents that an NPC recognizes the player.
- **EG — The model infers a secret from several individually visible clues.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EG specifically records: The model infers a secret from several individually visible clues.
- **EH — That inference is valid for a character with the same clues.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EH specifically records: That inference is valid for a character with the same clues.
- **EI — The character lacks one clue that the model saw in another packet.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EI specifically records: The character lacks one clue that the model saw in another packet.
- **EJ — One guild member learns a secret.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EJ specifically records: One guild member learns a secret.
- **EK — The guild does not officially know it.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EK specifically records: The guild does not officially know it.
- **EL — The member files an institutional report.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EL specifically records: The member files an institutional report.
- **EM — The report is classified.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EM specifically records: The report is classified.
- **EN — All leaders know, but ordinary members do not.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EN specifically records: All leaders know, but ordinary members do not.
- **EO — The leadership changes completely.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EO specifically records: The leadership changes completely.
- **EP — The archive preserves institutional knowledge.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EP specifically records: The archive preserves institutional knowledge.
- **EQ — A new leader has access but has not read the record.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario EQ specifically records: A new leader has access but has not read the record.
- **ER — A public office receives legal notice.** `knowledge and institutions`: Keep member awareness, official record, classified archive, role access, legal notice, institutional knowledge, personal reading, public claim, and distributed collective knowledge as independent profile-qualified records. Scenario ER specifically records: A public office receives legal notice.
- **ES — The current officeholder is personally unaware.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario ES specifically records: The current officeholder is personally unaware.
- **ET — An organization publishes a claim it privately rejects.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario ET specifically records: An organization publishes a claim it privately rejects.
- **EU — A collective knows something no individual member can reconstruct alone.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario EU specifically records: A collective knows something no individual member can reconstruct alone.
- **EV — A divination returns an exact proposition.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario EV specifically records: A divination returns an exact proposition.
- **EW — A divination returns symbolic imagery.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario EW specifically records: A divination returns symbolic imagery.
- **EX — A prophecy describes several possible futures.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario EX specifically records: A prophecy describes several possible futures.
- **EY — A deity deliberately provides false revelation.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario EY specifically records: A deity deliberately provides false revelation.
- **EZ — A source-local rule says the deity cannot lie.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario EZ specifically records: A source-local rule says the deity cannot lie.
- **FA — Two divinations conflict.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario FA specifically records: Two divinations conflict.
- **FB — A ward blocks divination.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario FB specifically records: A ward blocks divination.
- **FC — The ward causes an explicit unknown result.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario FC specifically records: The ward causes an explicit unknown result.
- **FD — The ward produces a false result.** `divination and source local knowledge`: Contain divination, prophecy, wards, deity constraints, retrocognition, and omniscience claims in versioned source-local observation/knowledge profiles. Exact, symbolic, multiple, blocked, false, cross-timeline, limited, and unrepresentable results remain distinct. Scenario FD specifically records: The ward produces a false result.
- **FE — Retrocognition observes a past event.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FE specifically records: Retrocognition observes a past event.
- **FF — The past event is in another timeline.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FF specifically records: The past event is in another timeline.
- **FG — A source-local entity claims omniscience.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FG specifically records: A source-local entity claims omniscience.
- **FH — Its knowledge is limited by domain.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FH specifically records: Its knowledge is limited by domain.
- **FI — A character asks a question current doctrine cannot represent.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FI specifically records: A character asks a question current doctrine cannot represent.
- **FJ — Information was correct when sent but false when received.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FJ specifically records: Information was correct when sent but false when received.
- **FK — An observer acts before a correction arrives.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FK specifically records: An observer acts before a correction arrives.
- **FL — A later fact retroactively explains old evidence.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FL specifically records: A later fact retroactively explains old evidence.
- **FM — An administrator discovers an old observation was not recorded.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FM specifically records: An administrator discovers an old observation was not recorded.
- **FN — A historical observer never had access to the repaired record.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FN specifically records: A historical observer never had access to the repaired record.
- **FO — A timeline branch carries copied memories until divergence.** `time and revision`: Preserve send/receive/act/correction times, valid and recorded time, branch lineage, future claims, causal changes, loops, doctrine versions, and historical access. Later interpretation or repair never rewrites an earlier observer state. Scenario FO specifically records: A timeline branch carries copied memories until divergence.
- **FP — A time traveler reveals future information.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FP specifically records: A time traveler reveals future information.
- **FQ — The revelation changes the future.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FQ specifically records: The revelation changes the future.
- **FR — The original future remains in another branch.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FR specifically records: The original future remains in another branch.
- **FS — A closed time loop contains information with no simple origin.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FS specifically records: A closed time loop contains information with no simple origin.
- **FT — Current canon changes an old source-local knowledge rule.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FT specifically records: Current canon changes an old source-local knowledge rule.
- **FU — Available evidence is incomplete.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FU specifically records: Available evidence is incomplete.
- **FV — Inference profiles are incomparable.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FV specifically records: Inference profiles are incomparable.
- **FW — Truth remains source-locally unknowable.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FW specifically records: Truth remains source-locally unknowable.
- **FX — Required historical evaluator is unavailable.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FX specifically records: Required historical evaluator is unavailable.
- **FY — An observer’s belief state is corrupted.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FY specifically records: An observer’s belief state is corrupted.
- **FZ — No registered proposition schema can express the claim.** `no lawful answer`: Return the precise lawful indeterminacy: evidence incomplete, profiles incomparable, source-locally unknowable, historical evaluator unavailable, belief state corrupted, or proposition schema missing. Quarantine/escalate rather than invent. Scenario FZ specifically records: No registered proposition schema can express the claim.

## Part XXI — Current runtime disposition

### Exists

- backend truth doctrine
- owner/interface skeleton
- visibility tiers and redaction policies
- narrow RT-002A-F vertical slice
- deterministic serializers/hashes
- conversion provenance/source-local structures

### Fixture-only

- hidden fact reference
- projection packets
- object/lever legality blockers
- preview/commit/audit receipts

### Conversion-only

- SourceEvidenceIR
- translation/source reliability/confidence
- map annotations
- source-local claims

### Missing

- all generalized AFQR-10 runtime owners and contracts

### May proceed

- AFQR-10 schema/fixture authoring
- conversion epistemic-pressure IR
- non-mutating dry run
- RT-002A-F side-channel audit
- narrow RT-002G after ratification and amendment

### Remains blocked

- generalized observation/evidence/belief/memory mutation
- generalized context packets
- dialogue knowledge conditions
- NPC knowledge/cognition
- rumor/deception propagation
- investigation/discovery runtime
- institutional/common knowledge
- divination and telepathy runtime
- player-character metaknowledge bridging

### Prohibited

- Treating RT-002 hidden-fact references as a generalized fact system.
- Using event hashes as knowledge or credibility.
- Storing hidden truth in generic metadata.
- Using model memory or transcript as character/world memory.
- Building generalized context packets before audience/purpose projection and noninterference contracts.
- Allowing conversion records to create campaign facts, beliefs, memories, or model packets.
## Part XXII — Required artifacts

### Immediate artifacts

- AFQR-10 ADR
- decision registry
- canonical terminology registry
- contract catalog
- side-channel threat model
- conversion pressure IR amendments
- 45-case dry-run fixtures

### Before authoritative observation

- proposition/truth/subject/interface registries
- observation/evidence contracts
- bitemporal/hash rules

### Before belief-state mutation

- belief/uncertainty/inference/revision schemas and owner reducers

### Before deception and rumor propagation

- deception, evidence authenticity, testimony, rumor lineage, propagation policies

### Before institutional knowledge

- group/institution/archive/role access/common knowledge profiles

### Before model-facing context packets

- allowlisted audience/purpose projection compiler and noninterference tests

### Before mass donor conversion

- epistemic pressure IR templates and donor-family fixtures

### Deferred work

- full cognition
- trust/reputation
- final perception formulas
- memory psychology
- final divination metaphysics
- distributed infrastructure optimization

## Part XXIII — Non-mutating prototype

**AFQR-10 Truth, Observation, Evidence, and Belief-State Determination Dry Run** contains **45 fixtures** in `fixtures/afqr_10_non_mutating_dry_run.yaml`. It runs deterministic pure evaluators only. It emits propositions, facts, observations, evidence relations, testimony/communications, belief alternatives, knowledge/uncertainty/inference/revision receipts, memory traces, disclosures, rumors, private receipts, observer/model projections, hashes, and AFQR handoffs. It prohibits truth, belief, memory, disclosure, rumor, event, or runtime mutation; model calls; and unregistered inference.

The prototype is the smallest useful dry run because it proves schema separations, profile behavior, side-channel-safe projection shapes, and historical basis before any persistent owner reducer is authorized.

## Part XXIV — Acceptance tests

### Truth and proposition

- [ ] Propositions use registered schemas and typed references.
- [ ] World, timeline, temporal scope, polarity, namespace, and canonical serialization are explicit.
- [ ] Fact records contain no observer belief.
- [ ] True, false, unresolved, indeterminate, and inapplicable are distinct.
- [ ] Open/closed-world policy and negative facts are explicit.
- [ ] Administrative repair and historical versions are append-only.

### Observation

- [ ] Observation differs from truth, evidence, belief, and knowledge.
- [ ] Interface, observer, conditions, state basis, profile versions, and hash are explicit.
- [ ] No observation, partial observation, false positive, false negative, noise, delay, occlusion, manipulation, and source-local output are distinct.
- [ ] Common-prestate simultaneous observation is deterministic.

### Evidence

- [ ] Evidence identity, provenance, authenticity, integrity, relevance, custody, visibility, duplication, destruction, and alteration are explicit.
- [ ] Support/opposition/qualification/context/irrelevance are typed.
- [ ] Provenance never implies credibility or conclusion.
- [ ] Forgery discovery appends findings and revision candidates without rewriting earlier receipts.

### Belief

- [ ] Beliefs are subject-owned and can be false, contradictory, role-scoped, outdated, source-misattributed, suspended, or refused.
- [ ] Competing hypotheses do not require complete possible worlds.
- [ ] No global logical closure or recency/file-order winner exists.
- [ ] History and revision basis are replayable.

### Knowledge

- [ ] Every authoritative knows check names a profile/version.
- [ ] Direct observation, certification, legal notice, institutional record, practical knowledge, source-local revelation, shared, distributed, public, common, and ignorance knowledge differ.
- [ ] Truth plus belief does not silently imply knowledge.

### Uncertainty

- [ ] Probability is optional; exact values, intervals, ordinal classes, alternatives, support/opposition, possibility sets, assurance classes, source-local values, and unquantified uncertainty serialize deterministically.
- [ ] Unlike uncertainty kinds cannot be compared or converted silently.
- [ ] Projection precision can be coarsened without changing the private record.

### Inference and revision

- [ ] Profiles are registered, pure, bounded, deterministic, source-scoped, versioned, and model-free.
- [ ] Deduction, defeasible inference, abduction, probabilistic update, classification, revelation, and memory retrieval differ.
- [ ] Expansion, contraction, revision, suspension, contradiction retention, invalidation, correction, supersession, and refusal differ.
- [ ] Missing or conflicting profiles return unresolved.

### Memory

- [ ] Memory differs from truth, event history, observation, evidence, transcript, and model context.
- [ ] Accurate, partial, reconstructed, false, altered, implanted, copied, inaccessible, erased, decayed, and source-misattributed traces are supported.
- [ ] External records and access rights are separate.
- [ ] Restoration never rewrites the originating event or identity.

### Deception and rumor

- [ ] Lie differs from false assertion, mistake, omission, misleading truth, disguise, impersonation, illusion, hallucination, forgery, planting, tampering, misinformation, and disinformation.
- [ ] Deception changes interfaces/evidence/opportunities, not truth or target belief directly.
- [ ] Rumor branches, mutation, merge, suppression, correction, adoption, retraction, and persistent public belief are replayable.
- [ ] Repetition and official status do not make a rumor true.

### Group knowledge

- [ ] Member knowledge, role access, official record, institutional knowledge, shared knowledge, distributed knowledge, public information, common belief, and common knowledge are distinct.
- [ ] Membership replacement and archive continuity are explicit.
- [ ] CommonKnowledgeCertificate states audience and communication assumptions without infinite nesting.

### Hidden information

- [ ] Private truth/observation/belief receipts are separate from actor/observer/player/model/public projections.
- [ ] Hidden proposition IDs, sources, identities, dependencies, option count/order, graph size, timing, hashes, confidence precision, source reliability, and retrieval rank do not leak.
- [ ] Opaque audience-scoped tokens and allowlists replace raw references.
- [ ] Generic blocker text and stable shape are tested across hidden-state variants.
- [ ] Cross-packet model noninterference prevents clue borrowing.

### Replay

- [ ] Replay reconstructs truth, observation, evidence availability, belief, memory accessibility, disclosure, group records, and model packet at each checkpoint.
- [ ] Valid, transaction, and logical times and profile/evaluator versions are preserved.
- [ ] Current doctrine never silently recomputes historical epistemic state.
- [ ] Missing historical evaluator returns unverifiable.

### Conversion

- [ ] Donor epistemology becomes pressure IR and receives one lawful outcome.
- [ ] Maps, rumors, divination, omniscience, memory, perception formulas, and official records do not become universal law.
- [ ] Conversion cannot create campaign facts, beliefs, memories, disclosures, executable inference, rumor propagation, or model packets.
- [ ] Source-local and doctrine-escalation destinations are explicit.

### Runtime containment

- [ ] RT-001/002 visibility and hidden-fact structures remain fixture-only.
- [ ] Event/audit hashes are not knowledge.
- [ ] Metadata is allowlisted and typed; blacklists are defense-in-depth only.
- [ ] Context packets are projections, not authority.
- [ ] Generalized epistemic mutation remains blocked until owner reducers and tests exist.

## Part XXV — Residual uncertainty ledger

- **Full cognition:** Belief-desire-intention interaction, emotion, personality, motivation, tactics, dialogue planning, learning, and agency remain outside AFQR-10.
- **Social trust:** Reputation, social trust, credibility networks, persuasion, authority, and institutional legitimacy require later doctrine; source reliability here is only typed evidence input.
- **Legal evidence:** Jurisdiction-specific admissibility, burdens, privilege, due process, and evidentiary standards remain source-local or later legal doctrine.
- **Personhood and consent:** Who may own beliefs/memories, consent to telepathy or alteration, control proxies/collectives, and bear responsibility is AFQR-11.
- **Final perception formulas:** Detection ranges, roll math, opposed checks, calibration thresholds, stealth, and environment interactions remain Batch A/B/runtime profile work.
- **Final memory psychology:** Exact consolidation, decay, interference, trauma, reconstruction, and individual variation remain later cognition/memory profiles.
- **Final divination doctrine:** No universal metaphysics is selected; source-local profiles can be registered after truth-access boundaries and canon review.
- **Distributed infrastructure:** Database partitioning, vector clocks, multi-node consistency, and privacy-preserving retrieval are implementation choices after the local kernel.
- **Performance risks:** Evidence graph size, proposition normalization, selector evaluation, bitemporal indexes, evaluator archives, projection compilation, and replay storage require benchmarks.

## Part XXVI — Roadmap conclusion

1. **Is AFQR-10 sufficiently resolved for ratification?** Yes. Ratify TTEP-PRV with the mandatory amendments and artifacts in this pack.
2. **Is another broad research pass required?** No. Focused implementation and performance research is sufficient.
3. **What mandatory amendments remain?** Qualified `knows`; federated proposition schemas; bitemporal fact and epistemic records; plural uncertainty; pure versioned inference/revision; finite common-knowledge certificates; allowlisted private/visible/model projections; opaque identifiers; full side-channel/noninterference tests; archived historical evaluators; blacklist-only metadata prohibited.
4. **What artifacts should be created immediately?** AFQR-10 ADR and registry, terminology registry, typed contract catalog, 50-question audit, 90-operation grammar, A–FZ adversarial registry, 45-case dry run, familiar-network graph, side-channel threat model, and conversion pressure IR amendment.
5. **What is the smallest non-mutating prototype?** The 45-fixture Truth, Observation, Evidence, and Belief-State Determination Dry Run included here.
6. **What runtime work remains blocked?** All generalized observation/evidence/belief/memory mutation, context packets, dialogue knowledge, NPC cognition, rumor/deception, investigation/discovery, institutional/common knowledge, divination, and telepathy.
7. **Does AFQR-10 unlock narrow RT-002G work?** Conditionally. Resume only after AFQR-01–10 artifact ratification and an AFQR-10 side-channel amendment/audit. RT-002G must remain a narrow fixture.
8. **What generalized context-packet work remains blocked?** Audience/purpose subject registry, visible belief/memory/evidence contracts, packet compiler, opaque tokens, cross-audience noninterference, historical packet basis, and model inference limits.
9. **What should AFQR-11 address?** Agency, Personhood, Consent, Control, Responsibility, and Decision Authority, including copies, collectives, proxies, possession, incapacitation, coercion, automation, and contested personhood.
10. **What is the exact next roadmap action?** Ratify and register the AFQR-10 artifact pack, then run the 45-case non-mutating dry run and an RT-002A-through-RT-002F side-channel/noninterference audit before authorizing the narrow RT-002G continuation.

## Part XXVII — Machine-readable decision block

The block below is identical in substance to `registries/afqr_10_decision_registry.yaml`.

```yaml
question_id: AFQR-10
question_title: Epistemic State Perception Evidence Knowledge Belief Uncertainty Secrecy Deception Memory Discovery and Observer
  Relative Truth
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: ratifiable_with_mandatory_implementation_artifacts_and_side_channel_amendment
selected_architecture: Typed Bitemporal Truth–Epistemic Provenance Architecture with Profiled Revision and Visibility-Safe
  Projection
selected_architecture_abbreviation: TTEP-PRV
confidence: high
central_law: Authoritative world truth and every observer-relative epistemic state are separately owned, versioned, and append-only.
  They may be connected only by registered observation, evidence, testimony, communication, inference, memory, and disclosure
  receipts. No observation, belief, memory, rumor, map, official record, or model output changes truth; no truth enters an
  observer or model projection without a registered visibility-safe path.
accepted_dependencies:
  AFQR_01:
    binding: truth, belief, memory, disclosure, and evidence owners prepare separate typed fragments; inseparable roots only
      are atomic
  AFQR_02:
    binding: command bases preserve what the actor was authorized to know at declaration and checkpoints; retry grants no
      new information
  AFQR_03:
    binding: epistemic actions name a result kind and registered interface; models cannot invent result bridges
  AFQR_04:
    binding: occurrence, observation, transmission, update, memory, disclosure, and narration use distinct logical times
  AFQR_05:
    binding: senses, languages, translation, sensors, archives, telepathy, and divination require registered bridges
  AFQR_06:
    binding: authoritative claim arbitration is separate from observer belief revision; inference policies cannot hide precedence
  AFQR_07:
    binding: information is not universally conserved; quantity, storage, copying, bandwidth, credentials, and sale route
      only when explicit
  AFQR_08:
    binding: epistemic subjects and content use typed identity/continuity; copied memories and beliefs do not copy identity
  AFQR_09:
    binding: notice, awareness, effectiveness, secrecy obligations, institutional roles, and knowledge conditions use governed
      relations and orthogonal lifecycle planes
definitions:
  proposition: A canonical typed claim token with predicate, typed arguments, scope, time, polarity, and namespace; it is
    not itself true or believed.
  authoritative_fact: A truth-owner record assigning a versioned truth status to a proposition within a truth domain and bitemporal
    interval.
  observation: An immutable record of what a registered interface produced for an observer under frozen conditions.
  evidence: An independently identified item that can be related to propositions under a registered inference profile; provenance
    does not imply credibility.
  testimony: A speaker-attributed assertion event separate from speaker belief, intent, delivery, recipient awareness, and
    truth.
  belief: A subject-owned stance toward a proposition or alternative set, including support, opposition, uncertainty, role
    scope, contradiction, and revision history.
  knowledge: A profile-qualified determination; the unqualified runtime predicate knows is prohibited.
  memory: A subject-owned trace and access state derived from but not identical to events, observations, beliefs, or truth.
  rumor: A lineage of proposition-bearing transmissions and mutations; not a global string and not truth.
  common_knowledge: A finite certificate that a registered public/shared event satisfies explicit communication and audience
    assumptions; not infinite nested materialization.
guarantees:
- truth and observer epistemic state remain separate
- false and contradictory beliefs are representable
- all authoritative knowledge checks are profile-qualified
- all truth and epistemic histories are bitemporal and append-only
- uncertainty is a tagged union rather than a universal scalar
- hidden information projections are audience- and purpose-scoped
- deception cannot directly mutate truth or target belief
- model context is a derived projection with no in-world authority
- source-local epistemologies remain contained
- missing doctrine returns a lawful unresolved/quarantine/escalation result
non_guarantees:
- perfectly rational agents
- global logical closure
- universal Bayesian calibration
- universal divination truth access
- automatic institution knowledge from member knowledge
- automatic common knowledge from publication
- psychologically realistic memory
- full NPC cognition, desire, emotion, agency, tactics, or dialogue
proposition_model:
  architecture: federated registry of proposition schemas by domain and source-local namespace
  canonical_serialization:
  - schema id
  - typed arguments
  - world/timeline scope
  - temporal scope
  - polarity
  - bounded quantification
  future_counterfactual_policy: Represent as scoped proposition contexts, not current facts.
  missing_schema: return unrepresentable_claim and AFQR10Handoff; do not use freeform authoritative prose.
truth_domain_model:
  truth_statuses:
  - 'true'
  - 'false'
  - unresolved
  - indeterminate
  - inapplicable
  absence_semantics:
  - open_world_default
  - closed_world_only_with_bounded_completeness_certificate
  - explicit_negative_fact
  scope:
  - canon_truth
  - campaign_truth
  - source_local_truth
  - timeline_truth
  owner: registered truth-domain owner
authoritative_fact_model:
  separate_from:
  - belief
  - observation
  - evidence
  - testimony
  - memory
  - rumor
  - record
  - model context
  versioning: fact identity and proposition identity persist across append-only versions
  repair: administrative repair appends a corrective transaction-time version and preserves historical receipts
open_closed_world_policy:
  default: open_world
  closed_world_requirement: registered domain, completeness boundary, effective interval, version, and owner
  not_recorded: unknown unless closed-world proof or explicit negative fact
epistemic_subject_model:
  subject_kinds:
  - actor
  - player_interface_recipient
  - party
  - organization
  - office
  - institution
  - collective
  - swarm
  - AI
  - spirit
  - proxy_manifestation
  - public_audience
  - model_projection_target
  entity_requirement: Individual in-world subjects normally reference runtime identities; bounded aggregates may be epistemic-only
    records with explicit selectors.
  model_rule: A model projection target is not an in-world knower by default.
observer_model:
  observer_is_role: An epistemic subject acting through a registered interface.
  simultaneous_observation: common-prestate and per-observer interface outputs may differ.
  proxy_rule: Proxy observations route through AFQR-08/09 relation and memory-sharing policies.
group_and_institution_model:
  separate_records:
  - member belief
  - official record
  - role access
  - institutional knowledge
  - distributed knowledge
  - public claim
  - common belief
  - common knowledge
  persistence: Archives and institutional owner continuity may preserve records across membership replacement.
observation_model:
  record_fields:
  - observer
  - interface
  - source
  - target
  - conditions
  - logical time
  - state basis
  - raw private result
  - interpreted result
  - uncertainty
  - occlusion
  - manipulation
  - visibility
  - provenance
  - hash
  law: observation does not equal truth or belief
observation_interface_model:
  interfaces:
  - sensory
  - sensor
  - scan
  - archive
  - document
  - witness
  - language
  - translation
  - telepathy
  - shared senses
  - divination
  - retrocognition
  - AI fusion
  requirements:
  - registered bridge
  - versioned evaluator
  - bounded output kind
  - uncertainty profile
  - manipulation and occlusion policy
evidence_model:
  relations:
  - supports
  - opposes
  - qualifies
  - contextualizes
  - irrelevant
  states:
  - authentic
  - forged
  - altered
  - duplicated
  - destroyed
  - hidden
  - disputed
  - unknown authenticity
  law: authenticity, relevance, reliability, strength, and conclusion remain distinct
evidence_provenance_model:
  basis: W3C-PROV-like entity/activity/agent lineage plus chain-of-custody events
  law: provenance establishes lineage, not credibility or truth
testimony_model:
  separates:
  - speaker
  - content
  - speaker belief where known
  - intent where relevant
  - language
  - translation
  - channel
  - delivery
  - recipient awareness
  - truth
  lie_profile: false assertion + speaker believes false + deceptive intent under registered policy
communication_model:
  delivery_states:
  - sent
  - delivered
  - intercepted
  - altered
  - delayed
  - lost
  - blocked
  - encrypted
  - decryption_failed
  time: send, delivery, receipt/read, and belief update are distinct
  role_delivery: office/role continuity and occupant awareness are separate
belief_state_model:
  stances:
  - accepted
  - rejected
  - suspected
  - possible
  - doubted
  - suspended
  - contradictory
  supports:
  - false belief
  - competing hypotheses
  - recognized or unrecognized contradiction
  - role/persona scope
  - outdated belief
  - refusal to update
  closure: none by default; bounded profile-specific inference only
knowledge_profile_model:
  profiles:
  - direct_observation
  - backend_certified
  - institutional_certification
  - legal_notice
  - practical_operational
  - source_local_revelation
  - public_knowledge
  - shared_knowledge
  - distributed_knowledge
  - common_knowledge
  - knowledge_of_ignorance
  runtime_rule: Every authoritative knows check names a profile and version.
uncertainty_model:
  tagged_union:
  - categorical
  - ordinal
  - exact_probability
  - probability_interval
  - weighted_alternatives
  - support_opposition
  - possibility_set
  - assurance_class
  - source_local
  - unquantified
  comparison: Only same-kind values or values with an explicit registered conversion/comparison profile may be compared.
  display: Audience projections may coarsen precision to prevent leakage.
inference_model:
  requirements:
  - registered
  - deterministic
  - versioned
  - pure
  - bounded
  - typed
  - source-scoped
  - replayable
  - no model calls
  - no direct mutation
  families:
  - deductive
  - defeasible
  - abductive
  - probabilistic_update
  - classification
  - pattern_recognition
  - source_local_revelation
  - memory_retrieval
  conflict: Incomparable or conflicting profiles remain distinct and unresolved; no file-order winner.
belief_revision_model:
  operations:
  - expansion
  - revision
  - contraction
  - suspension
  - contradiction_retention
  - source_reevaluation
  - evidence_invalidation
  - forgery_discovery
  - memory_correction
  - institutional_correction
  - supersession
  - refusal
  historical_rule: New receipts never edit earlier beliefs.
memory_model:
  trace_types:
  - episodic
  - semantic
  - working
  - external
  states:
  - accurate
  - partial
  - reconstructed
  - altered
  - 'false'
  - implanted
  - copied
  - decayed
  - source_misattributed
  - inaccessible
  - erased
  law: Memory mutations never rewrite facts, events, observations, or identity.
forgetting_policy:
  distinguishes:
  - decayed
  - inaccessible
  - retrieval_failed
  - erased
  - external_access_lost
  profiled: decay and retrieval are source/actor-specific and may be absent entirely
false_memory_policy:
  representation: MemoryTrace with altered/false content lineage and source attribution; belief update remains separate.
  truth_effect: none
external_memory_policy:
  representation: Evidence/document/database asset plus access relation and optional MemoryTrace pointer
  loss: Access loss does not destroy the external record unless a separate asset transition does.
secrecy_model:
  dimensions:
  - classification
  - compartment
  - need_to_know
  - concealment
  - hidden existence
  - knowledge of secrecy
  - encryption
  - source_local unknowability
  law: secret, unknown, unknowable, undiscovered, forgotten, redacted, encrypted, and classified are distinct
disclosure_model:
  transition_fields:
  - source
  - authority
  - recipient selector
  - content projection
  - timing
  - scope
  - delivery
  - visibility
  kinds:
  - private disclosure
  - publication
  - notification
  - revelation
  - declassification
  - accidental disclosure
  law: Disclosure changes access/epistemic opportunity, not fact truth.
redaction_model:
  rule: Redaction is a typed projection transform with manifest and stable safe shape; it is not misinformation unless content
    is altered to mislead under a deception profile.
declassification_model:
  rule: Declassification changes secrecy status and permitted disclosure; it does not establish recipient awareness or public/common
    knowledge.
information_flow_policy:
  approach: deny-by-default allowlisted projection plus purpose/audience labels and explicit declassification
  side_channels:
  - IDs
  - existence
  - counts
  - option count/order
  - response timing
  - inference duration
  - graph size
  - hashes
  - confidence precision
  - source reliability
  - retrieval rank
  - package names
  mitigation:
  - opaque audience-scoped tokens
  - constant-shape envelopes
  - generic blocker classes
  - stable ordering independent of hidden state
  - timing normalization or bounded buckets
  - private/visible hash separation
  - precision coarsening
  - cross-packet noninterference tests
deception_model:
  acts_on:
  - presented claims
  - interfaces
  - signals
  - observations
  - evidence
  - provenance
  - source attribution
  - visibility
  - memory where separately authorized
  never_directly_owns:
  - truth
  - target belief
  types:
  - lie
  - mistake
  - omission
  - misdirection
  - misleading truth
  - disguise
  - impersonation
  - illusion
  - hallucination
  - forgery
  - fabrication
  - tampering
  - spoofing
  - false trail
  - propaganda
  - misinformation
  - disinformation
illusion_model:
  default: Creates or modifies observation/signal output, not underlying truth.
  exception: If source-local law also creates real energy or harm, those truth changes route separately to their owners.
forgery_model:
  distinguishes:
  - fabricated evidence
  - altered authentic evidence
  - authentic evidence with false provenance
  - planted authentic evidence
  discovery: Appends authenticity/custody findings and revision candidates; earlier receipts remain.
rumor_model:
  identity: Rumor plus branch/variant/transmission lineage
  states:
  - originated
  - retold
  - mutated
  - merged
  - suppressed
  - corrected
  - institutionally_adopted
  - retracted
  - publicly_persistent
  law: No rumor state changes proposition truth automatically.
shared_knowledge_model:
  definition: Each member in an explicit audience has a qualifying personal or group-access record under a profile; not necessarily
    knowledge that others know.
distributed_knowledge_model:
  definition: The union of information accessible to a registered collective under a bounded aggregation profile can establish
    a group-level result even when no individual can reconstruct it.
common_knowledge_model:
  representation: Finite CommonKnowledgeCertificate
  requirements:
  - audience selector
  - public/shared event
  - delivery/reach assumptions
  - common-knowledge profile
  - validity interval
  - exceptions
  prohibition: No infinite nested statements.
institutional_knowledge_model:
  definition: Official institutional record or certified determination owned by the institution, separate from member beliefs
    and access rights.
truth_epistemic_update_pipeline:
  stages:
  - world event or information action
  - truth-state evaluation
  - observer/interface eligibility
  - observation generation
  - evidence registration
  - testimony/communication delivery
  - observer-specific interpretation
  - inference profile application
  - belief-update candidate
  - contradiction/revision evaluation
  - memory encoding candidate
  - disclosure/visibility projection
  - owner-fragment preparation
  - AFQR-01 commitment
  - context-packet projection
  - replay receipt
  pure_stages:
  - eligibility
  - observation calculation
  - evidence relation evaluation
  - inference
  - revision planning
  - projection compilation
  mutation_stages: Only owner fragment reducers at AFQR-01 commitment.
owner_boundaries:
  truth: truth-domain owners
  observation: observation owners
  evidence: evidence owners
  belief: epistemic subject owners
  memory: memory owners
  disclosure: disclosure/secrecy owners
  rumor: rumor owners
  group_knowledge: group/common-knowledge owners
  model_packet: context packet owner
AFQR_handoffs:
  AFQR_01: typed atomic commitment and receipts
  AFQR_02: command basis/checkpoints
  AFQR_03: epistemic action grammar
  AFQR_04: logical time and delayed propagation
  AFQR_05: interfaces/translation/telepathy/sensors
  AFQR_06: authoritative claim arbitration only
  AFQR_07: explicit information quantities/copying/storage/sale
  AFQR_08: subjects, aliases, copies, fusion/fission, proxies
  AFQR_09: roles, notice, secrecy obligations, institutional access, dependency effectiveness
historical_replay_policy:
  reconstruct:
  - truth version
  - observer eligibility
  - observation output
  - evidence availability
  - belief state
  - memory access
  - disclosure state
  - model projection
  - active profile/evaluator versions
  missing_evaluator: historical result unverifiable; do not recompute under current evaluator
bitemporal_policy:
  valid_time: when the proposition/evidence/belief/memory/disclosure applies in-world
  transaction_time: when the backend recorded or corrected it
  logical_time: causal scheduling and ordering
  repair: append new transaction-time version; historical observer access does not change
hidden_information_policy:
  receipts:
  - PrivateTruthReceipt
  - PrivateObservationReceipt
  - PrivateBeliefReceipt
  - PrivateEpistemicReceipt
  projections:
  - ActorVisibleEpistemicProjection
  - ObserverVisibleEpistemicProjection
  - PlayerVisibleEpistemicProjection
  - ModelVisibleEpistemicProjection
  - PublicEpistemicProjection
  default: deny and generic-safe output
model_context_projection_policy:
  relationship: Derived from authorized observer/player projections and accessible memories/evidence; never from raw truth.
  must_include:
  - intended audience
  - model purpose
  - actor/dialogue subject
  - visible beliefs and uncertainty
  - allowed and forbidden inferences
  - packet basis/hash
  - compiler version
  must_exclude:
  - other audience clues
  - player metaknowledge absent from character
  - hidden IDs/dependencies
  - raw backend references
  - model-created facts or memories
familiar_network_stress_case:
  fixture: fixtures/concealed_familiar_network_typed_graph.yaml
  key_decision: Proxy identity, contract suspension, notice, witness observations, illusion, archive evidence, official record,
    rumor, player/character knowledge, memory sharing, autonomy, retraction, and replay are independent typed nodes.
conversion_pipeline_handoff:
  IR_records:
  - TruthAssertionPressureIR
  - PropositionPressureIR
  - ObservationPressureIR
  - PerceptionPressureIR
  - EvidencePressureIR
  - TestimonyPressureIR
  - BeliefPressureIR
  - KnowledgePressureIR
  - UncertaintyPressureIR
  - MemoryPressureIR
  - ForgettingPressureIR
  - DeceptionPressureIR
  - IllusionPressureIR
  - RumorPressureIR
  - DiscoveryPressureIR
  - InvestigationPressureIR
  - DivinationPressureIR
  - MapKnowledgePressureIR
  - InstitutionalKnowledgePressureIR
  - CommonKnowledgePressureIR
  - HiddenInformationPressureIR
  - DisclosurePressureIR
  - SourceLocalEpistemologyPressureIR
  pipeline:
  - donor extraction
  - Conversion IR
  - epistemic-pressure ledger
  - donor-family comparison
  - doctrine/source-local review
  - profile registration
  - certification fixtures
  - optional canon promotion
  - runtime registry
  prohibitions:
  - no campaign facts
  - no actor beliefs/memories
  - no credibility decisions
  - no automatic inference rules
  - no context packet definitions
model_authority_policy:
  may:
  - parse non-authoritative claims
  - narrate visible observations
  - summarize authorized evidence/beliefs
  - express supplied uncertainty
  - ask visibility-safe clarification
  may_not:
  - infer hidden truth
  - decide noticing/knowledge/credibility
  - resolve contradictory evidence
  - create evidence/beliefs/memories/disclosures
  - use training knowledge as world truth
  - merge player and character knowledge
current_runtime_disposition:
  exists:
  - backend truth doctrine
  - owner/interface skeleton
  - visibility tiers and redaction policies
  - narrow RT-002A-F vertical slice
  - deterministic serializers/hashes
  - conversion provenance/source-local structures
  fixture_only:
  - hidden fact reference
  - projection packets
  - object/lever legality blockers
  - preview/commit/audit receipts
  conversion_only:
  - SourceEvidenceIR
  - translation/source reliability/confidence
  - map annotations
  - source-local claims
  missing:
  - all generalized AFQR-10 runtime owners and contracts
  risk: blacklist-based metadata and shape/status/ID/timing side channels
required_artifacts:
  immediate:
  - AFQR-10 ADR
  - decision registry
  - canonical terminology registry
  - contract catalog
  - side-channel threat model
  - conversion pressure IR amendments
  - 45-case dry-run fixtures
  before_authoritative_observation:
  - proposition/truth/subject/interface registries
  - observation/evidence contracts
  - bitemporal/hash rules
  before_belief_mutation:
  - belief/uncertainty/inference/revision schemas and owner reducers
  before_deception_rumor:
  - deception, evidence authenticity, testimony, rumor lineage, propagation policies
  before_institutional_knowledge:
  - group/institution/archive/role access/common knowledge profiles
  before_model_packets:
  - allowlisted audience/purpose projection compiler and noninterference tests
  before_mass_conversion:
  - epistemic pressure IR templates and donor-family fixtures
  deferred:
  - full cognition
  - trust/reputation
  - final perception formulas
  - memory psychology
  - final divination metaphysics
  - distributed infrastructure optimization
required_prototype:
  name: AFQR-10 Truth, Observation, Evidence, and Belief-State Determination Dry Run
  mode: non_mutating
  fixture_count: 45
  artifact: fixtures/afqr_10_non_mutating_dry_run.yaml
required_fixtures:
- 45-case dry run
- concealed familiar network
- A-FZ adversarial corpus
- RT-002A-F side-channel regression
- cross-audience packet noninterference
blocked_work:
- generalized observation/evidence/belief/memory mutation
- generalized context packets
- dialogue knowledge conditions
- NPC knowledge/cognition
- rumor/deception propagation
- investigation/discovery runtime
- institutional/common knowledge
- divination and telepathy runtime
- player-character metaknowledge bridging
work_unlocked:
- AFQR-10 schema/fixture authoring
- conversion epistemic-pressure IR
- non-mutating dry run
- RT-002A-F side-channel audit
- narrow RT-002G after ratification and amendment
rejected_alternatives:
- A global truth table plus visibility flags as universal architecture
- B per-observer fact sets as universal architecture
- C universal probabilistic beliefs
- D event-log-derived knowledge
- F BDI as epistemic foundation
- G full possible-world materialization
residual_risks:
- schema proliferation
- proposition namespace drift
- inference profile explosion
- projection side channels
- bitemporal storage growth
- historical evaluator archiving
- group selector complexity
- performance of evidence graphs
- authoring burden
- source-local profile containment
RT_002G_status: may_resume_narrowly_after_AFQR_01_10_artifact_ratification_and_AFQR_10_side_channel_amendment; remains_fixture_only_and_must_not_claim_generalized_epistemic_or_context_packet_authority
next_foundational_question:
  question_id: AFQR-11
  title: Agency, Personhood, Consent, Control, Responsibility, and Decision Authority
  exact_question: How should Astra represent who may decide, consent, refuse, control, delegate, override, and bear responsibility
    across actors, copies, collectives, proxies, institutions, possession, incapacitation, coercion, automation, and contested
    personhood without collapsing identity, capability, authority, ownership, epistemic state, and moral or legal status?
  reason: AFQR-10 exposes repeated dependencies on who owns beliefs, memories, disclosures, deception intent, consent to telepathy
    or memory alteration, institutional authority, and model/automation decision limits.
exact_next_roadmap_action: Ratify and register the AFQR-10 artifact pack, then run the 45-case non-mutating dry run and an
  RT-002A-through-RT-002F side-channel/noninterference audit before authorizing the narrow RT-002G continuation.
```
