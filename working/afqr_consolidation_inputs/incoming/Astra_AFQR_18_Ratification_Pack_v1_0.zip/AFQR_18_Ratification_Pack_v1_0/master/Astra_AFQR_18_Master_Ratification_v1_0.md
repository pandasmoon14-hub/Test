# Astra Foundational Question Resolution 18

## Space, Location, Position, Scale, Boundaries, Distance, Proximity, Reachability, Movement, Navigation, and Spatial Topology

**Status:** Architecturally resolved for ratification  
**Repository commit inspected:** `928bb79ce00a2de749d127dcc5cb8299de788a15`  
**Selected architecture:** Registered Federated Spatiotemporal Topology Architecture with Typed Domain–Frame–Support Ownership, Plural Metric–Reachability Profiles, Atomic Movement–Occupancy Transitions, and Bitemporal Map–Materialization Continuity  
**Abbreviation:** `RFSTA-DFS-PMR-AMO-MMC`  
**Confidence:** High

This master document is the integrated normative decision. Machine-readable registries, contracts, fixtures and evaluations in this pack are binding supplements where referenced.

## Part I — Executive decision

AFQR-18 selects **Registered Federated Spatiotemporal Topology Architecture with Typed Domain–Frame–Support Ownership, Plural Metric–Reachability Profiles, Atomic Movement–Occupancy Transitions, and Bitemporal Map–Materialization Continuity** (`RFSTA-DFS-PMR-AMO-MMC`).

### Central law

> No place name, location field, coordinate tuple, map feature, route plan, range label, movement declaration, portal description, travel summary, donor rule, sensor estimate, public report, or model narration possesses spatial mutation authority by itself. Every authoritative spatial result is a purpose-scoped, version-pinned, bitemporal determination over frozen spatial-domain, reference-frame, transform, support, extent, topology, metric, occupancy, movement, portal, environmental, embodiment, identity, epistemic, agency, behavioral, social, communication, institutional, governed-relation, quantity, and scheduler bases. Only owner-prepared AFQR-01 transitions may change position, topology, occupancy, transit, or arrival; maps, observations, estimates, route beliefs, plans, and model wording remain separate append-only records.

The architecture is a federated spatiotemporal ownership and transition framework. It permits coordinate-free relations, coordinates, grids, zones, graphs, continuous geometries, moving frames, portals, virtual networks, orbital profiles, and source-local spaces to coexist without elevating any one representation into universal Astra law.

It is not a universal coordinate space, grid, pathfinder, travel-time formula, tactical line-of-sight engine, portal metaphysics, or model-driven movement system.

**Confidence:** High. A second broad research pass is not required. Narrow certification research remains mandatory for any selected geometry kernel, CRS family, orbital profile, crowd method, collision profile, portal ontology, or source-local conceptual space.

## Part II — Repository-grounded diagnosis

### Verified baseline

The inspected `main` head is `928bb79ce00a2de749d127dcc5cb8299de788a15`, merge PR #325 / RT-002F.

### Implemented facts

The repository states that it remains in a foundation-building stage containing doctrine, schema, extraction/handoff and validation-hardening work, with mature runtime state still future work. The README assigns future truth, entity state, commands, deltas, event commits, context packets, hidden-information partitioning, persistence and replay to the backend, and denies those powers to the language model.

The current runtime slice provides narrow RT-001/RT-002 identity/reference, projection, object-lever legality, transaction-preview, event/state-delta and replay/audit fixtures. It does not implement generalized positions, coordinate frames, topology, distance, movement, occupancy, portals, collision, navigation or cross-partition transfer.

### Conversion-only surfaces

Current location, site, region, range, map, route, travel, navigation, movement, vehicle, encounter and source-local spatial fields are conversion records or procedure pressures. Batch B deliberately avoids defining exact distance, speed, travel-time, navigation, terrain or route mechanics. Batch C location/site/region/map records are conversion grammar rather than runtime spatial authority.

### Narrative-only surfaces

Scene descriptions, location prose, map prose, route narration, travel summaries, target descriptions and context-packet wording are non-authoritative presentation surfaces.

### Fifty-question diagnosis

| # | Question | Determination |
| --- | --- | --- |
| 1 | Is authoritative spatial state represented? | No. Repository runtime remains future-facing; RT-002 is an object/lever fixture. |
| 2 | Are locations distinct from positions? | Not in implemented runtime. Conversion doctrine uses location/site/region records without authoritative position ownership. |
| 3 | Are positions distinct from coordinates? | No generalized implementation exists. |
| 4 | Are spaces or spatial domains represented? | No authoritative SpatialDomain registry exists. |
| 5 | Are reference frames represented? | No. |
| 6 | Are coordinate transforms represented? | No. |
| 7 | Are scale and resolution represented? | Only as conversion or descriptive pressure, not runtime authority. |
| 8 | Are extents and footprints represented? | No generalized runtime contracts. |
| 9 | Are point and region-valued positions supported? | No. |
| 10 | Is uncertain position represented? | No authoritative spatial uncertainty state. |
| 11 | Are containment and overlap represented? | Only incidental object/owner references; no generalized spatial relations. |
| 12 | Are adjacency and connectivity separated? | No generalized topology implementation. |
| 13 | Are boundaries represented authoritatively? | No. |
| 14 | Are spatial boundaries distinct from environmental and legal boundaries? | Doctrine requires this separation; implementation is absent. |
| 15 | Are distance metrics registered? | No. |
| 16 | Can several metrics coexist? | Not implemented. |
| 17 | Are path length, travel time, and movement cost separated? | Batch B warns against universalization, but no runtime model exists. |
| 18 | Is proximity purpose-specific? | Not implemented. |
| 19 | Is reachability represented? | No. |
| 20 | Are reachability and path knowledge separated? | No runtime implementation; AFQR-10 and AFQR-18 doctrine require separation. |
| 21 | Are paths and routes represented? | Conversion/travel fields only; no authoritative path registry. |
| 22 | Are route versions and validity intervals represented? | No. |
| 23 | Is movement represented as authoritative transition? | No. |
| 24 | Are departure, transit, crossing, and arrival separated? | No. |
| 25 | Is intermediate movement state represented? | No. |
| 26 | Are collisions or obstructions represented? | No generalized spatial collision owner. |
| 27 | Are occupancy and capacity represented? | No. |
| 28 | Are moving frames represented? | No. |
| 29 | Are passengers and platform positions separated? | No authoritative implementation. |
| 30 | Are nested interiors represented? | Conversion schemas may describe vehicles/locations; runtime nested space is absent. |
| 31 | Are portals represented? | Only potential source-local/conversion content, not runtime portal state. |
| 32 | Are portal existence, activation, transit, and arrival separated? | No. |
| 33 | Is teleportation represented without assuming zero-distance ordinary movement? | No runtime representation. |
| 34 | Are orientation and facing represented? | No generalized runtime state. |
| 35 | Are line of sight and line of effect separated? | No finalized spatial query contracts. |
| 36 | Is navigation represented? | Batch B travel/navigation procedure pressure only. |
| 37 | Are maps separated from truth? | Doctrine says maps are records/claims rather than truth; no runtime map owner. |
| 38 | Can navigation beliefs and maps be wrong? | Architecturally required, not implemented. |
| 39 | Can hidden routes remain invisible to the model? | General hidden-information doctrine exists; spatial-specific enforcement is absent. |
| 40 | Are cross-partition transfers represented? | No. |
| 41 | Can movement commit atomically across owners? | AFQR-01 requires atomic plans, but no spatial coordinator exists. |
| 42 | Are movement retries idempotent? | AFQR-02 requires idempotency, but no movement implementation exists. |
| 43 | Are spatial simulation tiers represented? | Not in repository runtime. |
| 44 | Can promotion preserve unknown history? | Accepted AFQR doctrine requires it; implementation absent. |
| 45 | Are terrain and environment consumers of spatial support? | AFQR-17 establishes this architectural dependency; repository implementation absent. |
| 46 | Are travel systems consumers rather than spatial owners? | Batch B doctrine supports this boundary; no runtime consumer exists. |
| 47 | Which spatial fields are conversion-only? | Location, site, region, map, route, range, travel, navigation, encounter and source-local spatial descriptors. |
| 48 | Which are fixture-only? | RT-002 actor/NPC/object/lever references, projection, legality, event-delta and replay fields. |
| 49 | Which are narrative-only? | Location prose, map prose, scene descriptions, route descriptions, narration and context-packet wording. |
| 50 | What implementation remains blocked? | All authoritative spatial domains, frames, positions, topology, metrics, reachability, movement, occupancy, collision, portals, navigation and cross-partition transfer. |

### Implementation gaps and blocked work

There is no authoritative spatial-domain registry, frame transform graph, position owner, support/extent registry, dynamic topology, metric registry, reachability evaluator, movement coordinator, occupancy manager, collision owner, portal lifecycle, navigation-state owner, cross-partition transfer protocol, simulation-tier authority partition, or spatial model-output validator. All authoritative spatial mutation remains blocked.

## Part III — External research synthesis

The research pass adopts architecture and rejects universalization. Coordinate, topology, geometry, path planning, navigation, collision, maps, virtual networks and source-local spaces each contribute bounded mechanisms.

| # | Family | Actual mechanism | Astra lesson | Limitation | Disposition |
| --- | --- | --- | --- | --- | --- |
| 1 | Mathematical topology | Topological spaces distinguish neighborhoods, interiors, closures, boundaries, connected components and quotient constructions independently of metric geometry. | Represent topology as a registered family separate from geometry and distance; permit unusual and changing adjacency. | Abstract topology alone does not supply collision, movement cost, coordinates or source-local meaning. | adapt |
| 2 | Computational geometry | Robust geometry systems model points, curves, surfaces, volumes, containment and intersection, and warn that exact predicates and degenerate cases matter. | Use versioned predicate and precision profiles; preserve incomparable or unresolved results under degeneracy. | Euclidean geometric predicates do not cover graph, zone, virtual or metaphysical domains. | adapt |
| 3 | Graph theory and network topology | IETF RFC 8345 models generic networks with nodes, links, termination points, layering and technology-specific augmentation. | Use directed multigraph and hypergraph primitives with explicit endpoints, layers, direction and operational state. | Network connectivity is not physical geometry, metric distance or movement permission. | adopt_as_interchange_pattern |
| 4 | Geographic information systems | OGC standards separate coordinate reference systems, coordinate operations, geometry types, topology, scale and navigation-oriented indoor models. | Coordinates require declared CRS/frame/units; maps and geometries remain representations over authoritative support. | Earth-centric CRS standards cannot be universal for orbital, virtual or source-local domains. | adapt |
| 5 | Robotics and motion planning | OMPL treats planning as a search in a state/configuration space under explicit constraints and termination conditions. | Reachability and route generation must be actor-, embodiment-, constraint- and budget-specific. | Sampling planners do not provide universal optimality, deterministic semantics or narrative-space support by themselves. | adapt |
| 6 | Navigation | Navigation combines dead reckoning, landmarks, beacons, maps and corrections, each with accumulated error and uncertainty. | Keep navigation fixes and route knowledge in AFQR-10; never update true position from a belief without spatial validation. | Real-world methods assume particular sensors and physics. | adapt |
| 7 | Transportation and routing systems | Transportation networks distinguish topology, capacity, schedules, disruptions, transfers and time-dependent costs. | Routes require validity intervals, capacity and cost manifests; shortest path is not universally best or even comparable. | Transport optimization assumptions do not decide character behavior or source-local travel. | adapt |
| 8 | Physics and reference frames | Relative position and motion depend on frame; rotating and accelerating frames require time-dependent transforms. | Make reference frames state-bearing, nested, versioned and time-valid; retain local and world representations separately. | Classical physical frames cannot define every virtual, symbolic or metaphysical space. | adapt |
| 9 | Orbital and aerospace navigation | Orbital rendezvous and docking depend on relative motion, transfer windows, approach corridors and uncertainty rather than simple straight-line distance. | Use orbital profiles as source/domain specializations with moving frames and temporal reachability. | Full orbital mechanics is out of scope for foundational spatial doctrine. | contain |
| 10 | Spatial databases and indexing | Spatial databases provide typed geometries, region queries, nearest-neighbor indexes and temporal validity, while indexes accelerate queries rather than own truth. | Separate authoritative records from indexes and caches; queries name geometry, metric and validity profile. | Database geometry families do not cover every topology and index results may be approximate. | adapt |
| 11 | Spatiotemporal databases | Moving-object and bitemporal models distinguish valid time, transaction time, trajectories and historical queries. | Every position, transform, topology and route validity record needs explicit time semantics and append-only history. | Database models do not define action legality or physical causality. | adopt |
| 12 | Distributed simulations | Partitioned simulations require ownership, interest management, handoff, ghost data, rollback and deterministic ordering. | Cross-partition movement needs destination reservation, in-transit authority, atomic release/acceptance and duplicate suppression. | Implementation techniques vary and do not settle Astra’s domain semantics. | adapt |
| 13 | Computer graphics and scene graphs | Scene graphs and transform hierarchies represent parent–child transforms, local/world coordinates and bounding volumes. | Use hierarchical transforms for moving platforms and nested spaces, but keep scene representation subordinate to authoritative state. | Rendering graphs optimize presentation and culling; they are not simulation truth owners. | adapt |
| 14 | Game navigation and level topology | Navigation meshes, off-mesh links and hierarchical graphs support traversable surfaces, special transitions and dynamic obstacles. | Represent path supports and portal-like transitions as profile-specific navigation structures rather than universal geometry. | Engine navigation data is implementation-specific, often approximate and actor-dependent. | contain |
| 15 | Multi-agent movement and crowd simulation | Crowd systems distinguish global paths, local avoidance, capacity, bottlenecks, priorities and deadlocks. | Separate route planning, local collision avoidance, formation occupancy and crowd capacity; bound multi-agent candidate generation. | Crowd models often assume homogeneous agents and Euclidean local motion. | adapt |
| 16 | Visibility sensing and path queries | Geometric line of sight, occlusion, field of view and sensor coverage are prerequisites, not perception or knowledge. | Return line-of-sight, line-of-effect and sensor-geometry candidates only; AFQR-10 and action owners decide detection and use. | Ray models do not cover diffraction, network paths, magical senses or uncertainty universally. | adapt |
| 17 | Indoor underground and built-space topology | IndoorGML separates indoor space topology and navigation networks from building geometry and supports different contexts. | Use room/compartment topology, doors, corridors and vertical transitions as specialized domain models over shared primitives. | IndoorGML is Earth-building-oriented and not a full runtime movement model. | adapt |
| 18 | Maritime aerial and volumetric navigation | COLREGs distinguish visibility conditions, risk assessment, safe speed, traffic lanes, priorities and collision-avoidance action. | Collision avoidance is profile- and context-specific; geometry, observation, priority and action remain distinct. | Maritime legal rules are not universal movement law. | contain |
| 19 | Virtual network and information spaces | Network topologies distinguish nodes, links, addressing, routing and logical overlays from physical infrastructure. | Support logical/virtual domains and mappings without converting latency or hops into physical distance. | Protocol topology does not imply agency, security access or physical location. | adapt |
| 20 | Cognitive maps and spatial knowledge | Research distinguishes landmark, route and survey knowledge and documents systematic distortions and navigation errors. | Represent map, route and landmark knowledge as provenance-bearing AFQR-10 state that may be partial or false. | Human cognitive findings cannot be universalized to every species or AI. | adapt |
| 21 | Non-Euclidean and source-local spaces | Portal and non-Euclidean simulations can alter adjacency, orientation, path length and interior/exterior relations without one global Euclidean embedding. | Permit source-local topology, directed metrics, recursive interiors and bridge-gated transforms. | No one formal model covers all metaphysical or conceptual spaces. | contain |
| 22 | Games and simulation systems | Official engine and simulation materials use grids, navmeshes, portals, streaming partitions, range abstractions and nested transforms for different needs. | Treat each representation as a profile or simulation tier; no engine data structure becomes Astra doctrine. | Commercial systems optimize specific genres and rendering/runtime constraints. | contain |
| 23 | TTRPG systems | TTRPGs use grids, zones, range bands, movement points, chases, point crawls, hexcrawls, teleport rules and theater-of-the-mind abstractions. | Extract donor semantics into pressure IR and map directly, normalize, retain source-locally, quarantine or escalate. | Rules compress time, distance and action economy differently and cannot be compared by labels alone. | contain |

Representative sources and provenance are recorded in `research/external_research_synthesis.yaml`.

## Part IV — Canonical terminology

The canonical terminology registry contains 134 definitions. Terms such as *location*, *near*, *range*, *adjacent*, *reachable*, *path*, *move*, *arrived*, *portal* and *map position* are prohibited at runtime mutation boundaries without profile, owner, frame, purpose and time qualification.

### Definitions

| Term | Definition | Anti-collapse rule |
| --- | --- | --- |
| space | An unqualified conceptual category for spatial possibility; never an authoritative runtime record by itself. | space must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial domain | A registered owner-scoped domain declaring applicable topology, geometry, frames, metrics, movement and source-local profiles. | spatial domain must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial model | A typed AFQR-18 spatial foundations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | spatial model must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| reference frame | A versioned basis relative to which position, orientation or motion may be represented. | reference frame must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| coordinate system | A representation scheme for tuples inside a declared frame or coordinate reference; not place identity. | coordinate system must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| coordinate reference | A typed AFQR-18 spatial foundations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | coordinate reference must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| transform | A typed AFQR-18 spatial foundations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | transform must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| topology | The versioned connectivity, incidence, neighborhood and continuity structure of a spatial domain. | topology must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| geometry | A profile of shapes, dimensions and spatial predicates over a support representation. | geometry must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| scale | A typed AFQR-18 spatial foundations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | scale must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| resolution | A typed AFQR-18 spatial foundations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | resolution must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial support | The point, region, set, path, surface, volume, graph node set or source-local support occupied or referenced. | spatial support must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| extent | A bounded or otherwise qualified spatial support describing how far an entity or region spans. | extent must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| footprint | An embodiment-supplied support used for occupancy, clearance or collision under a named profile. | footprint must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| occupied support | The authoritative support reserved or occupied by an entity at a valid time. | occupied support must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial uncertainty | A bounded epistemic or representational statement that authoritative support is not exactly known to an audience. | spatial uncertainty must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| place | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | place must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| location | A qualified spatial or place reference used for a stated purpose; prohibited unqualified at mutation boundaries. | location must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| position | A time-scoped authoritative or candidate spatial support relation for an entity, distinct from coordinates. | position must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| site | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | site must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| region | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | region must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| zone | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | zone must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| cell | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | cell must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| node | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | node must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| waypoint | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | waypoint must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| landmark | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | landmark must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| coordinate | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | coordinate must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| relative position | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | relative position must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| absolute position | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | absolute position must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| estimated position | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | estimated position must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| hidden position | A typed AFQR-18 place position construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | hidden position must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| containment | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | containment must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| interior | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | interior must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| exterior | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | exterior must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| overlap | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | overlap must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| intersection | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | intersection must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| contact | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | contact must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| adjacency | A topology-profile relation indicating neighboring supports; it does not imply reachability or interaction. | adjacency must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| incidence | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | incidence must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| separation | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | separation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| boundary | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | boundary must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| interface | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | interface must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| connection | A typed potentially directed relation supporting a class of transitions subject to state and conditions. | connection must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| crossing | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | crossing must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| co-location | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | co-location must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial presence | A typed AFQR-18 spatial relations construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | spatial presence must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| metric | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | metric must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| distance | A metric-profile result between qualified endpoints at a frame, scale and time. | distance must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| path length | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | path length must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| graph distance | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | graph distance must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| geodesic distance | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | geodesic distance must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| proximity | A purpose-scoped classification derived under a named metric or relation profile. | proximity must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| range | A qualified threshold or interval relevant to a particular interface or action family; not universal distance. | range must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| range band | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | range band must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| bearing | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | bearing must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| heading | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | heading must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| facing | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | facing must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| orientation | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | orientation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| attitude | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | attitude must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| elevation | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | elevation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| altitude | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | altitude must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| depth | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | depth must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| relative velocity | A typed AFQR-18 distance orientation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | relative velocity must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| reachability | A determination that a destination can be reached under a named movement family, actor, constraints, time and purpose. | reachability must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| accessibility | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | accessibility must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| passability | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | passability must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| traversability | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | traversability must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| navigability | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | navigability must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| path | An authoritative or candidate ordered support through a spatial topology. | path must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| route | A plan or operational sequence using one or more paths and possibly nonspatial constraints. | route must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| corridor | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | corridor must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| lane | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | lane must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| segment | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | segment must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| path validity | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | path validity must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| route knowledge | AFQR-10 epistemic state describing what a subject knows or believes about routes. | route knowledge must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| route cost | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | route cost must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| travel-time estimate | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | travel-time estimate must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| portal chain | A typed AFQR-18 reachability paths construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | portal chain must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| movement | A typed process that may change position, occupancy or containment over logical time. | movement must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| displacement | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | displacement must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| traversal | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | traversal must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| trajectory | A time-parameterized or abstract ordered movement support, not necessarily continuous geometry. | trajectory must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| departure | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | departure must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| transit | A lawful intermediate state between departure and arrival. | transit must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| crossing event | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | crossing event must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| arrival | A determination that destination support and required occupancy relations were successfully established. | arrival must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| entry | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | entry must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| exit | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | exit must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| embarkation | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | embarkation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| disembarkation | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | disembarkation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| pursuit | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | pursuit must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| interception | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | interception must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| forced movement | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | forced movement must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| involuntary movement | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | involuntary movement must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| teleportation | A nonlocal transition family that does not traverse an ordinary spatial path unless its source-local profile says so. | teleportation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| phasing | A typed AFQR-18 movement construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | phasing must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| occupancy | A profile-scoped relation between an entity support and capacity-bearing support. | occupancy must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| capacity | A typed AFQR-18 occupancy obstruction construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | capacity must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| clearance | A typed AFQR-18 occupancy obstruction construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | clearance must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| collision | A spatial determination that swept supports intersect under a named collision profile; harm remains AFQR-16. | collision must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| obstruction | A typed AFQR-18 occupancy obstruction construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | obstruction must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| blocking | A typed AFQR-18 occupancy obstruction construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | blocking must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| crowding | A typed AFQR-18 occupancy obstruction construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | crowding must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| formation | A typed AFQR-18 occupancy obstruction construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | formation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| swept support | A typed AFQR-18 occupancy obstruction construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | swept support must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| dynamic obstacle | A typed AFQR-18 occupancy obstruction construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | dynamic obstacle must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| moving platform | A typed AFQR-18 occupancy obstruction construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | moving platform must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| nested space | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | nested space must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| navigation | Epistemically bounded planning and correction toward a spatial goal; it does not own true position. | navigation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| route planning | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | route planning must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| route following | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | route following must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| navigation fix | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | navigation fix must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| survey | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | survey must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| map | A versioned AFQR-10 proposition set representing spatial claims with coverage, resolution, age and provenance. | map must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| chart | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | chart must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| floor plan | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | floor plan must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial observation | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | spatial observation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial estimate | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | spatial estimate must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| coverage | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | coverage must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| map resolution | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | map resolution must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| map provenance | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | map provenance must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| frame transform validity interval | A typed AFQR-18 navigation representation construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | frame transform validity interval must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| position temporal validity | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | position temporal validity must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| region-valued position | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | region-valued position must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| distributed spatial support | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | distributed spatial support must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial hyperedge | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | spatial hyperedge must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| metric incomparability | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | metric incomparability must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| conditional reachability | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | conditional reachability must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| in-transit authority | The temporary owner responsible for an entity between source release and destination acceptance. | in-transit authority must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| destination reservation | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | destination reservation must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| portal connection state | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | portal connection state must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| portal transit state | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | portal transit state must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial simulation tier | A registered level of materialized spatial authority and detail. | spatial simulation tier must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |
| spatial authority partition | A typed AFQR-18 advanced spatiotemporal construct whose meaning is fixed by its registered profile, owner, validity interval, and purpose. | spatial authority partition must not be used as a synonym for adjacent spatial, epistemic, movement, environmental, embodiment, or model-narrative concepts. |

### Binding anti-collapse laws

The core separation laws in the question are accepted. In particular:

- topology is not geometry, metric or map;
- position is not coordinates;
- adjacency is not reachability;
- distance is not travel time, cost or path length;
- route knowledge is not path truth;
- movement declaration is not movement execution;
- portal connection is not activation, transit or arrival;
- line of sight is not observation;
- map claims and navigation fixes are AFQR-10 epistemic records;
- model prose cannot own position, route, movement, collision or arrival.

## Part V — Spatial domains, frames, and coordinates

A `SpatialDomainDefinition` declares the family of space being modeled and binds the authoritative owners for domain identity, frames, topology, metrics, movement, portals and source-local bridges. It may be coordinate-free.

Reference frames are state-bearing where dynamic. A frame has an origin binding, orientation state, motion state, parent binding and validity interval. Transforms are versioned adapters evaluated for a specific time. A transform can succeed, introduce bounded uncertainty, be inapplicable, be incomparable, or remain unavailable.

Coordinates are tuples interpreted under a `CoordinateSystemDefinition`; they require dimensions, units, frame/CRS, precision and validity. Coordinates are representations of a position and cannot create place identity or authoritative occupancy.

Moving, rotating, accelerating, body-relative, platform-relative, orbital, virtual, graph, dream, psychic, interplanar and source-local frames are supported through registered profiles rather than one global frame.

## Part VI — Positions, supports, extents, and scale

Authoritative position is a time-scoped relation between an entity and a spatial support in a domain. Supported forms include exact point, cell, node, region-valued, uncertain region, extended extent, surface, path, distributed set, multi-region support, hidden support, lawful in-transit support and unresolved support.

`SpatialSupportDefinition` is representation-neutral. `SpatialExtentState`, `FootprintState`, `OccupiedSupportState` and collision support are separate. AFQR-16 supplies embodiment-derived extents and footprints; AFQR-18 owns their accepted spatial placement and occupancy relations.

Scale and resolution are explicit metadata. Microscopic, body, room, site, regional, planetary, orbital, interstellar, interplanar, abstract-zone and source-local scales may use different representations. Scale never selects one geometry automatically.

## Part VII — Topology and spatial relations

Spatial topology is versioned and may contain nodes, directed or undirected edges, hyperedges, incidence relations, layers and dynamic connection state. It can represent region graphs, indoor spaces, route networks, portals, virtual networks and source-local adjacency without requiring a Euclidean embedding.

Containment, overlap, intersection, contact, adjacency, incidence, separation, boundary, connection and crossing are distinct relation families evaluated for named supports, frames, topology versions and validity times.

AFQR-18 owns boundary support and spatial relation. AFQR-17 owns environmental permeability and containment effects; AFQR-16 owns structural boundary integrity; AFQR-15 owns legal borders and jurisdiction. A shared support may back several boundary families without collapsing their meanings.

## Part VIII — Metrics, distance, proximity, and range

Every distance query binds endpoint semantics, frame, metric, scale, time, units, precision and uncertainty. Endpoints may be centers, surfaces, interfaces, regions, nodes or other qualified supports.

Euclidean, geodesic, graph, directed, asymmetric, path-length, topological, range-band and source-local metrics may coexist. Travel time and resource cost are derived under separate profiles and are not distance.

Proximity is purpose-scoped. An entity can be near for communication, far by traversable path, adjacent in a graph, outside weapon range and incomparable in a conceptual metric at the same time. `MetricIncomparabilityReceipt` is a lawful result.

## Part IX — Reachability, accessibility, paths, and routes

Reachability is evaluated for an origin, destination, movement family, embodiment, footprint, equipment, capability, terrain, environment, boundaries, portals, permissions, time, resources and purpose. Outcomes include reachable, conditionally reachable, unreachable, unknown, incomplete and unresolved.

Path truth, candidate paths, planned routes, known routes and believed routes remain separate. Path generation is bounded by candidate and query budgets. Dynamic paths have validity intervals and can be invalidated by obstacles, topology transitions, portal changes, capacity or environmental state.

Route cost can include time, resources, risk, legal constraints and source-local costs, but these dimensions are not collapsed into a universal scalar unless a registered profile explicitly does so.

## Part X — Movement, trajectories, crossings, and arrival

Movement proceeds through typed command, attempt, state-basis freeze, segment or trajectory planning, destination reservation, departure, transit, crossing, interruption and arrival stages.

A movement command does not move an entity. A planned route does not become a committed trajectory. Arrival requires destination support and occupancy acceptance. Interrupted movement must leave the entity at its last committed support or under an explicit in-transit authority.

Movement may be continuous, discrete, abstract, graph-based, orbital, carried, forced, involuntary, portal-mediated, teleported, phased, network-based or source-local. Each family declares whether intermediate supports are material.

## Part XI — Occupancy, capacity, collision, and obstruction

Occupancy is a profile-scoped relation between an entity support and a capacity-bearing support. Exclusive, shared, stacked, crowded, degraded, formation, seating, cargo, compartment, swarm and distributed occupancy are supported.

Capacity, clearance and footprint are qualified; legal capacity, environmental capacity and physical clearance do not substitute for each other.

Collision uses swept supports and validity intervals under a named collision profile. Overlap may be lawful without collision. Phasing, priority, avoidance, squeezing and dynamic obstacles are explicit. AFQR-18 determines collision or obstruction spatially; AFQR-16 owns impact transfer, damage and injury.

## Part XII — Moving frames and nested spaces

Moving containers have local frames and world transforms. A passenger can remain stationary in a vehicle frame while moving in a ship or planetary frame. Parent-frame motion does not rewrite local movement history.

Nested spaces may represent rooms in ships, elevators, carried containers, vehicles, pocket dimensions, summoned interiors, virtual control spaces and larger-inside-than-outside spaces. Independent topology and source-local transforms are supported.

A container crossing a partition requires coordinated transfer of its frame, occupant bindings and authoritative support without duplicating occupants.

## Part XIII — Portals and nonlocal transitions

A portal is not an edge that is always traversable. The architecture separates definition, instance, endpoints, connection state, direction, eligibility, activation, transit, destination resolution, arrival support and continuity.

One-way, keyed, conditional, unstable, destination-changing, splitting, network, ritual and interplanar portals are supported. Teleportation and phasing are nonlocal transition families, not zero-distance walking.

Portal use requires source-interface contact, action and resource validation where applicable, a lawful transit state and destination occupancy reservation. Side effects route to environmental, embodiment, identity or source-local owners.

## Part XIV — Visibility and targeting spatial handoffs

AFQR-18 may return spatial candidates for line of sight, line of effect, area inclusion, range eligibility, firing arcs, sensor geometry and communication paths.

These candidates do not establish observation, detection, recognition, target legality, attack success, communication delivery or effect. AFQR-10, AFQR-14, AFQR-03, AFQR-16 and the future conflict architecture retain those decisions.

Cover geometry is not protection effect; concealment is not line-of-sight obstruction; sensor coverage is not detection.

## Part XV — Navigation, maps, and spatial knowledge

Navigation consumes the navigator's authorized AFQR-10 state: maps, landmarks, route knowledge, sensor readings, dead reckoning, coordinate fixes, beacons and uncertainty. It never receives omniscient spatial truth unless access is explicitly authorized.

Route planning generates bounded plans over believed and authoritative supports while preserving their distinction. Navigation fixes can be accurate, biased, uncertain, stale or false. Becoming lost updates epistemic/navigation state, not true position.

Maps, charts, floor plans and route graphs are versioned proposition sets with spatial-reference bindings, coverage, resolution, age and provenance. They may omit, distort or falsify features.

## Part XVI — Cross-partition movement and deterministic replay

Cross-partition movement uses:

1. frozen source state;
2. destination eligibility and capacity reservation;
3. source release candidate;
4. explicit in-transit authority;
5. destination acceptance;
6. one AFQR-01 atomic commit plan;
7. idempotency and invariant receipts.

A source release cannot commit alone unless a valid in-transit owner assumes authority. Partial failures abort or remain in a lawful transit state. Duplicate retries cannot produce duplicate occupancy.

Replay retains domain, frame, transform, topology, metric, path, movement segment, portal and partition profile versions plus deterministic tie-break and precision receipts.

## Part XVII — Hidden spatial state and model projection

Spatial secrecy uses private receipts, audience-scoped tokens, projection-specific digests, constant-shape policy responses, query budgets, candidate-count padding and cross-packet isolation.

The threat model identifies 14 explicit side channels, including route-option cardinality, portal candidate counts, reservation timing, stable digests, map redaction geometry, pathfinding depth, ghost authority and model implicature.

A visible projection may state that no safe route can be established. It must not identify a concealed passage, hidden patrol, secret portal or classified destination unless disclosure is authorized.

Generated prose is validated semantically against permitted claim kinds and evidence bindings. Regeneration cannot choose a new authoritative movement or reveal hidden alternatives.

## Part XVIII — Typed contracts

The binding contract catalog contains **258** contracts. Every record includes the common authoritative envelope:

```yaml
record_id: string
schema_version: string
record_status: candidate|determined|committed|rejected|unresolved|unverifiable
authoritative_owner_ref: reference
source_local_namespace: string
policy_version_refs: [reference]
recorded_time: logical_or_bitemporal_value
logical_time: deterministic_order_value
private_integrity_commitment: audience_protected_digest
```

Optional temporal and cross-domain fields are record-specific. Omitted times or bases must not be inferred. Every contract prohibits model-authored spatial truth, implicit global coordinates, map-equals-territory, route-plan-equals-path, intent-equals-arrival, adjacency-equals-reachability, raw hidden state and freeform mutation.

### Contract index and specialized required fields

| Contract | Family | Owner | Specialized required fields |
| --- | --- | --- | --- |
| SpatialDomainDefinition | domain | spatial_domain_owner | private_integrity_commitment, spatial_domain_ref, spatial_model_profile_ref, topology_profile_ref, metric_profile_refs, movement_profile_refs |
| SpatialDomainInstance | domain | spatial_domain_owner | private_integrity_commitment, spatial_domain_ref, spatial_model_profile_ref, topology_profile_ref, metric_profile_refs, movement_profile_refs |
| SpatialStateAuthorityBinding | domain | spatial_domain_owner | private_integrity_commitment, spatial_domain_ref, spatial_model_profile_ref, topology_profile_ref, metric_profile_refs, movement_profile_refs |
| SpatialFamilyOwnerBinding | domain | spatial_domain_owner | private_integrity_commitment, spatial_domain_ref, spatial_model_profile_ref, topology_profile_ref, metric_profile_refs, movement_profile_refs |
| SpatialDomainContinuityProfile | domain | spatial_domain_owner | private_integrity_commitment, spatial_domain_ref, spatial_model_profile_ref, topology_profile_ref, metric_profile_refs, movement_profile_refs |
| SpatialDomainContinuityDetermination | domain | spatial_domain_owner | private_integrity_commitment, spatial_domain_ref, spatial_model_profile_ref, topology_profile_ref, metric_profile_refs, movement_profile_refs |
| SpatialDomainLineageEdge | domain | spatial_domain_owner | private_integrity_commitment, spatial_domain_ref, spatial_model_profile_ref, topology_profile_ref, metric_profile_refs, movement_profile_refs |
| ReferenceFrameDefinition | frame | reference_frame_owner | spatial_domain_ref, reference_frame_ref, parent_frame_ref, origin_binding_ref, transform_profile_ref, validity_interval |
| ReferenceFrameInstance | frame | reference_frame_owner | spatial_domain_ref, reference_frame_ref, parent_frame_ref, origin_binding_ref, transform_profile_ref, validity_interval |
| FrameOriginBinding | frame | reference_frame_owner | spatial_domain_ref, reference_frame_ref, parent_frame_ref, origin_binding_ref, transform_profile_ref, validity_interval |
| FrameOrientationState | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| FrameMotionState | frame | reference_frame_owner | spatial_domain_ref, reference_frame_ref, parent_frame_ref, origin_binding_ref, transform_profile_ref, validity_interval |
| FrameParentBinding | frame | reference_frame_owner | spatial_domain_ref, reference_frame_ref, parent_frame_ref, origin_binding_ref, transform_profile_ref, validity_interval |
| FrameTransformDefinition | frame | reference_frame_owner | spatial_domain_ref, reference_frame_ref, parent_frame_ref, origin_binding_ref, transform_profile_ref, validity_interval |
| FrameTransformCandidate | frame | reference_frame_owner | spatial_domain_ref, reference_frame_ref, parent_frame_ref, origin_binding_ref, transform_profile_ref, validity_interval |
| FrameTransformDetermination | frame | reference_frame_owner | spatial_domain_ref, reference_frame_ref, parent_frame_ref, origin_binding_ref, transform_profile_ref, validity_interval |
| FrameTransformValidityInterval | frame | reference_frame_owner | spatial_domain_ref, reference_frame_ref, parent_frame_ref, origin_binding_ref, transform_profile_ref, validity_interval |
| CoordinateSystemDefinition | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| CoordinateTuple | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| CoordinateValidityProfile | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| AuthoritativePositionState | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| PositionCandidate | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| PositionDetermination | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| PositionUncertaintyRegion | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| PositionTemporalValidity | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| ObservedPositionBinding | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| EstimatedPositionBinding | position_coordinate | position_owner | entity_ref, spatial_domain_ref, reference_frame_ref, coordinate_system_ref, position_support_ref, position_validity_interval |
| SpatialSupportDefinition | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| SpatialSupportInstance | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| SpatialExtentDefinition | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| SpatialExtentState | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| FootprintDefinition | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| FootprintState | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| OccupiedSupportState | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| DistributedSpatialSupport | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| SpatialSupportCompletenessStatus | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| SpatialTopologyDefinition | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| SpatialTopologyInstance | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| SpatialNode | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| SpatialEdge | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| SpatialHyperedge | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| SpatialIncidenceRelation | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| SpatialAdjacencyRelation | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| SpatialConnectivityState | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| TopologyTransitionCandidate | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| TopologyTransitionReceipt | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| SpatialRelationDefinition | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| SpatialRelationCandidate | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| SpatialRelationDetermination | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| ContainmentRelation | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| OverlapRelation | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| ContactRelation | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| SeparationRelation | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| BoundaryRelation | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| SpatialRelationEvidenceClosure | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| SpatialRelationValidityInterval | relation_boundary | spatial_relation_owner | subject_support_refs, relation_family, frame_ref, topology_version, relation_validity_interval, evidence_closure_ref |
| SpatialMetricDefinition | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| SpatialMetricApplicabilityProfile | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| DistanceQuery | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| DistanceEndpointBinding | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| DistanceCandidate | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| DistanceDetermination | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| ProximityProfile | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| ProximityDetermination | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| RangeBandDefinition | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| MetricIncomparabilityReceipt | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| OrientationDefinition | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| OrientationState | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| FacingState | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| HeadingState | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| BearingCandidate | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| BearingDetermination | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| RelativePositionState | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| VelocityState | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| RelativeVelocityState | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| ApproachState | orientation_motion | relative_motion_owner | private_integrity_commitment, entity_ref, reference_frame_ref, orientation_or_motion_state, validity_interval, uncertainty_manifest_ref |
| ReachabilityQuery | reachability | reachability_owner | origin_support_ref, destination_support_ref, purpose_ref, movement_family_ref, constraint_set_ref, input_closure_ref |
| ReachabilityPurpose | reachability | reachability_owner | origin_support_ref, destination_support_ref, purpose_ref, movement_family_ref, constraint_set_ref, input_closure_ref |
| MovementFamilyReference | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| ReachabilityInputClosure | reachability | reachability_owner | origin_support_ref, destination_support_ref, purpose_ref, movement_family_ref, constraint_set_ref, input_closure_ref |
| ReachabilityCandidate | reachability | reachability_owner | origin_support_ref, destination_support_ref, purpose_ref, movement_family_ref, constraint_set_ref, input_closure_ref |
| ReachabilityDetermination | reachability | reachability_owner | origin_support_ref, destination_support_ref, purpose_ref, movement_family_ref, constraint_set_ref, input_closure_ref |
| ReachabilityConstraintSet | reachability | reachability_owner | origin_support_ref, destination_support_ref, purpose_ref, movement_family_ref, constraint_set_ref, input_closure_ref |
| ReachabilityFailureReason | reachability | reachability_owner | origin_support_ref, destination_support_ref, purpose_ref, movement_family_ref, constraint_set_ref, input_closure_ref |
| ReachabilityUncertaintyManifest | reachability | reachability_owner | origin_support_ref, destination_support_ref, purpose_ref, movement_family_ref, constraint_set_ref, input_closure_ref |
| PathSupportDefinition | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| PathCandidate | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| PathSegment | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| PathBoundarySequence | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| PathValidityInterval | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| PathCompletenessStatus | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| RouteDefinition | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| RoutePlan | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| RouteSegmentPlan | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| RouteKnowledgeBinding | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| RouteCostManifest | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| RouteValidityDetermination | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| MovementDefinition | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementCommandReference | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementAttempt | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementStateBasis | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementTrajectoryCandidate | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementSegmentCandidate | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementSegmentDetermination | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementTransitionPlan | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementTransitionReceipt | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementInterruptionRecord | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| ArrivalDetermination | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| OccupancyDefinition | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| OccupancyState | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| OccupancyCandidate | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| OccupancyDetermination | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| SpatialCapacityDefinition | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| SpatialCapacityState | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| ClearanceProfile | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| CrowdingProfile | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| FormationSpatialProfile | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| OccupancyConflictSet | occupancy_capacity | occupancy_owner | spatial_support_ref, occupant_refs, footprint_refs, capacity_profile_ref, clearance_profile_ref, validity_interval |
| CollisionProfile | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| CollisionCandidate | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| CollisionDetermination | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| SweptSupportRecord | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| ObstructionDefinition | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| ObstructionState | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| PassageClearanceCandidate | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| PassageClearanceDetermination | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| CollisionAvoidanceCandidate | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| CollisionSpatialHandoff | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| MovingSpatialContainerDefinition | nested_moving_frame | nested_space_owner | container_ref, contained_frame_ref, local_position_ref, world_transform_ref, nested_space_binding_ref, validity_interval |
| MovingSpatialContainerInstance | nested_moving_frame | nested_space_owner | container_ref, contained_frame_ref, local_position_ref, world_transform_ref, nested_space_binding_ref, validity_interval |
| ContainedFrameBinding | nested_moving_frame | nested_space_owner | container_ref, contained_frame_ref, local_position_ref, world_transform_ref, nested_space_binding_ref, validity_interval |
| ContainerRelativePosition | nested_moving_frame | nested_space_owner | container_ref, contained_frame_ref, local_position_ref, world_transform_ref, nested_space_binding_ref, validity_interval |
| ContainerWorldTransform | nested_moving_frame | nested_space_owner | container_ref, contained_frame_ref, local_position_ref, world_transform_ref, nested_space_binding_ref, validity_interval |
| NestedSpaceDefinition | nested_moving_frame | nested_space_owner | container_ref, contained_frame_ref, local_position_ref, world_transform_ref, nested_space_binding_ref, validity_interval |
| NestedSpaceBinding | nested_moving_frame | nested_space_owner | container_ref, contained_frame_ref, local_position_ref, world_transform_ref, nested_space_binding_ref, validity_interval |
| NestedSpaceTransitionCandidate | nested_moving_frame | nested_space_owner | container_ref, contained_frame_ref, local_position_ref, world_transform_ref, nested_space_binding_ref, validity_interval |
| NestedSpaceTransitionReceipt | nested_moving_frame | nested_space_owner | container_ref, contained_frame_ref, local_position_ref, world_transform_ref, nested_space_binding_ref, validity_interval |
| PortalDefinition | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalInstance | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalEndpointBinding | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalConnectionState | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalEligibilityProfile | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalActivationCandidate | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalActivationDetermination | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalTransitAttempt | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalTransitState | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalArrivalCandidate | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalArrivalDetermination | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalContinuityProfile | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| LineOfSightSpatialCandidate | visibility_targeting | spatial_query_owner | observer_or_source_ref, target_ref, spatial_query_profile_ref, frame_ref, support_refs, candidate_status |
| LineOfEffectSpatialCandidate | visibility_targeting | spatial_query_owner | observer_or_source_ref, target_ref, spatial_query_profile_ref, frame_ref, support_refs, candidate_status |
| AreaInclusionCandidate | visibility_targeting | spatial_query_owner | observer_or_source_ref, target_ref, spatial_query_profile_ref, frame_ref, support_refs, candidate_status |
| RangeEligibilityCandidate | visibility_targeting | spatial_query_owner | observer_or_source_ref, target_ref, spatial_query_profile_ref, frame_ref, support_refs, candidate_status |
| FiringArcCandidate | visibility_targeting | spatial_query_owner | observer_or_source_ref, target_ref, spatial_query_profile_ref, frame_ref, support_refs, candidate_status |
| SensorGeometryCandidate | visibility_targeting | spatial_query_owner | observer_or_source_ref, target_ref, spatial_query_profile_ref, frame_ref, support_refs, candidate_status |
| CommunicationPathSpatialCandidate | visibility_targeting | spatial_query_owner | observer_or_source_ref, target_ref, spatial_query_profile_ref, frame_ref, support_refs, candidate_status |
| SpatialTargetingHandoff | visibility_targeting | spatial_query_owner | observer_or_source_ref, target_ref, spatial_query_profile_ref, frame_ref, support_refs, candidate_status |
| NavigationMethodDefinition | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| NavigationState | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| NavigationGoal | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| NavigationEvidenceClosure | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| NavigationFixCandidate | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| NavigationFixDetermination | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| RoutePlanningCandidate | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| RoutePlanningResult | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| RouteFollowingState | path_route | path_route_owner | origin_ref, destination_ref, path_or_route_ref, segment_refs, validity_interval, knowledge_binding_ref |
| NavigationErrorRecord | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| LostStateCandidate | spatial_core | spatial_state_owner | private_integrity_commitment, spatial_domain_ref, subject_refs, typed_payload_refs, validity_interval, determination_status |
| NavigationCorrectionRecord | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| SpatialPropositionDefinition | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| MapDefinition | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| MapVersion | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| MapSpatialReferenceBinding | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| MapFeatureClaim | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| MapFeatureGeometryReference | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| MapCoverageManifest | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| MapResolutionProfile | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| RouteKnowledgeRecord | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| LandmarkKnowledgeRecord | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| SpatialSurveyRecord | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| SpatialPartitionDefinition | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| SpatialPartitionOwnerBinding | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| CrossPartitionMovementPlan | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| SourcePartitionReleaseCandidate | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| DestinationPartitionReservation | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| InTransitAuthorityRecord | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| DestinationPartitionAcceptance | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| CrossPartitionMovementCommitPlan | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| CrossPartitionMovementReceipt | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| CrossPartitionMovementAbortReceipt | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| SpatialSimulationTierDefinition | simulation_tier | spatial_materialization_owner | spatial_domain_ref, current_tier_ref, target_tier_ref, authority_partition_ref, input_closure_ref, unknown_history_manifest_ref |
| SpatialMaterializationPolicy | simulation_tier | spatial_materialization_owner | spatial_domain_ref, current_tier_ref, target_tier_ref, authority_partition_ref, input_closure_ref, unknown_history_manifest_ref |
| SpatialPromotionInputClosure | simulation_tier | spatial_materialization_owner | spatial_domain_ref, current_tier_ref, target_tier_ref, authority_partition_ref, input_closure_ref, unknown_history_manifest_ref |
| SpatialPromotionReceipt | simulation_tier | spatial_materialization_owner | spatial_domain_ref, current_tier_ref, target_tier_ref, authority_partition_ref, input_closure_ref, unknown_history_manifest_ref |
| SpatialDemotionRetentionManifest | simulation_tier | spatial_materialization_owner | spatial_domain_ref, current_tier_ref, target_tier_ref, authority_partition_ref, input_closure_ref, unknown_history_manifest_ref |
| SpatialDemotionReceipt | simulation_tier | spatial_materialization_owner | spatial_domain_ref, current_tier_ref, target_tier_ref, authority_partition_ref, input_closure_ref, unknown_history_manifest_ref |
| SpatialAuthorityPartition | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| HistoricalSpatialApproximationRecord | simulation_tier | spatial_materialization_owner | spatial_domain_ref, current_tier_ref, target_tier_ref, authority_partition_ref, input_closure_ref, unknown_history_manifest_ref |
| PrivateSpatialReceipt | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| PrivatePositionReceipt | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| PrivateRouteReceipt | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| PrivatePortalReceipt | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| PrivateMovementReceipt | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| ActorVisibleSpatialProjection | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| ObserverVisibleSpatialProjection | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| PlayerVisibleSpatialProjection | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| ModelVisibleSpatialProjection | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| PublicSpatialProjection | spatial_core | spatial_state_owner | private_integrity_commitment, spatial_domain_ref, subject_refs, typed_payload_refs, validity_interval, determination_status |
| ModelSpatialGroundingManifest | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| PermittedSpatialClaimKindRegistry | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| ModelSpatialEvidenceBinding | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| ModelSpatialOutputValidator | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| CrossPacketSpatialIsolationReceipt | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| SpatialProjectionNoninterferenceReceipt | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| AudienceScopedSpatialToken | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| PrivateSpatialIntegrityCommitment | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| ProjectionSpecificSpatialDigest | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| AFQR18Handoff | handoff | spatial_handoff_coordinator | source_AFQR_ref, destination_AFQR_ref, handoff_kind, typed_payload_refs, basis_closure_ref, acceptance_status |
| CrossAudienceSpatialLinkabilityTest | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| SpatialPrecisionProfile | replay_validation | spatial_audit_owner | subject_record_refs, historical_profile_refs, canonical_input_digest, deterministic_result_digest, validation_status, failure_reasons |
| SpatialDegeneracyReceipt | replay_validation | spatial_audit_owner | subject_record_refs, historical_profile_refs, canonical_input_digest, deterministic_result_digest, validation_status, failure_reasons |
| SpatialPredicateProfile | replay_validation | spatial_audit_owner | subject_record_refs, historical_profile_refs, canonical_input_digest, deterministic_result_digest, validation_status, failure_reasons |
| SpatialPredicateDetermination | replay_validation | spatial_audit_owner | subject_record_refs, historical_profile_refs, canonical_input_digest, deterministic_result_digest, validation_status, failure_reasons |
| SpatialQueryBudget | replay_validation | spatial_audit_owner | subject_record_refs, historical_profile_refs, canonical_input_digest, deterministic_result_digest, validation_status, failure_reasons |
| SpatialCandidateEnumerationReceipt | replay_validation | spatial_audit_owner | subject_record_refs, historical_profile_refs, canonical_input_digest, deterministic_result_digest, validation_status, failure_reasons |
| SpatialPartitionGhostReference | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| SpatialOwnershipLease | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| SpatialOwnershipTransferReceipt | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| MovementIdempotencyReceipt | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| MovementInvariantValidationReceipt | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| DestinationCapacityReservation | partition | cross_partition_coordinator | source_partition_ref, destination_partition_ref, moving_entity_refs, reservation_ref, in_transit_authority_ref, commit_plan_ref |
| CrossingEventRecord | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| EntryEventRecord | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| ExitEventRecord | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| DepartureRecord | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| TransitStateRecord | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| ArrivalRecord | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| PortalSideEffectHandoff | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalFailureReceipt | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| PortalDestinationUncertaintyManifest | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| NavigationMapMismatchReceipt | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| RouteBeliefConflictSet | navigation_map | AFQR10_epistemic_owner | epistemic_subject_ref, map_or_navigation_record_ref, spatial_proposition_refs, coverage_or_uncertainty_ref, provenance_refs, validity_interval |
| DynamicObstacleState | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| MovementPriorityProfile | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| MovementDeadlockRecord | collision_obstruction | collision_spatial_owner | private_integrity_commitment, moving_or_static_support_refs, collision_or_obstruction_profile_ref, swept_support_refs, time_interval, spatial_handoff_ref |
| PursuitState | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| InterceptionCandidate | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| InterceptionDetermination | movement | movement_transition_owner | movement_attempt_ref, moving_entity_ref, origin_support_ref, destination_support_ref, segment_or_trajectory_ref, state_basis_ref |
| AFQR17SpatialSupportClosureReceipt | support_extent | spatial_support_owner | entity_ref, spatial_domain_ref, spatial_support_ref, extent_or_footprint_ref, completeness_status, validity_interval |
| SpatialConversionPressureRecord | spatial_core | spatial_state_owner | private_integrity_commitment, spatial_domain_ref, subject_refs, typed_payload_refs, validity_interval, determination_status |
| SourceLocalSpatialBridgeDefinition | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| SourceLocalSpatialBridgeCertification | portal | portal_transition_owner | portal_ref, endpoint_refs, connection_state_ref, eligibility_profile_ref, activation_or_transit_ref, arrival_support_ref |
| SpatialReplayVerificationReceipt | replay_validation | spatial_audit_owner | subject_record_refs, historical_profile_refs, canonical_input_digest, deterministic_result_digest, validation_status, failure_reasons |
| HistoricalTransformVerificationReceipt | replay_validation | spatial_audit_owner | subject_record_refs, historical_profile_refs, canonical_input_digest, deterministic_result_digest, validation_status, failure_reasons |
| HistoricalMetricVerificationReceipt | metric_distance | spatial_metric_owner | endpoint_bindings, metric_ref, frame_ref, scale_ref, query_time, precision_profile_ref |
| HistoricalTopologyVerificationReceipt | topology | spatial_topology_owner | private_integrity_commitment, spatial_domain_ref, topology_ref, topology_version, node_edge_or_hyperedge_refs, validity_interval |
| SpatialPrivateQueryPaddingReceipt | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |
| SpatialOptionCountNoninterferenceReceipt | security_projection | spatial_projection_security_owner | audience_selector_ref, visible_claim_refs, private_state_commitment_ref, opaque_token_ref, projection_digest_ref, noninterference_profile_ref |

The full schema-level definitions, including required, optional, hidden, derived and prohibited fields; temporal semantics; profile versions; cross-domain bases; security requirements; AFQR references and invariants are binding in `contracts/afqr_18_typed_contract_catalog.yaml`.

## Part XIX — Determination pipelines

### Position determination

`query → entity/domain/frame/time/purpose → authoritative support → representation profile → registered transforms → exact, region-valued, uncertain, hidden, in-transit or unresolved result → audience projection`

### Spatial relation

`subjects/supports/frame/topology/time/relation family → authoritative positions/extents → relation evaluator → determination → no automatic movement, exposure, targeting or effect`

### Distance and proximity

`endpoints/semantics → metric/frame/scale/time → transform and topology closure → deterministic precision → value, band, incomparable, unknown or unresolved`

### Reachability

`origin/destination/movement/embodiment/equipment/time/purpose → topology/terrain/environment/boundaries/portals/permissions/knowledge → bounded candidates → constraints/capacity/validity/resources → qualified result`

### Route planning

`navigation goal → AFQR-10 maps/landmarks/knowledge → bounded route candidates → path-truth separation → plural estimates → route plan only`

### Movement

`command → gateway/actor/control/method → origin/destination/path/time/footprint/environment/resources → capacity reservation → segment plan → crossings/collisions/interruptions → owner fragments → AFQR-01 commit → handoffs`

### Cross-partition movement

`source state → destination eligibility/reservation → transit authority → source release + destination acceptance → atomic commit or abort`

### Portal transit

`portal identity/endpoints/state/eligibility/time → source contact → activation → transit → destination resolution → occupancy reservation → atomic departure/transit/arrival → side-effect handoffs`

### Collision

`swept supports/intervals → collision profile → phasing/clearance/priority/avoidance → collision, near miss, obstruction or unresolved → AFQR-16 handoff only`

### Navigation update

`observation/map/landmark/dead reckoning → frozen evidence → method/uncertainty profile → fix candidate → AFQR-10 commit → optional plan revision; true position unchanged`

### Simulation-tier transition

`promotion/demotion request → frozen authority state → ownership partition → certified materialization → unknown-history retention → authority transfer → reconciliation without duplicate occupancy`

## Part XX — Operation grammar

Each operation below has a distinct owner boundary and returns a typed result without assuming downstream consequences.

| # | Operation | Owner | Lawful result boundary |
| --- | --- | --- | --- |
| 1 | exact position is recorded | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 2 | position is region-valued | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 3 | position is uncertain | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 4 | position is hidden | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 5 | frame transform succeeds | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 6 | frame transform is unavailable | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 7 | moving frame changes | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 8 | coordinate system changes | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 9 | entity extent changes | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 10 | footprint expands | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 11 | footprint contracts | position_owner | Owner determines a versioned state or transition over domain, frame, support, extent and validity time. |
| 12 | two supports overlap | spatial_relation_owner | Spatial relation owner evaluates named supports and topology; no exposure, jurisdiction or movement follows automatically. |
| 13 | one entity contains another | spatial_relation_owner | Spatial relation owner evaluates named supports and topology; no exposure, jurisdiction or movement follows automatically. |
| 14 | containment ends | spatial_relation_owner | Spatial relation owner evaluates named supports and topology; no exposure, jurisdiction or movement follows automatically. |
| 15 | two regions become adjacent | spatial_relation_owner | Spatial relation owner evaluates named supports and topology; no exposure, jurisdiction or movement follows automatically. |
| 16 | adjacency ends | spatial_relation_owner | Spatial relation owner evaluates named supports and topology; no exposure, jurisdiction or movement follows automatically. |
| 17 | boundary is crossed | spatial_relation_owner | Spatial relation owner evaluates named supports and topology; no exposure, jurisdiction or movement follows automatically. |
| 18 | boundary location is disputed | spatial_relation_owner | Spatial relation owner evaluates named supports and topology; no exposure, jurisdiction or movement follows automatically. |
| 19 | distance is measured | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 20 | several metrics disagree | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 21 | range band is determined | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 22 | proximity threshold is met | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 23 | path exists | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 24 | path is incomplete | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 25 | path becomes invalid | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 26 | route is known | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 27 | route is falsely believed | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 28 | route plan is generated | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 29 | route plan is revised | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 30 | route cost changes | path_route_owner | Metric/path owner returns a qualified result; distance, cost, route belief and reachability remain distinct. |
| 31 | movement command is issued | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 32 | movement attempt begins | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 33 | movement segment completes | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 34 | movement is interrupted | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 35 | movement is blocked | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 36 | movement is redirected | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 37 | forced movement occurs | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 38 | carried movement occurs | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 39 | involuntary fall occurs | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 40 | jump begins | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 41 | flight path changes | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 42 | climb succeeds spatially | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 43 | swim route changes | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 44 | vehicle translates | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 45 | vehicle rotates | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 46 | passenger remains locally stationary | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 47 | passenger disembarks | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 48 | entity enters a compartment | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 49 | entity exits a compartment | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 50 | destination capacity is unavailable | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 51 | crowding occurs | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 52 | formation moves | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 53 | formation breaks | movement_transition_owner | Movement coordinator prepares departure, transit, crossing, occupancy and arrival fragments for AFQR-01 atomic commit. |
| 54 | collision candidate occurs | collision_spatial_owner | Spatial owner determines intersection, clearance or obstruction; AFQR-16 owns any harm. |
| 55 | collision is avoided | collision_spatial_owner | Spatial owner determines intersection, clearance or obstruction; AFQR-16 owns any harm. |
| 56 | collision is committed | collision_spatial_owner | A committed spatial collision record is permitted only after swept-support validation; physical consequences route to AFQR-16. |
| 57 | obstruction appears | collision_spatial_owner | Spatial owner determines intersection, clearance or obstruction; AFQR-16 owns any harm. |
| 58 | obstruction is removed | collision_spatial_owner | Spatial owner determines intersection, clearance or obstruction; AFQR-16 owns any harm. |
| 59 | passage clearance is insufficient | collision_spatial_owner | Spatial owner determines intersection, clearance or obstruction; AFQR-16 owns any harm. |
| 60 | portal connection opens | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 61 | portal connection closes | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 62 | portal direction changes | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 63 | portal activation succeeds | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 64 | portal activation fails | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 65 | portal transit begins | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 66 | portal destination changes | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 67 | portal arrival succeeds | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 68 | portal arrival support is unavailable | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 69 | teleportation is interrupted | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 70 | nonlocal path lacks bridge | portal_transition_owner | Portal owner separates connection, eligibility, activation, transit, destination and arrival under source-local bridges. |
| 71 | line-of-sight spatial candidate exists | spatial_query_owner | Spatial query emits a candidate only; observation, legality and effects remain downstream. |
| 72 | line-of-effect candidate is blocked | spatial_query_owner | Spatial query emits a candidate only; observation, legality and effects remain downstream. |
| 73 | target is within geometric range | spatial_query_owner | Spatial query emits a candidate only; observation, legality and effects remain downstream. |
| 74 | target remains ineligible for action | spatial_query_owner | Spatial query emits a candidate only; observation, legality and effects remain downstream. |
| 75 | sensor geometry covers target | spatial_query_owner | Spatial query emits a candidate only; observation, legality and effects remain downstream. |
| 76 | observation still fails | spatial_query_owner | Spatial query emits a candidate only; observation, legality and effects remain downstream. |
| 77 | navigation fix is accurate | AFQR10_epistemic_owner | AFQR-10 commits a navigation or map knowledge record without mutating spatial truth. |
| 78 | navigation fix is wrong | AFQR10_epistemic_owner | AFQR-10 commits a navigation or map knowledge record without mutating spatial truth. |
| 79 | navigator becomes lost | AFQR10_epistemic_owner | AFQR-10 commits a navigation or map knowledge record without mutating spatial truth. |
| 80 | map is updated | AFQR10_epistemic_owner | AFQR-10 commits a navigation or map knowledge record without mutating spatial truth. |
| 81 | map remains incomplete | AFQR10_epistemic_owner | AFQR-10 commits a navigation or map knowledge record without mutating spatial truth. |
| 82 | cross-partition transfer succeeds | cross_partition_coordinator | Authority transfer uses reservation, in-transit ownership, atomic handoff or tier partitioning without invented history. |
| 83 | destination reservation fails | cross_partition_coordinator | Authority transfer uses reservation, in-transit ownership, atomic handoff or tier partitioning without invented history. |
| 84 | source release occurs without destination acceptance attempt | cross_partition_coordinator | Invalid partial-transition candidate: source release may not commit without destination acceptance or a lawful in-transit authority record. |
| 85 | duplicate movement retry is suppressed | cross_partition_coordinator | Idempotency receipt suppresses the duplicate attempt; no second displacement or occupancy transition occurs. |
| 86 | aggregate space is promoted | cross_partition_coordinator | Authority transfer uses reservation, in-transit ownership, atomic handoff or tier partitioning without invented history. |
| 87 | promotion preserves hidden route | cross_partition_coordinator | Authority transfer uses reservation, in-transit ownership, atomic handoff or tier partitioning without invented history. |
| 88 | model invents a doorway | spatial_projection_security_owner | Model output is rejected by semantic validator because wording cannot create topology, movement or arrival. |
| 89 | model declares arrival without commitment | spatial_projection_security_owner | Model output is rejected by semantic validator because wording cannot create topology, movement or arrival. |
| 90 | no lawful spatial determination exists | spatial_projection_security_owner | Return spatial_outcome_unresolved with missing construct/bridge reasons and no invented certainty. |

The complete machine-readable grammar is `operations/afqr_18_operation_grammar.yaml`.

## Part XXI — Central stress cases

### 1. Moving ship, nested frames, and compartment transit

The ship uses a root frame, rotating and nonrotating section frames, lift and vehicle frames, and nested virtual control spaces. Corridor and airlock topology is dynamic. The crew member's local position is preserved through platform motion, while world transforms change. The outdated map is an AFQR-10 claim, not route truth. When the corridor closes, the route becomes invalid and movement remains interrupted until a revised route or emergency portal candidate passes eligibility, activation, transit and destination-capacity checks. Environmental presence routes to AFQR-17. Hidden obstruction identity remains private.

### 2. Multiplanar city with shifting topology

Overlapping districts may lack topological connection. Directed metrics permit asymmetric street length. Portal endpoint and destination versions change over logical time. The psychic map records belief-space propositions and cannot replace physical or planar truth. Jurisdictional borders route to AFQR-15. Storm-driven portal eligibility routes through AFQR-17. Pursuit and targeting consume spatial candidates without resolving behavior or action effects.

### 3. Distributed familiar swarm

Each derivative body has a separate authoritative support and movement profile. Formation support is an aggregate over members, not one body position. Reachability is evaluated per flyer, crawler, phaser and rider. Portal capacity may admit only some members. A refusing derivative is not voluntarily moved; forced relocation requires AFQR-11 authority. Aggregate and detailed tiers use explicit authority partitions. Proximity-dependent shared functions receive qualified spatial handoffs.

### 4. Aggregate travel promoted to local detail

The aggregate route graph records a region-valued party position and durable travel attempt. The collapsed bridge invalidates the old-map route. The hidden lair remains concealed. Promotion materializes only certified current topology and position support; it does not invent footsteps, previous coordinates, encounters or discovery. Local movement becomes deterministic from the promotion boundary forward.

Machine-readable stress fixtures are stored in `fixtures/`.

## Part XXII — Candidate comparison

Scores use 1–5 per axis across 33 criteria.

| Candidate | Architecture | Total | Fatal limitation |
| --- | --- | --- | --- |
| A | Universal coordinate space | 74 | fails source-local, abstract, nested and portal domains |
| B | Universal grid or hex | 72 | scale and donor-model collapse |
| C | Zone and range-band architecture | 72 | insufficient occupancy, collision and exact geometry |
| D | Pure graph topology | 103 | insufficient geometry, orientation and continuous supports |
| E | Continuous geometry and physics | 72 | high cost and poor abstract/source-local compatibility |
| F | Source-local spatial adapters | 101 | cross-source incoherence and adapter arbitrage |
| G | Navigation-centric architecture | 70 | does not own exact occupancy, collision or topology |
| H | Registered Federated Spatiotemporal Topology Architecture with Typed Domain–Frame–Support Ownership, Plural Metric–Reachability Profiles, Atomic Movement–Occupancy Transitions, and Bitemporal Map–Materialization Continuity | 161 | none |

Candidate H is selected because it is the only architecture that supports coordinate, graph, region, zone, nested, moving, portal, virtual and source-local spaces while preserving owner boundaries, uncertainty, atomic movement, simulation tiers and model independence.

## Part XXIII — Adversarial evaluation

All 200 scenarios receive distinct records and dispositions.

| ID | Scenario | Category | Final lawful disposition |
| --- | --- | --- | --- |
| SPA-001 | Entity has exact local coordinates. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-002 | Entity has only region-valued position. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-003 | Entity position is uncertain. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-004 | Entity position is hidden. | domains_frames_coordinates | private_state_preserved_with_noninterfering_projection |
| SPA-005 | Two frames share one origin. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-006 | One frame rotates relative to another. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-007 | Frame accelerates. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-008 | Frame transform is time-dependent. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-009 | Transform profile is unavailable. | domains_frames_coordinates | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-010 | Coordinates use incompatible units. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-011 | Coordinates use incompatible dimensions. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-012 | One position has several valid representations. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-013 | Source-local space has no ordinary coordinates. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-014 | Virtual position maps imperfectly to physical infrastructure. | domains_frames_coordinates | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-015 | Orbital position is expressed in moving frame. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-016 | Body-relative location is used. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-017 | Coordinate precision is insufficient. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-018 | Coordinate transform introduces bounded uncertainty. | domains_frames_coordinates | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-019 | Model treats coordinates as place identity. | domains_frames_coordinates | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-020 | Spatial frame remains unresolved. | domains_frames_coordinates | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-021 | Point-like entity occupies one support. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-022 | Extended entity spans several supports. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-023 | Distributed entity occupies disconnected supports. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-024 | Entity footprint changes. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-025 | Two extents overlap. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-026 | Overlap occurs without collision. | supports_extents_boundaries | spatial_collision_or_obstruction_determination_only_AFQR16_effect_handoff_if_committed |
| SPA-027 | Entity is contained in vehicle. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-028 | Vehicle is contained in ship. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-029 | Nested containment changes. | supports_extents_boundaries | typed_spatial_candidate_subject_to_owner_validation |
| SPA-030 | One region overlaps several environmental regions. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-031 | Boundary is open. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-032 | Boundary is closed. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-033 | Boundary moves. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-034 | Boundary location is disputed. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-035 | Legal border differs from spatial boundary. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-036 | Environmental boundary uses structural support. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-037 | Region splits. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-038 | Regions merge. | supports_extents_boundaries | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-039 | Model invents a region boundary. | supports_extents_boundaries | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-040 | Spatial support remains unresolved. | supports_extents_boundaries | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-041 | Euclidean distance is applicable. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-042 | Graph distance is applicable. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-043 | Geodesic distance differs from straight-line distance. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-044 | Directed distance is asymmetric. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-045 | Path cost differs by direction. | metrics_distance | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-046 | Travel time differs from path length. | metrics_distance | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-047 | Range band compresses several exact distances. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-048 | Two metrics produce incomparable results. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-049 | Endpoint is a surface rather than center. | metrics_distance | typed_spatial_candidate_subject_to_owner_validation |
| SPA-050 | Distance is measured between moving entities. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-051 | Distance changes during query. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-052 | Proximity threshold is purpose-specific. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-053 | Near in one metric but far in another. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-054 | Zero graph distance does not imply physical co-location. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-055 | Portal path is topologically short but physically distant. | metrics_distance | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-056 | Uncertainty prevents exact distance. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-057 | Distance estimate is based on false map. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-058 | Source-local metric lacks bridge. | metrics_distance | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-059 | Model equates travel time with distance. | metrics_distance | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-060 | Distance remains unresolved. | metrics_distance | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-061 | Destination is reachable by walking. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-062 | Destination is reachable only by flight. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-063 | Destination is reachable with special equipment. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-064 | Destination is geometrically near but unreachable. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-065 | Destination is distant but portal-reachable. | reachability_paths_routes | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-066 | Path exists but is unknown to actor. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-067 | Actor believes nonexistent route exists. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-068 | Known route becomes blocked. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-069 | Route validity expires. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-070 | Route is one-way. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-071 | Route capacity is limited. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-072 | Route requires permission. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-073 | Permission exists but path is impassable. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-074 | Pathfinding candidate set exceeds bound. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-075 | Dynamic obstacle invalidates route. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-076 | Several routes have incomparable costs. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-077 | Route crosses several jurisdictions. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-078 | Route crosses hazardous environments. | reachability_paths_routes | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-079 | Model invents a shortcut. | reachability_paths_routes | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-080 | Reachability remains unresolved. | reachability_paths_routes | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-081 | Movement attempt succeeds. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-082 | Movement is blocked before departure. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-083 | Movement is interrupted in transit. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-084 | Arrival support becomes unavailable. | movement_transit_occupancy | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-085 | Entity enters lawful in-transit state. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-086 | Entity crosses a boundary. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-087 | Entity changes environmental region. | movement_transit_occupancy | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-088 | Forced movement occurs. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-089 | Carried entity moves with carrier. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-090 | Passenger remains stationary in local frame. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-091 | Passenger changes world position. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-092 | Entity disembarks. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-093 | Destination occupancy exceeds capacity. | movement_transit_occupancy | typed_spatial_candidate_subject_to_owner_validation |
| SPA-094 | Crowding is permitted under degraded profile. | movement_transit_occupancy | typed_spatial_candidate_subject_to_owner_validation |
| SPA-095 | Formation occupies several supports. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-096 | Formation breaks during movement. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-097 | Duplicate movement command is retried. | movement_transit_occupancy | idempotent_duplicate_suppressed |
| SPA-098 | Cross-owner movement commit partially fails. | movement_transit_occupancy | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-099 | Model declares arrival from intent. | movement_transit_occupancy | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-100 | Movement outcome remains unresolved. | movement_transit_occupancy | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-101 | Swept supports do not intersect. | collision_obstruction_relative_motion | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-102 | Near miss occurs. | collision_obstruction_relative_motion | spatial_collision_or_obstruction_determination_only_AFQR16_effect_handoff_if_committed |
| SPA-103 | Collision occurs. | collision_obstruction_relative_motion | spatial_collision_or_obstruction_determination_only_AFQR16_effect_handoff_if_committed |
| SPA-104 | Phasing prevents collision. | collision_obstruction_relative_motion | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-105 | Collision profile is missing. | collision_obstruction_relative_motion | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-106 | Static obstruction blocks passage. | collision_obstruction_relative_motion | spatial_collision_or_obstruction_determination_only_AFQR16_effect_handoff_if_committed |
| SPA-107 | Dynamic obstacle enters path. | collision_obstruction_relative_motion | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-108 | Clearance is insufficient. | collision_obstruction_relative_motion | spatial_collision_or_obstruction_determination_only_AFQR16_effect_handoff_if_committed |
| SPA-109 | Entity squeezes through under special profile. | collision_obstruction_relative_motion | typed_spatial_candidate_subject_to_owner_validation |
| SPA-110 | Two movers contest one narrow passage. | collision_obstruction_relative_motion | typed_spatial_candidate_subject_to_owner_validation |
| SPA-111 | Priority rule resolves crossing. | collision_obstruction_relative_motion | typed_spatial_candidate_subject_to_owner_validation |
| SPA-112 | Simultaneous movement creates deadlock. | collision_obstruction_relative_motion | spatial_collision_or_obstruction_determination_only_AFQR16_effect_handoff_if_committed |
| SPA-113 | Pursuer intercepts target spatially. | collision_obstruction_relative_motion | typed_spatial_candidate_subject_to_owner_validation |
| SPA-114 | Pursuer reaches old target position. | collision_obstruction_relative_motion | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-115 | Relative velocity prevents docking. | collision_obstruction_relative_motion | spatial_collision_or_obstruction_determination_only_AFQR16_effect_handoff_if_committed |
| SPA-116 | Docking corridor is available. | collision_obstruction_relative_motion | spatial_collision_or_obstruction_determination_only_AFQR16_effect_handoff_if_committed |
| SPA-117 | Moving platform rotates during approach. | collision_obstruction_relative_motion | typed_spatial_candidate_subject_to_owner_validation |
| SPA-118 | Collision routes harm to AFQR-16. | collision_obstruction_relative_motion | spatial_collision_or_obstruction_determination_only_AFQR16_effect_handoff_if_committed |
| SPA-119 | Model invents impact. | collision_obstruction_relative_motion | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-120 | Collision outcome remains unresolved. | collision_obstruction_relative_motion | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-121 | Portal connects two endpoints. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-122 | Portal is one-way. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-123 | Portal requires a key. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-124 | Portal is active but target is ineligible. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-125 | Portal destination changes. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-126 | Portal splits into several destinations. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-127 | Portal closes during transit. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-128 | Arrival support is occupied. | portals_nested_source_local | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-129 | Teleportation bypasses ordinary path. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-130 | Teleportation preserves orientation. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-131 | Teleportation changes orientation. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-132 | Phasing crosses structural boundary. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-133 | Source-local transition lacks bridge. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-134 | Interior is larger than exterior. | portals_nested_source_local | typed_spatial_candidate_subject_to_owner_validation |
| SPA-135 | Pocket space moves with container. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-136 | Pocket-space entrance is destroyed. | portals_nested_source_local | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-137 | Network traversal uses logical topology. | portals_nested_source_local | typed_spatial_candidate_subject_to_owner_validation |
| SPA-138 | Conceptual proximity is mistaken for physical proximity. | portals_nested_source_local | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-139 | Model normalizes non-Euclidean space. | portals_nested_source_local | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-140 | Portal outcome remains unresolved. | portals_nested_source_local | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-141 | Geometric line of sight exists. | visibility_targeting_navigation | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-142 | Observation still fails. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-143 | Line of sight is blocked. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-144 | Line of effect differs from line of sight. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-145 | Target is within geometric range. | visibility_targeting_navigation | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-146 | Action remains illegal or infeasible. | visibility_targeting_navigation | typed_spatial_candidate_subject_to_owner_validation |
| SPA-147 | Area inclusion is ambiguous at boundary. | visibility_targeting_navigation | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-148 | Sensor geometry covers target. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-149 | Sensor lacks compatible modality. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-150 | Navigation fix is accurate. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-151 | Navigation fix is biased. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-152 | Dead reckoning accumulates error. | visibility_targeting_navigation | typed_spatial_candidate_subject_to_owner_validation |
| SPA-153 | Landmark is misidentified. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-154 | Map is outdated. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-155 | Map intentionally omits route. | visibility_targeting_navigation | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-156 | Actor becomes lost. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-157 | Route correction succeeds. | visibility_targeting_navigation | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-158 | Several maps disagree. | visibility_targeting_navigation | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-159 | Model treats map as truth. | visibility_targeting_navigation | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-160 | Navigation outcome remains unresolved. | visibility_targeting_navigation | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-161 | Entity crosses partition successfully. | partitions_tiers_secrecy_replay | typed_spatial_candidate_subject_to_owner_validation |
| SPA-162 | Destination reservation fails. | partitions_tiers_secrecy_replay | typed_spatial_candidate_subject_to_owner_validation |
| SPA-163 | Source release is aborted. | partitions_tiers_secrecy_replay | typed_spatial_candidate_subject_to_owner_validation |
| SPA-164 | Lawful in-transit authority persists. | partitions_tiers_secrecy_replay | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-165 | Entity appears duplicated after partial failure. | partitions_tiers_secrecy_replay | idempotent_duplicate_suppressed |
| SPA-166 | Duplicate is rejected by invariant. | partitions_tiers_secrecy_replay | idempotent_duplicate_suppressed |
| SPA-167 | Group transfer partially qualifies. | partitions_tiers_secrecy_replay | typed_spatial_candidate_subject_to_owner_validation |
| SPA-168 | Moving platform crosses partition with occupants. | partitions_tiers_secrecy_replay | typed_spatial_candidate_subject_to_owner_validation |
| SPA-169 | Hidden position affects targeting feasibility. | partitions_tiers_secrecy_replay | private_state_preserved_with_noninterfering_projection |
| SPA-170 | Visible blocker leaks hidden position. | partitions_tiers_secrecy_replay | private_state_preserved_with_noninterfering_projection |
| SPA-171 | Secret route affects navigation options. | partitions_tiers_secrecy_replay | private_state_preserved_with_noninterfering_projection |
| SPA-172 | Cross-packet retrieval exposes concealed portal. | partitions_tiers_secrecy_replay | private_state_preserved_with_noninterfering_projection |
| SPA-173 | Stable digest links hidden location. | partitions_tiers_secrecy_replay | private_state_preserved_with_noninterfering_projection |
| SPA-174 | Region graph is promoted to detailed space. | partitions_tiers_secrecy_replay | typed_support_relation_or_topology_determination_without_collision_exposure_or_jurisdiction_inference |
| SPA-175 | Promotion preserves unknown rooms. | partitions_tiers_secrecy_replay | typed_spatial_candidate_subject_to_owner_validation |
| SPA-176 | Detailed space is demoted. | partitions_tiers_secrecy_replay | typed_spatial_candidate_subject_to_owner_validation |
| SPA-177 | Current metric differs from historical metric. | partitions_tiers_secrecy_replay | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-178 | Historical transform evaluator is unavailable. | partitions_tiers_secrecy_replay | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-179 | Replay produces different path tie-break. | partitions_tiers_secrecy_replay | bounded_reachability_or_route_determination_separate_from_route_knowledge_and_execution |
| SPA-180 | Spatial state is corrupted. | partitions_tiers_secrecy_replay | typed_spatial_candidate_subject_to_owner_validation |
| SPA-181 | Donor grid maps directly. | donor_model_lawful_absence | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-182 | Donor zone system requires normalization. | donor_model_lawful_absence | conversion_pressure_receives_direct_normalized_source_local_quarantine_or_escalation_outcome |
| SPA-183 | Donor range bands remain source-local. | donor_model_lawful_absence | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-184 | Donor point crawl lacks exact distances. | donor_model_lawful_absence | qualified_metric_result_or_incomparability_no_reachability_inference |
| SPA-185 | Donor movement points mix time and distance. | donor_model_lawful_absence | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-186 | Donor teleport spell lacks arrival semantics. | donor_model_lawful_absence | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-187 | Donor map conflicts with canonical topology. | donor_model_lawful_absence | AFQR10_epistemic_or_spatial_query_candidate_no_truth_or_action_inference |
| SPA-188 | Donor location prose invents no coordinates. | donor_model_lawful_absence | versioned_domain_frame_position_determination_with_uncertainty_or_unresolved_result |
| SPA-189 | Unknown spatial domain is quarantined. | donor_model_lawful_absence | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-190 | Unknown portal ontology is quarantined. | donor_model_lawful_absence | source_local_portal_or_nonlocal_candidate_requires_registered_bridge_and_arrival_support |
| SPA-191 | Model invents a hidden room. | donor_model_lawful_absence | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-192 | Model invents cover. | donor_model_lawful_absence | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-193 | Model invents distance. | donor_model_lawful_absence | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-194 | Model moves an NPC without commitment. | donor_model_lawful_absence | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-195 | Model reveals target position. | donor_model_lawful_absence | reject_model_claim_and_preserve_committed_or_hidden_spatial_state |
| SPA-196 | Narration conflicts with committed movement. | donor_model_lawful_absence | movement_candidate_requires_atomic_departure_transit_occupancy_and_arrival_plan |
| SPA-197 | Public location report conflicts with truth. | donor_model_lawful_absence | typed_spatial_candidate_subject_to_owner_validation |
| SPA-198 | No valid spatial bridge exists. | donor_model_lawful_absence | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-199 | No typed construct represents the space. | donor_model_lawful_absence | lawfully_unresolved_or_quarantined_no_mutation |
| SPA-200 | Spatial outcome remains lawfully unresolved. | donor_model_lawful_absence | typed_spatial_candidate_subject_to_owner_validation |

The full evidence, owners, projections, handoffs and unresolved fields are in `evaluation/afqr_18_adversarial_scenarios_SPA_001_200.yaml`.

## Part XXIV — Current runtime disposition

### Exists

- doctrine, conversion IR, lawful-outcome taxonomy and authority hierarchy;
- Batch B travel/navigation/location pressure;
- Batch C location/site/region/map/vehicle conversion records;
- narrow RT-002 object-lever references, projection, legality, delta and replay fixtures.

### Fixture-only

RT-002 actor/NPC/object/lever references and visibility fields. They do not define general position, occupancy or movement.

### Conversion-only

Locations, sites, regions, maps, range labels, travel routes, movement fields, vehicle locations, encounter zones and source-local portal descriptions.

### Narrative-only

Spatial prose, directions, scene location text, map narration, movement narration and context-packet language.

### Absent and blocked

Authoritative domains, frames, transforms, positions, supports, topology, metrics, reachability, routes, movement, occupancy, collision, portals, navigation, partitions and materialization.

### May proceed

Ratification artifacts, schema registries, non-mutating fixtures, static validation, AFQR-17 handoff closure and model noninterference evaluation.

### Prohibited

Treating current fields, prose, maps, model output or donor rules as authoritative spatial state.

## Part XXV — Required artifacts

### Immediate

ADR, master decision, machine registry, terminology, 50-question audit, candidate matrix, contract catalog, conversion IR amendment, operation grammar, SPA-001–200 evaluation, 50-case dry run, four stress fixtures, research synthesis, threat model, acceptance matrix, manifest and validation report.

### Before authoritative position and topology

Federated owner registry, domain/frame registry, transform evaluator registry, topology registry, precision/degeneracy profiles, state store and replay verifier.

### Before distance and reachability

Metric registry, endpoint semantics, fixed-precision quantity integration, bounded query engine, path-support providers, terrain/environment/embodiment input closures.

### Before movement execution

Movement action families, movement coordinator, occupancy owner, destination reservation, in-transit authority, AFQR-01 commit plans and idempotency.

### Before occupancy and collision

Footprint integration from AFQR-16, capacity/clearance profiles, swept-support evaluator, simultaneous-movement groups and AFQR-16 collision handoff.

### Before portals

Portal registries, source-local bridge certification, activation resources, transit state, destination resolution and arrival-capacity handling.

### Before navigation

AFQR-10 spatial propositions, map versions, route knowledge, navigation methods, uncertainty and correction records.

### Before cross-partition movement

Partition owners, reservation protocol, authority transfer, rollback, ghost non-authority, deterministic parallelism and duplication invariants.

### Before model-facing narration

Grounding manifests, permitted claim registry, evidence bindings, semantic validator, retrieval isolation, timing/cardinality noninterference and adversarial certification.

### Before mass conversion

Spatial pressure IR validation, donor-family pilots, grid/zone/range/movement-point decomposition, portal/source-local certification and canon conflict review.

### Deferred

Final tactical geometry, LOS/LOE, combat targeting, initiative, speed/cost formulas, orbital mechanics, crowd simulation, world generation and encounter generation.

## Part XXVI — Non-mutating prototype

**Prototype:** AFQR-18 Space, Position, Reachability, Movement, Navigation, and Spatial Topology Dry Run.

It performs no world, position, topology, occupancy, portal, environmental or resource mutation and makes no model calls.

| # | Case | Expected result |
| --- | --- | --- |
| 1 | exact point position | typed_non_mutating_candidate |
| 2 | region-valued position | typed_non_mutating_candidate |
| 3 | uncertain position | typed_non_mutating_candidate |
| 4 | hidden position | audience_scoped_projection_without_hidden_identifier |
| 5 | static reference frame | typed_non_mutating_candidate |
| 6 | rotating frame | typed_non_mutating_candidate |
| 7 | nested frame transform | typed_non_mutating_candidate |
| 8 | unavailable transform | frame_transform_unavailable |
| 9 | extended footprint | typed_non_mutating_candidate |
| 10 | distributed support | typed_non_mutating_candidate |
| 11 | containment | typed_non_mutating_candidate |
| 12 | overlap without collision | typed_non_mutating_candidate |
| 13 | moving boundary | typed_non_mutating_candidate |
| 14 | disputed boundary | typed_non_mutating_candidate |
| 15 | Euclidean distance | typed_non_mutating_candidate |
| 16 | graph distance | typed_non_mutating_candidate |
| 17 | asymmetric metric | typed_non_mutating_candidate |
| 18 | metric incomparability | metrics_incomparable |
| 19 | geometric proximity without reachability | proximity_established_reachability_not_established |
| 20 | path existence | typed_non_mutating_candidate |
| 21 | unknown path | path_truth_or_knowledge_unresolved |
| 22 | invalidated route | route_invalid_at_query_time |
| 23 | conditional reachability | conditionally_reachable |
| 24 | several incomparable routes | route_candidates_incomparable |
| 25 | movement plan | typed_non_mutating_candidate |
| 26 | interrupted movement | lawful_in_transit_or_last_committed_support |
| 27 | in-transit state | typed_non_mutating_candidate |
| 28 | arrival-capacity failure | destination_reservation_failed_no_departure_commit |
| 29 | carried movement | typed_non_mutating_candidate |
| 30 | passenger in moving frame | typed_non_mutating_candidate |
| 31 | crowding | typed_non_mutating_candidate |
| 32 | formation movement | typed_non_mutating_candidate |
| 33 | collision | collision_spatial_candidate_AFQR16_handoff_only |
| 34 | collision avoidance | near_miss_or_avoidance_candidate |
| 35 | obstruction | typed_non_mutating_candidate |
| 36 | portal activation | activation_candidate_no_transit_commit |
| 37 | portal transit | portal_transit_candidate_with_arrival_reservation |
| 38 | changing portal destination | versioned_destination_candidate |
| 39 | teleportation without ordinary path | nonlocal_transition_without_ordinary_path |
| 40 | line-of-sight spatial candidate | spatial_LOS_candidate_only |
| 41 | line-of-effect obstruction | spatial_LOE_blocked_candidate |
| 42 | inaccurate navigation fix | AFQR10_epistemic_record_no_position_mutation |
| 43 | false map route | AFQR10_epistemic_record_no_position_mutation |
| 44 | cross-partition reservation | destination_reservation_candidate |
| 45 | atomic movement handoff | owner_fragment_commit_plan_not_executed |
| 46 | aggregate-to-detailed promotion | materialization_candidate_preserves_unknown_history |
| 47 | promotion preserving hidden route | audience_scoped_projection_without_hidden_identifier |
| 48 | hidden-position model projection | audience_scoped_projection_without_hidden_identifier |
| 49 | source-local non-Euclidean space | source_local_bridge_required_or_quarantine |
| 50 | no lawful spatial determination | spatial_outcome_unresolved |

Outputs include domains and owners, frames and transforms, positions and uncertainty, supports/extents/footprints, topology relations, distance/proximity, reachability, paths/routes, movement/transit, occupancy/collision, portal state, navigation/map records, cross-partition plans, private receipts, projections, deterministic commitments and AFQR handoffs.

## Part XXVII — Acceptance tests

The acceptance matrix contains **180** non-mutating tests.

| ID | Category | Assertion |
| --- | --- | --- |
| AFQR18-ACC-001 | spatial_domains_and_frames | Spatial domain differs from frame coordinate system topology and map. |
| AFQR18-ACC-002 | spatial_domains_and_frames | Each spatial domain declares authoritative family owners and applicable profiles. |
| AFQR18-ACC-003 | spatial_domains_and_frames | Frames are versioned and state-bearing when dynamic. |
| AFQR18-ACC-004 | spatial_domains_and_frames | Nested moving rotating and accelerating frames are supported. |
| AFQR18-ACC-005 | spatial_domains_and_frames | Transform validity intervals are explicit. |
| AFQR18-ACC-006 | spatial_domains_and_frames | Transform uncertainty is propagated. |
| AFQR18-ACC-007 | spatial_domains_and_frames | Source-local frames remain namespaced. |
| AFQR18-ACC-008 | spatial_domains_and_frames | Missing transforms yield unresolved rather than guessed results. |
| AFQR18-ACC-009 | spatial_domains_and_frames | Coordinates include units dimensions and reference bindings. |
| AFQR18-ACC-010 | spatial_domains_and_frames | Several coordinate representations may describe one position. |
| AFQR18-ACC-011 | spatial_domains_and_frames | Coordinate tuples never create place identity. |
| AFQR18-ACC-012 | spatial_domains_and_frames | Historical frame and transform versions remain replayable. |
| AFQR18-ACC-013 | position_and_support | Position differs from coordinates location labels and map claims. |
| AFQR18-ACC-014 | position_and_support | Point region-valued uncertain extended distributed hidden and in-transit positions are supported. |
| AFQR18-ACC-015 | position_and_support | Authoritative observed estimated and mapped positions differ. |
| AFQR18-ACC-016 | position_and_support | Extent footprint occupied support and collision support differ. |
| AFQR18-ACC-017 | position_and_support | Position is validity-time scoped. |
| AFQR18-ACC-018 | position_and_support | Hidden position remains audience-scoped. |
| AFQR18-ACC-019 | position_and_support | One entity may occupy multiple nonexclusive supports. |
| AFQR18-ACC-020 | position_and_support | Distributed supports may be disconnected. |
| AFQR18-ACC-021 | position_and_support | Support completeness may be partial or unknown. |
| AFQR18-ACC-022 | position_and_support | Position determination identifies owner and basis closure. |
| AFQR18-ACC-023 | position_and_support | Model cannot assign authoritative position. |
| AFQR18-ACC-024 | position_and_support | Unknown support yields unresolved without geometry invention. |
| AFQR18-ACC-025 | topology_relations_boundaries | Topology differs from geometry and metrics. |
| AFQR18-ACC-026 | topology_relations_boundaries | Nodes edges hyperedges and incidence are explicit. |
| AFQR18-ACC-027 | topology_relations_boundaries | Containment overlap contact adjacency separation and connection differ. |
| AFQR18-ACC-028 | topology_relations_boundaries | Adjacency does not establish reachability. |
| AFQR18-ACC-029 | topology_relations_boundaries | Topology changes are versioned. |
| AFQR18-ACC-030 | topology_relations_boundaries | Region split and merge preserve lineage candidates. |
| AFQR18-ACC-031 | topology_relations_boundaries | Spatial environmental structural and legal boundaries differ. |
| AFQR18-ACC-032 | topology_relations_boundaries | Moving disputed open closed and hidden boundaries are supported. |
| AFQR18-ACC-033 | topology_relations_boundaries | Crossing is a typed event. |
| AFQR18-ACC-034 | topology_relations_boundaries | Boundary crossing does not automatically establish exposure or jurisdiction. |
| AFQR18-ACC-035 | topology_relations_boundaries | Unknown relations remain unresolved. |
| AFQR18-ACC-036 | topology_relations_boundaries | Model cannot invent a boundary or connection. |
| AFQR18-ACC-037 | metrics_distance_proximity | Metric definition is explicit and versioned. |
| AFQR18-ACC-038 | metrics_distance_proximity | Endpoints and endpoint semantics are explicit. |
| AFQR18-ACC-039 | metrics_distance_proximity | Frame scale time units and precision are explicit. |
| AFQR18-ACC-040 | metrics_distance_proximity | Several metrics may coexist. |
| AFQR18-ACC-041 | metrics_distance_proximity | Distance path length graph distance travel time and cost differ. |
| AFQR18-ACC-042 | metrics_distance_proximity | Asymmetric directed and incomparable metrics are supported. |
| AFQR18-ACC-043 | metrics_distance_proximity | Range bands remain profile-scoped. |
| AFQR18-ACC-044 | metrics_distance_proximity | Proximity is purpose-specific. |
| AFQR18-ACC-045 | metrics_distance_proximity | Surface-to-surface and center-based endpoints remain distinguishable. |
| AFQR18-ACC-046 | metrics_distance_proximity | Moving-endpoint queries bind a query time or interval. |
| AFQR18-ACC-047 | metrics_distance_proximity | Distance uncertainty is retained. |
| AFQR18-ACC-048 | metrics_distance_proximity | Model cannot invent distance or equate travel time with distance. |
| AFQR18-ACC-049 | reachability_paths_routes | Reachability is purpose actor and movement-family specific. |
| AFQR18-ACC-050 | reachability_paths_routes | Embodiment equipment terrain environment boundaries portals time and resources are explicit. |
| AFQR18-ACC-051 | reachability_paths_routes | Route existence differs from route knowledge. |
| AFQR18-ACC-052 | reachability_paths_routes | Planned route differs from authoritative path support. |
| AFQR18-ACC-053 | reachability_paths_routes | Dynamic route validity intervals are supported. |
| AFQR18-ACC-054 | reachability_paths_routes | Path candidate generation is bounded. |
| AFQR18-ACC-055 | reachability_paths_routes | Conditional incomplete unknown unreachable and unresolved outcomes are supported. |
| AFQR18-ACC-056 | reachability_paths_routes | Permissions do not establish passability. |
| AFQR18-ACC-057 | reachability_paths_routes | Geometric proximity does not establish reachability. |
| AFQR18-ACC-058 | reachability_paths_routes | Route costs may be plural and incomparable. |
| AFQR18-ACC-059 | reachability_paths_routes | Path truth remains separate from maps and beliefs. |
| AFQR18-ACC-060 | reachability_paths_routes | Model cannot invent a shortcut or route. |
| AFQR18-ACC-061 | movement_and_atomicity | Command attempt segment transit crossing interruption and arrival differ. |
| AFQR18-ACC-062 | movement_and_atomicity | Movement uses frozen state bases. |
| AFQR18-ACC-063 | movement_and_atomicity | Intermediate in-transit state is represented where required. |
| AFQR18-ACC-064 | movement_and_atomicity | Movement retries are idempotent. |
| AFQR18-ACC-065 | movement_and_atomicity | Voluntary forced carried and involuntary movement differ. |
| AFQR18-ACC-066 | movement_and_atomicity | Movement changes several owner domains only through AFQR-01 plans. |
| AFQR18-ACC-067 | movement_and_atomicity | Departure does not commit without destination acceptance or lawful transit authority. |
| AFQR18-ACC-068 | movement_and_atomicity | Arrival requires destination support and occupancy acceptance. |
| AFQR18-ACC-069 | movement_and_atomicity | Interrupted movement retains a lawful support state. |
| AFQR18-ACC-070 | movement_and_atomicity | Materially changed routes require new attempts. |
| AFQR18-ACC-071 | movement_and_atomicity | Model cannot infer movement or arrival from intent. |
| AFQR18-ACC-072 | movement_and_atomicity | Historical movement segments remain replayable. |
| AFQR18-ACC-073 | occupancy_collision_obstruction | Occupancy differs from containment and general presence. |
| AFQR18-ACC-074 | occupancy_collision_obstruction | Capacity and clearance are profile-specific. |
| AFQR18-ACC-075 | occupancy_collision_obstruction | Extended and distributed footprints are supported. |
| AFQR18-ACC-076 | occupancy_collision_obstruction | Crowding and degraded occupancy are supported. |
| AFQR18-ACC-077 | occupancy_collision_obstruction | Formation support differs from member supports. |
| AFQR18-ACC-078 | occupancy_collision_obstruction | Collision uses swept supports and time intervals. |
| AFQR18-ACC-079 | occupancy_collision_obstruction | Overlap does not automatically imply collision. |
| AFQR18-ACC-080 | occupancy_collision_obstruction | Collision does not create injury directly. |
| AFQR18-ACC-081 | occupancy_collision_obstruction | Dynamic obstacles are supported. |
| AFQR18-ACC-082 | occupancy_collision_obstruction | Clearance and obstruction are interface-specific. |
| AFQR18-ACC-083 | occupancy_collision_obstruction | Collision avoidance and priority remain separate from collision truth. |
| AFQR18-ACC-084 | occupancy_collision_obstruction | AFQR-16 receives only certified collision handoffs. |
| AFQR18-ACC-085 | moving_frames_nested_spaces | Local and world positions differ. |
| AFQR18-ACC-086 | moving_frames_nested_spaces | Passengers inherit platform motion without losing local state. |
| AFQR18-ACC-087 | moving_frames_nested_spaces | Nested containment is versioned. |
| AFQR18-ACC-088 | moving_frames_nested_spaces | Rotating and accelerating frames are supported. |
| AFQR18-ACC-089 | moving_frames_nested_spaces | Container transfers preserve occupant consistency. |
| AFQR18-ACC-090 | moving_frames_nested_spaces | Local stationary state may coexist with changing world position. |
| AFQR18-ACC-091 | moving_frames_nested_spaces | Rooms elevators vehicles and pocket spaces may have independent frames. |
| AFQR18-ACC-092 | moving_frames_nested_spaces | Larger-inside-than-outside spaces remain source-local. |
| AFQR18-ACC-093 | moving_frames_nested_spaces | Parent transform changes do not rewrite local movement history. |
| AFQR18-ACC-094 | moving_frames_nested_spaces | Destroyed entrances do not automatically destroy nested-space identity. |
| AFQR18-ACC-095 | moving_frames_nested_spaces | Nested-frame transforms retain time validity. |
| AFQR18-ACC-096 | moving_frames_nested_spaces | Scene graph or rendering hierarchy cannot own simulation truth. |
| AFQR18-ACC-097 | portals_nonlocal_transitions | Portal identity differs from endpoints and connection state. |
| AFQR18-ACC-098 | portals_nonlocal_transitions | Existence eligibility activation transit and arrival differ. |
| AFQR18-ACC-099 | portals_nonlocal_transitions | One-way conditional keyed and unstable portals are supported. |
| AFQR18-ACC-100 | portals_nonlocal_transitions | Destination changes are versioned. |
| AFQR18-ACC-101 | portals_nonlocal_transitions | Arrival support and capacity are explicit. |
| AFQR18-ACC-102 | portals_nonlocal_transitions | Portal closure during transit yields a profile-scoped result. |
| AFQR18-ACC-103 | portals_nonlocal_transitions | Teleportation is not zero-distance walking. |
| AFQR18-ACC-104 | portals_nonlocal_transitions | Orientation continuity is profile-scoped. |
| AFQR18-ACC-105 | portals_nonlocal_transitions | Nonlocal transitions require registered bridges. |
| AFQR18-ACC-106 | portals_nonlocal_transitions | Source-local side effects remain separate handoffs. |
| AFQR18-ACC-107 | portals_nonlocal_transitions | Portal route knowledge may be false or incomplete. |
| AFQR18-ACC-108 | portals_nonlocal_transitions | Model cannot create or activate portals. |
| AFQR18-ACC-109 | visibility_targeting_navigation | Line of sight differs from line of effect. |
| AFQR18-ACC-110 | visibility_targeting_navigation | Geometric inclusion differs from observation. |
| AFQR18-ACC-111 | visibility_targeting_navigation | Range differs from action legality. |
| AFQR18-ACC-112 | visibility_targeting_navigation | Sensor geometry differs from detection. |
| AFQR18-ACC-113 | visibility_targeting_navigation | Cover geometry differs from protection effect. |
| AFQR18-ACC-114 | visibility_targeting_navigation | Navigation consumes epistemic state. |
| AFQR18-ACC-115 | visibility_targeting_navigation | Route planning differs from execution. |
| AFQR18-ACC-116 | visibility_targeting_navigation | Navigation fixes retain uncertainty and provenance. |
| AFQR18-ACC-117 | visibility_targeting_navigation | Maps are versioned proposition sets. |
| AFQR18-ACC-118 | visibility_targeting_navigation | Maps may be false incomplete outdated or deliberately misleading. |
| AFQR18-ACC-119 | visibility_targeting_navigation | Lost state does not relocate true position. |
| AFQR18-ACC-120 | visibility_targeting_navigation | Model cannot treat map claims as truth. |
| AFQR18-ACC-121 | cross_partition_movement | Source and destination partition owners are explicit. |
| AFQR18-ACC-122 | cross_partition_movement | Destination reservation precedes exclusive release where required. |
| AFQR18-ACC-123 | cross_partition_movement | In-transit authority is explicit. |
| AFQR18-ACC-124 | cross_partition_movement | Atomic commit prevents duplicate occupancy. |
| AFQR18-ACC-125 | cross_partition_movement | Abort and rollback are replayable. |
| AFQR18-ACC-126 | cross_partition_movement | Moving groups and containers are supported. |
| AFQR18-ACC-127 | cross_partition_movement | Partial group qualification is explicit. |
| AFQR18-ACC-128 | cross_partition_movement | Technical retry cannot duplicate movement. |
| AFQR18-ACC-129 | cross_partition_movement | Ghost or interest-management records never own truth. |
| AFQR18-ACC-130 | cross_partition_movement | Source release without acceptance is rejected unless transit authority exists. |
| AFQR18-ACC-131 | cross_partition_movement | Partition transfer retains identity and movement provenance. |
| AFQR18-ACC-132 | cross_partition_movement | Cross-owner invariant failure aborts the transition. |
| AFQR18-ACC-133 | hidden_state_model_safety | Hidden positions routes portals and obstructions are audience-scoped. |
| AFQR18-ACC-134 | hidden_state_model_safety | Candidate counts do not leak hidden topology. |
| AFQR18-ACC-135 | hidden_state_model_safety | Option counts do not reveal secret routes. |
| AFQR18-ACC-136 | hidden_state_model_safety | Query timing and error surfaces are padded or normalized where required. |
| AFQR18-ACC-137 | hidden_state_model_safety | Stable public digests do not correlate concealed locations. |
| AFQR18-ACC-138 | hidden_state_model_safety | Model claims require evidence bindings. |
| AFQR18-ACC-139 | hidden_state_model_safety | Unsupported position distance route movement and arrival claims are rejected. |
| AFQR18-ACC-140 | hidden_state_model_safety | Cross-packet retrieval is isolated. |
| AFQR18-ACC-141 | hidden_state_model_safety | Narration cannot mutate spatial state. |
| AFQR18-ACC-142 | hidden_state_model_safety | Visible blockers do not name concealed causes. |
| AFQR18-ACC-143 | hidden_state_model_safety | Regeneration of prose cannot create a new authoritative choice. |
| AFQR18-ACC-144 | hidden_state_model_safety | Cross-audience linkability tests are mandatory. |
| AFQR18-ACC-145 | simulation_tiers | Tier definitions are explicit. |
| AFQR18-ACC-146 | simulation_tiers | Promotion inputs are frozen. |
| AFQR18-ACC-147 | simulation_tiers | Authority transfers rather than duplicates. |
| AFQR18-ACC-148 | simulation_tiers | Promotion does not invent historical movement. |
| AFQR18-ACC-149 | simulation_tiers | Unknown rooms paths portals and occupancy remain unknown. |
| AFQR18-ACC-150 | simulation_tiers | Demotion retains committed spatial facts. |
| AFQR18-ACC-151 | simulation_tiers | Aggregate and detailed movement do not double count. |
| AFQR18-ACC-152 | simulation_tiers | Authority partition is explicit during mixed-tier operation. |
| AFQR18-ACC-153 | simulation_tiers | Promotion may materialize only certified detail. |
| AFQR18-ACC-154 | simulation_tiers | Re-materialization requirements are versioned. |
| AFQR18-ACC-155 | simulation_tiers | Historical approximations are labeled non-authoritative. |
| AFQR18-ACC-156 | simulation_tiers | Tier changes are replayable. |
| AFQR18-ACC-157 | conversion | Donor grids become pressure IR rather than universal law. |
| AFQR18-ACC-158 | conversion | Donor zones retain explicit semantics. |
| AFQR18-ACC-159 | conversion | Donor range bands remain qualified profiles. |
| AFQR18-ACC-160 | conversion | Donor movement points are decomposed where possible. |
| AFQR18-ACC-161 | conversion | Donor portals remain source-local where necessary. |
| AFQR18-ACC-162 | conversion | Conversion cannot move campaign entities. |
| AFQR18-ACC-163 | conversion | Conversion cannot create hidden routes. |
| AFQR18-ACC-164 | conversion | Conversion cannot define private model context. |
| AFQR18-ACC-165 | conversion | Descriptive location prose creates no coordinates. |
| AFQR18-ACC-166 | conversion | Every construct receives a lawful outcome. |
| AFQR18-ACC-167 | conversion | Donor map conflicts route to canon or source-local review. |
| AFQR18-ACC-168 | conversion | Unknown spatial ontology is quarantined or escalated. |
| AFQR18-ACC-169 | runtime_containment | Existing location range map travel and movement fields remain conversion or fixture scoped. |
| AFQR18-ACC-170 | runtime_containment | PCR location metadata does not establish spatial simulation. |
| AFQR18-ACC-171 | runtime_containment | Travel doctrine does not own authoritative movement. |
| AFQR18-ACC-172 | runtime_containment | Environmental regions do not own universal topology. |
| AFQR18-ACC-173 | runtime_containment | Current object-lever mutation is not spatial movement. |
| AFQR18-ACC-174 | runtime_containment | Generalized position mutation remains blocked. |
| AFQR18-ACC-175 | runtime_containment | Generalized topology mutation remains blocked. |
| AFQR18-ACC-176 | runtime_containment | Generalized collision and portal execution remain blocked. |
| AFQR18-ACC-177 | runtime_containment | Model-authored spatial truth is prohibited. |
| AFQR18-ACC-178 | runtime_containment | RT-002G remains spatially fixed. |
| AFQR18-ACC-179 | runtime_containment | Bounded spatial narration requires grounding and validation. |
| AFQR18-ACC-180 | runtime_containment | Missing runtime owner returns blocked or unresolved rather than implicit execution. |

## Part XXVIII — Residual uncertainty ledger

The following remain deliberately unresolved and require later doctrine or implementation profiles:

- final tactical geometry and area shapes;
- final line-of-sight and line-of-effect algorithms;
- combat targeting, simultaneous action and initiative;
- movement rates, path costs and travel-time formulas;
- orbital mechanics and rendezvous solvers;
- crowd, formation and traffic performance models;
- procedural world and encounter generation;
- source-local conceptual-space metaphysics;
- large-scale partitioning and deterministic parallel performance;
- model-training and dialogue behavior.

These are escalation points, not permission to improvise defaults.

## Part XXIX — Roadmap conclusion

1. **Resolved for ratification:** Yes.
2. **Second broad research pass:** No.
3. **Mandatory amendments:** federated domain/frame/support ownership; coordinate-position separation; versioned transforms; topology/geometry/metric separation; plural distance; purpose-specific reachability; path-truth/route-knowledge separation; atomic movement/occupancy; moving frames; portal lifecycle; navigation epistemics; partition authority; tier materialization; hidden-safe validation.
4. **Immediate artifacts:** Included in this pack.
5. **Smallest prototype:** The supplied 50-case non-mutating dry run.
6. **Execution blocked:** All authoritative position, topology, movement, arrival, occupancy, collision, portal, navigation and cross-partition mutation.
7. **Authoritative spatial mutation unlocked:** No.
8. **Bounded spatial narration unlocked:** Only after grounding, evidence bindings, semantic validation and isolation are implemented.
9. **AFQR-17 handoffs:** Closed at the architectural-contract level, not implemented.
10. **RT-002G:** Unchanged and spatially fixed.
11. **AFQR-19:** Capabilities, Targeting, Contests, Reactions, Interrupts, Conflict, Combat, and Multi-Actor Action Resolution.
12. **Exact next action:** Ratify and register AFQR-18; execute the 50-case dry run and RT-002A–F spatial/model noninterference audit; close AFQR-17 provisional spatial references in doctrine registries; keep RT-002G spatially fixed; then open AFQR-19 as a read-only investigation.

## Part XXX — Machine-readable decision block

```yaml
question_id: AFQR-18
question_title: Space Location Position Scale Boundaries Distance Proximity Reachability Movement Navigation
  and Spatial Topology
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: architecturally_resolved_for_ratification
selected_architecture: Registered Federated Spatiotemporal Topology Architecture with Typed Domain–Frame–Support
  Ownership, Plural Metric–Reachability Profiles, Atomic Movement–Occupancy Transitions, and Bitemporal Map–Materialization
  Continuity
selected_architecture_abbreviation: RFSTA-DFS-PMR-AMO-MMC
confidence: high
central_law: No place name, location field, coordinate tuple, map feature, route plan, range label, movement
  declaration, portal description, travel summary, donor rule, sensor estimate, public report, or model narration
  possesses spatial mutation authority by itself. Every authoritative spatial result is a purpose-scoped, version-pinned,
  bitemporal determination over frozen spatial-domain, reference-frame, transform, support, extent, topology,
  metric, occupancy, movement, portal, environmental, embodiment, identity, epistemic, agency, behavioral,
  social, communication, institutional, governed-relation, quantity, and scheduler bases. Only owner-prepared
  AFQR-01 transitions may change position, topology, occupancy, transit, or arrival; maps, observations, estimates,
  route beliefs, plans, and model wording remain separate append-only records.
accepted_dependencies:
  AFQR_01:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: owner-prepared atomic spatial and occupancy transitions
  AFQR_02:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: idempotent movement and durable travel attempts
  AFQR_03:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: typed movement and spatial-interaction action gateway
  AFQR_04:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: logical-time trajectories, crossings and simultaneous movement
  AFQR_05:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: registered frame, topology and source-local bridges
  AFQR_06:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: typed spatial-claim arbitration without geometry invention
  AFQR_07:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: typed spatial quantities, precision, capacity and settlement
  AFQR_08:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: domain, place, route and portal identity continuity
  AFQR_09:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: governed access, route, occupancy and corridor relations
  AFQR_10:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: maps, observations, estimates and route knowledge
  AFQR_11:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: voluntary, forced, carried and involuntary movement separation
  AFQR_12:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: destination and route choice remain behavioral decisions
  AFQR_13:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: proximity and territory do not create social state
  AFQR_14:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: directions, coordinates and route instructions remain communication
  AFQR_15:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: legal borders, jurisdiction and spatial boundaries remain distinct
  AFQR_16:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: embodiment supplies extents, footprints and collision supports
  AFQR_17:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_18_effect: environment consumes certified spatial supports and paths
definitions:
  canonical_terminology_registry: registries/canonical_terminology.yaml
  definition_count: 134
guarantees:
- coordinate representations never replace authoritative position ownership
- topology geometry metrics maps and navigation beliefs remain distinct
- multiple spatial domains frames metrics and movement profiles may coexist
- movement changes occupancy only through owner-prepared atomic transitions
- cross-partition movement prevents duplicate exclusive occupancy
- hidden positions routes portals and reservations are audience-scoped
- AFQR-17 provisional spatial support references receive typed AFQR-18 contracts
- lawful unknown incomparable in-transit aborted and unresolved results are supported
non_guarantees:
- one universal geometry coordinate system grid metric pathfinder movement rate line-of-sight algorithm or
  portal metaphysics
- final combat targeting movement cost travel time orbital mechanics crowd simulation or procedural world generation
- authoritative movement or topology mutation before runtime implementation and certification
spatial_domain_model:
  ownership: federated_by_spatial_family
  required_declarations:
  - topology_profile
  - geometry_profile_or_none
  - metric_profiles
  - scale_profiles
  - movement_profiles
  - transform_profiles
  - source_local_namespace
  supports_coordinate_free_domains: true
reference_frame_model:
  frames_are_state_bearing: true
  moving_rotating_accelerating_nested: true
  transforms_versioned_and_time_valid: true
  missing_transform_result: unresolved
coordinate_system_model:
  coordinates_are_representations: true
  units_dimensions_epoch_and_frame_required: true
  multiple_representations_allowed: true
frame_transform_model:
  registered_adapters_only: true
  uncertainty_propagated: true
  historical_versions_retained: true
position_model:
  forms:
  - exact
  - region_valued
  - uncertain
  - hidden
  - extended
  - distributed
  - in_transit
  - unresolved
  owner: position_owner
  time_scoped: true
spatial_support_model:
  support_families:
  - point
  - cell
  - node
  - region
  - surface
  - volume
  - path
  - set
  - distributed
  - source_local
  coordinate_free_supported: true
extent_and_footprint_model:
  embodiment_supplied: true
  extent_footprint_occupancy_collision_shape_separated: true
spatial_uncertainty_model:
  epistemic_owner: AFQR-10
  uncertainty_region_supported: true
  hidden_and_unknown_separated: true
scale_and_resolution_model:
  scale_does_not_select_geometry: true
  tiers:
  - microscopic
  - body
  - room
  - site
  - regional
  - planetary
  - orbital
  - interstellar
  - interplanar
  - abstract_zone
  - source_local
topology_model:
  nodes_edges_hyperedges_incidence: true
  dynamic_versioned: true
  directed_multilayer_non_euclidean_supported: true
spatial_relation_model:
  families:
  - containment
  - overlap
  - contact
  - adjacency
  - incidence
  - separation
  - boundary
  - crossing
  profile_scoped: true
containment_and_overlap_model:
  do_not_imply_collision_or_exposure: true
  nested_and_multi_region_supported: true
boundary_model:
  spatial_support_owned_here: true
  environmental_structural_legal_effects_owned_elsewhere: true
  moving_hidden_disputed_supported: true
connectivity_model:
  connection_state_separate_from_reachability: true
  directionality_and_conditions_explicit: true
metric_model:
  plural_metrics: true
  asymmetric_and_incomparable_supported: true
  metric_requires_profile: true
distance_model:
  requires:
  - endpoints
  - endpoint_semantics
  - frame
  - metric
  - scale
  - time
  - precision
  does_not_imply:
  - travel_time
  - cost
  - reachability
proximity_model:
  purpose_scoped: true
  near_unqualified_prohibited: true
range_band_model:
  profile_scoped_compression: true
  not_universal_distance: true
orientation_and_relative_motion_model:
  orthogonal_states:
  - orientation
  - facing
  - heading
  - bearing
  - attitude
  - velocity
  - relative_velocity
  - approach
  action_relevance_profile_scoped: true
reachability_model:
  inputs:
  - origin
  - destination
  - movement_family
  - embodiment
  - equipment
  - terrain
  - environment
  - boundaries
  - portals
  - permissions
  - time
  - resources
  outcomes:
  - reachable
  - conditionally_reachable
  - unreachable
  - unknown
  - incomplete
  - unresolved
accessibility_model:
  legal_access_physical_access_and_usable_access_separated: true
path_model:
  authoritative_support_candidate_and_belief_separated: true
  bounded_generation: true
  dynamic_validity: true
route_model:
  route_is_plan_not_truth: true
  may_include_nonspatial_constraints: true
  versioned_segments: true
route_knowledge_model:
  owner: AFQR-10
  may_be_false_incomplete_outdated: true
movement_model:
  phases:
  - command
  - attempt
  - departure
  - segment
  - crossing
  - transit
  - interruption
  - arrival
  owner: movement_transition_owner
  atomicity: AFQR-01
trajectory_model:
  continuous_or_abstract: true
  intermediate_state_when_required: true
crossing_and_arrival_model:
  crossing_is_event: true
  arrival_requires_destination_support_and_occupancy: true
movement_interruption_model:
  preserves_lawful_in_transit_or_last_committed_support: true
forced_and_carried_movement_model:
  agency_origin_records_required: true
  passenger_voluntariness_not_inferred: true
occupancy_model:
  separate_from_presence_and_containment: true
  exclusive_shared_distributed_supported: true
capacity_and_clearance_model:
  profile_scoped: true
  physical_operational_legal_environmental_qualified: true
collision_model:
  uses_swept_support_and_time: true
  harm_handoff: AFQR-16
  does_not_create_injury: true
obstruction_model:
  interface_specific: true
  may_block_movement_visibility_effect_or_communication_differently: true
formation_model:
  aggregate_and_member_supports_separated: true
  breakage_transition_supported: true
moving_frame_model:
  local_and_world_state_separate: true
  time_buffered_transform_graph: true
nested_space_model:
  hierarchical_frames: true
  independent_topology_supported: true
  larger_inside_outside_source_local: true
moving_platform_model:
  passenger_local_position_preserved_while_world_position_changes: true
portal_model:
  stages:
  - existence
  - endpoint_binding
  - connection
  - eligibility
  - activation
  - transit
  - arrival
  direction_and_destination_versioned: true
nonlocal_transition_model:
  ordinary_path_not_required: true
  arrival_support_required: true
teleportation_model:
  not_zero_distance_walking: true
  source_local_side_effect_handoff: true
source_local_spatial_model:
  namespaced: true
  bridge_certification_required: true
  no_ordinary_geometry_normalization: true
line_of_sight_handoff:
  spatial_candidate_only: true
  observation_owner: AFQR-10/runtime observation
line_of_effect_handoff:
  spatial_candidate_only: true
  effect_owner: AFQR-03/16 as applicable
targeting_spatial_handoff:
  range_and_geometry_do_not_establish_legality: true
sensor_geometry_handoff:
  coverage_does_not_establish_detection: true
navigation_model:
  consumes_epistemic_state: true
  methods:
  - dead_reckoning
  - landmark
  - coordinate
  - beacon
  - celestial
  - map
  - network
  - portal_chain
  - source_local
map_model:
  versioned_proposition_set: true
  coverage_resolution_age_provenance_required: true
  not_truth_owner: true
survey_model:
  evidence_and_uncertainty_retained: true
navigation_uncertainty_model:
  fix_error_and_lost_state_explicit: true
  does_not_move_true_position: true
cross_partition_movement_model:
  source_release_destination_reservation_in_transit_authority_destination_acceptance: true
in_transit_authority_model:
  prevents_ownerless_or_duplicate_entity: true
movement_atomicity_model:
  AFQR01_commit_plan: true
  technical_retry_idempotent: true
  abort_and_rollback_receipts: true
identity_handoff:
  AFQR-08: place route portal and domain continuity
epistemic_handoff:
  AFQR-10: observed estimated mapped and believed positions and routes
agency_and_control_handoff:
  AFQR-11: voluntary forced carried and involuntary movement
behavioral_handoff:
  AFQR-12: destination route pursuit and escape selection
social_handoff:
  AFQR-13: proximity co-location territory and migration impacts only
communication_handoff:
  AFQR-14: directions coordinates and route instructions
institutional_handoff:
  AFQR-15: territory border jurisdiction access and corridor authority
embodiment_handoff:
  AFQR-16: extent footprint collision support and harm consequences
environmental_handoff:
  AFQR-17: terrain/environment state over certified supports and exposure presence
governed_relation_handoff:
  AFQR-09: access occupancy easements route and portal relations
quantity_and_settlement_handoff:
  AFQR-07: distance angle velocity capacity time and movement resources
action_gateway_handoff:
  AFQR-03: movement and spatial manipulation legality
scheduler_handoff:
  AFQR-04: logical-time movement and dynamic frames
spatial_simulation_tier_model:
  tiers:
  - descriptive_place
  - region_graph
  - zone_topology
  - materialized_local_space
  - detailed_dynamic_space
  - full_spatial_fixture
spatial_materialization_policy:
  no_invented_history: true
  unknown_rooms_routes_portals_positions_preserved: true
spatial_authority_partition:
  aggregate_and_detailed_authority_mutually_accounted: true
  no_double_counting: true
hidden_spatial_state_policy:
  audience_scoped: true
  query_shape_padding: true
  candidate_count_noninterference: true
visible_projection_policy:
  qualified_visible_claims_only: true
  concealed_support_not_named: true
model_context_policy:
  untrusted_model: true
  grounded_claim_allowlist_required: true
model_output_validation:
  semantic_validator_required: true
  rejects_unsupported_position_distance_route_movement_arrival: true
side_channel_protection:
  opaque_tokens: true
  projection_specific_digests: true
  cross_audience_linkability_tests: true
historical_replay_policy:
  retain_frames_transforms_topologies_metrics_paths_portals_navigation_records: true
  missing_evaluator: unverifiable
bitemporal_policy:
  valid_time_and_recorded_time_separate: true
  append_only_corrections: true
owner_boundaries:
  spatial_truth: federated_spatial_owners
  maps_and_beliefs: AFQR-10
  terrain_and_weather: AFQR-17
  embodiment_support: AFQR-16
  legal_borders: AFQR-15
  model: no_authority
AFQR_handoffs:
  AFQR17_spatial_support_closure: architecturally_closed_not_implemented
  AFQR16_collision_effect: typed_handoff_only
moving_ship_stress_case:
  result: nested frame hierarchy plus dynamic route validity and atomic compartment transitions; no map or
    model authority
multiplanar_city_stress_case:
  result: directed plural metrics, changing portal topology, source-local bridges and disputed map claims
distributed_familiar_stress_case:
  result: multi-body distributed supports, member-specific reachability, consent-aware relocation and tier
    partitioning
aggregate_travel_promotion_stress_case:
  result: route-graph authority promoted without invented footsteps, rooms, routes or discoveries
conversion_pipeline_handoff:
  pressure_IR_types: 32
  lawful_outcomes:
  - direct
  - normalized
  - source_local
  - quarantined
  - doctrine_escalation
  campaign_mutation_prohibited: true
model_authority_policy:
  position_distance_path_route_movement_collision_portal_navigation_map_authority: false
current_runtime_disposition:
  repository_head: 928bb79ce00a2de749d127dcc5cb8299de788a15
  authoritative_spatial_runtime: absent
  RT_001_RT_002: narrow_fixture_only
  conversion_fields: non_authoritative
  narrative_fields: non_authoritative
required_artifacts:
  immediate:
  - ADR
  - decision_registry
  - terminology
  - repository_audit
  - candidate_comparison
  - contract_catalog
  - operation_grammar
  - SPA_evaluation
  - dry_run
  - stress_fixtures
  - acceptance_tests
  - research_synthesis
  - manifest
  before_runtime:
  - owner registries
  - transform registry
  - topology registry
  - metric registry
  - movement coordinator
  - partition protocol
  - model validator
required_prototype:
  name: AFQR-18 Space, Position, Reachability, Movement, Navigation, and Spatial Topology Dry Run
  case_count: 50
  mutating: false
required_fixtures:
- moving_ship_nested_frames
- multiplanar_city
- distributed_familiar_swarm
- aggregate_world_travel_promotion
blocked_work:
- authoritative_position_mutation
- topology_mutation
- movement_execution
- portal_activation
- collision_effect
- cross_partition_transfer
- authoritative_navigation
- model_authored_spatial_truth
work_unlocked:
- schema_and_fixture_design
- non_mutating_spatial_dry_run
- AFQR17_spatial_contract_closure
- bounded_spatial_projection_design
rejected_alternatives:
- universal_coordinate_space
- universal_grid_or_hex
- universal_zone_model
- pure_graph_only
- continuous_physics_only
- source_local_adapters_only
- navigation_centric_only
- LLM_spatial_authority
residual_risks:
- final_tactical_geometry
- line_of_sight
- line_of_effect
- combat_targeting
- simultaneous_action
- movement_cost_speed
- travel_time
- orbital_mechanics
- crowd_simulation
- world_generation
- source_local_conceptual_spaces
- distributed_performance
- training_model_behavior
AFQR17_spatial_handoff_status: architecturally_closed_by_AFQR18_contracts_but_not_runtime_implemented
RT_002G_status: unchanged_narrow_spatially_fixed_fixture
next_foundational_question:
  question_id: AFQR-19
  title: Capabilities, Targeting, Contests, Reactions, Interrupts, Conflict, Combat, and Multi-Actor Action
    Resolution
  rationale: spatial, environmental, embodiment, agency, behavior, communication and institutional prerequisites
    now exist architecturally
exact_next_roadmap_action: Ratify and register AFQR-18; execute the 50-case non-mutating spatial dry run and
  an RT-002A–F spatial/model noninterference audit; close AFQR-17 provisional spatial references in doctrine
  registries; keep RT-002G spatially fixed; then open AFQR-19 as a read-only foundational investigation.
```