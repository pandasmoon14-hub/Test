# AFQR-18 Ratification Pack v1.0

Selected architecture:

**Registered Federated Spatiotemporal Topology Architecture with Typed Domain–Frame–Support Ownership, Plural Metric–Reachability Profiles, Atomic Movement–Occupancy Transitions, and Bitemporal Map–Materialization Continuity** (`RFSTA-DFS-PMR-AMO-MMC`)

Repository commit inspected: `928bb79ce00a2de749d127dcc5cb8299de788a15`

This package contains the integrated 30-part ratification, decision and terminology registries, repository audit, candidate comparison, 258 typed contracts, conversion IR amendments, 90-operation grammar, 200 adversarial scenarios, 50-case non-mutating prototype, four stress fixtures, 180 acceptance tests, research synthesis, security threat model, manifests and validation results.

## Authority

This pack is an architectural artifact. It does not implement runtime movement, position, topology, portals, collision, navigation, or cross-partition transfer.

## Principal files

- `master/Astra_AFQR_18_Master_Ratification_v1_0.md`
- `registries/afqr_18_decision_registry.yaml`
- `contracts/afqr_18_typed_contract_catalog.yaml`
- `operations/afqr_18_operation_grammar.yaml`
- `evaluation/afqr_18_adversarial_scenarios_SPA_001_200.yaml`
- `fixtures/afqr_18_non_mutating_dry_run.yaml`
- `tests/validation_report.yaml`
