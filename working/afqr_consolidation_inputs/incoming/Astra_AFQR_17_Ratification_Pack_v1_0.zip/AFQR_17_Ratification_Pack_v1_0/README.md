# Astra AFQR-17 Ratification Pack v1.0

This package ratifies AFQR-17: Environment, Media, Atmosphere, Weather, Terrain, Hazards, Contamination, Exposure, Ecological Processes, and Environmental Change.

## Decision

- Architecture: Registered Federated Environment–Process Architecture with Typed Region–Medium–Field Ownership, Bounded Source–Transport–Hazard Graphs, Profile-Scoped Terrain–Weather–Ecology Families, and Bitemporal Observation–Materialization Continuity
- Abbreviation: `RFEPA-RMF-STHG-TWE-OMC`
- Repository commit inspected: `928bb79ce00a2de749d127dcc5cb8299de788a15`
- Resolution: architecturally resolved for ratification
- Runtime mutation unlocked: no
- Next foundational question: AFQR-18 spatial topology

## Principal contents

- `master/` — integrated 30-part ratification
- `adrs/` — concise architectural decision record
- `contracts/` — 243 typed contracts and conversion IR amendment
- `operations/` — 90-operation grammar
- `evaluation/` — 200 adversarial scenarios and 180 acceptance tests
- `fixtures/` — 50-case dry run and four stress-case typed graphs
- `registries/` — decision, terminology, candidates, audit, inventory, and security
- `sources/` — repository and external research evidence
- `manifests/` — frozen payload and artifact manifests
- `validation/` — structural validation report

No artifact in this pack modifies repository or runtime state.
