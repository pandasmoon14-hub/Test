# Astra Foundational Question Resolution 17

## Environment, Media, Atmosphere, Weather, Terrain, Hazards, Contamination, Exposure, Ecological Processes, and Environmental Change

**Status:** Architecturally resolved for ratification  
**Repository commit inspected:** `928bb79ce00a2de749d127dcc5cb8299de788a15`  
**Selected architecture:** Registered Federated Environment–Process Architecture with Typed Region–Medium–Field Ownership, Bounded Source–Transport–Hazard Graphs, Profile-Scoped Terrain–Weather–Ecology Families, and Bitemporal Observation–Materialization Continuity  
**Abbreviation:** `RFEPA-RMF-STHG-TWE-OMC`  
**Confidence:** High

This master document is the integrated normative decision. Machine-readable registries and evaluation artifacts in this pack are binding supplements where referenced.


## Part I — Executive decision

AFQR-17 selects **Registered Federated Environment–Process Architecture with Typed Region–Medium–Field Ownership, Bounded Source–Transport–Hazard Graphs, Profile-Scoped Terrain–Weather–Ecology Families, and Bitemporal Observation–Materialization Continuity** (`RFEPA-RMF-STHG-TWE-OMC`).

### Central law

> No place label, region tag, map feature, weather table, climate descriptor, terrain modifier, hazard clock, contamination label, ecological aggregate, donor rule, sensor reading, forecast, public report, or model narration possesses environmental mutation authority by itself. Every authoritative environmental result is a purpose-scoped, version-pinned, bitemporal determination over frozen region, medium, field, boundary, source, sink, reservoir, transport, terrain, climate, process, hazard, contamination, ecological, quantity, spatial-reference, epistemic, agency, social, institutional, embodiment, and governed-relation bases. AFQR-17 ends at certified target-interface exposure and never creates injury or bodily effect; only owner-prepared AFQR-01 transitions mutate environmental state, while observations, maps, forecasts, projections, and later reinterpretations remain separate append-only records.

The architecture is a federated owner and process framework, not a weather table, a hazard clock, a universal stat block, or a world-generation engine. It provides lawful landing places for environmental constructs across natural, artificial, digital, planetary, interplanar, and source-local environments while keeping spatial topology, target-side injury, institutional authority, and model narration in their proper owner domains.

A second broad research pass is not required. Implementation of particular atmospheres, transport regimes, contaminants, fires, ecologies, planets, or source-local fields will require narrow technical research and certification.


## Part II — Repository-grounded diagnosis

### Verified repository baseline

The current head of `main` was independently verified as `928bb79ce00a2de749d127dcc5cb8299de788a15`, the merge of PR #325 / RT-002F.

### Implemented repository facts

The repository contains authority-separation doctrine, conversion intake and lawful-outcome infrastructure, Batch B ownership pressure for environment/hazard/weather/terrain/exposure, Batch C location/hazard/map record families, and the narrow RT-002 actor/NPC/object/lever reference–legality–event–replay fixture.

### Conversion-only surfaces

Current location, region, biome, terrain, weather, hazard, environment, travel, exposure, map, table, and encounter fields are conversion records, procedure pressure, or source-local content. They are not runtime environmental state.

### Fixture-only surfaces

RT-002A–F provides narrow state-owner references, projection, object-lever eligibility, transaction preview, event/state-delta receipts, and replay/audit receipts. It does not implement environmental regions, media, boundaries, transport, weather, hazards, contamination, ecology, exposure production, or materialization.

### Narrative-only surfaces

Descriptions, context-packet text, map prose, adventure narration, table entries, and model wording are epistemic or presentation surfaces.

### Explicit 50-question diagnosis

The full question-by-question repository audit is stored in `registries/repository_audit_50_questions.yaml`. Its controlling conclusion is that generalized authoritative environmental simulation is absent; existing terms must not be promoted by field-name inference.

### Work blocked at this baseline

Authoritative environment owners, environmental process execution, transport, weather, hazards, contamination, exposure production, resource processes, ecology, simulation tiers, and model-facing environmental validation remain blocked.


## Part III — External research synthesis

The research pass extracts architecture, not universal physical or ecological law. Earth science and engineering sources are adopted only for distinctions such as observation versus forecast, source versus reservoir, transport versus deposition, hazard versus exposure, and platform environment versus platform integrity.

### Atmospheric science and meteorology
**Mechanism established.** Forecasts assimilate observations into versioned models and remain predictions.

**Astra lesson.** Astra records forecasts assimilate observations into versioned models and remain predictions.

**Limitation.** Earth operational weather models do not define exotic atmospheres.

**Disposition.** `adapt`.

### Climatology
**Mechanism established.** Climate regimes, variability, trends, and compound events operate at multiple scales.

**Astra lesson.** Climate regimes, variability, trends, and compound events operate at multiple scales.

**Limitation.** Earth climate findings are not universal planetary laws.

**Disposition.** `adapt`.

### Fluid dynamics and transport
**Mechanism established.** Advection, diffusion, mixing, deposition, and boundary interaction are distinct process stages.

**Astra lesson.** Advection, diffusion, mixing, deposition, and boundary interaction are distinct process stages.

**Limitation.** Full numerical fluid simulation is too costly and assumption-heavy.

**Disposition.** `adapt`.

### Thermodynamics and heat transfer
**Mechanism established.** Temperature, heat, sources, sinks, gradients, phase change, and transfer modes differ.

**Astra lesson.** Temperature, heat, sources, sinks, gradients, phase change, and transfer modes differ.

**Limitation.** Material equations require substrate-specific calibration.

**Disposition.** `adapt`.

### Geology and terrain
**Mechanism established.** Terrain is substrate, history, stability, scale, and affordance—not a single movement modifier.

**Astra lesson.** Terrain is substrate, history, stability, scale, and affordance—not a single movement modifier.

**Limitation.** Earth geomorphology cannot govern magical or artificial terrain.

**Disposition.** `adapt`.

### Hydrology and oceanography
**Mechanism established.** Flows, tides, currents, salinity, waves, and boundaries require distinct profiles.

**Astra lesson.** Flows, tides, currents, salinity, waves, and boundaries require distinct profiles.

**Limitation.** Ocean models are not universal fluid doctrine.

**Disposition.** `adapt`.

### Fire science
**Mechanism established.** Ignition, fuel, support medium, heat release, smoke, ventilation, spread, and suppression are separable.

**Astra lesson.** Ignition, fuel, support medium, heat release, smoke, ventilation, spread, and suppression are separable.

**Limitation.** Oxygen combustion is not universal source-local fire.

**Disposition.** `adapt`.

### Hazard and disaster science
**Mechanism established.** Hazard, exposure, vulnerability, capacity, consequence, and disaster risk are distinct.

**Astra lesson.** Hazard, exposure, vulnerability, capacity, consequence, and disaster risk are distinct.

**Limitation.** Policy risk frameworks do not determine game effects.

**Disposition.** `adopt distinctions`.

### Environmental chemistry
**Mechanism established.** Sources, media, partitioning, transport, transformation, persistence, exposure, and remediation are separate.

**Astra lesson.** Sources, media, partitioning, transport, transformation, persistence, exposure, and remediation are separate.

**Limitation.** Chemical-specific coefficients remain content profiles.

**Disposition.** `adapt`.

### Radiation and electromagnetic environments
**Mechanism established.** Field state, shielding, dose rate, accumulation, and induced effects require typed interfaces.

**Astra lesson.** Field state, shielding, dose rate, accumulation, and induced effects require typed interfaces.

**Limitation.** Target effects remain AFQR-16.

**Disposition.** `adapt`.

### Ecology
**Mechanism established.** Populations, habitats, interactions, disturbance, succession, and regime shifts require profile-scoped processes.

**Astra lesson.** Populations, habitats, interactions, disturbance, succession, and regime shifts require profile-scoped processes.

**Limitation.** No single equilibrium or food-web model is universal.

**Disposition.** `adapt`.

### Population ecology
**Mechanism established.** Carrying capacity depends on habitat heterogeneity, connectivity, stages, and movement.

**Astra lesson.** Carrying capacity depends on habitat heterogeneity, connectivity, stages, and movement.

**Limitation.** No universal logistic-growth equation.

**Disposition.** `adapt`.

### Landscape ecology
**Mechanism established.** Patches, corridors, connectivity, edge effects, and scale shape population processes.

**Astra lesson.** Patches, corridors, connectivity, edge effects, and scale shape population processes.

**Limitation.** Spatial implementation awaits AFQR-18.

**Disposition.** `adapt`.

### Epidemiological interfaces
**Mechanism established.** Environmental persistence, vectors, shedding, seasonality, and exposure pathways belong source-side.

**Astra lesson.** Environmental persistence, vectors, shedding, seasonality, and exposure pathways belong source-side.

**Limitation.** Host infection and full epidemiology remain outside AFQR-17.

**Disposition.** `contain`.

### Resource management
**Mechanism established.** Stock, flow, capacity, extraction, regeneration, thresholds, and irreversible shifts differ.

**Astra lesson.** Stock, flow, capacity, extraction, regeneration, thresholds, and irreversible shifts differ.

**Limitation.** Final economy and governance remain handoffs.

**Disposition.** `adapt`.

### Environmental engineering
**Mechanism established.** Controlled environments require sensors, setpoints, reservoirs, ventilation, filtration, isolation, and failure modes.

**Astra lesson.** Controlled environments require sensors, setpoints, reservoirs, ventilation, filtration, isolation, and failure modes.

**Limitation.** Platform integrity remains AFQR-16.

**Disposition.** `adopt interfaces`.

### Planetary science
**Mechanism established.** Planetary atmospheres vary in composition, pressure, temperature, radiation, and dynamics.

**Astra lesson.** Planetary atmospheres vary in composition, pressure, temperature, radiation, and dynamics.

**Limitation.** Earthlike assumptions are rejected.

**Disposition.** `adopt diversity`.

### Built environments
**Mechanism established.** Compartments can have local atmosphere, pressure, life-support, isolation, and emergency modes.

**Astra lesson.** Compartments can have local atmosphere, pressure, life-support, isolation, and emergency modes.

**Limitation.** Exact spacecraft engineering is source-specific.

**Disposition.** `adapt`.

### Geographic information and maps
**Mechanism established.** Features, coordinate references, coverage, scale, resolution, provenance, and time are explicit.

**Astra lesson.** Features, coordinate references, coverage, scale, resolution, provenance, and time are explicit.

**Limitation.** AFQR-17 does not select one coordinate system.

**Disposition.** `adopt epistemic separation`.

### Forecasting and uncertainty
**Mechanism established.** Forecast issue time, target time, model version, ensemble spread, calibration, and later verification differ.

**Astra lesson.** Forecast issue time, target time, model version, ensemble spread, calibration, and later verification differ.

**Limitation.** Forecasts never mutate future truth.

**Disposition.** `adopt`.

### Distributed process simulation
**Mechanism established.** Versioned process steps, event queues, budgets, deterministic ordering, aggregation, and replay support scale.

**Astra lesson.** Versioned process steps, event queues, budgets, deterministic ordering, aggregation, and replay support scale.

**Limitation.** Implementation performance remains future work.

**Disposition.** `adopt`.

### Games and simulation systems
**Mechanism established.** Weather, terrain, fire, hazards, ecology, and maps are commonly compressed into playable abstractions.

**Astra lesson.** Weather, terrain, fire, hazards, ecology, and maps are commonly compressed into playable abstractions.

**Limitation.** These are pressure profiles, not Astra law.

**Disposition.** `contain`.

### TTRPG systems
**Mechanism established.** Donors supply tags, clocks, tables, damage shortcuts, and local cosmologies.

**Astra lesson.** Donors supply tags, clocks, tables, damage shortcuts, and local cosmologies.

**Limitation.** Preserve function; reject universalization and direct mutation.

**Disposition.** `contain`.



## Part IV — Canonical terminology

The following definitions are runtime-qualified terms. The complete registry also records prohibited unqualified uses and anti-collapse notes.

- **environment** — A purpose-scoped authoritative environmental state domain; not a synonym for location, map, terrain, or narration.
- **environmental region** — A typed state-bearing environmental partition or overlap set with explicit purpose, owner, continuity, and boundary references.
- **medium** — A state-bearing carrier or substrate through which quantities, materials, signals, organisms, or source-local effects may exist or move.
- **field** — A spatially or topologically varying environmental state that may influence interfaces without being identical to force or effect.
- **reservoir** — A bounded stock-holding environmental state with capacity, composition, ownership, and balance evidence.
- **source** — A registered producer of environmental stock, flow, field, or process output.
- **sink** — A registered remover or receiver of environmental stock, flow, field, or process output.
- **carrier** — A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **boundary** — A state-bearing interface constraint governing adjacency, permeability, containment, transfer, and visibility without owning universal geometry.
- **interface** — A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **compartment** — A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **zone** — A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **habitat** — A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **biome** — A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **climate regime** — A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **artificial environment** — A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **source-local environment** — A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental variable** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental quantity** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **composition** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **concentration** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **gradient** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **flux** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **pressure** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **temperature** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **humidity** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **illumination** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **radiation field** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **gravity field** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **flow** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **current** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **wind** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental capacity** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental state snapshot** — A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **terrain** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **surface** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **substrate** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **slope** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **roughness** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **stability** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **traction** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **permeability** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **obstruction** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **cover** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **concealment** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **visibility effect** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **traversability** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **navigability** — A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **terrain affordance** — A purpose- and embodiment-scoped opportunity or constraint exposed by terrain; not a flat universal modifier.
- **weather** — A comparatively short-timescale environmental state or process realization within a region.
- **weather event** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **weather process** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **storm** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **precipitation** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **front** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **season** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **climate** — A profile of longer-timescale distributions, regimes, variability, trends, and constraints; not current weather.
- **climate regime** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **climate trend** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **anomaly** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **forecast** — A versioned epistemic prediction with issue time, target time, model basis, uncertainty, and later verification.
- **warning** — A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **hazard** — A typed source or condition capable of producing adverse exposure or constraints under specified triggers and interfaces; not guaranteed harm.
- **hazard source** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **hazard instance** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **trigger** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **activation** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **hazard scope** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **propagation** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **escalation** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **suppression** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **containment** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **termination** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **residual hazard** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **compound hazard** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **cascading hazard** — A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **contaminant** — A typed material, organism, signal, field-bearing entity, or source-local substance whose presence and transport are separately represented.
- **pollutant** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **pathogen reservoir** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **toxin reservoir** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **radioactive material** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **corruption reservoir** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **contaminated medium** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **deposition** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **accumulation** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **persistence** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **decay** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **neutralization** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **remediation** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **secondary contamination** — A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **population** — An aggregate ecological state over a defined category, region, cohort, and time; not an individual actor or collective mind.
- **cohort** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **niche** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **carrying capacity** — A profile-scoped contextual support limit emerging from habitat, resources, interactions, time, and uncertainty; not a fixed universal scalar.
- **biomass** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **recruitment** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **mortality** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **migration** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **competition** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **predation** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **mutualism** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **parasitism** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **succession** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **disturbance** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **resilience** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **regime shift** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **invasive population** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **extinction risk** — A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental observation** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **sensor reading** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **sample** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **survey** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **map** — A versioned claim set or representation about spatial/environmental features with coverage, scale, age, and provenance; not territory truth.
- **chart** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental model** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **confidence** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **uncertainty** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **coverage** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **resolution** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **map age** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **provenance** — A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental process** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **process step** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **transport profile** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **transport path** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **process budget** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **propagation frontier** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **simulation tier** — A named fidelity and ownership mode with explicit retained truth, permitted approximations, promotion inputs, and demotion obligations.
- **materialization** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **promotion** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **demotion** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **historical approximation** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental intervention** — A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **target presence** — A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **target interface** — A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental exposure** — A certified source-side target-interface quantity or qualitative state handed to AFQR-16; not uptake, injury, or condition.
- **exposure quantity** — A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **environmental resource** — A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **resource stock** — A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **resource flow** — A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **regeneration** — A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **depletion** — A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.
- **harvest pressure** — A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time, visibility, and source-local namespace must be qualified at runtime.

### Prohibited unqualified runtime terms

`safe, dangerous, toxic, breathable, impassable, visible, covered, stable, storm, climate, biome, contaminated, exposed, extinct, dead ecosystem, resource-rich, accurate map, certain forecast, global hazard, environmental damage`

Each requires a named owner, scope, region/medium/field or audience, purpose, profile version, effective time, evidence basis, and source-local namespace where applicable.


## Part V — Environmental regions, ownership, media, and fields

An `EnvironmentalRegionInstance` is a purpose-scoped state partition or overlap set. It does not have to be a single geometric polygon, room, hex, or volume. A region may be an atmosphere layer, compartment, watershed, habitat patch, orbital zone, network environment, magical field extent, or source-local plane.

Ownership is federated. Separate owners may control region identity, medium composition, field state, boundary state, terrain state, weather, hazards, contamination reservoirs, resources, ecological populations, and epistemic records. Coordinators may gather candidate fragments but may not mutate those owners.

Media and fields are independently registered and may overlap. An atmosphere, fluid, vacuum, soil, data network, psychic medium, or interplanar substrate has only the variables declared by its profile. A field is not assumed to be uniform, causal, harmful, or compatible with every target.


## Part VI — Boundaries, containment, and transport interfaces

Boundaries are state-bearing relations or entities with purpose, adjacency references, permeability, containment, current state, and interface profiles. Geometry is referenced but not universally owned here; AFQR-18 will own position, distance, reachability, and general spatial topology.

Open, sealed, porous, moving, disputed, network, planar, membrane, and phase boundaries are legal profiles. A breach is an explicit transition. Containment affects environmental transport and may fail independently of target protection.

Transport is decomposed into carrier, path, boundary interaction, transfer, attenuation, conversion, deposition, resuspension, and loss. No mandatory grid, continuous coordinate space, or fluid solver is imposed.


## Part VII — Environmental quantities, sources, sinks, and reservoirs

Quantified environmental state uses AFQR-07. Sources produce; sinks remove or receive; reservoirs store; transformations convert. Stock, flow, capacity, flux, composition, concentration, and regeneration are distinct.

Every transformation manifest identifies inputs, outputs, losses, byproducts, residuals, fixed precision, and rounding. Negative reservoirs, implicit free sources, and undocumented destruction are invalid. Source-local creation or annihilation requires an explicit namespaced exception manifest rather than silent balance failure.


## Part VIII — Environmental processes and scheduling

An environmental process has a definition, versioned instance, frozen input closure, process state, budget, step candidate, owner-prepared transition, and termination receipt. AFQR-04 logical time governs ordering. Worker completion is never procedure.

Propagation uses frontiers, cycle detection, fan-out and depth budgets, deterministic stochastic receipts where needed, and explicit terminal states. Missing process profiles produce unresolved or quarantine outcomes rather than improvised equations.


## Part IX — Terrain and environmental affordances

Terrain is not geometry and does not own movement success. It is a profile-scoped combination of substrate, surface, condition, and purpose-specific affordances.

Affordances may include load support, traction, stability, permeability, obstruction, cover potential, concealment, excavation difficulty, buildability, traversability, or navigability. They are embodiment- and method-relative. Cover blocks or attenuates a route; concealment impairs observation; obstruction constrains passage; visibility remains an epistemic and future spatial/sensory handoff.

Terrain records may change through erosion, flooding, collapse, excavation, construction, or source-local transformation. Maps are not authoritative terrain.


## Part X — Weather and climate

Weather state, weather event, weather process, season, climate regime, climate trend, and forecast are separate.

Climate profiles constrain available forcing, distributions, variability, and consistency checks; they do not select each weather event. Weather transitions may be deterministic or use backend stochastic receipts. Local terrain, external forcing, artificial control, and source-local fields are explicit inputs.

Forecasts are AFQR-10 epistemic products with issue time, target time, model version, evidence closure, uncertainty, audience, and verification. Forecasts may disagree or be wrong and never own future mutation.


## Part XI — Hazards and disasters

A hazard is a typed potential source or environmental condition, not a harmful effect. Hazard presence, trigger satisfaction, activation, scope, escalation, movement, propagation, suppression, containment, residual state, target exposure, and termination are separate.

Compound hazards combine through registered interaction definitions. Cascades have budgets and cycle detection. Fire, smoke, flood, collapse, debris, radiation, and source-local disasters specialize common region, medium, source, reservoir, transport, and hazard primitives rather than forming unrelated engines.

Combustion does not assume oxygen universally. Collapse may originate from AFQR-16 structural change but environmental debris, smoke, atmosphere, and exposure production remain AFQR-17.


## Part XII — Contamination and environmental exposure

Contamination separates contaminant identity, source, reservoir, carrier, medium state, composition, concentration, partitioning, transport, deposition, resuspension, decay, transformation, accumulation, cleanup, waste, and residual state.

AFQR-17 resolves target presence, environmental interface contact, route, duration, and the quantity or qualitative state reaching the interface. It then creates `AFQR16ExposureHandoff`. AFQR-17 may not determine target uptake, penetration into a body or structure, injury, condition, impairment, or death.

Cleanup is not erasure. Partial removal, residual contamination, disposal, secondary waste, and ecological effects remain explicit.


## Part XIII — Environmental resources

Environmental resources use separate definitions for stock, flow, capacity, regeneration, depletion, harvest eligibility, harvest pressure, and balance. Renewable, nonrenewable, diffuse, mobile, atmospheric, biological, energetic, and source-local resources may coexist.

Regeneration requires a registered source or transformation. Harvesting requires AFQR-07 settlement. Carrying capacity and habitat quality are not resource-stock synonyms. Environmental resources do not become a universal currency.


## Part XIV — Ecology, populations, and habitats

An ecological population is an aggregate, not an actor, faction, species definition, or collective mind. It is scoped by category, cohort, region, habitat, time, and profile.

Recruitment, mortality, migration, resource dependency, competition, predation, mutualism, parasitism, disease pressure, succession, disturbance, invasion, resilience, regime shift, and extinction risk are separate process families. Carrying capacity is contextual and profile-scoped rather than one fixed number.

Ecological processes are bounded and may remain aggregate. Materialization never invents individual organisms or historical events. Extinction risk does not establish extinction.


## Part XV — Artificial, planetary, and source-local environments

Artificial environments separate platform integrity from environmental medium. Compartments, setpoints, actual state, sensor readings, controller actions, ventilation, filtration, reserves, isolation, and emergency modes remain distinct. AFQR-16 owns platform components and occupant effects.

Planetary and orbital profiles may declare non-Earth atmospheres, vacuum, radiation, gravity-like fields, subsurface oceans, and source-local solvents or media. Interplanar and magical fields remain namespaced and require registered interfaces. No exotic medium is normalized to ordinary air.


## Part XVI — Observation, maps, forecasts, and environmental knowledge

Environmental truth is distinct from observation, sensor reading, sample, survey, map, chart, forecast, warning, institutional report, public belief, and model portrayal.

Sensors have method, calibration, coverage, resolution, error, access, and provenance. Maps contain versioned feature claims, coverage, scale, coordinate-reference handoffs, age, and uncertainty. A map may merge regions, omit features, or be outdated without changing territory.

Forecast revisions append new records. Historical forecasts remain available for verification and audit.


## Part XVII — Hidden state and model projection

Private hazards, unknown terrain, secret routes, concealed boundaries, latent contamination, hidden reservoirs, undiscovered populations, protected habitats, covert interventions, and classified forecasts are audience-scoped.

Security requires deterministic private integrity commitments, audience-scoped opaque tokens, projection-specific digests, cross-packet isolation, cross-audience linkability tests, constant policy error surfaces, and semantic output validation.

The model receives only a grounding manifest, permitted claim kinds, evidence bindings, qualified uncertainty, and an authorized projection. Prompt text is not the security boundary. Unsupported weather, terrain, hazard, contamination, ecological, map, and forecast claims are rejected.


## Part XVIII — Typed contracts

The machine-readable catalog contains **243** schema-level contracts. Every entry declares required, optional, hidden, derived, and prohibited fields; authoritative owner; relevant temporal semantics; profile versions; source-local namespace; cross-domain bases; deterministic private commitments; opaque audience tokens; AFQR references; and invariants.

- `EnvironmentalRegionDefinition` — family `region`, owner `environmental_region_owner`.
- `EnvironmentalRegionInstance` — family `region`, owner `environmental_region_owner`.
- `EnvironmentalStateAuthorityBinding` — family `environment_core`, owner `environmental_state_owner`.
- `EnvironmentalRegionOwnerBinding` — family `region`, owner `environmental_region_owner`.
- `EnvironmentalRegionContinuityProfile` — family `region`, owner `environmental_region_owner`.
- `EnvironmentalRegionContinuityDetermination` — family `region`, owner `environmental_region_owner`.
- `EnvironmentalRegionLineageEdge` — family `region`, owner `environmental_region_owner`.
- `EnvironmentalMediumDefinition` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `EnvironmentalMediumInstance` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `EnvironmentalFieldDefinition` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `EnvironmentalFieldInstance` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `MediumCompositionState` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `FieldStateSnapshot` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `MediumOrFieldApplicabilityProfile` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `MediumOrFieldInteractionInterface` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `EnvironmentalBoundaryDefinition` — family `boundary`, owner `environmental_boundary_owner`.
- `EnvironmentalBoundaryInstance` — family `boundary`, owner `environmental_boundary_owner`.
- `BoundaryPermeabilityProfile` — family `boundary`, owner `environmental_boundary_owner`.
- `BoundaryContainmentProfile` — family `boundary`, owner `environmental_boundary_owner`.
- `BoundaryState` — family `boundary`, owner `environmental_boundary_owner`.
- `BoundaryBreachCandidate` — family `boundary`, owner `environmental_boundary_owner`.
- `BoundaryBreachDetermination` — family `boundary`, owner `environmental_boundary_owner`.
- `BoundaryTransitionReceipt` — family `boundary`, owner `environmental_boundary_owner`.
- `EnvironmentalSourceDefinition` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalSourceInstance` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalSinkDefinition` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalSinkInstance` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalReservoirDefinition` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalReservoirState` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalTransformationDefinition` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalTransformationManifest` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalBalanceReceipt` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalProcessDefinition` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalProcessInstance` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalProcessInputClosure` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalProcessState` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalProcessStepCandidate` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalProcessTransition` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalProcessTerminationReceipt` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalProcessBudget` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalTransportProfile` — family `transport`, owner `environmental_transport_owner`.
- `TransportCarrierBinding` — family `transport`, owner `environmental_transport_owner`.
- `TransportPathReference` — family `transport`, owner `environmental_transport_owner`.
- `TransportBoundaryInteraction` — family `boundary`, owner `environmental_boundary_owner`.
- `TransportQuantityManifest` — family `transport`, owner `environmental_transport_owner`.
- `TransportAttenuationManifest` — family `transport`, owner `environmental_transport_owner`.
- `TransportDepositionManifest` — family `transport`, owner `environmental_transport_owner`.
- `TransportPropagationCandidate` — family `transport`, owner `environmental_transport_owner`.
- `TransportPropagationReceipt` — family `transport`, owner `environmental_transport_owner`.
- `TerrainDefinition` — family `terrain`, owner `terrain_state_owner`.
- `TerrainInstance` — family `terrain`, owner `terrain_state_owner`.
- `TerrainSubstrateBinding` — family `terrain`, owner `terrain_state_owner`.
- `TerrainSurfaceProfile` — family `terrain`, owner `terrain_state_owner`.
- `TerrainAffordanceDefinition` — family `terrain`, owner `terrain_state_owner`.
- `TerrainAffordanceInstance` — family `terrain`, owner `terrain_state_owner`.
- `TerrainConditionState` — family `terrain`, owner `terrain_state_owner`.
- `TerrainTransitionCandidate` — family `terrain`, owner `terrain_state_owner`.
- `TerrainTransitionReceipt` — family `terrain`, owner `terrain_state_owner`.
- `WeatherStateDefinition` — family `weather_climate`, owner `weather_or_climate_owner`.
- `WeatherStateSnapshot` — family `weather_climate`, owner `weather_or_climate_owner`.
- `WeatherProcessDefinition` — family `process`, owner `environmental_process_owner`.
- `WeatherEventInstance` — family `weather_climate`, owner `weather_or_climate_owner`.
- `WeatherTransitionCandidate` — family `weather_climate`, owner `weather_or_climate_owner`.
- `WeatherTransitionReceipt` — family `weather_climate`, owner `weather_or_climate_owner`.
- `ClimateRegimeDefinition` — family `weather_climate`, owner `weather_or_climate_owner`.
- `ClimateRegimeInstance` — family `weather_climate`, owner `weather_or_climate_owner`.
- `ClimateTrendRecord` — family `weather_climate`, owner `weather_or_climate_owner`.
- `WeatherClimateConsistencyAssessment` — family `weather_climate`, owner `weather_or_climate_owner`.
- `HazardDefinition` — family `hazard`, owner `hazard_state_owner`.
- `HazardInstance` — family `hazard`, owner `hazard_state_owner`.
- `HazardSourceBinding` — family `balance`, owner `environmental_balance_owner`.
- `HazardTriggerDefinition` — family `hazard`, owner `hazard_state_owner`.
- `HazardTriggerCandidate` — family `hazard`, owner `hazard_state_owner`.
- `HazardActivationDetermination` — family `hazard`, owner `hazard_state_owner`.
- `HazardState` — family `hazard`, owner `hazard_state_owner`.
- `HazardEscalationProfile` — family `hazard`, owner `hazard_state_owner`.
- `HazardPropagationProfile` — family `hazard`, owner `hazard_state_owner`.
- `HazardSuppressionCandidate` — family `hazard`, owner `hazard_state_owner`.
- `HazardContainmentState` — family `hazard`, owner `hazard_state_owner`.
- `HazardTerminationDetermination` — family `hazard`, owner `hazard_state_owner`.
- `HazardInteractionDefinition` — family `hazard`, owner `hazard_state_owner`.
- `CompoundHazardProfile` — family `hazard`, owner `hazard_state_owner`.
- `CascadingHazardProfile` — family `hazard`, owner `hazard_state_owner`.
- `HazardInteractionCandidate` — family `hazard`, owner `hazard_state_owner`.
- `HazardPropagationFrontier` — family `hazard`, owner `hazard_state_owner`.
- `HazardCycleDetectionReceipt` — family `hazard`, owner `hazard_state_owner`.
- `HazardPropagationBudget` — family `hazard`, owner `hazard_state_owner`.
- `HazardCascadeTerminationReceipt` — family `hazard`, owner `hazard_state_owner`.
- `CombustionProcessProfile` — family `process`, owner `environmental_process_owner`.
- `FuelState` — family `disaster`, owner `specialized_environmental_process_owner`.
- `IgnitionCandidate` — family `disaster`, owner `specialized_environmental_process_owner`.
- `SmokeReservoirState` — family `balance`, owner `environmental_balance_owner`.
- `FloodProcessProfile` — family `process`, owner `environmental_process_owner`.
- `FloodExtentState` — family `disaster`, owner `specialized_environmental_process_owner`.
- `CollapseHazardProfile` — family `hazard`, owner `hazard_state_owner`.
- `DebrisFieldState` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `DisasterCompositeState` — family `disaster`, owner `specialized_environmental_process_owner`.
- `ContaminantDefinition` — family `contamination`, owner `contamination_state_owner`.
- `ContaminantInstance` — family `contamination`, owner `contamination_state_owner`.
- `ContaminationReservoir` — family `balance`, owner `environmental_balance_owner`.
- `ContaminatedMediumState` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `ContaminantTransportProfile` — family `transport`, owner `environmental_transport_owner`.
- `ContaminantTransformationProfile` — family `balance`, owner `environmental_balance_owner`.
- `ContaminationAccumulationState` — family `contamination`, owner `contamination_state_owner`.
- `ContaminationCleanupCandidate` — family `contamination`, owner `contamination_state_owner`.
- `ContaminationCleanupReceipt` — family `contamination`, owner `contamination_state_owner`.
- `ResidualContaminationRecord` — family `contamination`, owner `contamination_state_owner`.
- `EnvironmentalExposureProfile` — family `exposure`, owner `environmental_exposure_production_owner`.
- `TargetPresenceCandidate` — family `exposure`, owner `environmental_exposure_production_owner`.
- `TargetPresenceDetermination` — family `exposure`, owner `environmental_exposure_production_owner`.
- `TargetInterfaceContactCandidate` — family `exposure`, owner `environmental_exposure_production_owner`.
- `EnvironmentalExposureCandidate` — family `exposure`, owner `environmental_exposure_production_owner`.
- `EnvironmentalExposureQuantityManifest` — family `exposure`, owner `environmental_exposure_production_owner`.
- `EnvironmentalExposureUncertaintyManifest` — family `exposure`, owner `environmental_exposure_production_owner`.
- `AFQR16ExposureHandoff` — family `exposure`, owner `environmental_exposure_production_owner`.
- `EnvironmentalResourceDefinition` — family `resource`, owner `environmental_resource_owner`.
- `EnvironmentalResourceStock` — family `resource`, owner `environmental_resource_owner`.
- `EnvironmentalResourceFlow` — family `resource`, owner `environmental_resource_owner`.
- `ResourceRegenerationProfile` — family `resource`, owner `environmental_resource_owner`.
- `ResourceDepletionProfile` — family `resource`, owner `environmental_resource_owner`.
- `HarvestEligibilityCandidate` — family `resource`, owner `environmental_resource_owner`.
- `HarvestPressureRecord` — family `resource`, owner `environmental_resource_owner`.
- `EnvironmentalCapacityState` — family `resource`, owner `environmental_resource_owner`.
- `EnvironmentalResourceBalanceReceipt` — family `balance`, owner `environmental_balance_owner`.
- `HabitatDefinition` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `HabitatInstance` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `HabitatQualityState` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `EcologicalPopulationDefinition` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `EcologicalPopulationInstance` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `PopulationCohortState` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `PopulationProcessProfile` — family `process`, owner `environmental_process_owner`.
- `PopulationResourceDependency` — family `resource`, owner `environmental_resource_owner`.
- `PopulationInteractionRelation` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `PopulationMigrationCandidate` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `PopulationTransitionReceipt` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `EcologicalProcessDefinition` — family `process`, owner `environmental_process_owner`.
- `EcologicalProcessInstance` — family `process`, owner `environmental_process_owner`.
- `EcologicalInteractionProfile` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `CarryingCapacityProfile` — family `resource`, owner `environmental_resource_owner`.
- `SuccessionProfile` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `DisturbanceProfile` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `InvasionProfile` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `ExtinctionRiskAssessment` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `EcologicalTransitionCandidate` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `EcologicalTransitionReceipt` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `EnvironmentalInterventionDefinition` — family `intervention`, owner `environmental_intervention_owner`.
- `EnvironmentalInterventionEligibility` — family `intervention`, owner `environmental_intervention_owner`.
- `EnvironmentalInterventionPlan` — family `intervention`, owner `environmental_intervention_owner`.
- `EnvironmentalInterventionResourceManifest` — family `resource`, owner `environmental_resource_owner`.
- `EnvironmentalInterventionAttempt` — family `intervention`, owner `environmental_intervention_owner`.
- `EnvironmentalInterventionEffectCandidate` — family `intervention`, owner `environmental_intervention_owner`.
- `EnvironmentalInterventionOutcome` — family `intervention`, owner `environmental_intervention_owner`.
- `EnvironmentalInterventionComplicationCandidate` — family `intervention`, owner `environmental_intervention_owner`.
- `ArtificialEnvironmentProfile` — family `artificial`, owner `artificial_environment_owner`.
- `EnvironmentalControlSubsystemReference` — family `artificial`, owner `artificial_environment_owner`.
- `CompartmentEnvironmentState` — family `artificial`, owner `artificial_environment_owner`.
- `LifeSupportEnvironmentalState` — family `artificial`, owner `artificial_environment_owner`.
- `EnvironmentalControlSetpoint` — family `artificial`, owner `artificial_environment_owner`.
- `EnvironmentalControlFailureCandidate` — family `artificial`, owner `artificial_environment_owner`.
- `EmergencyEnvironmentalMode` — family `artificial`, owner `artificial_environment_owner`.
- `EnvironmentalObservation` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `EnvironmentalSensorDefinition` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `EnvironmentalSensorReading` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `EnvironmentalSampleRecord` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `EnvironmentalSurveyRecord` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `MapDefinition` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `MapVersion` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `MapFeatureClaim` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `MapCoverageManifest` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `ForecastDefinition` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `ForecastInstance` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `ForecastUncertaintyManifest` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `ForecastVerificationRecord` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `EnvironmentalSimulationTierDefinition` — family `simulation`, owner `environmental_materialization_owner`.
- `EnvironmentalMaterializationPolicy` — family `simulation`, owner `environmental_materialization_owner`.
- `EnvironmentalPromotionInputClosure` — family `simulation`, owner `environmental_materialization_owner`.
- `EnvironmentalPromotionReceipt` — family `simulation`, owner `environmental_materialization_owner`.
- `EnvironmentalDemotionRetentionManifest` — family `simulation`, owner `environmental_materialization_owner`.
- `EnvironmentalDemotionReceipt` — family `simulation`, owner `environmental_materialization_owner`.
- `HistoricalEnvironmentalApproximationRecord` — family `simulation`, owner `environmental_materialization_owner`.
- `PrivateEnvironmentalReceipt` — family `security`, owner `private_environmental_receipt_owner`.
- `PrivateHazardReceipt` — family `hazard`, owner `hazard_state_owner`.
- `PrivateContaminationReceipt` — family `contamination`, owner `contamination_state_owner`.
- `PrivateEcologyReceipt` — family `security`, owner `private_environmental_receipt_owner`.
- `PrivateForecastReceipt` — family `observation_forecast`, owner `AFQR10_epistemic_or_forecast_owner`.
- `ActorVisibleEnvironmentalProjection` — family `projection`, owner `audience_projection_owner`.
- `ObserverVisibleEnvironmentalProjection` — family `projection`, owner `audience_projection_owner`.
- `PlayerVisibleEnvironmentalProjection` — family `projection`, owner `audience_projection_owner`.
- `ModelVisibleEnvironmentalProjection` — family `projection`, owner `audience_projection_owner`.
- `PublicEnvironmentalProjection` — family `environment_core`, owner `environmental_state_owner`.
- `ModelEnvironmentalGroundingManifest` — family `model_boundary`, owner `model_boundary_validator_owner`.
- `PermittedEnvironmentalClaimKindRegistry` — family `model_boundary`, owner `model_boundary_validator_owner`.
- `ModelEnvironmentalEvidenceBinding` — family `model_boundary`, owner `model_boundary_validator_owner`.
- `ModelEnvironmentalOutputValidator` — family `model_boundary`, owner `model_boundary_validator_owner`.
- `CrossPacketEnvironmentalIsolationReceipt` — family `model_boundary`, owner `model_boundary_validator_owner`.
- `EnvironmentalProjectionNoninterferenceReceipt` — family `model_boundary`, owner `model_boundary_validator_owner`.
- `AudienceScopedEnvironmentalToken` — family `security`, owner `private_environmental_receipt_owner`.
- `PrivateEnvironmentalIntegrityCommitment` — family `security`, owner `private_environmental_receipt_owner`.
- `ProjectionSpecificEnvironmentalDigest` — family `security`, owner `private_environmental_receipt_owner`.
- `CrossAudienceEnvironmentalLinkabilityTest` — family `security`, owner `private_environmental_receipt_owner`.
- `AFQR17Handoff` — family `handoff`, owner `handoff_coordinator_non_mutating`.
- `AtmosphereProfile` — family `environment_core`, owner `environmental_state_owner`.
- `FluidMediumProfile` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `VacuumEnvironmentProfile` — family `environment_core`, owner `environmental_state_owner`.
- `RadiationEnvironmentProfile` — family `environment_core`, owner `environmental_state_owner`.
- `IlluminationFieldProfile` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `AcousticFieldProfile` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `ElectromagneticFieldProfile` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `GravityFieldProfile` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `SourceLocalFieldProfile` — family `medium_field`, owner `environmental_medium_or_field_owner`.
- `EnvironmentalAdjacencyReference` — family `spatial_handoff`, owner `AFQR18_spatial_owner_pending`.
- `EnvironmentalContainmentDependency` — family `environment_core`, owner `environmental_state_owner`.
- `EnvironmentalProcessDependency` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalInvariantSet` — family `process`, owner `environmental_process_owner`.
- `EnvironmentalStochasticSelectionReceipt` — family `process`, owner `environmental_process_owner`.
- `TerrainSupportAssessment` — family `terrain`, owner `terrain_state_owner`.
- `TerrainCoverProjection` — family `terrain`, owner `terrain_state_owner`.
- `TerrainConcealmentProjection` — family `terrain`, owner `terrain_state_owner`.
- `TerrainVisibilityHandoff` — family `terrain`, owner `terrain_state_owner`.
- `TerrainNavigationHandoff` — family `terrain`, owner `terrain_state_owner`.
- `WeatherObservationClosure` — family `weather_climate`, owner `weather_or_climate_owner`.
- `WeatherStochasticSelectionReceipt` — family `weather_climate`, owner `weather_or_climate_owner`.
- `ClimateConstraintManifest` — family `weather_climate`, owner `weather_or_climate_owner`.
- `HazardExposureProductionManifest` — family `hazard`, owner `hazard_state_owner`.
- `HazardSuppressionOutcome` — family `hazard`, owner `hazard_state_owner`.
- `HazardResidualState` — family `hazard`, owner `hazard_state_owner`.
- `ContaminationDisposalManifest` — family `contamination`, owner `contamination_state_owner`.
- `WasteReservoirState` — family `balance`, owner `environmental_balance_owner`.
- `EnvironmentalRemediationProfile` — family `contamination`, owner `contamination_state_owner`.
- `EcologicalMortalityCandidate` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `EcologicalRecruitmentCandidate` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `EcologicalResourcePressure` — family `resource`, owner `environmental_resource_owner`.
- `HabitatFragmentationRecord` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `MigrationCorridorReference` — family `ecology`, owner `ecological_population_or_habitat_owner`.
- `EnvironmentalCommandHandoff` — family `handoff`, owner `handoff_coordinator_non_mutating`.
- `EnvironmentalActionGatewayHandoff` — family `handoff`, owner `handoff_coordinator_non_mutating`.
- `EnvironmentalSchedulerHandoff` — family `handoff`, owner `handoff_coordinator_non_mutating`.
- `EnvironmentalInstitutionalHandoff` — family `handoff`, owner `handoff_coordinator_non_mutating`.
- `EnvironmentalGovernedRelationHandoff` — family `handoff`, owner `handoff_coordinator_non_mutating`.
- `EnvironmentalQuantitySettlementHandoff` — family `handoff`, owner `handoff_coordinator_non_mutating`.
- `EnvironmentalSpatialHandoff` — family `handoff`, owner `handoff_coordinator_non_mutating`.
- `EnvironmentalConversionCertification` — family `environment_core`, owner `environmental_state_owner`.
- `EnvironmentalSourceLocalContainmentReceipt` — family `balance`, owner `environmental_balance_owner`.


## Part XIX — Determination pipelines

### Environmental-process pipeline

`scheduled/triggered process → resolve owner/region/media/fields/boundaries → freeze state and profiles → gather sources/sinks/reservoirs → bounded step → transport/transformation/hazard/terrain/resource/ecology candidates → owner fragments → AFQR-01 commit → next schedule and projections`

### Transport pipeline

`source/reservoir output → carrier/profile → path/boundaries → transfer/attenuation/conversion/deposition/loss → reservoir update or exposure candidate → AFQR-07 balance receipt`

### Weather pipeline

`weather step → freeze atmosphere/region → climate/season/forcing/local profiles → candidate weather states → deterministic or receipted stochastic selection → commit → forecasts and warnings separately`

### Hazard pipeline

`hazard instance → source/trigger/region/state/scope → activation → escalation/propagation/suppression/containment → target-interface exposure candidates → AFQR-16 handoff → schedule continuation`

### Contamination pipeline

`release/reservoir → contaminant/medium/composition/concentration → transport/transformation/deposition/decay/accumulation → reservoir candidates → target exposure → cleanup/waste/residual candidates`

### Terrain-affordance pipeline

`proposed action → terrain/surface/medium/boundary → purpose and embodiment profile → support/obstruction/visibility/traction/stability constraints → AFQR-03 and AFQR-18 handoffs → no action-success decision`

### Exposure pipeline

`target overlap candidate → presence → interface → route/duration/environmental quantity → environment-owned containment → certified AFQR-16 exposure handoff → no uptake/effect mutation`

### Ecological pipeline

`scheduled ecology step → population/habitat/resource/interaction/disturbance closure → bounded profile → recruitment/mortality/migration/resource/succession/risk candidates → owner fragments → atomic commit`

### Intervention pipeline

`command → target/authority/access/method/resources/interfaces → eligibility → reservation → attempt → environmental/resource/contamination/hazard/ecology candidates → owner commit → monitoring/residual scheduling`

### Observation and forecast pipeline

`request → observer/instrument/method/coverage/access → visible evidence → observation/forecast candidates → uncertainty/model/provenance → epistemic commit → no environmental mutation`


## Part XX — Operation grammar

The operation catalog is also available as `operations/afqr_17_operation_grammar.yaml`.

1. **atmospheric composition changes** — Evaluate 'atmospheric composition changes' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
2. **pressure rises** — Evaluate 'pressure rises' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
3. **pressure falls** — Evaluate 'pressure falls' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
4. **compartment depressurizes** — Evaluate 'compartment depressurizes' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
5. **airlock contains pressure** — Evaluate 'airlock contains pressure' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
6. **boundary leaks** — Evaluate 'boundary leaks' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
7. **fluid flows through opening** — Evaluate 'fluid flows through opening' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
8. **contaminant diffuses** — Evaluate 'contaminant diffuses' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
9. **contaminant deposits** — Evaluate 'contaminant deposits' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
10. **contaminant decays** — Evaluate 'contaminant decays' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
11. **heat source activates** — Evaluate 'heat source activates' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
12. **region warms** — Evaluate 'region warms' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
13. **region cools** — Evaluate 'region cools' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
14. **phase change occurs** — Evaluate 'phase change occurs' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
15. **wind increases** — Evaluate 'wind increases' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
16. **current changes** — Evaluate 'current changes' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
17. **storm forms** — Evaluate 'storm forms' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
18. **storm moves** — Evaluate 'storm moves' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
19. **precipitation begins** — Evaluate 'precipitation begins' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
20. **visibility falls** — Evaluate 'visibility falls' only under the registered media_transport profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
21. **climate regime constrains weather** — Evaluate 'climate regime constrains weather' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
22. **forecast is issued** — Evaluate 'forecast is issued' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
23. **forecast is wrong** — Evaluate 'forecast is wrong' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
24. **terrain becomes unstable** — Evaluate 'terrain becomes unstable' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
25. **slope collapses** — Evaluate 'slope collapses' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
26. **erosion changes terrain** — Evaluate 'erosion changes terrain' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
27. **cover is created** — Evaluate 'cover is created' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
28. **cover is destroyed** — Evaluate 'cover is destroyed' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
29. **concealment changes** — Evaluate 'concealment changes' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
30. **navigation affordance changes** — Evaluate 'navigation affordance changes' only under the registered weather_terrain profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
31. **hazard exists but remains dormant** — Evaluate 'hazard exists but remains dormant' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
32. **hazard trigger is satisfied** — Evaluate 'hazard trigger is satisfied' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
33. **hazard activates** — Evaluate 'hazard activates' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
34. **hazard escalates** — Evaluate 'hazard escalates' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
35. **hazard propagates** — Evaluate 'hazard propagates' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
36. **hazard is contained** — Evaluate 'hazard is contained' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
37. **hazard is suppressed** — Evaluate 'hazard is suppressed' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
38. **hazard terminates** — Evaluate 'hazard terminates' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
39. **two hazards combine** — Evaluate 'two hazards combine' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
40. **cascading hazard exceeds bound** — Evaluate 'cascading hazard exceeds bound' only under the registered hazard profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
41. **fire ignites** — Evaluate 'fire ignites' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
42. **fire spreads** — Evaluate 'fire spreads' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
43. **fire consumes fuel** — Evaluate 'fire consumes fuel' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
44. **smoke accumulates** — Evaluate 'smoke accumulates' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
45. **fire is extinguished** — Evaluate 'fire is extinguished' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
46. **flood begins** — Evaluate 'flood begins' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
47. **flood expands** — Evaluate 'flood expands' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
48. **water recedes** — Evaluate 'water recedes' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
49. **structural collapse creates debris hazard** — Evaluate 'structural collapse creates debris hazard' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
50. **radiation field intensifies** — Evaluate 'radiation field intensifies' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
51. **toxic reservoir leaks** — Evaluate 'toxic reservoir leaks' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
52. **pathogen persists in medium** — Evaluate 'pathogen persists in medium' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
53. **contamination accumulates in soil** — Evaluate 'contamination accumulates in soil' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
54. **cleanup removes part of reservoir** — Evaluate 'cleanup removes part of reservoir' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
55. **cleanup creates hazardous waste** — Evaluate 'cleanup creates hazardous waste' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
56. **residual contamination remains** — Evaluate 'residual contamination remains' only under the registered disaster_contamination profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
57. **target enters hazardous region** — Evaluate 'target enters hazardous region' only under the registered exposure profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
58. **target is present but not exposed** — Target presence may be established while interface contact or exposure is not; emit no AFQR-16 handoff.
59. **target interface exposure occurs** — Create a certified source-side exposure candidate with route, duration, quantity/qualitative state, uncertainty, and target-interface identity; do not determine uptake or harm.
60. **AFQR-16 rejects unsupported uptake** — Record AFQR-16 rejection or unresolved uptake; environmental truth remains unchanged except already committed source-side state.
61. **environmental resource regenerates** — Evaluate 'environmental resource regenerates' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
62. **resource is harvested** — Evaluate 'resource is harvested' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
63. **harvesting exceeds regeneration** — Evaluate 'harvesting exceeds regeneration' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
64. **stock is depleted** — Evaluate 'stock is depleted' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
65. **carrying capacity changes** — Evaluate 'carrying capacity changes' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
66. **population grows** — Evaluate 'population grows' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
67. **population declines** — Evaluate 'population declines' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
68. **migration occurs** — Evaluate 'migration occurs' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
69. **predation pressure changes** — Evaluate 'predation pressure changes' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
70. **competition changes** — Evaluate 'competition changes' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
71. **mutualism is disrupted** — Evaluate 'mutualism is disrupted' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
72. **invasive population establishes** — Evaluate 'invasive population establishes' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
73. **ecological succession advances** — Evaluate 'ecological succession advances' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
74. **disturbance resets succession** — Evaluate 'disturbance resets succession' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
75. **extinction risk rises** — Evaluate 'extinction risk rises' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
76. **habitat is restored** — Evaluate 'habitat is restored' only under the registered resource_ecology profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
77. **artificial environment maintains setpoint** — Evaluate 'artificial environment maintains setpoint' only under the registered artificial_source_local profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
78. **life support fails** — Evaluate 'life support fails' only under the registered artificial_source_local profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
79. **emergency environmental mode activates** — Evaluate 'emergency environmental mode activates' only under the registered artificial_source_local profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
80. **terraforming process advances** — Evaluate 'terraforming process advances' only under the registered artificial_source_local profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
81. **magical field shifts** — Evaluate 'magical field shifts' only under the registered artificial_source_local profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
82. **planar boundary destabilizes** — Evaluate 'planar boundary destabilizes' only under the registered artificial_source_local profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
83. **map is updated** — Evaluate 'map is updated' only under the registered epistemic_model profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
84. **map remains incomplete** — Evaluate 'map remains incomplete' only under the registered epistemic_model profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
85. **sensor reading is false** — Evaluate 'sensor reading is false' only under the registered epistemic_model profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
86. **hidden hazard affects feasibility** — Evaluate 'hidden hazard affects feasibility' only under the registered epistemic_model profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
87. **visible blocker protects hidden hazard identity** — Evaluate 'visible blocker protects hidden hazard identity' only under the registered epistemic_model profiles, prepare owner-specific non-mutating candidates, validate quantities and hidden-state policy, and commit only through AFQR-01.
88. **model invents a storm** — Reject unsupported model claim; produce validation failure and noninterference receipt; no environmental mutation.
89. **model reveals concealed contamination** — Reject unsupported model claim; produce validation failure and noninterference receipt; no environmental mutation.
90. **no lawful environmental determination exists** — Return lawful unresolved, quarantine, or doctrine escalation; create no environmental fact.


## Part XXI — Central stress cases

### Shipboard Environmental Cascade
- **Regions:** Each compartment is a purpose-scoped environmental region; ship hull and doors are AFQR-16 structures referenced by AFQR-17 boundaries.
- **Processes:** Depressurization, fire, smoke, toxin transport, ventilation loss, reserve release, and suppression are separate scheduled processes.
- **Exposure:** Crew and cargo receive target-interface exposure handoffs only after presence, boundary, route, duration, and quantity are established.
- **Cascade:** Propagation uses budgets, cycle detection, common-cause grouping, and owner-prepared atomic fragments.
- **Knowledge:** Damaged sensors produce uncertain AFQR-10 readings; hidden structural defects remain outside visible environmental packets.
- **Result:** AFQR-17 does not mutate crew injury or ship structural damage.

### Contaminated Ecosystem and Settlement
- **Partitioning:** Water, sediment, organisms, farmland, and waste are separate reservoirs with transformation and transport manifests.
- **Ecology:** Bioaccumulation and food-web transfer are profile-scoped ecological/contamination processes, not direct body conditions.
- **Epistemics:** Initial non-detection and later misidentification are preserved as observation and diagnosis histories.
- **Resources:** Harvest restriction, imports, and depletion use AFQR-07 and institutional handoffs.
- **Cleanup:** Magical purification requires a source-local bridge, balance manifest, residual state, and hazardous-waste output.
- **Result:** Public panic and illegal dumping are social, behavioral, and institutional handoffs rather than environmental automatic effects.

### Multiplanar Storm and Source-Local Field Conflict
- **Continuity:** Storm continuity across attenuation, amplification, and division is profile-scoped and may yield several candidates.
- **Interfaces:** Each boundary declares physical, psychic, conceptual, and source-local transfer interfaces independently.
- **Forecasts:** Disagreement is retained by issue time, model, evidence, and audience; no forecast controls mutation.
- **Hidden State:** The rupture remains private and cannot leak through route blockers, option counts, or model prose.
- **Ecology:** Species-specific environmental suitability and risk are population-profile outputs, not species stereotypes.
- **Result:** Conceptual exposure is handed to AFQR-16 only through a certified source-local interface.

### Regional Ecology under Aggregate-to-Detailed Promotion
- **Promotion:** Frozen aggregate state constrains detailed initialization but does not synthesize historical individuals or events.
- **Unknown History:** Unsimulated storms, deaths, migrations, and hidden paths remain unknown rather than retroactively invented.
- **Donor Facts:** The hidden lair and scripted weather remain source-local authored facts subject to compatibility and timing validation.
- **Ecology:** Invasive pressure, drought, migration, and depletion become forward-valid candidates under registered profiles.
- **Maps:** Player maps retain prior coverage, age, and uncertainty; materialization does not grant observation.
- **Result:** Detailed future processing begins from a certified closure with an approximation certificate.


## Part XXII — Candidate comparison

Scores use 1–5 across 29 required criteria. Candidate H is selected because it alone combines donor neutrality, quantity validity, environmental and source-local diversity, bounded propagation, epistemic separation, tiered simulation, AFQR-16 exposure correctness, and model independence without requiring a universal physics or grid model.

| Candidate | Architecture | Score | Selected |
|---|---|---:|---|
| A | Static location tags | 64 | No |
| B | Universal environmental-stat block | 87 | No |
| C | Full physics simulation | 85 | No |
| D | Hazard-centric architecture | 89 | No |
| E | Cellular/grid process simulation | 118 | No |
| F | Agent-based ecosystem | 89 | No |
| G | Source-local adapters | 91 | No |
| H | Registered Federated Environment–Process Architecture with Typed Region–Medium–Field Ownership, Bounded Source–Transport–Hazard Graphs, Profile-Scoped Terrain–Weather–Ecology Families, and Bitemporal Observation–Materialization Continuity | 141 | Yes |


## Part XXIII — Adversarial evaluation

Every `ENV-001` through `ENV-200` scenario receives an individual record in `evaluation/afqr_17_adversarial_scenarios_ENV_001_200.yaml`.

- `ENV-001` — One region contains one atmosphere. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-002` — Region contains overlapping media. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-003` — Region boundary is open. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-004` — Region boundary is sealed. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-005` — Boundary is partially permeable. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-006` — Boundary moves. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-007` — Boundary location is disputed. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-008` — Compartment contains local atmosphere. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-009` — Artificial region overlaps natural environment. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-010` — Region exists in virtual space. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-011` — Plane has source-local environmental medium. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-012` — Field overlaps several regions. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-013` — Region owner differs from location owner. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-014` — Region splits. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-015` — Regions merge. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-016` — Map treats two regions as one. **Disposition:** `commit_epistemic_record_only`.
- `ENV-017` — Authoritative boundary is unknown. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-018` — No registered medium describes the environment. **Disposition:** `quarantine_or_escalate`.
- `ENV-019` — Model assumes Earthlike air. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-020` — Environmental classification remains unresolved. **Disposition:** `lawful_unresolved`.
- `ENV-021` — Source emits into medium. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-022` — Sink removes material. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-023` — Reservoir accumulates stock. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-024` — Reservoir exceeds capacity. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-025` — Material transforms into another family. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-026` — Transport crosses porous boundary. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-027` — Transport is blocked. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-028` — Transport is redirected. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-029` — Transport produces deposition. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-030` — Deposited material is resuspended. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-031` — Diffusion occurs. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-032` — Flow advects contaminant. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-033` — Mixing profile is missing. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-034` — Quantities use incompatible units. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-035` — Transformation produces byproduct. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-036` — Conservation receipt fails. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-037` — Transport path is hidden. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-038` — Source-local transport lacks bridge. **Disposition:** `quarantine_or_escalate`.
- `ENV-039` — Model invents plume direction. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-040` — Transport outcome remains unresolved. **Disposition:** `lawful_unresolved`.
- `ENV-041` — Stable flat terrain supports travel. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-042` — Rough terrain reduces one affordance. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-043` — Terrain supports one body but not another. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-044` — Surface is slippery. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-045` — Surface cannot support load. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-046` — Terrain provides cover. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-047` — Terrain provides concealment only. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-048` — Cover blocks one route but not another. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-049` — Vegetation changes visibility. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-050` — Terrain becomes flooded. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-051` — Erosion changes route. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-052` — Collapse creates obstacle. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-053` — Excavation changes permeability. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-054` — Terrain is navigable with special equipment. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-055` — Source-local terrain alters metaphysical access. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-056` — Map has outdated terrain. **Disposition:** `commit_epistemic_record_only`.
- `ENV-057` — Terrain affordance data is incomplete. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-058` — Model invents a hidden path. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-059` — Donor terrain tag lacks semantics. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-060` — Terrain outcome remains unresolved. **Disposition:** `lawful_unresolved`.
- `ENV-061` — Weather remains stable. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-062` — Temperature changes. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-063` — Pressure front moves. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-064` — Wind increases. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-065` — Precipitation begins. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-066` — Storm forms. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-067` — Storm crosses regions. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-068` — Storm divides. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-069` — Storm dissipates. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-070` — Local terrain alters weather. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-071` — Season changes profile. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-072` — Weather conflicts with climate regime. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-073` — Climate trend shifts. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-074` — Artificial weather control activates. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-075` — Weather-control resource fails. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-076` — Forecast is accurate. **Disposition:** `commit_epistemic_record_only`.
- `ENV-077` — Forecast is wrong. **Disposition:** `commit_epistemic_record_only`.
- `ENV-078` — Several forecasts disagree. **Disposition:** `commit_epistemic_record_only`.
- `ENV-079` — Model turns forecast into certainty. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-080` — Weather outcome remains unresolved. **Disposition:** `lawful_unresolved`.
- `ENV-081` — Hazard remains dormant. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-082` — Hazard trigger is satisfied. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-083` — Hazard activates. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-084` — Hazard affects only part of region. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-085` — Hazard moves. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-086` — Hazard spreads. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-087` — Hazard escalation threshold is reached. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-088` — Suppression reduces hazard. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-089` — Containment holds. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-090` — Containment fails. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-091` — Fire ignites. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-092` — Fire lacks required support medium. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-093` — Fire produces smoke. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-094` — Smoke enters adjacent region. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-095` — Flood expands. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-096` — Collapse creates secondary hazard. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-097` — Two hazards combine. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-098` — Hazard cascade exceeds bound. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-099` — Model declares automatic damage. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-100` — Hazard outcome remains unresolved. **Disposition:** `lawful_unresolved`.
- `ENV-101` — Contaminant enters water. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-102` — Contaminant enters soil. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-103` — Contaminant enters atmosphere. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-104` — Contaminant partitions among media. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-105` — Contaminant decays. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-106` — Contaminant transforms. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-107` — Contaminant accumulates. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-108` — Contaminant concentration is uncertain. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-109` — Pathogen persists in reservoir. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-110` — Radiation field changes. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-111` — Magical corruption spreads. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-112` — Informational hazard uses network medium. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-113` — Target enters contaminated region. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-114` — Target is shielded from medium. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-115` — Exposure reaches target interface. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-116` — AFQR-16 finds no target uptake. **Disposition:** `retain_environmental_exposure_record_AFQR16_no_uptake`.
- `ENV-117` — Cleanup removes some contamination. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-118` — Cleanup creates secondary waste. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-119` — Model reveals hidden contamination. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-120` — Contamination outcome remains unresolved. **Disposition:** `lawful_unresolved`.
- `ENV-121` — Renewable stock regenerates. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-122` — Nonrenewable stock is extracted. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-123` — Harvest remains below regeneration. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-124` — Harvest exceeds regeneration. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-125` — Resource stock is depleted. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-126` — Habitat quality improves. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-127` — Habitat quality declines. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-128` — Carrying capacity changes. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-129` — Population grows. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-130` — Population declines. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-131` — Population migrates. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-132` — Migration corridor is blocked. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-133` — Predation pressure increases. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-134` — Competition changes. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-135` — Mutualism is disrupted. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-136` — Invasive population establishes. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-137` — Disturbance begins succession. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-138` — Extinction risk increases. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-139` — Model treats population as one actor. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-140` — Ecological outcome remains unresolved. **Disposition:** `lawful_unresolved`.
- `ENV-141` — Habitat maintains atmosphere. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-142` — Environmental-control setpoint changes. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-143` — Ventilation fails. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-144` — Compartment isolates successfully. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-145` — Emergency atmosphere activates. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-146` — Artificial gravity changes. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-147` — Orbital radiation increases. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-148` — Vacuum boundary is breached. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-149` — Planet has non-Earth atmosphere. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-150` — Subsurface ocean supports habitat. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-151` — Terraforming stage advances. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-152` — Terraforming harms local ecology. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-153` — Magical field changes gravity-like behavior. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-154` — Psychic environment affects communication interface. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-155` — Planar boundary amplifies one field. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-156` — Source-local environment lacks translation bridge. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-157` — Environmental-control AI supplies false reading. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-158` — Model normalizes exotic medium into air. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-159` — Platform and environment owners conflict. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-160` — Artificial-environment outcome remains unresolved. **Disposition:** `lawful_unresolved`.
- `ENV-161` — Direct observation is accurate. **Disposition:** `commit_epistemic_record_only`.
- `ENV-162` — Sensor reading is noisy. **Disposition:** `commit_epistemic_record_only`.
- `ENV-163` — Sensor is miscalibrated. **Disposition:** `commit_epistemic_record_only`.
- `ENV-164` — Survey has incomplete coverage. **Disposition:** `commit_epistemic_record_only`.
- `ENV-165` — Map is outdated. **Disposition:** `commit_epistemic_record_only`.
- `ENV-166` — Map intentionally omits feature. **Disposition:** `commit_epistemic_record_only`.
- `ENV-167` — Forecast model changes. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-168` — Hidden hazard affects path feasibility. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-169` — Visible blocker leaks hidden hazard identity. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-170` — Classified contamination remains private. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-171` — Cross-packet retrieval exposes hidden route. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-172` — Stable digest links secret environmental region. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-173` — Aggregate region is promoted to detailed simulation. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-174` — Promotion preserves unknown history. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-175` — Detailed environment is demoted. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-176` — Current process profile differs from historical profile. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-177` — Replay produces different rounding. **Disposition:** `abort_or_mark_unverifiable`.
- `ENV-178` — Duplicate environmental command is retried. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-179` — Cross-owner environmental commit partially fails. **Disposition:** `abort_or_mark_unverifiable`.
- `ENV-180` — Invariant failure leaves negative reservoir. **Disposition:** `abort_or_mark_unverifiable`.
- `ENV-181` — Model invents rain. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-182` — Model invents terrain obstruction. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-183` — Model exposes hidden hazard. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-184` — Model turns map claim into truth. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-185` — Model declares ecosystem dead. **Disposition:** `reject_model_claim_no_mutation`.
- `ENV-186` — Narration conflicts with committed weather. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-187` — Public report conflicts with environmental truth. **Disposition:** `commit_epistemic_record_only`.
- `ENV-188` — Environmental record is sealed. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-189` — Donor environment conflicts with Astra doctrine. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-190` — Donor hazard clock cannot map directly. **Disposition:** `commit_epistemic_record_only`.
- `ENV-191` — Unknown medium lacks process profile. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-192` — Unknown terrain lacks affordance profile. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-193` — Unknown contaminant is quarantined. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-194` — No valid exposure bridge exists. **Disposition:** `quarantine_or_escalate`.
- `ENV-195` — No valid ecological profile exists. **Disposition:** `quarantine_or_escalate`.
- `ENV-196` — Environmental state is corrupted. **Disposition:** `abort_or_mark_unverifiable`.
- `ENV-197` — Historical map version is unavailable. **Disposition:** `commit_epistemic_record_only`.
- `ENV-198` — Historical process evaluator is unavailable. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-199` — No typed construct represents the environment. **Disposition:** `typed_candidate_subject_to_owner_validation`.
- `ENV-200` — Environmental outcome remains lawfully unresolved. **Disposition:** `typed_candidate_subject_to_owner_validation`.


## Part XXIV — Current runtime disposition

### Exists

Authority-separation doctrine, conversion IR, lawful outcomes, Batch B environment/hazard procedure pressure, Batch C location/hazard/map record schemas, and narrow RT-002 owner/projection/event/replay fixtures.

### Fixture-only

Actor, NPC, object, lever, action eligibility, preview, event, delta, and replay receipt structures.

### Conversion-only

Location, site, region, terrain, weather, biome, hazard, environment, map, travel, encounter-table, exposure, and regional-affliction fields.

### Narrative-only

Environmental description, source prose, context-packet wording, map prose, and model narration.

### Absent and blocked

Runtime environmental regions, media, fields, boundaries, process engines, transport, weather, hazards, contamination, exposure production, resource processes, ecology, artificial-environment control, simulation tiers, and model validators.

### May proceed

Doctrine registration, schema review, non-mutating dry runs, conversion-pressure classification, side-channel testing, and AFQR-18 investigation.

### Prohibited

Model-authored environmental truth, direct hazard-to-injury mutation, global weather tables, unqualified Earthlike atmosphere, map-as-territory, forecast-as-future, and conversion-stage campaign mutation.


## Part XXV — Required artifacts

1. **Immediate:** this master, decision registry, contract catalog, terminology, candidate comparison, 90 operations, 200 scenarios, 50 dry-run cases, four stress fixtures, acceptance matrix, conversion amendment, research synthesis, repository evidence, and threat model.
2. **Before authoritative environmental state:** owner registries, region/media/field/boundary schemas, invariants, AFQR-01 transaction plans.
3. **Before transport and propagation:** AFQR-07 quantity profiles, registered interfaces, process budgets, cycle detection, AFQR-18 spatial references.
4. **Before hazard mutation:** hazard lifecycle engine, trigger profiles, compound-hazard certification, suppression/containment contracts.
5. **Before contamination and exposure:** contaminant registry, fate/transport profiles, AFQR-16 handoff certification, hidden-state tests.
6. **Before ecology and population processes:** population/habitat owners, bounded profiles, resource bridges, promotion/demotion certification.
7. **Before artificial-environment control:** platform/environment split, setpoint/sensor/controller contracts, emergency-mode tests.
8. **Before model narration:** grounding manifests, claim registry, evidence bindings, semantic validator, isolation and noninterference.
9. **Before mass donor conversion:** pressure IR evaluation, donor-family fixtures, source-local bridges, quarantine/escalation queues.
10. **Deferred:** final spatial topology, movement, tactical visibility, full climate/fluid models, epidemiology, procedural generation, encounters, and urban simulation.


## Part XXVI — Non-mutating prototype

The smallest useful prototype is the **AFQR-17 Environment, Hazard, Contamination, Exposure, and Ecology Dry Run**.

It evaluates 50 cases without world-state, environmental-state, weather, hazard, contamination, exposure, body, population, resource, intervention, or event mutation. It produces typed records, candidate or unresolved determinations, private receipts, visible/model projections, deterministic commitments, and AFQR handoffs.

The fixture is `fixtures/afqr_17_non_mutating_dry_run.yaml`.


## Part XXVII — Acceptance tests

The acceptance matrix contains **180** tests.

- [ ] `AFQR17-AT-001` Environment differs from location, terrain, map, and medium.
- [ ] `AFQR17-AT-002` Region identity and owner are explicit.
- [ ] `AFQR17-AT-003` Regions may overlap.
- [ ] `AFQR17-AT-004` Media and fields may overlap independently.
- [ ] `AFQR17-AT-005` Region continuity is profile-specific.
- [ ] `AFQR17-AT-006` Artificial, virtual, planetary, and source-local regions are supported.
- [ ] `AFQR17-AT-007` Unknown region classification is lawful.
- [ ] `AFQR17-AT-008` Region owner may differ from location owner.
- [ ] `AFQR17-AT-009` Region splits and mergers preserve lineage.
- [ ] `AFQR17-AT-010` No location tag creates runtime environmental state.
- [ ] `AFQR17-AT-011` Boundaries are explicit state-bearing entities or relations.
- [ ] `AFQR17-AT-012` Permeability, containment, geometry reference, and state differ.
- [ ] `AFQR17-AT-013` Breach is a transition rather than inferred description.
- [ ] `AFQR17-AT-014` Moving and disputed boundaries are supported.
- [ ] `AFQR17-AT-015` Containment does not guarantee protection for every target.
- [ ] `AFQR17-AT-016` Boundary transport requires registered interfaces.
- [ ] `AFQR17-AT-017` Open, sealed, porous, membrane, network, and planar boundaries remain distinct.
- [ ] `AFQR17-AT-018` Boundary state is versioned.
- [ ] `AFQR17-AT-019` Unknown boundaries remain unknown.
- [ ] `AFQR17-AT-020` Boundary failure and platform structural failure have separate owners.
- [ ] `AFQR17-AT-021` Quantities use AFQR-07 semantics.
- [ ] `AFQR17-AT-022` Sources, sinks, reservoirs, and transformations differ.
- [ ] `AFQR17-AT-023` Capacity and stock differ.
- [ ] `AFQR17-AT-024` Transport retains losses and byproducts.
- [ ] `AFQR17-AT-025` Fixed precision and replay are enforced.
- [ ] `AFQR17-AT-026` Source-local exceptions require explicit manifests.
- [ ] `AFQR17-AT-027` Negative stocks and free creation are prevented.
- [ ] `AFQR17-AT-028` Composition and concentration differ.
- [ ] `AFQR17-AT-029` Flux and accumulated stock differ.
- [ ] `AFQR17-AT-030` Balance failure aborts mutation.
- [ ] `AFQR17-AT-031` Processes are definitions plus versioned instances.
- [ ] `AFQR17-AT-032` Process steps use frozen inputs.
- [ ] `AFQR17-AT-033` Workers do not own mutation.
- [ ] `AFQR17-AT-034` Propagation is bounded.
- [ ] `AFQR17-AT-035` Cycles are detected.
- [ ] `AFQR17-AT-036` Logical time, not worker order, is authoritative.
- [ ] `AFQR17-AT-037` Missing process profiles yield unresolved or quarantine.
- [ ] `AFQR17-AT-038` Process budgets constrain fan-out.
- [ ] `AFQR17-AT-039` Deterministic stochastic selections retain receipts.
- [ ] `AFQR17-AT-040` Historical evaluators are retained or replay becomes unverifiable.
- [ ] `AFQR17-AT-041` Terrain differs from geometry and movement cost.
- [ ] `AFQR17-AT-042` Affordances are purpose-specific.
- [ ] `AFQR17-AT-043` Cover differs from concealment and obstruction.
- [ ] `AFQR17-AT-044` Terrain may support one embodiment and not another.
- [ ] `AFQR17-AT-045` Terrain transitions are versioned.
- [ ] `AFQR17-AT-046` Maps do not own terrain truth.
- [ ] `AFQR17-AT-047` Model cannot invent terrain features.
- [ ] `AFQR17-AT-048` Traction, stability, load support, permeability, and visibility are separable.
- [ ] `AFQR17-AT-049` Navigation remains an AFQR-18 handoff.
- [ ] `AFQR17-AT-050` A donor terrain tag requires semantics before runtime use.
- [ ] `AFQR17-AT-051` Weather differs from climate and season.
- [ ] `AFQR17-AT-052` Weather processes are versioned.
- [ ] `AFQR17-AT-053` Climate constrains rather than dictates weather.
- [ ] `AFQR17-AT-054` Forecasts differ from future truth.
- [ ] `AFQR17-AT-055` Forecast uncertainty is explicit.
- [ ] `AFQR17-AT-056` Controlled weather uses action and resource handoffs.
- [ ] `AFQR17-AT-057` Model cannot create weather.
- [ ] `AFQR17-AT-058` Weather identity and continuity are profile-scoped.
- [ ] `AFQR17-AT-059` Local terrain and external forcing are explicit inputs.
- [ ] `AFQR17-AT-060` Forecast revisions do not rewrite prior forecasts.
- [ ] `AFQR17-AT-061` Hazard presence differs from activation.
- [ ] `AFQR17-AT-062` Trigger, scope, escalation, spread, and termination are explicit.
- [ ] `AFQR17-AT-063` Target exposure is separate.
- [ ] `AFQR17-AT-064` Hazard propagation is bounded.
- [ ] `AFQR17-AT-065` Compound and cascading hazards are represented.
- [ ] `AFQR17-AT-066` Suppression and containment differ.
- [ ] `AFQR17-AT-067` Hazards do not automatically create damage.
- [ ] `AFQR17-AT-068` Dormant and residual hazards are supported.
- [ ] `AFQR17-AT-069` Hazard cycles and cascade budgets are audited.
- [ ] `AFQR17-AT-070` No hazard clock is mutation authority by itself.
- [ ] `AFQR17-AT-071` Contaminant source, reservoir, medium, transport, and target exposure differ.
- [ ] `AFQR17-AT-072` Concentration and composition are typed.
- [ ] `AFQR17-AT-073` Decay, transformation, deposition, and cleanup are explicit.
- [ ] `AFQR17-AT-074` Cleanup byproducts are represented.
- [ ] `AFQR17-AT-075` AFQR-17 ends at certified target exposure.
- [ ] `AFQR17-AT-076` AFQR-16 owns uptake and effect.
- [ ] `AFQR17-AT-077` Hidden contamination remains private.
- [ ] `AFQR17-AT-078` Target presence may exist without exposure.
- [ ] `AFQR17-AT-079` Unknown routes and unsupported interfaces return unresolved.
- [ ] `AFQR17-AT-080` Environmental exposure includes uncertainty and target-interface identity.
- [ ] `AFQR17-AT-081` Resource stock, flow, capacity, and regeneration differ.
- [ ] `AFQR17-AT-082` Renewable and nonrenewable profiles differ.
- [ ] `AFQR17-AT-083` Harvesting uses AFQR-07 settlement.
- [ ] `AFQR17-AT-084` Regeneration is not free creation.
- [ ] `AFQR17-AT-085` Depletion and restoration are explicit.
- [ ] `AFQR17-AT-086` Environmental resources do not become universal currency.
- [ ] `AFQR17-AT-087` Harvest eligibility and harvest pressure differ.
- [ ] `AFQR17-AT-088` Common-pool governance remains an AFQR-15 handoff.
- [ ] `AFQR17-AT-089` Diffuse and flow resources are supported.
- [ ] `AFQR17-AT-090` Resource processes do not silently mutate ecology.
- [ ] `AFQR17-AT-091` Population differs from individual actor, species, faction, and collective mind.
- [ ] `AFQR17-AT-092` Habitat and population differ.
- [ ] `AFQR17-AT-093` Carrying capacity is profile-scoped.
- [ ] `AFQR17-AT-094` Recruitment, mortality, migration, and interaction differ.
- [ ] `AFQR17-AT-095` Ecological processes are bounded.
- [ ] `AFQR17-AT-096` Aggregate simulation does not invent individuals.
- [ ] `AFQR17-AT-097` Extinction risk differs from extinction fact.
- [ ] `AFQR17-AT-098` Ecological equilibrium is not universal or static.
- [ ] `AFQR17-AT-099` Competition, predation, mutualism, and parasitism remain typed.
- [ ] `AFQR17-AT-100` Population processes preserve stage, region, time, and uncertainty.
- [ ] `AFQR17-AT-101` Platform integrity differs from internal environmental state.
- [ ] `AFQR17-AT-102` Occupants differ from environmental medium.
- [ ] `AFQR17-AT-103` Environmental-control subsystems are referenced rather than duplicated.
- [ ] `AFQR17-AT-104` Emergency environmental modes are explicit.
- [ ] `AFQR17-AT-105` Non-Earth and source-local media are supported.
- [ ] `AFQR17-AT-106` No Earthlike atmosphere is assumed.
- [ ] `AFQR17-AT-107` Source-local fields require registered bridges.
- [ ] `AFQR17-AT-108` Setpoint, actual state, sensor reading, and controller output differ.
- [ ] `AFQR17-AT-109` AI control does not imply truthful readings.
- [ ] `AFQR17-AT-110` Planar and virtual environments retain source-local semantics.
- [ ] `AFQR17-AT-111` Observation differs from environmental truth.
- [ ] `AFQR17-AT-112` Sensors have coverage, resolution, error, and provenance.
- [ ] `AFQR17-AT-113` Maps are versioned claims.
- [ ] `AFQR17-AT-114` Maps may be incomplete or wrong.
- [ ] `AFQR17-AT-115` Forecasts retain model and issue-time provenance.
- [ ] `AFQR17-AT-116` Forecast revisions do not rewrite prior forecasts.
- [ ] `AFQR17-AT-117` Model presentations remain grounded.
- [ ] `AFQR17-AT-118` Samples and surveys retain method and chain of provenance.
- [ ] `AFQR17-AT-119` Map coverage and feature claims are separate.
- [ ] `AFQR17-AT-120` Public reports may conflict with environmental truth.
- [ ] `AFQR17-AT-121` Concealed hazards remain audience-scoped.
- [ ] `AFQR17-AT-122` Unknown terrain does not leak through response options.
- [ ] `AFQR17-AT-123` Private forecasts and classified controls remain private.
- [ ] `AFQR17-AT-124` Stable public hashes do not correlate secret regions.
- [ ] `AFQR17-AT-125` Model environmental claims require evidence bindings.
- [ ] `AFQR17-AT-126` Unsupported terrain, weather, hazard, contamination, and ecology claims are rejected.
- [ ] `AFQR17-AT-127` Cross-packet retrieval is isolated.
- [ ] `AFQR17-AT-128` Narration cannot mutate the environment.
- [ ] `AFQR17-AT-129` Timing and candidate-count side channels are controlled.
- [ ] `AFQR17-AT-130` Projection-specific digests are audience unlinkable.
- [ ] `AFQR17-AT-131` Tier definitions are explicit.
- [ ] `AFQR17-AT-132` Promotion inputs are frozen.
- [ ] `AFQR17-AT-133` Promotion does not invent historical processes.
- [ ] `AFQR17-AT-134` Unknown terrain, hazards, populations, and resources remain unknown.
- [ ] `AFQR17-AT-135` Demotion retains committed information.
- [ ] `AFQR17-AT-136` Re-materialization requirements are explicit.
- [ ] `AFQR17-AT-137` Aggregate and detailed processes do not double count.
- [ ] `AFQR17-AT-138` Approximation certificates state retained and unknown facts.
- [ ] `AFQR17-AT-139` Promotion does not grant observation.
- [ ] `AFQR17-AT-140` Tier changes are owner-prepared and replayable.
- [ ] `AFQR17-AT-141` Historical region and boundary versions are retained.
- [ ] `AFQR17-AT-142` Environmental process profiles are retained.
- [ ] `AFQR17-AT-143` Quantity and rounding records are retained.
- [ ] `AFQR17-AT-144` Hazard and contamination histories are retained.
- [ ] `AFQR17-AT-145` Weather and climate records are retained.
- [ ] `AFQR17-AT-146` Ecological process versions are retained.
- [ ] `AFQR17-AT-147` Forecasts and observations remain immutable.
- [ ] `AFQR17-AT-148` Current models do not rewrite historical state.
- [ ] `AFQR17-AT-149` Missing historical evaluators yield unverifiable results.
- [ ] `AFQR17-AT-150` Duplicate commands are idempotent.
- [ ] `AFQR17-AT-151` Donor environment systems become pressure IR.
- [ ] `AFQR17-AT-152` Donor terrain tags do not become universal semantics.
- [ ] `AFQR17-AT-153` Donor weather tables do not become authoritative global weather.
- [ ] `AFQR17-AT-154` Donor hazard clocks remain source-local where necessary.
- [ ] `AFQR17-AT-155` Conversion cannot mutate campaign environments.
- [ ] `AFQR17-AT-156` Conversion cannot expose targets or create injuries.
- [ ] `AFQR17-AT-157` Conversion cannot define hidden model context.
- [ ] `AFQR17-AT-158` Every donor environmental construct receives a lawful outcome.
- [ ] `AFQR17-AT-159` Descriptive setting prose is not executable policy.
- [ ] `AFQR17-AT-160` Mixed-source interactions require certified bridges.
- [ ] `AFQR17-AT-161` Existing location, hazard, map, terrain, and travel schemas remain conversion- or fixture-scoped unless generalized implementation is proven.
- [ ] `AFQR17-AT-162` Existing PCR or region metadata does not establish environmental simulation.
- [ ] `AFQR17-AT-163` Existing hazard clocks do not own generalized environmental mutation.
- [ ] `AFQR17-AT-164` Generalized weather remains blocked.
- [ ] `AFQR17-AT-165` Generalized hazard and contamination mutation remain blocked.
- [ ] `AFQR17-AT-166` Generalized ecology remains blocked.
- [ ] `AFQR17-AT-167` Model-authored environmental truth is prohibited.
- [ ] `AFQR17-AT-168` Narrow RT-002G remains environmentally inert.
- [ ] `AFQR17-AT-169` Current object-lever legality does not resolve terrain or hazards.
- [ ] `AFQR17-AT-170` Context packets are projections, not environmental state.
- [ ] `AFQR17-AT-171` AFQR-16 receives certified exposure and owns target uptake/effects.
- [ ] `AFQR17-AT-172` AFQR-18 owns universal position, distance, reachability, movement, and spatial topology.
- [ ] `AFQR17-AT-173` AFQR-07 owns quantified balances and settlement.
- [ ] `AFQR17-AT-174` AFQR-10 owns observations, maps, forecasts, and belief.
- [ ] `AFQR17-AT-175` AFQR-15 owns environmental regulation and authority.
- [ ] `AFQR17-AT-176` AFQR-03 owns action representability and legality.
- [ ] `AFQR17-AT-177` AFQR-04 owns logical scheduling.
- [ ] `AFQR17-AT-178` AFQR-01 owns atomic transition commitment.
- [ ] `AFQR17-AT-179` AFQR-09 owns governed environmental dependencies.
- [ ] `AFQR17-AT-180` No handoff grants the coordinator mutation authority.


## Part XXVIII — Residual uncertainty ledger

- **Universal spatial topology:** AFQR-18.
- **Movement, reachability, pathfinding, and tactical visibility:** AFQR-18 and later action/combat doctrine.
- **Final climate simulation:** profile-specific implementation research.
- **Fluid dynamics:** bounded profiles; no universal CFD requirement.
- **Population epidemiology:** later cross-population doctrine; AFQR-17 owns environmental reservoirs and exposure paths only.
- **Planetary physics:** source- and planet-specific profiles.
- **Procedural world generation:** later generation doctrine; cannot own truth without validation.
- **Encounter generation:** table/generation/action handoff; not environmental process authority.
- **Resource economy:** AFQR-07 and later economy.
- **Urban and settlement simulation:** later population/infrastructure doctrine.
- **Source-local metaphysical environments:** namespaced bridges and certification.
- **Distributed runtime performance:** implementation benchmarking.
- **Training-model behavior:** separate model adapter evaluation.


## Part XXIX — Roadmap conclusion

1. **Resolved for ratification?** Yes.
2. **Second broad research pass?** No.
3. **Mandatory amendments?** Federated environmental ownership; explicit regions/media/fields/boundaries; AFQR-07 balance manifests; bounded processes and propagation; terrain affordances; weather/climate/forecast separation; hazard lifecycle; contamination reservoirs; AFQR-16 exposure boundary; aggregate ecology; simulation-tier continuity; hidden-state validation.
4. **Immediate artifacts?** All are included in this pack.
5. **Smallest prototype?** The 50-case non-mutating dry run.
6. **Execution still blocked?** All authoritative environmental, weather, hazard, contamination, exposure, resource, ecological, and intervention mutation.
7. **Does AFQR-17 unlock authoritative mutation?** No.
8. **Does it unlock bounded narration?** Only after executable grounding, evidence binding, output validation, isolation, and noninterference exist.
9. **RT-002G effect?** None; it remains narrow and environmentally inert.
10. **AFQR-18?** **Space, Location, Position, Scale, Boundaries, Distance, Proximity, Reachability, Movement, Navigation, and Spatial Topology.**
11. **Exact next action:** Ratify and register AFQR-17; execute the dry run and RT-002A–F environmental/model noninterference audit; keep RT-002G inert; then open AFQR-18 read-only.


## Part XXX — Machine-readable decision block

```yaml
question_id: AFQR-17
question_title: Environment Media Atmosphere Weather Terrain Hazards Contamination Exposure Ecological Processes
  and Environmental Change
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: architecturally_resolved_for_ratification
selected_architecture: Registered Federated Environment–Process Architecture with Typed Region–Medium–Field Ownership,
  Bounded Source–Transport–Hazard Graphs, Profile-Scoped Terrain–Weather–Ecology Families, and Bitemporal Observation–Materialization
  Continuity
selected_architecture_abbreviation: RFEPA-RMF-STHG-TWE-OMC
confidence: high
central_law: No place label, region tag, map feature, weather table, climate descriptor, terrain modifier, hazard
  clock, contamination label, ecological aggregate, donor rule, sensor reading, forecast, public report, or model
  narration possesses environmental mutation authority by itself. Every authoritative environmental result is a
  purpose-scoped, version-pinned, bitemporal determination over frozen region, medium, field, boundary, source,
  sink, reservoir, transport, terrain, climate, process, hazard, contamination, ecological, quantity, spatial-reference,
  epistemic, agency, social, institutional, embodiment, and governed-relation bases. AFQR-17 ends at certified target-interface
  exposure and never creates injury or bodily effect; only owner-prepared AFQR-01 transitions mutate environmental
  state, while observations, maps, forecasts, projections, and later reinterpretations remain separate append-only
  records.
accepted_dependencies:
  AFQR_01:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: owner-prepared atomic environmental transitions
  AFQR_02:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: idempotent intervention and long-running attempt lifecycle
  AFQR_03:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: typed environmental action gateway
  AFQR_04:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: logical-time environmental scheduler
  AFQR_05:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: registered medium and interface bridges
  AFQR_06:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: typed claim arbitration without process invention
  AFQR_07:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: typed quantities, balances, stocks, flows, and settlement
  AFQR_08:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: region/process continuity and lineage
  AFQR_09:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: governed environmental dependencies and duties
  AFQR_10:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: observations, maps, forecasts, and environmental epistemics
  AFQR_11:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: agency and responsibility separation
  AFQR_12:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: environment-to-behavior handoffs only
  AFQR_13:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: environment-to-social handoffs only
  AFQR_14:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: warnings, reports, and forecast communication
  AFQR_15:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: environmental governance and authority handoffs
  AFQR_16:
    accepted: true
    implementation_status: architectural_constraint_not_assumed_implemented
    AFQR_17_effect: certified target-interface exposure boundary
definitions:
  environment: A purpose-scoped authoritative environmental state domain; not a synonym for location, map, terrain,
    or narration.
  environmental region: A typed state-bearing environmental partition or overlap set with explicit purpose, owner,
    continuity, and boundary references.
  medium: A state-bearing carrier or substrate through which quantities, materials, signals, organisms, or source-local
    effects may exist or move.
  field: A spatially or topologically varying environmental state that may influence interfaces without being identical
    to force or effect.
  reservoir: A bounded stock-holding environmental state with capacity, composition, ownership, and balance evidence.
  source: A registered producer of environmental stock, flow, field, or process output.
  sink: A registered remover or receiver of environmental stock, flow, field, or process output.
  carrier: A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  boundary: A state-bearing interface constraint governing adjacency, permeability, containment, transfer, and visibility
    without owning universal geometry.
  interface: A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  compartment: A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  zone: A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  habitat: A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  biome: A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  climate regime: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  artificial environment: A typed AFQR-17 environmental entities construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  source-local environment: A typed AFQR-17 environmental entities construct whose scope, owner, policy version,
    effective time, visibility, and source-local namespace must be qualified at runtime.
  environmental variable: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  environmental quantity: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  composition: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  concentration: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  gradient: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  flux: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  pressure: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  temperature: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  humidity: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  illumination: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  radiation field: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  gravity field: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  flow: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  current: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  wind: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  environmental capacity: A typed AFQR-17 environmental state construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  environmental state snapshot: A typed AFQR-17 environmental state construct whose scope, owner, policy version,
    effective time, visibility, and source-local namespace must be qualified at runtime.
  terrain: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  surface: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  substrate: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  slope: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local
    namespace must be qualified at runtime.
  roughness: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  stability: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  traction: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  permeability: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  obstruction: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  cover: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility, and source-local
    namespace must be qualified at runtime.
  concealment: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  visibility effect: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  traversability: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  navigability: A typed AFQR-17 terrain construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  terrain affordance: A purpose- and embodiment-scoped opportunity or constraint exposed by terrain; not a flat
    universal modifier.
  weather: A comparatively short-timescale environmental state or process realization within a region.
  weather event: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  weather process: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  storm: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  precipitation: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  front: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  season: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  climate: A profile of longer-timescale distributions, regimes, variability, trends, and constraints; not current
    weather.
  climate trend: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  anomaly: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  forecast: A versioned epistemic prediction with issue time, target time, model basis, uncertainty, and later verification.
  warning: A typed AFQR-17 weather climate construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  hazard: A typed source or condition capable of producing adverse exposure or constraints under specified triggers
    and interfaces; not guaranteed harm.
  hazard source: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  hazard instance: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  trigger: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  activation: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  hazard scope: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  propagation: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  escalation: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  suppression: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  containment: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  termination: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  residual hazard: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  compound hazard: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  cascading hazard: A typed AFQR-17 hazard construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  contaminant: A typed material, organism, signal, field-bearing entity, or source-local substance whose presence
    and transport are separately represented.
  pollutant: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  pathogen reservoir: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  toxin reservoir: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  radioactive material: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  corruption reservoir: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  contaminated medium: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  deposition: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  accumulation: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  persistence: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  decay: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  neutralization: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  remediation: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  secondary contamination: A typed AFQR-17 contamination construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  population: An aggregate ecological state over a defined category, region, cohort, and time; not an individual
    actor or collective mind.
  cohort: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  niche: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and source-local
    namespace must be qualified at runtime.
  carrying capacity: A profile-scoped contextual support limit emerging from habitat, resources, interactions, time,
    and uncertainty; not a fixed universal scalar.
  biomass: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  recruitment: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  mortality: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  migration: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  competition: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  predation: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  mutualism: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility, and
    source-local namespace must be qualified at runtime.
  parasitism: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  succession: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  disturbance: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  resilience: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  regime shift: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  invasive population: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  extinction risk: A typed AFQR-17 ecology construct whose scope, owner, policy version, effective time, visibility,
    and source-local namespace must be qualified at runtime.
  environmental observation: A typed AFQR-17 observation representation construct whose scope, owner, policy version,
    effective time, visibility, and source-local namespace must be qualified at runtime.
  sensor reading: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  sample: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  survey: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  map: A versioned claim set or representation about spatial/environmental features with coverage, scale, age, and
    provenance; not territory truth.
  chart: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  environmental model: A typed AFQR-17 observation representation construct whose scope, owner, policy version,
    effective time, visibility, and source-local namespace must be qualified at runtime.
  confidence: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  uncertainty: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  coverage: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  resolution: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  map age: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  provenance: A typed AFQR-17 observation representation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  environmental process: A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  process step: A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  transport profile: A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  transport path: A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  process budget: A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  propagation frontier: A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  simulation tier: A named fidelity and ownership mode with explicit retained truth, permitted approximations, promotion
    inputs, and demotion obligations.
  materialization: A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  promotion: A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  demotion: A typed AFQR-17 process and simulation construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  historical approximation: A typed AFQR-17 process and simulation construct whose scope, owner, policy version,
    effective time, visibility, and source-local namespace must be qualified at runtime.
  environmental intervention: A typed AFQR-17 process and simulation construct whose scope, owner, policy version,
    effective time, visibility, and source-local namespace must be qualified at runtime.
  target presence: A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  target interface: A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  environmental exposure: A certified source-side target-interface quantity or qualitative state handed to AFQR-16;
    not uptake, injury, or condition.
  exposure quantity: A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  environmental resource: A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  resource stock: A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  resource flow: A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
  regeneration: A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  depletion: A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective time,
    visibility, and source-local namespace must be qualified at runtime.
  harvest pressure: A typed AFQR-17 exposure and resources construct whose scope, owner, policy version, effective
    time, visibility, and source-local namespace must be qualified at runtime.
guarantees:
- environment, location, terrain, map, medium, field, hazard, exposure, and effect remain distinct
- all environmental mutations are owner-prepared and AFQR-01 committed
- all quantified stocks, flows, transport, losses, and transformations use AFQR-07
- process execution is versioned, bounded, scheduler-controlled, and replayable
- weather and climate are distinct
- hazard presence, activation, propagation, exposure, and effect are distinct
- AFQR-17 ends at certified target-interface exposure
- maps, observations, and forecasts remain AFQR-10 epistemic records
- simulation-tier promotion cannot invent history
- source-local environmental systems remain contained
- model output cannot create environmental truth
non_guarantees:
- one universal physics engine
- one universal spatial coordinate system
- final movement or pathfinding
- final climate simulation
- full fluid dynamics
- full epidemiology
- one universal ecology
- final resource economy
- procedural world generation
- encounter generation
- universal planetary physics
- universal metaphysical environment
environmental_region_model:
  type: overlapping purpose-scoped state regions
  owner: EnvironmentalStateAuthorityBinding
  continuity: profile-specific lineage; map and location identity excluded
environmental_ownership_model:
  federated: true
  owners:
  - region
  - medium
  - field
  - boundary
  - process
  - terrain
  - weather
  - hazard
  - contamination
  - resource
  - population
  - habitat
  - epistemic record
  coordinators_mutate: false
region_continuity_model:
  split_merge_transform: n-ary candidates
  storms_plumes_rivers: profile-scoped identities
  unknown: lawful unresolved
medium_model:
  variables: profile-selected
  earthlike_default: false
  overlap: true
  examples:
  - atmosphere
  - fluid
  - vacuum
  - soil
  - network
  - interplanar medium
field_model:
  separate_from_force_effect: true
  variation: spatial or topological
  interfaces: registered and source-local capable
atmosphere_and_fluid_model:
  composition_pressure_temperature_flow_separate: true
  breathability: target-relative AFQR-16 handoff
  full_CFD_required: false
environmental_quantity_model:
  owner: AFQR-07
  typed_units: true
  fixed_precision: true
  qualitative_profiles_allowed: true
boundary_model:
  state_bearing: true
  properties:
  - permeability
  - containment
  - state
  - adjacency reference
  - purpose
  geometry_owner: AFQR-18 pending
containment_model:
  separate_from_target_protection: true
  breach_is_transition: true
  moving_disputed_unknown_supported: true
transport_interface_model:
  stages:
  - carrier
  - path
  - boundary interaction
  - transfer
  - attenuation
  - conversion
  - deposition
  - loss
  universal_grid: false
source_sink_reservoir_model:
  distinct: true
  capacity_stock_separate: true
  negative_stock_prohibited: true
environmental_transformation_model:
  manifest_outputs:
  - inputs
  - outputs
  - losses
  - byproducts
  - residuals
  source_local_exception_requires_manifest: true
environmental_balance_model:
  AFQR_07_receipt_required: true
  rounding_versioned: true
  arbitrage_prevention: true
environmental_process_model:
  definition_instance_separate: true
  frozen_input_closure: true
  bounded_step: true
  owner_prepared_output: true
scheduler_model:
  owner: AFQR-04
  worker_order_authoritative: false
  periodic_and_event_driven_separate: true
transport_and_propagation_model:
  budgets: true
  cycle_detection: true
  frontier_receipts: true
  bounded_fanout: true
terrain_model:
  not_geometry: true
  not_flat_modifier: true
  state:
  - substrate
  - surface
  - condition
  transitions_versioned: true
terrain_affordance_model:
  purpose_specific: true
  embodiment_specific: true
  examples:
  - support
  - traction
  - cover potential
  - concealment
  - permeability
  - buildability
  - navigability
cover_concealment_visibility_handoff:
  cover: route obstruction/protection potential
  concealment: observation degradation
  visibility: AFQR-10 and future spatial/sensory handoff
  action_success_decided: false
weather_model:
  state_event_process_separate: true
  local_variation: true
  deterministic_or_receipted_stochastic: true
climate_model:
  constrains_weather: true
  determines_each_event: false
  regime_variability_trend_separate: true
forecast_model:
  epistemic: true
  issue_target_times: true
  uncertainty_and_model_version: true
  future_mutation_authority: false
hazard_model:
  lifecycle:
  - dormant
  - active
  - escalating
  - spreading
  - suppressed
  - contained
  - residual
  - terminated
  hazard_not_effect: true
hazard_trigger_model:
  presence_activation_separate: true
  trigger_evidence: true
  eligibility_scope_explicit: true
compound_and_cascade_model:
  typed_interactions: true
  budgets_and_cycle_detection: true
  automatic_global_cascade: false
hazard_suppression_model:
  suppression_containment_termination_separate: true
  resource_handoff: AFQR-07
  action_handoff: AFQR-03
fire_model:
  specializes_shared_primitives: true
  stages:
  - ignition
  - support medium
  - fuel
  - heat
  - smoke
  - spread
  - suppression
  oxygen_assumed: false
flood_model:
  specializes_transport_and_reservoirs: true
  extent_state: true
  terrain_interaction: true
collapse_and_disaster_model:
  AFQR16_structure_trigger_handoff: true
  debris_hazard_separate: true
  compound_event_supported: true
contamination_model:
  source_reservoir_medium_target_separate: true
  composition_concentration_separate: true
  latent_hidden_supported: true
contaminant_transport_model:
  partition_transform_deposit_resuspend_decay: true
  carrier_and_boundary_explicit: true
cleanup_and_residual_model:
  partial_cleanup: true
  waste_byproduct: true
  residual_record: true
  restoration_not_erasure: true
environmental_exposure_model:
  source_side_only: true
  requires:
  - target presence
  - target interface
  - route
  - duration
  - quantity or qualitative state
  - uncertainty
AFQR16_exposure_handoff:
  contract: AFQR16ExposureHandoff
  AFQR17_may_decide:
  - presence
  - environmental interface contact
  - source-side quantity
  AFQR17_may_not_decide:
  - uptake
  - penetration into target
  - injury
  - condition
  - death
environmental_resource_model:
  stock_flow_capacity_separate: true
  diffuse_flow_renewable_nonrenewable: true
  not_currency: true
resource_regeneration_model:
  registered_source_or_transformation_required: true
  schedule_versioned: true
resource_depletion_model:
  harvest_settlement: AFQR-07
  restoration_separate: true
  thresholds_profile_scoped: true
habitat_model:
  region_quality_resources_connectivity_separate: true
  not_species_identity: true
ecological_population_model:
  aggregate_not_actor: true
  cohorts_supported: true
  individual_materialization_not_implied: true
population_process_model:
  recruitment_mortality_migration_separate: true
  bounded: true
  stochastic_receipts_where_used: true
ecological_interaction_model:
  typed:
  - competition
  - predation
  - mutualism
  - parasitism
  - resource dependency
  universal_food_web: false
migration_and_succession_model:
  corridors_spatial_handoff: AFQR-18
  succession_disturbance_separate: true
  history_not_invented: true
extinction_risk_model:
  risk_not_fact: true
  uncertainty: true
  population_and_habitat_basis: true
environmental_intervention_model:
  typed_attempts: true
  authority_access_resources_interfaces_required: true
  complications_and_residuals: true
artificial_environment_model:
  platform_integrity_owner: AFQR-16
  medium_owner: AFQR-17
  setpoint_actual_sensor_command_separate: true
  emergency_modes: true
planetary_environment_model:
  non_Earth_media: true
  orbital_vacuum_radiation_gravity_supported: true
  one_physics_model: false
source_local_environment_model:
  namespace_required: true
  bridge_required: true
  quarantine_supported: true
observation_model:
  owner: AFQR-10 epistemic owner
  truth_mutation: false
  method_coverage_resolution_error_provenance: true
sensor_model:
  reading_instrument_truth_separate: true
  calibration_and_failure: true
map_model:
  versioned_claims: true
  territory_truth: false
  coverage_scale_age_provenance: true
forecast_uncertainty_model:
  ensemble_or_qualitative: true
  calibration_and_verification: true
  wrong_forecast_lawful: true
identity_handoff:
  owner: AFQR-08
  subjects:
  - region
  - storm
  - plume
  - river
  - ecosystem
  - split or merged environment
epistemic_handoff:
  owner: AFQR-10
  subjects:
  - observation
  - sensor
  - sample
  - survey
  - map
  - forecast
  - public report
agency_handoff:
  owner: AFQR-11
  rule: natural processes are not agents; artificial/source-local agency requires profiles
behavioral_handoff:
  owner: AFQR-12
  rule: environment may inform options/appraisal but does not dictate behavior
social_handoff:
  owner: AFQR-13
  rule: environmental state creates social candidates only through typed bridges
communication_handoff:
  owner: AFQR-14
  subjects:
  - warnings
  - forecasts
  - reports
  - maps
  - evacuation messages
institutional_handoff:
  owner: AFQR-15
  subjects:
  - quarantine
  - regulation
  - protected zones
  - restoration authority
  - resource licenses
embodiment_handoff:
  owner: AFQR-16
  boundary: certified target-interface exposure only
governed_relation_handoff:
  owner: AFQR-09
  subjects:
  - ownership
  - custody
  - maintenance
  - containment duties
  - access
quantity_and_settlement_handoff:
  owner: AFQR-07
  subjects:
  - stocks
  - flows
  - capacity
  - harvest
  - cleanup resources
  - control resources
action_gateway_handoff:
  owner: AFQR-03
  subjects:
  - travel
  - harvest
  - containment
  - cleanup
  - weather control
  - restoration
scheduler_handoff:
  owner: AFQR-04
  subjects:
  - weather
  - transport
  - hazards
  - contamination
  - ecology
  - regeneration
spatial_system_handoff:
  owner: AFQR-18 proposed
  subjects:
  - coordinates
  - distance
  - position
  - adjacency geometry
  - reachability
  - movement
  - pathfinding
  - line of sight
environmental_simulation_tier_model:
  tiers:
  - descriptive_reference
  - regional_summary
  - aggregate_process
  - active_hazard
  - materialized_environment
  - full_environmental_fixture
  double_counting_prohibited: true
environmental_materialization_policy:
  promotion_frozen: true
  unknown_history_preserved: true
  demotion_retention_required: true
  observation_not_granted: true
hidden_environmental_state_policy:
  audience_scoped: true
  protected:
  - hazards
  - terrain
  - routes
  - boundaries
  - contamination
  - reservoirs
  - populations
  - controls
  - forecasts
visible_projection_policy:
  minimized: true
  qualified_uncertainty: true
  no_hidden_reason_leak: true
model_context_policy:
  untrusted: true
  evidence_bound: true
  claim_allowlist: true
  prompt_only_security: false
model_output_validation:
  semantic: true
  rejects_unsupported_claims: true
  committed_state_expansion_prohibited: true
side_channel_protection:
  constant_policy_surfaces: true
  candidate_count_protected: true
  timing_protected: true
  projection_specific_digests: true
historical_replay_policy:
  profiles_and_inputs_retained: true
  observations_and_forecasts_immutable: true
  missing_evaluator: unverifiable
bitemporal_policy:
  valid_time_and_recorded_time: true
  record_specific_temporal_fields: true
  retroactive_rewrite: false
owner_boundaries:
  federated: true
  coordinator_mutation: false
  cross_owner_atomicity: AFQR-01
AFQR_handoffs:
  AFQR_01: commit
  AFQR_03: actions
  AFQR_04: schedule
  AFQR_07: quantities
  AFQR_08: identity
  AFQR_10: epistemics
  AFQR_16: target effects
  AFQR_18: spatial topology pending
shipboard_cascade_stress_case:
  status: passes
  key_rule: compartment environments and platform/crew integrity remain separate owners
contaminated_ecosystem_stress_case:
  status: passes
  key_rule: partitioned reservoirs, ecology, resources, institutions, and target exposures remain separate
multiplanar_storm_stress_case:
  status: passes
  key_rule: boundary-specific physical and source-local interfaces; continuity may divide
aggregate_promotion_stress_case:
  status: passes
  key_rule: promotion constrains future state without inventing unsimulated history
conversion_pipeline_handoff:
  pressure_IR_types:
  - EnvironmentalRegionPressureIR
  - EnvironmentalMediumPressureIR
  - EnvironmentalFieldPressureIR
  - BoundaryPressureIR
  - AtmospherePressureIR
  - FluidPressureIR
  - TerrainPressureIR
  - TerrainAffordancePressureIR
  - WeatherPressureIR
  - ClimatePressureIR
  - HazardPressureIR
  - FirePressureIR
  - FloodPressureIR
  - CollapsePressureIR
  - ContaminationPressureIR
  - RadiationEnvironmentPressureIR
  - MagicalEnvironmentPressureIR
  - PlanarEnvironmentPressureIR
  - EnvironmentalExposurePressureIR
  - ResourceStockPressureIR
  - ResourceRegenerationPressureIR
  - HabitatPressureIR
  - PopulationPressureIR
  - EcologicalInteractionPressureIR
  - MigrationPressureIR
  - SuccessionPressureIR
  - EnvironmentalInterventionPressureIR
  - ArtificialEnvironmentPressureIR
  - MapPressureIR
  - ForecastPressureIR
  - EnvironmentalSimulationTierPressureIR
  - SourceLocalEnvironmentOntologyPressureIR
  lawful_outcomes:
  - direct
  - normalized
  - source_local
  - quarantine
  - escalation
  campaign_mutation: false
model_authority_policy:
  authoritative_environmental_interpretation: false
  weather_generation: false
  hazard_activation: false
  ecology_simulation: false
  narration_only_after_validation: true
current_runtime_disposition:
  exists:
  - backend-authority doctrine
  - conversion scope and IR
  - Batch B environment/hazard pressure owner
  - Batch C location/hazard/map record families
  - narrow RT-002 state owner/projection/event/replay fixtures
  fixture_only:
  - actor/NPC/object/lever references
  - eligibility
  - transaction preview
  - event/delta/replay receipts
  conversion_only:
  - location
  - region
  - terrain
  - weather
  - hazard
  - environment
  - map
  - travel
  - encounter-table fields
  narrative_only:
  - descriptions
  - source prose
  - context-packet text
  absent:
  - authoritative environmental owners
  - process scheduler implementations
  - weather
  - hazards
  - contamination
  - exposure production
  - ecology
  - simulation tiers
  prohibited:
  - model-authored environmental truth
  - automatic harm from hazards
  - map or forecast authority
required_artifacts:
  immediate:
  - master ratification
  - decision registry
  - typed contract catalog
  - operation grammar
  - 200-case evaluation
  - 50-case dry run
  - four stress fixtures
  - acceptance matrix
  - conversion IR amendment
  - research synthesis
  - security threat model
  before_authoritative_environmental_state:
  - owner registries
  - region/media/field/boundary schemas
  - state invariants
  - AFQR-01 transaction bindings
  before_transport_and_propagation:
  - AFQR-07 quantity profiles
  - transport interfaces
  - process budgets
  - cycle detection
  - AFQR-18 spatial references
  before_hazard_mutation:
  - hazard lifecycle engine
  - trigger profiles
  - compound hazard certification
  - suppression contracts
  before_contamination_and_exposure:
  - contaminant registry
  - transport and fate profiles
  - target-interface handoff certification
  - hidden-state tests
  before_ecology:
  - population/habitat owners
  - bounded process profiles
  - resource bridges
  - promotion/demotion certification
  before_artificial_controls:
  - platform/environment owner split
  - sensor/setpoint/control contracts
  - failure and emergency-mode tests
  before_model_narration:
  - grounding manifests
  - claim registry
  - evidence bindings
  - semantic validator
  - cross-packet isolation
  before_mass_conversion:
  - pressure IR evaluation
  - donor-family fixtures
  - source-local bridge certification
  - quarantine queues
  deferred:
  - final spatial topology
  - movement/pathfinding
  - full climate/fluid models
  - epidemiology
  - world generation
  - encounter generation
required_prototype:
  name: AFQR-17 Environment, Hazard, Contamination, Exposure, and Ecology Dry Run
  case_count: 50
  mutating: false
  artifact: fixtures/afqr_17_non_mutating_dry_run.yaml
required_fixtures:
- shipboard_environmental_cascade
- contaminated_ecosystem_and_settlement
- multiplanar_storm
- aggregate_promotion
blocked_work:
- authoritative environmental mutation
- weather transitions
- hazard activation/propagation
- contamination transport
- target exposure commitment
- resource settlement
- population transitions
- environmental interventions
- model-authored environmental truth
work_unlocked:
- architectural registration
- non-mutating dry run
- schema and registry design
- conversion pressure classification
- bounded environmental narration design after validation
- AFQR-18 investigation
rejected_alternatives:
- static location tags
- universal environmental stat block
- full universal physics engine
- hazard-only environment
- mandatory cellular grid
- all-agent ecology
- unbounded source-local adapters
residual_risks:
- spatial topology dependency
- large-scale process performance
- profile authoring burden
- cross-tier double counting
- source-local bridge explosion
- forecast and map leakage
- ecological overmaterialization
RT_002G_status: unchanged_narrow_environmentally_inert_fixture
next_foundational_question:
  question_id: AFQR-18
  title: Space, Location, Position, Scale, Boundaries, Distance, Proximity, Reachability, Movement, Navigation,
    and Spatial Topology
  reason: AFQR-17 deliberately leaves universal geometry, distance, adjacency, reachability, movement, pathfinding,
    and tactical visibility to a dedicated owner; this dependency should precede combat sequencing and generalized
    travel.
exact_next_roadmap_action: Ratify and register AFQR-17; execute the 50-case non-mutating environmental dry run and
  an RT-002A–RT-002F environmental/model noninterference audit; keep RT-002G environmentally inert; then open AFQR-18
  as a read-only foundational investigation.
```
