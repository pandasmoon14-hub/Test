# Astra Foundational Question Resolution 13

## Social Relationships, Trust, Reputation, Status, Norms, Culture, Affiliation, and Group Dynamics

Status: ratification candidate  
Version: 1.0  
Repository baseline inspected: `928bb79ce00a2de749d127dcc5cb8299de788a15`  
Selected architecture: **Registered Multiplex Social-State Architecture with Domain-Scoped Trust, Audience-Relative Reputation, Modular Culture–Norm Profiles, and Bitemporal Network Continuity**  
Abbreviation: **RMSSA-DT-ARR-MCNP-BNC**

This is the integrated human-readable authority candidate. Normative sidecars contain the complete schemas, operations, adversarial cases, fixtures, registries, and validation evidence so AFQR-13 does not become one social-system megafile.

## Part I — Executive decision

### Selected architecture

**Registered Multiplex Social-State Architecture with Domain-Scoped Trust, Audience-Relative Reputation, Modular Culture–Norm Profiles, and Bitemporal Network Continuity** (`RMSSA-DT-ARR-MCNP-BNC`)

### Central law

> No encounter, communication, repeated contact, governed relation, graph edge, public record, audience claim, social metric, donor descriptor, or model portrayal creates authoritative relationship, trust, reputation, status, affiliation, culture, norm, kinship, coalition, or social continuity by itself. Every social result is a typed, purpose- and audience-scoped, version-pinned determination over frozen identity, epistemic, agency, behavioral, governed-relation, and event bases; every mutation is owner-prepared and committed through AFQR-01; graph metrics and aggregates remain derived observations; historical social state and later corrections are append-only.

### Confidence

**High.** Ownership, separation, directionality, audience relativity, temporal semantics, transition boundaries, social continuity, projection safety, conversion handoff, and lawful unresolved outcomes are resolved. Final romance, prejudice, law, diplomacy, economic exchange, population sociology, propaganda, and source-local social formulas remain downstream.

### What it is

A federated architecture combining typed multiplex relation instances, directional domain-scoped trust, audience-owned reputation, jurisdiction-scoped status and rank, governed affiliation handoffs, modular culture and norm profiles, typed kinship/household structures, temporal social-network projections, coalition/schism records, scalable materialization tiers, private commitments, and deterministic replay.

### What it is not

It is not a relationship score, universal trust meter, global reputation ledger, cultural stereotype package, social alignment system, universal family model, graph-proximity inference engine, unrestricted agent-based society simulator, or model-authored relationship engine.

### Research disposition

No second broad research pass is required before ratification. Narrow primary research remains mandatory when implementing specific kinship, romance, culture, norm, status, prejudice, diplomacy, trust-repair, artificial-society, or source-local profiles.

## Part II — Repository-grounded diagnosis

### Verified baseline

The inspected `main` head is `928bb79ce00a2de749d127dcc5cb8299de788a15`, the merge of PR #325 / RT-002F. No later commit was present during this investigation.

### Repository facts

The repository README identifies Astra as a foundation-stage doctrine/schema/conversion project with future deterministic runtime work. It states that the backend owns truth and state and that the model is restricted to interpretation, narration, and constrained proposals. Current RT-001/RT-002 structures provide owner/reference, projection, legality, preview, event/delta, and audit fixtures for one actor, one NPC target, and one object/lever command family. They do not implement social relationships, trust, audience reputation, status, membership, culture, norms, kinship, networks, coalitions, or social continuity.

`faction_social_owner`, relationship-like schema fields, culture/background entries, faction descriptions, companion bonds, allies/enemies, role labels, and reputation-like donor terminology are not proof of generalized runtime social state. AFQR-08–12 ratification packs are accepted architecture unless separately committed and implemented.

### Fifty explicit determinations

| # | Question | Determination |
|---:|---|---|
| 1 | Are social relationships represented authoritatively? | No. Relationship-like fields are doctrine, conversion/schema descriptors, or future runtime requirements; no generalized social-relation owner or committed relation state exists. |
| 2 | Are relationships typed or freeform? | Conversion schemas may type source constructs, but runtime relationships are not implemented. Freeform prose is not authoritative. |
| 3 | Are relationships symmetric or directional? | No executable directionality model exists. AFQR-13 requires explicit participant roles and directional dimensions. |
| 4 | Are multiple dimensions supported? | Not at runtime. The selected architecture introduces multiplex dimensions without a universal track set. |
| 5 | Is relationship recognition separated from relationship truth? | AFQR-10 supplies epistemic separation doctrinally, but no social-recognition runtime records exist. |
| 6 | Is trust represented? | No authoritative trust state exists. |
| 7 | Is trust domain-specific? | Not implemented; AFQR-13 mandates domain-scoped trust. |
| 8 | Is distrust distinct from low trust? | Not implemented; AFQR-13 makes distrust a separate supported assessment. |
| 9 | Is reliance distinct from trust? | Resource, custody, or dependency references do not implement social reliance. AFQR-13 separates reliance decisions from trust. |
| 10 | Is betrayal represented? | Only as donor/narrative pressure. No trust-violation or betrayal determination exists. |
| 11 | Is trust repair represented? | No. |
| 12 | Is reputation represented? | No authoritative audience-owned reputation state exists. |
| 13 | Is reputation audience-specific? | No runtime implementation. AFQR-10 allows audience-relative belief; AFQR-13 adds reputation audiences. |
| 14 | Can false reputation exist? | Doctrinally yes through AFQR-10 false belief/rumor; no social reputation runtime consumes it. |
| 15 | Can audiences disagree? | AFQR-10 supports differing epistemic states; no reputation aggregation/diffusion implementation exists. |
| 16 | Is reputation distinct from fact and personality? | Required doctrinally; not implemented. |
| 17 | Is status represented? | Role, office, rank, or source-local descriptors may appear in schemas, but no general status owner exists. |
| 18 | Are formal and informal status separated? | No executable separation exists. |
| 19 | Are status and authority separated? | AFQR-09/11 separate office/authority relations from identity, but generalized status is absent. |
| 20 | Is rank represented? | Only source-local or conversion descriptors; no RankStructure/RankOccupancy runtime. |
| 21 | Is prestige represented? | Only narrative or donor pressure; no authoritative prestige state. |
| 22 | Is membership represented? | Faction/institution membership can be described in conversion schemas and governed-relation doctrine, but no generalized campaign membership transition service exists. |
| 23 | Are membership, allegiance, and loyalty separated? | Not in executable runtime; AFQR-13 requires separation and AFQR-12 owns loyalty motives/commitments. |
| 24 | Are overlapping affiliations supported? | No runtime implementation; required by AFQR-13. |
| 25 | Are secret affiliations supported? | Hidden-information references exist narrowly, but no private affiliation records or projections exist. |
| 26 | Is culture represented? | Batch A/C and conversion materials describe culture, but no authoritative subject cultural state or runtime profile exists. |
| 27 | Is culture separated from ancestry and personality? | Doctrine requires separation; runtime implementation is absent. |
| 28 | Are subcultures supported? | At most source/local schema pressure, not authoritative runtime. |
| 29 | Are mixed cultural identities supported? | No runtime records exist. |
| 30 | Are norms represented? | Rules, laws, customs, and source-local doctrine appear in conversion material, but no NormDefinition/awareness/compliance runtime exists. |
| 31 | Are norms separated from laws and personal values? | AFQR-09/12 supply handoff boundaries; no social norm engine exists. |
| 32 | Are norm awareness and compliance separated? | AFQR-10 can represent awareness; no norm-applicability/compliance service exists. |
| 33 | Are sanctions represented? | Consequences, governed relations, and resource changes exist as doctrine surfaces, not social sanction execution. |
| 34 | Is kinship represented? | Ancestry, lineage, household, or relationship descriptors may occur in conversion content; no typed kinship runtime exists. |
| 35 | Is household membership separated from kinship? | No runtime implementation; AFQR-13 requires separate relation families. |
| 36 | Are friendship and obligation separated? | AFQR-09 distinguishes governed relations from informal social relations doctrinally; friendship runtime is absent. |
| 37 | Are collective and institutional social states represented? | Faction/institution schemas are conversion structures; AFQR-11/12 distinguish institutional agency/behavior, but social-state services are absent. |
| 38 | Are coalitions and schisms represented? | No generalized runtime structures. |
| 39 | Is group cohesion represented? | No certified cohesion profile exists. |
| 40 | Are social networks represented? | No authoritative or derived social-network snapshot service exists. |
| 41 | Can public opinion differ from institutional record? | AFQR-10 supports this epistemically, but AFQR-13 records are not implemented. |
| 42 | Can one actor have several reputations among different audiences? | Not implemented; required by audience-owned reputation state. |
| 43 | Can a clone inherit none, some, or disputed reputation? | AFQR-08 supports identity separation; social continuity policy is absent. |
| 44 | Can office succession preserve formal ties but not personal ties? | AFQR-08/09 support the distinction doctrinally; no SocialRelationContinuityReceipt exists. |
| 45 | Can a familiar hold independent relationships? | Companion/familiar fields are conversion or schema pressure. AFQR-11/12 permit independent subjects, but no social state exists. |
| 46 | Can institutions retain relationships after full membership replacement? | Institutional identity continuity may permit it doctrinally, but explicit relation continuity is absent. |
| 47 | Which social fields are conversion-only? | Relationship, bond, loyalty, attitude, reputation, rank, status, culture, faction, organization, role, affiliation, norm, custom, kinship, household, ally/enemy, reaction, honor, influence, and similar donor fields remain conversion evidence unless promoted. |
| 48 | Which are fixture-only? | RT-002 actor, NPC target, faction_social_reference projection kind, object/lever command participants, preview, event, delta, and audit references are fixture-only and carry no generalized social semantics. |
| 49 | Which are narrative descriptors? | NPC relationship prose, faction attitudes, cultural descriptions, mission allies/enemies, companion bonds, social hooks, dialogue examples, and adapter examples are portrayal or authored content, not state. |
| 50 | What implementation remains blocked? | Authoritative relationship mutation, trust determination, reputation diffusion, status/membership transitions, norm execution, social-network simulation, coalition/schism execution, continuity, and model-facing social dialogue packets remain blocked. |

### Blocked work

Authoritative relationship mutation, trust updates, reputation propagation, status/rank transitions, admission/expulsion, norm applicability/enforcement, sanctions, social-network materialization, coalition/schism execution, continuity, and model-facing social dialogue remain blocked until AFQR-13 registries, owner routes, evaluators, AFQR-01 fragments, historical archives, and noninterference tests exist.

## Part III — External research synthesis

The research supports multiplex, temporal, audience-relative, profile-scoped architecture rather than one scalar social model. Network analysis provides useful representations and derived metrics but cannot supply relationship truth. Trust literature distinguishes domains, evidence, reliance, distrust, violation, and repair. Reputation systems require provenance, audience segmentation, and attack resistance. Status, identity, culture, norms, kinship, institutions, and group dynamics each require separate constructs and source-local containment.

| Family | Actual mechanism or finding | Astra lesson | Limitation | Disposition |
|---|---|---|---|---|
| social_network_multiplex | Multilayer/multiplex networks distinguish relation layers and coupling rather than forcing all ties into one graph. | Use typed edge layers, hyperedges, and layer-specific metrics. | Network formalisms do not establish social meaning or causation. | adapt |
| social_network_temporal | Edge activity timing changes reachability, diffusion, and centrality. | Version network snapshots and use logical-time propagation rather than static graph truth. | A review/modeling framework, not a social ontology. | adopt |
| community_detection | Community partitions are algorithm-derived and depend on metrics and data. | Store metric definitions, snapshot basis, and uncertainty; never treat detected community as authoritative membership. | Algorithms can be unstable and resolution-dependent. | adapt |
| threshold_collective_behavior | Aggregate cascades can arise from heterogeneous thresholds; similar averages can yield different outcomes. | Separate emergent group patterns from individual motives, norms, and collective intention. | Stylized binary model; not universal social behavior. | adapt |
| complex_contagion | Some behaviors require reinforcement from multiple contacts; diffusion depends on bridge width and clustering. | Support registered simple/complex diffusion profiles and provenance-preserving multi-source exposure. | Not every rumor, norm, or affiliation diffuses as contagion. | adapt |
| trust_integrative | Trust depends on trustor, perceived ability, benevolence, integrity, and risk context. | Make trust directional, domain-specific, evidence-based, and distinct from reliance. | Organizational/human model; categories are not universal. | adapt |
| trust_distrust | Trust and distrust can coexist rather than occupy one continuum. | Represent distrust separately and permit mixed domain states. | Conceptual organizational theory, not a complete runtime formula. | adopt |
| trust_automation | Appropriate reliance requires calibrated trust matched to system capability and context. | Separate technical reliability, social trust, evidence, and reliance decisions for artificial agents/systems. | Automation domain; not universal interpersonal trust. | adapt |
| trust_repair | Trust repair depends on violation type and attribution; apology/explanation effects differ. | Use profile-specific violation and repair candidates; forgiveness and repair are distinct. | Scenario experiments and limited domains. | adapt |
| reputation_online | Reputation systems aggregate distributed feedback but face sparse evidence, retaliation, and manipulation. | Audience/proposition ownership, provenance, aggregation profiles, and attack resistance are mandatory. | Marketplace focus and simplified ratings. | adapt |
| reputation_mechanism | Online feedback mechanisms are design-dependent and vulnerable to strategic manipulation. | Never equate rating aggregation with truth; certify audience and manipulation assumptions. | Electronic market context. | adapt |
| sybil_resistance | Without trusted identity constraints, one actor can create many pseudonymous identities and distort distributed systems. | Reputation aggregation must bind AFQR-08 identity evidence and detect coordinated claims. | Distributed computing threat model, not all social settings. | adopt |
| status_prestige_dominance | Prestige and dominance are different status processes; prestige involves voluntarily conferred deference. | Separate prestige, dominance, rank, authority, and observed deference. | Evolutionary account; not universal culture law. | adapt |
| status_inconsistency | Actors can occupy inconsistent positions across multiple status systems. | Status is jurisdiction/profile-specific and can be conflicting or incomparable. | Organizational setting. | adopt |
| social_identity | Minimal categorization can affect allocation and in-group behavior. | Support self-claims, assigned categories, salience, and cross-cutting affiliations without making bias universal. | Human experimental pattern; does not define individual behavior. | contain |
| multiple_group_membership | People hold multiple memberships with varying perceived overlap and complexity. | Represent overlapping, conflicting, and differently salient affiliations. | Human social-psychology model. | adapt |
| norms_empirical_expectations | Norm compliance can depend on empirical and normative expectations plus conditional preferences. | Separate norm recognition, awareness, endorsement, expectation, compliance, and enforcement. | Theory centered on human norms; profile-specific implementation needed. | adapt |
| pluralistic_ignorance | Public conformity can coexist with private rejection because actors misperceive others’ attitudes. | Public norm belief, private endorsement, and actual compliance require separate records. | Specific empirical context. | adopt |
| institutional_governance | Durable institutions use explicit boundaries, rules, monitoring, sanctions, and nested governance. | Model institutional norms, membership, procedures, and sanctions as registered profiles and governed handoffs. | Common-pool governance; not universal institutional structure. | adapt |
| culture_dynamic | Multiple cultural meaning systems can be acquired and contextually activated. | Support mixed cultural affiliation, exposure, competence, identity, and context-specific practice. | Human experimental account; avoid universal priming mechanics. | adapt |
| cultural_evolution | Cultural transmission can follow several biased learning pathways and population dynamics. | Treat diffusion and adoption as profile-driven, not inheritance or personality. | Models are abstractions and not one universal culture engine. | contain |
| kinship_anthropology | Kinship categories are culturally constructed and cannot be reduced universally to biology. | Use typed biological, legal, social, ritual, and source-local kinship definitions. | Critical anthropology; does not supply runtime rules. | adopt |
| households | Households require operational definitions distinct from family and kinship. | Separate household membership, residence, kinship, care, and authority. | Historical-demographic typology, not universal. | adapt |
| groupthink | Cohesive decision groups can suppress dissent under certain conditions. | Group cohesion never implies consensus or good decisions; preserve dissent and procedure evidence. | Historical/case-based theory and contested generality. | contain |
| minority_influence | Consistent minorities can influence majority judgments. | Permit dissent-driven group transitions without majority-wins social law. | Laboratory perception task. | adapt |
| ostracism | Exclusion can affect belonging, control, esteem, and behavior, with context-dependent responses. | Represent ostracism events and profile-scoped impacts; do not prescribe universal trauma responses. | Human review literature; downstream psychology remains AFQR-12/source-local. | adapt |
| organizational_identity | Organizations maintain claims about central, distinctive, and enduring character separate from member identity. | Institutional identity, public mission, culture, and member beliefs remain distinct continuity families. | Conceptual organizational theory. | adapt |
| organizational_memory | Organizational information can be retained in individuals, culture, transformations, structures, ecology, and archives. | Institutional memory and social continuity require explicit stores and succession receipts. | Conceptual model, not a deterministic runtime implementation. | adapt |
| artificial_institutions | Artificial institutions distinguish rules regulating behavior from rules constituting roles/statuses. | Keep norm, status, role, sanction, and agent action separate for artificial societies. | Formal MAS model; social meaning is domain-dependent. | adapt |
| animal_social_networks | Animal social systems can be studied as networks with dynamic associations and individual variation. | Support nonhuman social subjects and profile-specific ties without human relationship assumptions. | Observational/network emphasis, not full cognition or norm theory. | adapt |
| nemesis_system | The Nemesis design tracks persistent NPC hierarchy, encounters, promotions, rivalries, and generated social history. | Persistent rivals require backend state, identity, event history, and bounded procedural transitions—not model memory. | Patent describes one game-specific hierarchy and encounter system. | contain |
| ttrpg_factions | Faction status and clocks provide compact source-local abstractions for relations and progress. | Map as source-local/normalized pressure, not universal reputation or relationship law. | Narrative game abstraction; limited granularity. | contain |
| ttrpg_renown | Renown represents standing within an organization and can gate ranks or benefits. | Treat as a source-local quantity/status/membership profile with explicit audience and governance. | Single donor family and often scalar. | contain |

## Part IV — Canonical terminology

| Term | Definition |
|---|---|
| `social relation` | A registered typed social connection or social-position relation among one or more participant bindings; it does not imply affection, obligation, recognition, or reciprocity. |
| `relationship` | A social-relation instance whose dimensions, participants, recognition, visibility, and lifecycle are explicit. |
| `relation dimension` | One independently governed aspect of a multiplex relation, such as familiarity, affection, rivalry, dependence, cooperation, or source-local meaning. |
| `relation participant` | An identity-scoped reference bound to a relation in a named role and direction. |
| `dyadic relation` | A relation whose authoritative participant set contains exactly two bindings. |
| `asymmetric relation` | A relation or relation dimension whose state from A toward B need not equal the state from B toward A. |
| `reciprocal relation` | A relation whose certified profile requires compatible participant acknowledgments or directional states; reciprocity is determined, not presumed. |
| `multiplex relation` | A relation carrying several separately typed dimensions without collapsing them into one score. |
| `group relation` | A relation binding one or more subjects to a group, audience, household, coalition, culture, or institution. |
| `role relation` | A relation attached to a role or office facet rather than automatically to the occupant as a person. |
| `formal relation` | A relation recognized by a registered institution, procedure, jurisdiction, or governed-relation authority. |
| `informal relation` | A social relation not dependent on formal institutional recognition. |
| `acknowledged relation` | A relation or relation claim a named participant or audience explicitly recognizes. |
| `hidden relation` | A committed relation whose existence or dimensions are restricted to authorized audiences. |
| `acquaintance` | A familiarity-class relation with limited recognition and no implied trust or affection. |
| `friendship` | A source/profile-qualified relation type; it may require recognition or reciprocity under its profile but never follows automatically from contact. |
| `rivalry` | A competitive relation dimension that may coexist with respect, cooperation, affection, or trust in other domains. |
| `enmity` | A hostile relation dimension or profile, not a universal action command. |
| `intimacy` | A profile-scoped closeness or disclosure relation; it is not consent, ownership, or guaranteed affection. |
| `attachment` | A behavioral or affective relation reference routed to AFQR-12 where motivational or emotional state is involved. |
| `dependency` | A social or governed relation involving reliance on another subject or structure; it is not trust or authority by default. |
| `patronage` | A typed relation involving support, sponsorship, access, or resource flow with explicit governed-relation handoffs. |
| `mentorship` | A typed developmental or instructional relation that does not automatically grant authority, kinship, or loyalty. |
| `alliance` | A formal or informal cooperative relation or governed agreement scoped to stated purposes. |
| `coalition` | A multi-party temporary or persistent grouping organized around partly shared goals or procedures without requiring friendship, trust, or cultural unity. |
| `estrangement` | A transition or state of reduced contact, recognition, or relation dimensions; not universal termination. |
| `trust` | A directional, domain-specific determination that a subject is willing to accept a defined vulnerability or reliance under stated evidence and conditions. |
| `reliance` | A decision or practical dependence on another subject or system, which may occur without personal trust. |
| `confidence` | A profile-qualified degree or qualitative assessment of support for a trust, reputation, status, or other social determination. |
| `credibility` | An audience- or trust-domain assessment of the reliability of a source or claim. |
| `predictability` | An expectation of behavioral regularity, separable from benevolence, integrity, approval, or trust. |
| `benevolence expectation` | A domain-specific expectation that another subject is disposed to protect or advance the trustor’s interests. |
| `competence trust` | Trust scoped to another’s ability in a defined task or domain. |
| `discretion trust` | Trust scoped to handling confidential or sensitive information. |
| `loyalty trust` | Trust scoped to expected support or non-defection under stated conditions; distinct from actual allegiance or affection. |
| `distrust` | A supported expectation of unreliability, harmfulness, deception, or adverse conduct in a domain; not merely low trust. |
| `suspicion` | An uncertain adverse trust or credibility assessment that does not establish wrongdoing. |
| `trust domain` | The explicit purpose, vulnerability, action family, or reliance context to which a trust determination applies. |
| `trust condition` | A condition under which a trust determination or reliance basis remains applicable. |
| `trust violation` | A profile-scoped event or evidence pattern inconsistent with an existing trust expectation. |
| `betrayal` | A trust-violation or relationship-impact claim requiring a named profile, expectation, evidence basis, and determination. |
| `trust repair` | A candidate or determination concerning restoration or recalibration of a trust domain after a violation. |
| `forgiveness` | A behavioral, relational, cultural, or normative transition that does not automatically restore trust or erase responsibility. |
| `reconciliation` | A profile-scoped process or transition toward renewed interaction or relation repair; no universal sequence is implied. |
| `reputation` | An audience-owned, proposition-scoped epistemic-social state concerning a subject; it is not intrinsic truth or personality. |
| `audience` | A registered social/epistemic grouping whose members or aggregate process may own reputation or public-standing state. |
| `public standing` | A projection or aggregate reputation/status view for a defined public audience and jurisdiction. |
| `renown` | A source/profile-qualified positive public-standing or reputation construct. |
| `notoriety` | A source/profile-qualified high-salience reputation that may be adverse, mixed, or context-specific. |
| `fame` | Breadth or salience of recognition within a defined audience, separate from approval. |
| `infamy` | A negative or adverse reputation construct in a defined audience, not universal moral truth. |
| `credibility reputation` | Audience reputation concerning truthfulness or claim reliability. |
| `competence reputation` | Audience reputation concerning capability in a defined domain. |
| `threat reputation` | Audience reputation concerning danger, coercive capacity, or expected harm. |
| `professional reputation` | Audience reputation scoped to occupation, role, craft, or institutional domain. |
| `rumor` | A provenance-bearing epistemic claim transmitted socially without automatic truth or reputation adoption. |
| `public claim` | A claim available to a defined public audience; publicity does not establish truth or consensus. |
| `official record` | An institutional record with explicit authority and scope; it is distinct from awareness, public belief, and truth. |
| `social attribution` | An observer or audience assignment of action, motive, relation, or status, separate from authoritative action origin or responsibility. |
| `reputation diffusion` | A scheduled, provenance-preserving transmission of reputation-relevant claims among audiences or subjects. |
| `reputation correction` | An append-only audience-state update or claim challenging prior reputation; correction need not reach or persuade all audiences. |
| `status` | A jurisdiction- and profile-scoped social position or recognized standing. |
| `rank` | A position within a versioned ordered or partially ordered rank structure. |
| `title` | A named designation with explicit issuer, jurisdiction, and recognition; it need not confer authority. |
| `office` | An identity-distinct institutional role that may hold governed authorities and formal relations. |
| `prestige` | Informal or formal esteem that may produce voluntarily conferred deference; distinct from dominance and authority. |
| `honor` | A source/profile-qualified status, reputation, normative, or quantity construct that must be explicitly disambiguated. |
| `seniority` | A position based on duration, sequence, or tenure within a defined structure. |
| `caste` | A source-local social classification or hierarchy requiring containment, jurisdiction, and protected-subject review. |
| `class` | A qualified social, economic, institutional, or source-local category; unqualified runtime use is prohibited. |
| `citizenship` | A governed membership/status relation in a defined polity or source-local jurisdiction. |
| `qualification` | A certified competence or eligibility status, distinct from prestige and authority. |
| `social position` | A typed location in one or more formal or informal social structures. |
| `deference` | Observed or expected behavior toward a status holder; it does not prove recognition, consent, or legitimacy. |
| `status claim` | A proposition that a subject holds a status, rank, title, or position. |
| `perceived status` | An observer- or audience-relative belief about status. |
| `formal status` | Status conferred or recognized by a registered authority or procedure. |
| `informal status` | Social standing not dependent on formal institutional grant. |
| `status mobility` | A transition among positions in a defined status structure. |
| `membership` | A governed or social relation connecting a subject to a group under an explicit affiliation definition. |
| `affiliation` | A broader social association or identification that may be formal, informal, self-claimed, observer-assigned, or disputed. |
| `allegiance` | A behavioral or governed commitment to support a group or cause; distinct from membership. |
| `coalition membership` | Membership in a coalition with explicit purpose, lifecycle, and rights/duties handoffs. |
| `household membership` | Participation in a household structure, distinct from kinship and legal residence. |
| `employment` | A governed work relation with explicit duties, rights, compensation, and authority handoffs. |
| `office occupancy` | The identity-scoped relation between an office and its current occupant. |
| `honorary membership` | Membership recognized symbolically or ceremonially with explicitly limited consequences. |
| `secret membership` | A membership relation whose existence or details are hidden from one or more audiences. |
| `suspended membership` | Membership whose lifecycle or consequences are partly inactive under explicit policy. |
| `disputed membership` | A membership claim whose authoritative status remains unresolved. |
| `defection` | A transition candidate or determination involving withdrawal, switch of allegiance, or departure under a profile. |
| `expulsion` | An authority-driven membership termination or suspension process under a registered procedure. |
| `recruitment` | A communication, selection, or admission process; it does not itself create membership. |
| `culture` | A modular, source-scoped system of practices, symbols, institutions, narratives, interpretive frameworks, and norms; not an executable personality package. |
| `subculture` | A culture profile situated within, across, or against one or more broader cultures. |
| `counterculture` | A culture or affiliation defined partly through opposition to selected norms or institutions. |
| `tradition` | A temporally continued practice, narrative, norm, or institution with explicit recognition and transmission history. |
| `custom` | A recognized recurring social practice, distinct from law and personal habit. |
| `convention` | A coordination norm or recurring practice sustained by mutual expectations or procedures. |
| `etiquette` | A source/profile-qualified set of interaction norms and practices. |
| `taboo` | A strongly prohibited or sacred norm under a defined cultural/source-local profile. |
| `ritual` | A structured social or source-local practice with explicit participants, recognition, and effects. |
| `norm` | A registered expectation, convention, prescription, or standard for a defined audience and jurisdiction. |
| `role expectation` | A norm or behavioral expectation associated with a role; it is not a command, motive, or guaranteed behavior. |
| `institutional policy` | An official rule or directive of an institution, distinct from member awareness, endorsement, and practice. |
| `moral norm` | A source/profile-qualified norm framed as moral by an audience; it is not universal Astra morality. |
| `sacred norm` | A source-local norm tied to religious, spiritual, or metaphysical significance. |
| `norm awareness` | An epistemic determination that a subject has access to or understands a norm. |
| `norm endorsement` | A behavioral/value stance supporting a norm; distinct from awareness and compliance. |
| `norm compliance` | Evidence or determination that conduct conformed to a norm under a named profile. |
| `norm enforcement` | An institutional, social, or source-local process applying responses to norm claims or violations. |
| `sanction` | A consequence or response linked to a norm or governed rule; it requires proper action, relation, quantity, and responsibility handoffs. |
| `norm contestation` | A record that a norm’s existence, interpretation, legitimacy, applicability, or enforcement is disputed. |
| `cultural adoption` | A candidate or determined change in cultural affiliation, practice, competence, or identity—not a single switch. |
| `acculturation` | A profile-scoped process of exposure, learning, practice, adaptation, or identity change across cultures. |
| `group` | A registered collection or audience; grouping alone does not establish agency, institution, culture, or common intention. |
| `community` | A source/profile-qualified social grouping that may include audience, culture, network, location, or membership components. |
| `institution` | A continuity-bearing governed social entity with registered procedures, records, roles, and owner boundaries. |
| `faction` | A registered group, institution, coalition, or sub-group requiring qualification; it is not automatically one agent. |
| `clique` | A tightly connected social subnetwork or grouping under a profile; network density alone is not authoritative membership. |
| `network` | A derived or authoritative graph representation of typed social participants and relations. |
| `cohesion` | A profile-scoped assessment of coordination, stability, retention, trust, shared goals, or other named dimensions. |
| `polarization` | A profile-scoped pattern of separation or opposition among positions, groups, or network structures. |
| `conformity` | Behavioral alignment with perceived group expectations; route motive and action origin to AFQR-12/11. |
| `dissent` | Expressed or enacted disagreement with a group, policy, norm, or decision. |
| `marginalization` | A profile-scoped social process involving reduced access, standing, inclusion, or network position; not universal law. |
| `ostracism` | Exclusion or social non-engagement under a registered event or group-dynamics profile. |
| `schism` | A transition in which a group, institution, culture, or coalition separates into disputed or distinct successors. |
| `integration` | A profile-scoped process of participation or structural inclusion without requiring assimilation. |
| `assimilation` | A source/profile-qualified process of adopting or being required to adopt cultural or group patterns. |
| `collective efficacy` | A group-level assessment of perceived or demonstrated capacity for coordinated action under a named profile. |
| `social centrality` | A derived network metric within a specified snapshot, edge projection, and metric definition; it does not establish authority or importance universally. |
| `emergent group pattern` | A derived pattern produced by interactions without presuming collective intention or one group mind. |
| `kinship` | A typed biological, legal, adoptive, social, ritual, lineage, or source-local relation. |
| `household` | A registered social/organizational unit with membership and continuity rules distinct from kinship. |
| `lineage` | A typed continuity or descent relation, not automatic inheritance, authority, or cultural identity. |
| `chosen family` | A self- and/or mutually recognized social kinship relation under an explicit profile. |
| `ritual kinship` | A socially or source-locally constituted kinship relation created or recognized through ritual or convention. |
| `social event` | A committed event eligible to produce non-mutating social-impact candidates under registered profiles. |
| `social impact candidate` | A proposed relation, trust, reputation, status, affiliation, culture, norm, or group-state change that has no authority until owner preparation and AFQR-01 commit. |
| `social continuity` | A profile-specific determination of what social state is preserved, disputed, divided, or not transferred across identity or institutional transitions. |
| `social simulation tier` | A declared fidelity/ownership tier controlling what social state is materialized and what approximations are permitted. |
| `association` | A weak or generic affiliation requiring qualification before runtime use. |

### Prohibited unqualified runtime terms

`relationship`, `trust`, `loyalty`, `reputation`, `status`, `culture`, `faction`, `friend`, `enemy`, `ally`, `honor`, `influence`, `social score`, `public opinion`, `family`, `member`, `rank`, `prestige`, `norm violation`, `betrayal`, `forgiveness`, `coalition`, `community`, `centrality`, `approval`, `affection`, `hostility`.

Any use at a runtime boundary must identify the registered profile or definition, participant direction, audience/jurisdiction, owner, effective time, policy version, and visibility basis.


## Part V — Social subjects, audiences, and ownership

AFQR-13 uses a federated owner model. A social subject can be an individual, persona, office, institution, collective, faction, household, culture, swarm, artificial agent, public audience, community, or source-local entity only when a registered eligibility profile and AFQR-08 identity facet exist. Social subject, relationship participant, epistemic subject, audience, institution, collective, office, behavioral subject, and model consumer are non-interchangeable.

The social coordinator may discover candidates and gather owner fragments, but it cannot mutate participant relations, audience reputation, institutional records, or hidden social state. Each record binds effective, recorded, and logical time; identity, epistemic, agency, behavioral, and governed-relation bases; policy versions; and an audience-safe private commitment.

## Part VI — Multiplex social relationships

A SocialRelationDefinition registers participant arity, allowed roles, directionality, reciprocity rules, dimensions, lifecycle, recognition semantics, and source-local namespace. A SocialRelationInstance binds identity facets and contains independently owned dimension states. No universal affection/trust/respect/fear/loyalty track set exists.

Authoritative relation registration, each participant’s belief, public acknowledgment, observer inference, institutional recognition, self-description, and model portrayal are separate. One-sided friendship, false public alliance, hidden rivalry, and office-versus-person relations are lawful without forced reconciliation.

## Part VII — Trust and reliance

Trust is a directional determination from trustor to trustee in a named domain and condition set. Evidence is AFQR-10 grounded and may be false, incomplete, private, or disputed. Trust, distrust, suspicion, confidence, credibility, predictability, affection, loyalty, and reliance remain distinct.

A trust violation is profile-scoped. Betrayal is a claim/determination, not an event label with universal effects. TrustRepairCandidate, forgiveness, reconciliation, compensation, explanation, and renewed reliance are separate outcomes. No global trust score exists.

## Part VIII — Reputation and public standing

Reputation belongs to audiences, not intrinsically to its subject. Each ReputationState binds an audience, proposition, evidence/provenance graph, aggregation/revision profile, uncertainty, visibility, and time. Audiences may overlap, disagree, contain false beliefs, or be disputed.

Diffusion is scheduled through AFQR-04 and AFQR-10 testimony/rumor records. Translation, retraction, brigading, Sybil identities, coordinated misinformation, language boundaries, and partial correction are explicit. No universal global update or majority-truth rule is permitted.

## Part IX — Status, rank, prestige, and hierarchy

StatusDefinition and StatusJurisdiction define what status means and where it applies. Formal status, perceived status, rank occupancy, title, office, prestige, deference, dominance, authority, power, capability, wealth, and reputation are separate. Multiple status systems can conflict or remain incomparable.

Office succession may transfer formal office relations under AFQR-08/09 while personal prestige, friendship, trust, and reputation require separate continuity determinations.

## Part X — Membership and affiliation

AffiliationDefinition and MembershipRelation represent formal membership, informal affiliation, citizenship, employment, office, household participation, religious affiliation, coalition membership, honorary status, secrecy, suspension, dispute, coercion, defection, and expulsion. Self-identification and external recognition remain separate.

Rights, duties, access, authority, protection, representation, and resource claims route through AFQR-09 and AFQR-07. Membership never universally creates loyalty, allegiance, trust, cultural identity, or agency.

## Part XI — Culture and norms

CultureDefinition is a modular bundle of practices, symbols, institutions, narratives, interpretive frameworks, and norm references—not personality. Cultural exposure, competence, practice, self-identification, external assignment, adoption, rejection, diaspora change, subculture, and mixed identity are independent records.

NormDefinition separates audience, jurisdiction, recognition, awareness, endorsement, applicability, compliance evidence, violation claims, determinations, enforcement, legitimacy, and change. Repeated behavior does not establish a norm automatically; a norm does not guarantee compliance. Sanctions route to action, authority, responsibility, governed-relation, and quantity owners.

## Part XII — Kinship and household relations

Kinship definitions support biological lineage, legal parentage, adoption, chosen family, ritual kinship, clan, mentorship lineage, spiritual lineage, and source-local systems. HouseholdDefinition separately owns household membership and lifecycle.

Kinship does not automatically confer affection, trust, consent, custody, guardianship, inheritance, authority, culture, or obligation. Those consequences require AFQR-09/11 and source-local determinations.

## Part XIII — Group dynamics and social networks

SocialNetworkSnapshot stores a valid-time participant set and typed edge/hyperedge projections. Metrics are versioned derived observations over named snapshots. Centrality is not authority; community detection is not membership; graph reachability is not influence or causation. Hidden and incomplete networks are first-class.

Coalitions, cliques, alliances, factions, cohesion, polarization, dissent, ostracism, recruitment, defection, schism, and emergent patterns use registered profiles. A coalition may lack trust or shared culture. Emergent patterns do not prove unified intention or one collective mind.

## Part XIV — Social transitions and continuity

Social events create candidates, not automatic changes. Introduction, assistance, gift, insult, harm, promise, disclosure, betrayal, apology, forgiveness, reconciliation, admission, expulsion, status change, and sanction each route through named impact profiles.

Continuity is evaluated separately for personal relations, office relations, institutional alliances, kinship, household, reputation by audience, rank, membership, cultural identity, norm recognition, and coalition state. Copy, fusion, fission, resurrection, reincarnation, office succession, familiar autonomy, and institutional turnover transfer nothing automatically.

## Part XV — Hidden social state and model projection

Private relation, trust, reputation, status, affiliation, culture, norm, coalition, and network records use audience-scoped opaque tokens and private integrity commitments. Public digests are projection-specific and unlinkable across audiences. Count, topology, search-size, policy-name, timing, and blocker side channels are suppressed.

The model receives a ModelSocialGroundingManifest and permitted claim kinds. It may portray committed visible social state but cannot infer or create friendship, trust, reputation, culture, status, membership, norm violation, coalition, or relationship transitions. Cross-packet retrieval and cache isolation are hard security requirements.

## Part XVI — Typed contracts

The sidecar catalog contains 122 schemas. Every schema identifies required, optional, hidden, derived, and prohibited fields; owner routes; identity, epistemic, agency, behavioral, governed-relation, temporal, policy, commitment, and AFQR bases.

| Contract | Authoritative owner | Representative required fields |
|---|---|---|
| `SocialSubjectReference` | `social_relation_owner` | social_subject_reference_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialAudienceReference` | `social_relation_owner` | social_audience_reference_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialStateJurisdictionRecord` | `social_relation_owner` | social_state_jurisdiction_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialRelationDefinition` | `social_relation_owner` | social_relation_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialRelationInstance` | `social_relation_owner` | relation_instance_id, relation_definition_ref, participant_binding_refs, jurisdiction_ref, lifecycle_state |
| `SocialRelationParticipantBinding` | `social_relation_owner` | relation_ref, participant_ref, participant_role, direction, identity_facet_ref |
| `SocialRelationDimensionDefinition` | `social_relation_owner` | social_relation_dimension_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialRelationDimensionState` | `social_relation_owner` | relation_ref, dimension_definition_ref, directional_subject_ref, directional_object_ref, state_representation |
| `SocialRelationRecognitionRecord` | `social_relation_owner` | social_relation_recognition_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialRelationTransition` | `social_relation_owner` | social_relation_transition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialRelationContinuityProfile` | `social_relation_owner` | social_relation_continuity_profile_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialRelationContinuityReceipt` | `social_relation_owner` | social_relation_continuity_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialRelationLineageEdge` | `kinship_household_owner` | social_relation_lineage_edge_id, subject_or_scope_ref, status, schema_version, effective_time |
| `TrustDomainDefinition` | `trust_owner` | trust_domain_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `TrustProfile` | `trust_owner` | trust_profile_id, subject_or_scope_ref, status, schema_version, effective_time |
| `TrustEvidenceSet` | `trust_owner` | trust_evidence_set_id, subject_or_scope_ref, status, schema_version, effective_time |
| `TrustDetermination` | `trust_owner` | trustor_ref, trustee_ref, trust_domain_ref, evidence_set_ref, determination_status |
| `TrustCondition` | `trust_owner` | trust_condition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `RelianceDecisionReference` | `trust_owner` | reliance_decision_reference_id, subject_or_scope_ref, status, schema_version, effective_time |
| `TrustViolationRecord` | `trust_owner` | trust_violation_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `TrustRepairCandidate` | `trust_owner` | trust_repair_candidate_id, subject_or_scope_ref, status, schema_version, effective_time |
| `TrustRepairDetermination` | `trust_owner` | trust_repair_determination_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ReputationProposition` | `reputation_audience_owner` | reputation_proposition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ReputationAudienceDefinition` | `reputation_audience_owner` | reputation_audience_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ReputationClaim` | `reputation_audience_owner` | reputation_claim_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ReputationEvidenceRelation` | `reputation_audience_owner` | reputation_evidence_relation_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ReputationState` | `reputation_audience_owner` | audience_ref, reputation_subject_ref, proposition_ref, claim_refs, revision_profile_ref |
| `ReputationAggregationProfile` | `reputation_audience_owner` | reputation_aggregation_profile_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ReputationDiffusionRecord` | `reputation_audience_owner` | reputation_diffusion_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ReputationCorrectionRecord` | `reputation_audience_owner` | reputation_correction_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PublicStandingProjection` | `reputation_audience_owner` | public_standing_projection_id, subject_or_scope_ref, status, schema_version, effective_time |
| `StatusDefinition` | `status_rank_owner` | status_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `StatusJurisdiction` | `status_rank_owner` | status_jurisdiction_id, subject_or_scope_ref, status, schema_version, effective_time |
| `StatusClaim` | `status_rank_owner` | status_claim_id, subject_or_scope_ref, status, schema_version, effective_time |
| `StatusDetermination` | `status_rank_owner` | subject_ref, status_definition_ref, jurisdiction_ref, claim_refs, determination_status |
| `RankStructure` | `status_rank_owner` | rank_structure_id, subject_or_scope_ref, status, schema_version, effective_time |
| `RankDefinition` | `status_rank_owner` | rank_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `RankOccupancy` | `status_rank_owner` | rank_occupancy_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PrestigeState` | `status_rank_owner` | prestige_state_id, subject_or_scope_ref, status, schema_version, effective_time |
| `DeferenceExpectation` | `status_rank_owner` | deference_expectation_id, subject_or_scope_ref, status, schema_version, effective_time |
| `StatusTransition` | `status_rank_owner` | status_transition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `AffiliationDefinition` | `affiliation_membership_owner` | affiliation_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `MembershipRelation` | `affiliation_membership_owner` | member_ref, affiliation_definition_ref, membership_status_ref, recognition_status, schema_version |
| `MembershipStatus` | `status_rank_owner` | membership_status_id, subject_or_scope_ref, status, schema_version, effective_time |
| `MembershipEligibility` | `affiliation_membership_owner` | membership_eligibility_id, subject_or_scope_ref, status, schema_version, effective_time |
| `AdmissionRecord` | `affiliation_membership_owner` | admission_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SuspensionRecord` | `affiliation_membership_owner` | suspension_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ExpulsionRecord` | `affiliation_membership_owner` | expulsion_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `DefectionRecord` | `affiliation_membership_owner` | defection_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `AffiliationRecognitionRecord` | `affiliation_membership_owner` | affiliation_recognition_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CultureDefinition` | `culture_profile_owner` | culture_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CulturalProfile` | `culture_profile_owner` | cultural_profile_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CulturalAffiliationRecord` | `affiliation_membership_owner` | subject_ref, culture_definition_ref, affiliation_kind, self_claim_status, external_recognition_status |
| `CulturalExposureRecord` | `culture_profile_owner` | cultural_exposure_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CulturalCompetenceRecord` | `culture_profile_owner` | cultural_competence_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CulturalPracticeRecord` | `culture_profile_owner` | cultural_practice_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CulturalIdentityClaim` | `culture_profile_owner` | cultural_identity_claim_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CulturalAdoptionCandidate` | `culture_profile_owner` | cultural_adoption_candidate_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CulturalContinuityReceipt` | `culture_profile_owner` | cultural_continuity_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormDefinition` | `norm_owner` | norm_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormAudience` | `norm_owner` | norm_audience_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormJurisdiction` | `norm_owner` | norm_jurisdiction_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormRecognitionRecord` | `norm_owner` | norm_recognition_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormAwarenessRecord` | `norm_owner` | norm_awareness_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormEndorsementRecord` | `norm_owner` | norm_endorsement_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormApplicabilityDetermination` | `norm_owner` | norm_ref, subject_or_event_ref, audience_ref, jurisdiction_ref, applicability_status |
| `NormComplianceEvidence` | `norm_owner` | norm_compliance_evidence_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormViolationClaim` | `norm_owner` | norm_violation_claim_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormViolationDetermination` | `norm_owner` | norm_violation_determination_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormSanctionReference` | `norm_owner` | norm_sanction_reference_id, subject_or_scope_ref, status, schema_version, effective_time |
| `NormChangeRecord` | `norm_owner` | norm_change_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `KinshipRelationDefinition` | `kinship_household_owner` | kinship_relation_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `KinshipRelationInstance` | `kinship_household_owner` | kinship_relation_instance_id, subject_or_scope_ref, status, schema_version, effective_time |
| `HouseholdDefinition` | `kinship_household_owner` | household_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `HouseholdMembershipRecord` | `affiliation_membership_owner` | household_membership_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `LineageRelationReference` | `kinship_household_owner` | lineage_relation_reference_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialEventDefinition` | `social_event_impact_owner` | social_event_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialEventRecord` | `social_event_impact_owner` | social_event_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialImpactCandidate` | `social_event_impact_owner` | social_impact_candidate_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialImpactDetermination` | `social_event_impact_owner` | social_impact_determination_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialNetworkSnapshot` | `social_network_projection_owner` | snapshot_id, participant_set_ref, edge_projection_refs, hyperedge_projection_refs, valid_interval |
| `SocialNetworkEdgeProjection` | `social_network_projection_owner` | social_network_edge_projection_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialNetworkHyperedgeProjection` | `social_network_projection_owner` | social_network_hyperedge_projection_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialMetricDefinition` | `social_network_projection_owner` | social_metric_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialMetricReceipt` | `social_network_projection_owner` | social_metric_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CoalitionDefinition` | `coalition_group_dynamics_owner` | coalition_definition_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CoalitionFormationCandidate` | `coalition_group_dynamics_owner` | coalition_formation_candidate_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CoalitionFormationReceipt` | `coalition_group_dynamics_owner` | coalition_definition_ref, participant_refs, formation_basis_refs, formation_status, schema_version |
| `CoalitionMembershipRecord` | `affiliation_membership_owner` | coalition_membership_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CoalitionCohesionAssessment` | `coalition_group_dynamics_owner` | coalition_cohesion_assessment_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CoalitionConflictRecord` | `coalition_group_dynamics_owner` | coalition_conflict_record_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SchismCandidate` | `coalition_group_dynamics_owner` | schism_candidate_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SchismReceipt` | `coalition_group_dynamics_owner` | schism_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialInfluenceManifest` | `social_influence_router` | social_influence_manifest_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialInfluenceHandoff` | `social_influence_router` | social_influence_handoff_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialSimulationTier` | `social_simulation_tier_owner` | social_simulation_tier_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialMaterializationPolicy` | `social_simulation_tier_owner` | social_materialization_policy_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialPromotionReceipt` | `social_simulation_tier_owner` | social_promotion_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialDemotionReceipt` | `social_simulation_tier_owner` | social_demotion_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialApproximationCertificate` | `social_simulation_tier_owner` | tier_ref, population_scope, retained_state_refs, approximation_profile_ref, error_bounds_or_qualitative_limits |
| `PrivateRelationshipReceipt` | `social_projection_security_owner` | private_relationship_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PrivateTrustReceipt` | `trust_owner` | private_trust_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PrivateReputationReceipt` | `reputation_audience_owner` | private_reputation_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PrivateStatusReceipt` | `status_rank_owner` | private_status_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PrivateAffiliationReceipt` | `affiliation_membership_owner` | private_affiliation_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PrivateCultureReceipt` | `culture_profile_owner` | private_culture_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PrivateNormReceipt` | `norm_owner` | private_norm_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PrivateCoalitionReceipt` | `coalition_group_dynamics_owner` | private_coalition_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ActorVisibleSocialProjection` | `social_projection_security_owner` | actor_visible_social_projection_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ObserverVisibleSocialProjection` | `social_projection_security_owner` | observer_visible_social_projection_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PlayerVisibleSocialProjection` | `social_projection_security_owner` | player_visible_social_projection_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ModelVisibleSocialProjection` | `social_projection_security_owner` | model_visible_social_projection_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PublicSocialProjection` | `social_projection_security_owner` | public_social_projection_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ModelSocialGroundingManifest` | `social_projection_security_owner` | model_social_grounding_manifest_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PermittedSocialClaimKindRegistry` | `social_architecture_registry_owner` | permitted_social_claim_kind_registry_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ModelSocialOutputValidator` | `social_projection_security_owner` | model_social_output_validator_id, subject_or_scope_ref, status, schema_version, effective_time |
| `CrossPacketSocialIsolationReceipt` | `social_projection_security_owner` | cross_packet_social_isolation_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `SocialProjectionNoninterferenceReceipt` | `social_projection_security_owner` | social_projection_noninterference_receipt_id, subject_or_scope_ref, status, schema_version, effective_time |
| `AudienceScopedSocialToken` | `social_projection_security_owner` | audience_scoped_social_token_id, subject_or_scope_ref, status, schema_version, effective_time |
| `PrivateSocialIntegrityCommitment` | `social_projection_security_owner` | private_social_integrity_commitment_id, subject_or_scope_ref, status, schema_version, effective_time |
| `ProjectionSpecificSocialDigest` | `social_projection_security_owner` | projection_specific_social_digest_id, subject_or_scope_ref, status, schema_version, effective_time |
| `AFQR13Handoff` | `social_architecture_registry_owner` | handoff_id, source_owner, target_AFQR_or_owner, payload_refs, handoff_status |

## Part XVII — Determination pipelines

### Relationship-impact pipeline

```text
committed interaction or social event
→ freeze participant identities and social basis
→ identify applicable relation dimensions
→ gather participant-visible and private evidence
→ apply registered social-impact profiles
→ produce non-mutating candidates
→ detect conflicts and hidden-state constraints
→ prepare owner fragments
→ AFQR-01 commit
→ private and visible projections
```

### Trust pipeline

```text
observation, testimony, action, outcome, or disclosure
→ identify trustor, trustee, domain, and conditions
→ freeze AFQR-10 evidence
→ apply trust profile
→ candidate / unresolved result
→ optional reliance-decision handoff
→ owner fragment
→ commit
→ projection
```

### Reputation pipeline

```text
claim, observation, rumor, record, or public event
→ identify audiences and proposition
→ freeze accessible evidence and provenance
→ apply audience revision/aggregation profile
→ reputation candidates
→ schedule registered diffusion
→ commit audience-owner fragments
→ projections
```

### Status and membership pipeline

```text
claim, appointment, election, admission, promotion, recognition, or dispute
→ resolve jurisdiction and governed relation
→ verify eligibility and authority
→ apply status/membership profile
→ AFQR-06 arbitration if needed
→ AFQR-09 transition
→ owner fragment
→ commit and notification
```

### Norm pipeline

```text
norm reference or candidate
→ audience/jurisdiction
→ recognition and awareness
→ applicability
→ compliance evidence or violation claim
→ named-profile determination
→ sanction/social-impact handoff
→ commit proper owners
```

### Coalition pipeline

```text
shared interest, threat, communication, or coordinated event
→ candidate participants
→ perceived and actual common interests
→ procedure or emergent-pattern profile
→ formation/defection/cohesion/schism candidates
→ agency, goal, membership, relation handoffs
→ authorized commit
```

All discovery, evaluation, aggregation, and arbitration stages are non-mutating unless an owner explicitly prepares an AFQR-01 fragment. Diffusion, expiry, decay, review, and delayed recognition use AFQR-04 logical-time profiles.

## Part XVIII — Operation grammar

| ID | Operation | Owner | Rule |
|---|---|---|---|
| OP-001 | first meeting | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-002 | repeated contact | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-003 | introduction by a trusted intermediary | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-004 | assistance | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-005 | rescue | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-006 | gift | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-007 | repayment | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-008 | unrequested favor | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-009 | public praise | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-010 | private praise | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-011 | insult | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-012 | public humiliation | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-013 | threat | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-014 | accusation | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-015 | apology | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-016 | forgiveness | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-017 | refusal to forgive | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-018 | reconciliation | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-019 | betrayal | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-020 | suspected betrayal | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-021 | accidental harm | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-022 | deliberate harm | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-023 | justified harm under a norm | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-024 | promise | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-025 | promise kept | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-026 | promise broken | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-027 | secret kept | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-028 | secret disclosed | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-029 | competence demonstrated | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-030 | incompetence demonstrated | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-031 | truthful testimony | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-032 | discovered lie | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-033 | misunderstanding corrected | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-034 | rumor spreads | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-035 | rumor is retracted | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-036 | audience ignores retraction | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-037 | reputation improves locally | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-038 | reputation worsens in another audience | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-039 | title granted | `status_rank_owner` | Resolve jurisdiction, claim, issuer, recognition, and office/rank boundaries; status does not imply authority or prestige. |
| OP-040 | title disputed | `status_rank_owner` | Resolve jurisdiction, claim, issuer, recognition, and office/rank boundaries; status does not imply authority or prestige. |
| OP-041 | informal prestige increases | `status_rank_owner` | Resolve jurisdiction, claim, issuer, recognition, and office/rank boundaries; status does not imply authority or prestige. |
| OP-042 | rank promotion | `status_rank_owner` | Resolve jurisdiction, claim, issuer, recognition, and office/rank boundaries; status does not imply authority or prestige. |
| OP-043 | demotion | `status_rank_owner` | Resolve jurisdiction, claim, issuer, recognition, and office/rank boundaries; status does not imply authority or prestige. |
| OP-044 | office succession | `status_rank_owner` | Resolve jurisdiction, claim, issuer, recognition, and office/rank boundaries; status does not imply authority or prestige. |
| OP-045 | membership application | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-046 | admission | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-047 | honorary membership | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-048 | secret membership | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-049 | membership suspension | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-050 | expulsion | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-051 | voluntary defection | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-052 | coerced affiliation | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-053 | dual membership | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-054 | conflicting allegiance | `affiliation_membership_owner` | Route formal rights/duties through AFQR-09 and preserve self-claim, recognition, secrecy, and lifecycle separately. |
| OP-055 | coalition formation | `coalition_group_dynamics_owner` | Produce coalition, membership, cohesion, or schism candidates without assuming common trust, culture, or one group mind. |
| OP-056 | coalition member defects | `coalition_group_dynamics_owner` | Produce coalition, membership, cohesion, or schism candidates without assuming common trust, culture, or one group mind. |
| OP-057 | clique forms | `coalition_group_dynamics_owner` | Produce coalition, membership, cohesion, or schism candidates without assuming common trust, culture, or one group mind. |
| OP-058 | faction schism | `coalition_group_dynamics_owner` | Produce coalition, membership, cohesion, or schism candidates without assuming common trust, culture, or one group mind. |
| OP-059 | alliance without trust | `coalition_group_dynamics_owner` | Produce coalition, membership, cohesion, or schism candidates without assuming common trust, culture, or one group mind. |
| OP-060 | friendship without formal alliance | `coalition_group_dynamics_owner` | Produce coalition, membership, cohesion, or schism candidates without assuming common trust, culture, or one group mind. |
| OP-061 | affection without trust | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-062 | trust without affection | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-063 | rivalry with respect | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-064 | enmity with cooperation | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-065 | mentorship | `kinship_household_owner` | Create typed kinship/household/relation candidates; no automatic affection, authority, inheritance, or obligation. |
| OP-066 | patronage | `kinship_household_owner` | Create typed kinship/household/relation candidates; no automatic affection, authority, inheritance, or obligation. |
| OP-067 | dependency | `kinship_household_owner` | Create typed kinship/household/relation candidates; no automatic affection, authority, inheritance, or obligation. |
| OP-068 | household formation | `kinship_household_owner` | Create typed kinship/household/relation candidates; no automatic affection, authority, inheritance, or obligation. |
| OP-069 | adoption | `kinship_household_owner` | Create typed kinship/household/relation candidates; no automatic affection, authority, inheritance, or obligation. |
| OP-070 | ritual kinship | `kinship_household_owner` | Create typed kinship/household/relation candidates; no automatic affection, authority, inheritance, or obligation. |
| OP-071 | chosen family | `kinship_household_owner` | Create typed kinship/household/relation candidates; no automatic affection, authority, inheritance, or obligation. |
| OP-072 | cultural exposure | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-073 | cultural competence develops | `trust_owner` | Evaluate named trust domains and relation dimensions from evidence; forgiveness, repair, reliance, and trust remain separate. |
| OP-074 | cultural identity claim | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-075 | cultural adoption | `kinship_household_owner` | Create typed kinship/household/relation candidates; no automatic affection, authority, inheritance, or obligation. |
| OP-076 | cultural rejection | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |
| OP-077 | norm learned | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-078 | norm misunderstood | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-079 | norm endorsed | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-080 | norm rejected | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-081 | norm followed strategically | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-082 | norm violated unknowingly | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-083 | norm violation alleged falsely | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-084 | sanction imposed | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-085 | ostracism | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-086 | rehabilitation | `culture_norm_owner` | Separate exposure, competence, identity, norm awareness, endorsement, compliance, enforcement, and sanction handoffs. |
| OP-087 | public status differs from private reputation | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-088 | clone faces predecessor reputation | `reputation_audience_owner` | Create audience-specific claim/revision/diffusion candidates with provenance; no global reputation update. |
| OP-089 | office inherits formal ties but not friendship | `status_rank_owner` | Resolve jurisdiction, claim, issuer, recognition, and office/rank boundaries; status does not imply authority or prestige. |
| OP-090 | no lawful social determination exists | `social_event_impact_owner` | Record the social event and produce dimension-specific impact candidates; repeated contact or narrative meaning is not automatic relation change. |

## Part XIX — Central stress cases

### Persistent Rival

```yaml
subjects:
- player_character
- rival_persona
- rival_office_or_faction_role
- faction
- public_audiences
relation_dimensions:
- rivalry
- respect
- fear
- cooperation
- attachment
- enmity
- familiarity
trust_domains:
- combat_competence_high
- truthfulness_low_or_uncertain
- cooperation_against_shared_threat_conditional
reputation:
- rival_spreads_partly_false_player_reputation
- rival_gains_faction_status
- audiences_diverge
norms:
- faction_norm_against_forgiveness
- private_reconciliation_candidate
decision: Keep every dimension directional and audience-specific. Cooperation does not create friendship; public
  enemy status does not erase private reconciliation; hidden motives remain AFQR-12 private state.
handoffs:
- AFQR-10 false attribution and rumor
- AFQR-12 fear/resentment/attachment/goals
- AFQR-11 action origin
- AFQR-09 faction role and office
- AFQR-01 commit
```

### Uplifted Dependent

```yaml
subjects:
- uplifted_subject
- former_guardian
- new_community
- chosen_family
- legal_or_social_status_audiences
relations:
- care
- teaching
- dependency
- possible_guardianship
- claimed_parentage
- chosen_family
- community_affiliation
conflicts:
- creator/guardian/owner/parent/patron/exploiter/liberator audience narratives
- private rejection of creation identity
- resource dependency versus autonomous affiliation
decision: Creation and nurture establish no universal parenthood or ownership. Kinship, care, guardianship, trust,
  dependence, status, cultural identity, and reputation are separately determined.
handoffs:
- AFQR-11 autonomy/consent/personhood
- AFQR-12 values/loyalty/resentment
- AFQR-09 guardianship/dependency
- AFQR-10 audience narratives
```

### Familiar Network

```yaml
subjects:
- original_familiar
- ritual_derivative
- signer
- contract_administrator
- religious_community
- public_property_audience
relations:
- origin/derivative lineage
- friendship with signer
- fear of original
- distrust of administrator
- religious membership
- independent reputation
hidden:
- religious affiliation
- private goals
- autonomy transition basis
decision: Derivative reputation and relationships use its distinct identity reference. Public property classification
  remains source-local law/reputation, not core personhood or social truth. Autonomy does not erase prior ties or
  impose inherited obligations.
handoffs:
- AFQR-08 derivative identity
- AFQR-09 contract obligations
- AFQR-11 agency/status safeguards
- AFQR-12 private goals
- AFQR-10 hidden affiliation
```

### Coalition Asymmetric Information

```yaml
subjects:
- multiple_factions
- leaders
- coalition
- enemy
- public_propaganda_audience
state:
- incompatible cultures
- domain-specific distrust
- false reputation
- secret enemy alliance
- partly overlapping goals
- consensus norm
- emergency authority
- defection after misunderstanding
- status-motivated retention
decision: Coalition membership, trust, cultural identity, public unity claims, norm recognition, authority, cohesion,
  and institutional continuity remain separate. Defection and schism append transitions and do not retroactively
  erase coalition acts.
handoffs:
- AFQR-10 misinformation/rumor
- AFQR-11 collective procedure/authority
- AFQR-12 goals/behavior
- AFQR-09 membership obligations
- AFQR-04 timing
```


## Part XX — Candidate comparison

| Candidate | Architecture | Score / 240 | Disposition |
|---|---|---:|---|
| A | Single relationship score | 78 | Rejected as universal; useful components may be retained |
| B | Fixed relationship tracks | 108 | Rejected as universal; useful components may be retained |
| C | Typed social graph | 173 | Rejected as universal; useful components may be retained |
| D | Reputation ledger | 149 | Rejected as universal; useful components may be retained |
| E | Institutional-role model | 160 | Rejected as universal; useful components may be retained |
| F | Agent-based social simulation | 136 | Rejected as universal; useful components may be retained |
| G | Narrative tags and fronts | 132 | Rejected as universal; useful components may be retained |
| H | Registered Multiplex Social-State Architecture with Domain-Scoped Trust, Audience-Relative Reputation, Modular Culture–Norm Profiles, and Bitemporal Network Continuity | 229 | Selected |

Candidate H is selected because it is the only option that jointly preserves multiplex relations, domain trust, audience reputation, formal/informal status, governed affiliation, modular culture/norms, network derivation, hidden projections, continuity, conversion safety, and corpus-scale simulation tiers. Candidate C’s typed graph is retained as one substrate; Candidate D’s reputation ledger and Candidate E’s institutional model become bounded subsystems; Candidate F is permitted only as a registered aggregate/detailed simulation profile.

## Part XXI — Adversarial evaluation

All 200 cases receive distinct records and final dispositions in the sidecar. The table below is complete but deliberately concise; full bases, owners, receipts, projections, hashes, and handoffs are in YAML.

| ID | Scenario | Owner | Final disposition |
|---|---|---|---|
| SOC-001 | Two subjects have met once. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Two subjects have met once. |
| SOC-002 | One recognizes the other; recognition is not mutual. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: One recognizes the other; recognition is not mutual. |
| SOC-003 | One claims friendship; the other does not. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: One claims friendship; the other does not. |
| SOC-004 | Friendship is public but privately rejected. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Friendship is public but privately rejected. |
| SOC-005 | Affection exists without familiarity. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Affection exists without familiarity. |
| SOC-006 | Familiarity exists without affection. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Familiarity exists without affection. |
| SOC-007 | Rivalry and respect coexist. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Rivalry and respect coexist. |
| SOC-008 | Enmity and cooperation coexist. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Enmity and cooperation coexist. |
| SOC-009 | Relationship differs by persona. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Relationship differs by persona. |
| SOC-010 | Relationship differs by office and person. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Relationship differs by office and person. |
| SOC-011 | One party is unaware of the relation. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: One party is unaware of the relation. |
| SOC-012 | Observer incorrectly infers a romance. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Observer incorrectly infers a romance. |
| SOC-013 | Public labels two actors allies. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Public labels two actors allies. |
| SOC-014 | Formal alliance exists without personal relation. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Formal alliance exists without personal relation. |
| SOC-015 | Personal friendship survives institutional war. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Personal friendship survives institutional war. |
| SOC-016 | Hidden relationship is discovered. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Hidden relationship is discovered. |
| SOC-017 | Relationship participant identity is disputed. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Relationship participant identity is disputed. |
| SOC-018 | Relation is source-local and cannot normalize. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Relation is source-local and cannot normalize. |
| SOC-019 | Relation dimensions conflict. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Scenario-specific application: Relation dimensions conflict. |
| SOC-020 | No lawful relationship profile applies. | `social_relation_owner` | Register directional participant recognition and applicable relation dimensions; do not infer reciprocity, romance, alliance, or friendship. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: No lawful relationship profile applies. |
| SOC-021 | Subject trusts another’s honesty. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Subject trusts another’s honesty. |
| SOC-022 | Subject distrusts competence but trusts intent. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Subject distrusts competence but trusts intent. |
| SOC-023 | Subject relies on someone they dislike. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Subject relies on someone they dislike. |
| SOC-024 | Subject likes someone they do not trust. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Subject likes someone they do not trust. |
| SOC-025 | Trust is conditional on supervision. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Trust is conditional on supervision. |
| SOC-026 | Trust is limited to one domain. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Trust is limited to one domain. |
| SOC-027 | Trust is based on false evidence. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Trust is based on false evidence. |
| SOC-028 | Trust persists after evidence is disproven. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Trust persists after evidence is disproven. |
| SOC-029 | One betrayal damages one trust domain. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: One betrayal damages one trust domain. |
| SOC-030 | Betrayal is disputed. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Betrayal is disputed. |
| SOC-031 | Accidental failure is perceived as betrayal. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Accidental failure is perceived as betrayal. |
| SOC-032 | Forgiveness occurs without restored trust. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Forgiveness occurs without restored trust. |
| SOC-033 | Trust is restored without affection. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Trust is restored without affection. |
| SOC-034 | Institutional trust differs from member trust. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Institutional trust differs from member trust. |
| SOC-035 | AI is trusted technically but not socially. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: AI is trusted technically but not socially. |
| SOC-036 | Trust profile is source-local. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Trust profile is source-local. |
| SOC-037 | Several trust profiles disagree. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Scenario-specific application: Several trust profiles disagree. |
| SOC-038 | Trust evidence is hidden. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Trust evidence is hidden. |
| SOC-039 | Model narrates trust not present in state. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Model narrates trust not present in state. |
| SOC-040 | Trust remains unresolved. | `trust_owner` | Evaluate only named trust domains and evidence; retain reliance, affection, forgiveness, violation, distrust, and repair as separate records. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: Trust remains unresolved. |
| SOC-041 | Subject has good local reputation. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Subject has good local reputation. |
| SOC-042 | Same subject has bad reputation elsewhere. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Same subject has bad reputation elsewhere. |
| SOC-043 | Reputation is based on true conduct. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Reputation is based on true conduct. |
| SOC-044 | Reputation is based on rumor. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Reputation is based on rumor. |
| SOC-045 | Official record conflicts with public belief. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Official record conflicts with public belief. |
| SOC-046 | Reputation differs by trait. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Reputation differs by trait. |
| SOC-047 | Competence reputation is high; honesty reputation is low. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Competence reputation is high; honesty reputation is low. |
| SOC-048 | Reputation exists among people who never met the subject. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Reputation exists among people who never met the subject. |
| SOC-049 | Reputation propagates through a network. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Reputation propagates through a network. |
| SOC-050 | Reputation stops at a language boundary. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Reputation stops at a language boundary. |
| SOC-051 | Translation changes the reputation claim. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Translation changes the reputation claim. |
| SOC-052 | Retraction reaches only part of the audience. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Retraction reaches only part of the audience. |
| SOC-053 | Coordinated misinformation creates false reputation. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Coordinated misinformation creates false reputation. |
| SOC-054 | Brigading manipulates a rating system. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Brigading manipulates a rating system. |
| SOC-055 | Reputation aggregation profile is absent. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: Reputation aggregation profile is absent. |
| SOC-056 | Audience boundaries are disputed. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Audience boundaries are disputed. |
| SOC-057 | Clone inherits public reputation incorrectly. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Clone inherits public reputation incorrectly. |
| SOC-058 | Institution inherits predecessor notoriety. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Scenario-specific application: Institution inherits predecessor notoriety. |
| SOC-059 | Reputation is hidden from its subject. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Reputation is hidden from its subject. |
| SOC-060 | Public standing remains lawfully unresolved. | `reputation_audience_owner` | Update no intrinsic subject score; create audience/proposition-specific claim or revision candidates with provenance, translation, diffusion, and manipulation checks. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: Public standing remains lawfully unresolved. |
| SOC-061 | Formal title is granted. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Formal title is granted. |
| SOC-062 | Title is not recognized locally. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Title is not recognized locally. |
| SOC-063 | Informal prestige exceeds formal rank. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Informal prestige exceeds formal rank. |
| SOC-064 | Rank exceeds practical authority. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Rank exceeds practical authority. |
| SOC-065 | Officeholder lacks public legitimacy. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Officeholder lacks public legitimacy. |
| SOC-066 | Deference occurs due to fear rather than status recognition. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Deference occurs due to fear rather than status recognition. |
| SOC-067 | Subject falsely claims rank. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Subject falsely claims rank. |
| SOC-068 | Rank credentials are forged. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Rank credentials are forged. |
| SOC-069 | Status applies only within one institution. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Status applies only within one institution. |
| SOC-070 | Ritual status applies across institutions. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Ritual status applies across institutions. |
| SOC-071 | Two status systems conflict. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Two status systems conflict. |
| SOC-072 | Caste status changes after migration. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Caste status changes after migration. |
| SOC-073 | Prestige rises after public success. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Prestige rises after public success. |
| SOC-074 | Prestige falls despite factual innocence. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Prestige falls despite factual innocence. |
| SOC-075 | Office changes occupant. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Office changes occupant. |
| SOC-076 | Personal prestige does not transfer. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Personal prestige does not transfer. |
| SOC-077 | Formal office relations do transfer. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Formal office relations do transfer. |
| SOC-078 | Status profile is source-local. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Status profile is source-local. |
| SOC-079 | Model equates status with authority. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Model equates status with authority. |
| SOC-080 | Status remains disputed. | `status_rank_owner` | Resolve status definition, jurisdiction, claim, recognition, office/rank, prestige, deference, and authority independently. Scenario-specific application: Status remains disputed. |
| SOC-081 | Formal membership is granted. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Formal membership is granted. |
| SOC-082 | Member never adopts group identity. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Member never adopts group identity. |
| SOC-083 | Nonmember strongly identifies with group. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Nonmember strongly identifies with group. |
| SOC-084 | Secret membership exists. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Secret membership exists. |
| SOC-085 | Membership is coerced. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Membership is coerced. |
| SOC-086 | Membership is honorary. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Membership is honorary. |
| SOC-087 | Membership is suspended. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Membership is suspended. |
| SOC-088 | Member defects. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Member defects. |
| SOC-089 | Expulsion is disputed. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Expulsion is disputed. |
| SOC-090 | Dual memberships conflict. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Dual memberships conflict. |
| SOC-091 | Membership grants access but no authority. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Membership grants access but no authority. |
| SOC-092 | Membership grants duty but no loyalty. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Membership grants duty but no loyalty. |
| SOC-093 | Apparent member is an infiltrator. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Apparent member is an infiltrator. |
| SOC-094 | Institution falsely claims a member. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Institution falsely claims a member. |
| SOC-095 | Member acts against the group. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Member acts against the group. |
| SOC-096 | Public attributes member action to group. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Public attributes member action to group. |
| SOC-097 | Group disavows action. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Group disavows action. |
| SOC-098 | Group later ratifies action. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Group later ratifies action. |
| SOC-099 | Membership lineage after fusion is unclear. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Scenario-specific application: Membership lineage after fusion is unclear. |
| SOC-100 | No lawful affiliation determination exists. | `affiliation_membership_owner` | Resolve membership lifecycle, self-identification, recognition, allegiance, rights/duties, secrecy, and institutional attribution separately. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: No lawful affiliation determination exists. |
| SOC-101 | Subject is raised in one culture. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Subject is raised in one culture. |
| SOC-102 | Subject adopts another culture. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Subject adopts another culture. |
| SOC-103 | Subject identifies with several cultures. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Subject identifies with several cultures. |
| SOC-104 | Others assign a culture the subject rejects. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Others assign a culture the subject rejects. |
| SOC-105 | Cultural competence exists without identification. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Cultural competence exists without identification. |
| SOC-106 | Identification exists without competence. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Identification exists without competence. |
| SOC-107 | Cultural practice is strategic. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Cultural practice is strategic. |
| SOC-108 | Cultural practice is private. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Cultural practice is private. |
| SOC-109 | Diaspora culture diverges. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Diaspora culture diverges. |
| SOC-110 | Subculture rejects parent-culture norm. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Subculture rejects parent-culture norm. |
| SOC-111 | Institution has culture without unified identity. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Institution has culture without unified identity. |
| SOC-112 | Artificial agents develop source-local culture. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Artificial agents develop source-local culture. |
| SOC-113 | Familiar adopts local religious practice. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Familiar adopts local religious practice. |
| SOC-114 | Clone rejects predecessor culture. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Clone rejects predecessor culture. |
| SOC-115 | Fusion combines incompatible cultural identities. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Fusion combines incompatible cultural identities. |
| SOC-116 | Fission successors claim same tradition. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Fission successors claim same tradition. |
| SOC-117 | Culture definition is overbroad. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Culture definition is overbroad. |
| SOC-118 | Donor culture is a personality stereotype. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Scenario-specific application: Donor culture is a personality stereotype. |
| SOC-119 | Model infers culture from appearance. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Model infers culture from appearance. |
| SOC-120 | Cultural identity remains unresolved. | `culture_profile_owner` | Represent modular culture affiliation, exposure, competence, identity claims, practices, and source-local profiles; prohibit stereotype execution. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: Cultural identity remains unresolved. |
| SOC-121 | Norm exists and subject knows it. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Norm exists and subject knows it. |
| SOC-122 | Norm exists but subject is unaware. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Norm exists but subject is unaware. |
| SOC-123 | Subject knows and rejects the norm. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Subject knows and rejects the norm. |
| SOC-124 | Subject endorses but violates the norm. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Subject endorses but violates the norm. |
| SOC-125 | Subject complies strategically. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Subject complies strategically. |
| SOC-126 | Norm is disputed. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Norm is disputed. |
| SOC-127 | Two norms conflict. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Two norms conflict. |
| SOC-128 | Norm differs by role. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Norm differs by role. |
| SOC-129 | Norm differs by subculture. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Norm differs by subculture. |
| SOC-130 | Norm is obsolete but still enforced. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Norm is obsolete but still enforced. |
| SOC-131 | Norm emerges from repeated behavior. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Norm emerges from repeated behavior. |
| SOC-132 | Repeated behavior occurs without norm recognition. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Repeated behavior occurs without norm recognition. |
| SOC-133 | False violation accusation spreads. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: False violation accusation spreads. |
| SOC-134 | Violation is proven. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Violation is proven. |
| SOC-135 | Sanction is formal. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Sanction is formal. |
| SOC-136 | Sanction is informal. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Sanction is informal. |
| SOC-137 | Ostracism occurs without formal decision. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Ostracism occurs without formal decision. |
| SOC-138 | Norm enforcement is selective. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Norm enforcement is selective. |
| SOC-139 | Source-local taboo has metaphysical effects. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Scenario-specific application: Source-local taboo has metaphysical effects. |
| SOC-140 | Norm applicability is unresolved. | `norm_owner` | Separate norm existence, audience, awareness, endorsement, applicability, compliance evidence, violation claim, determination, and sanction handoff. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: Norm applicability is unresolved. |
| SOC-141 | Biological parentage exists. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Biological parentage exists. |
| SOC-142 | Legal parentage differs. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Legal parentage differs. |
| SOC-143 | Adoptive kinship is recognized. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Adoptive kinship is recognized. |
| SOC-144 | Chosen family is privately recognized. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Chosen family is privately recognized. |
| SOC-145 | Ritual kinship creates a governed relation. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Ritual kinship creates a governed relation. |
| SOC-146 | Household membership exists without kinship. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Household membership exists without kinship. |
| SOC-147 | Kinship exists without household membership. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Kinship exists without household membership. |
| SOC-148 | Genetic relation is unknown. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Genetic relation is unknown. |
| SOC-149 | Clone claims sibling relation. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Clone claims sibling relation. |
| SOC-150 | Original rejects clone kinship claim. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Original rejects clone kinship claim. |
| SOC-151 | Mentorship lineage grants prestige. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Mentorship lineage grants prestige. |
| SOC-152 | Spiritual lineage conflicts with biological lineage. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Spiritual lineage conflicts with biological lineage. |
| SOC-153 | Family relation has no affection. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Family relation has no affection. |
| SOC-154 | Care exists without authority. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Care exists without authority. |
| SOC-155 | Guardian authority exists without trust. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Guardian authority exists without trust. |
| SOC-156 | Uplifted dependent rejects creator-as-parent claim. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Uplifted dependent rejects creator-as-parent claim. |
| SOC-157 | Household splits. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Household splits. |
| SOC-158 | Inheritance rule is source-local. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Inheritance rule is source-local. |
| SOC-159 | Model equates creator with parent. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Model equates creator with parent. |
| SOC-160 | Kinship status remains disputed. | `kinship_household_owner` | Use qualified biological/legal/adoptive/social/ritual/household relations; route authority, inheritance, care, and prestige to their owners. Scenario-specific application: Kinship status remains disputed. |
| SOC-161 | Coalition forms around shared threat. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Coalition forms around shared threat. |
| SOC-162 | Coalition lacks mutual trust. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Coalition lacks mutual trust. |
| SOC-163 | Coalition members have incompatible goals. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Coalition members have incompatible goals. |
| SOC-164 | One member secretly serves the enemy. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: One member secretly serves the enemy. |
| SOC-165 | Coalition develops shared routine. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Coalition develops shared routine. |
| SOC-166 | Coalition becomes institution. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Coalition becomes institution. |
| SOC-167 | Clique forms within institution. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Clique forms within institution. |
| SOC-168 | Group polarization increases. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Group polarization increases. |
| SOC-169 | Minority dissent changes policy. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Minority dissent changes policy. |
| SOC-170 | Dissent is suppressed. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Dissent is suppressed. |
| SOC-171 | Schism occurs. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Schism occurs. |
| SOC-172 | Schism boundaries are disputed. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Schism boundaries are disputed. |
| SOC-173 | Member belongs to both successor factions. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Member belongs to both successor factions. |
| SOC-174 | Network centrality changes after one actor leaves. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Network centrality changes after one actor leaves. |
| SOC-175 | High centrality is mistaken for authority. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: High centrality is mistaken for authority. |
| SOC-176 | Social-network data is incomplete. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Social-network data is incomplete. |
| SOC-177 | Hidden network exists. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Hidden network exists. |
| SOC-178 | Aggregate simulation approximates group behavior. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Aggregate simulation approximates group behavior. |
| SOC-179 | Promotion to detailed simulation reveals no historical motive. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Scenario-specific application: Promotion to detailed simulation reveals no historical motive. |
| SOC-180 | Group-dynamics policy is unavailable. | `coalition_group_dynamics_owner` | Record coalition/group transitions or derived network patterns without inferring shared trust, unified intention, authority, or complete individual history. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: Group-dynamics policy is unavailable. |
| SOC-181 | Copy begins with no recognized friendships. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: Copy begins with no recognized friendships. |
| SOC-182 | One friend recognizes the copy as continuation. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: One friend recognizes the copy as continuation. |
| SOC-183 | Public assigns predecessor reputation to copy. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: Public assigns predecessor reputation to copy. |
| SOC-184 | Fusion inherits conflicting affiliations. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: Fusion inherits conflicting affiliations. |
| SOC-185 | Fission divides one office relationship. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: Fission divides one office relationship. |
| SOC-186 | Resurrection restores formal membership. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: Resurrection restores formal membership. |
| SOC-187 | Personal trust is not restored automatically. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: Personal trust is not restored automatically. |
| SOC-188 | Reincarnated subject claims former kinship. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: Reincarnated subject claims former kinship. |
| SOC-189 | Familiar keeps relationships after autonomy. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: Familiar keeps relationships after autonomy. |
| SOC-190 | Institution keeps alliances after leadership replacement. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Scenario-specific application: Institution keeps alliances after leadership replacement. |
| SOC-191 | Hidden affiliation affects action legality. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Hidden affiliation affects action legality. |
| SOC-192 | Visible blocker leaks secret membership. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Visible blocker leaks secret membership. |
| SOC-193 | Model packet exposes hidden rivalry. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Model packet exposes hidden rivalry. |
| SOC-194 | Cross-packet retrieval exposes secret alliance. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Cross-packet retrieval exposes secret alliance. |
| SOC-195 | Stable hash links covert relationships. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Stable hash links covert relationships. |
| SOC-196 | Model invents friendship after dialogue. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Model invents friendship after dialogue. |
| SOC-197 | Model stereotypes culture. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Use audience-scoped opaque tokens, private commitments, projection-specific digests, constant-shape responses, and cross-packet isolation. Scenario-specific application: Model stereotypes culture. |
| SOC-198 | Social state is corrupted. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: Social state is corrupted. |
| SOC-199 | No typed construct represents the relation. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: No typed construct represents the relation. |
| SOC-200 | Social outcome remains lawfully unresolved. | `social_continuity_security_owner` | Apply family-specific social continuity and audience-safe projection; block leakage, model invention, corrupt state, or absent profiles with unresolved/quarantine outcomes. Final state remains unresolved, unverifiable, quarantined, or escalated; no fallback score or model judgment is permitted. Scenario-specific application: Social outcome remains lawfully unresolved. |

## Part XXII — Current runtime disposition

### Exists

Backend-authority doctrine, conversion/schema social descriptors, reference-only state-owner families, narrow hidden-information projection boundaries, and RT-002 fixture actor/NPC/faction-social references.

### Fixture-only

RT-002A–F actor, NPC target, scene, object/lever, hazard, condition, hidden-fact, legality, preview, event/delta, and audit records.

### Conversion-only

Relationship, bond, loyalty, reputation, rank, status, culture, faction, role, affiliation, norm, custom, kinship, household, reaction, honor, influence, ally/enemy, and similar donor constructs unless formally promoted into AFQR-13 definitions and runtime profiles.

### Narrative-only

NPC relationship prose, faction attitudes, mission allies/enemies, companion bonds, cultural characterization, dialogue examples, and adapter examples.

### Missing

All authoritative AFQR-13 owners, registries, evaluators, transition fragments, network snapshots, reputation diffusion, continuity, simulation-tier, and model-grounding implementations.

### Permitted now

Doctrine registration, schema implementation, conversion-pressure validation, non-mutating evaluators, fixtures, benchmarks, security tests, and bounded social projection design.

### Prohibited

Automatic friendship, trust, loyalty, reputation, status, culture, membership, norm violation, coalition, or relationship mutation from prose, graph proximity, repeated interaction, source conversion, or model output.

## Part XXIII — Required artifacts

1. **Immediate:** ADR, decision registry, terminology, contracts, operations, 200 cases, 50-case dry run, four stress graphs, research synthesis, security threat model, validation manifest.
2. **Before authoritative relationships:** social-subject/participant registries, relation/dimension definitions, transition evaluators, owner fragments, continuity archive.
3. **Before trust mutation:** trust domains, evidence/revision profiles, violation/repair profiles, reliance handoffs.
4. **Before reputation propagation:** audience registry, provenance graph, aggregation/revision policies, translation and diffusion scheduler, Sybil/brigading fixtures.
5. **Before status and membership:** status jurisdictions, rank structures, affiliation definitions, eligibility, authority, AFQR-06/09 transitions.
6. **Before culture and norms:** culture modules, norm audience/jurisdiction, awareness/applicability/compliance evaluators, sanction handoffs.
7. **Before coalition/group simulation:** temporal network snapshot service, coalition/schism profiles, cohesion metrics, tier promotion/demotion certificates.
8. **Before model-facing social dialogue:** grounding manifests, claim registry, output validator, packet isolation, projection noninterference.
9. **Before mass conversion:** social-pressure IR validator, donor-family certification fixtures, source-local namespace governance.
10. **Deferred:** romance, prejudice/discrimination, political legitimacy, economics, crime, propaganda, diplomacy, population sociology, tactical social AI.

## Part XXIV — Non-mutating prototype

**AFQR-13 Social Relations, Trust, Reputation, Status, Culture, and Group Dynamics Dry Run** evaluates 50 cases. It freezes all AFQR bases, emits typed candidates/determinations, private receipts, audience projections, deterministic commitments, and handoffs, and performs no mutation, propagation, sanction, coalition formation, model call, or event commitment.

## Part XXV — Acceptance tests

- [ ] **ACC-001 / social_relationships:** relations typed
- [ ] **ACC-002 / social_relationships:** directionality explicit
- [ ] **ACC-003 / social_relationships:** symmetry not assumed
- [ ] **ACC-004 / social_relationships:** multiplex dimensions supported
- [ ] **ACC-005 / social_relationships:** formal informal separate
- [ ] **ACC-006 / social_relationships:** truth recognition separate
- [ ] **ACC-007 / social_relationships:** one sided disputed supported
- [ ] **ACC-008 / social_relationships:** hidden private
- [ ] **ACC-009 / social_relationships:** no universal score
- [ ] **ACC-010 / social_relationships:** model cannot create
- [ ] **ACC-011 / trust:** domain specific
- [ ] **ACC-012 / trust:** reliance separate
- [ ] **ACC-013 / trust:** affection separate
- [ ] **ACC-014 / trust:** loyalty separate
- [ ] **ACC-015 / trust:** distrust not zero
- [ ] **ACC-016 / trust:** conditions evidence explicit
- [ ] **ACC-017 / trust:** betrayal profile scoped
- [ ] **ACC-018 / trust:** repair forgiveness separate
- [ ] **ACC-019 / trust:** unresolved supported
- [ ] **ACC-020 / trust:** model cannot establish
- [ ] **ACC-021 / reputation:** audience relative
- [ ] **ACC-022 / reputation:** not intrinsic
- [ ] **ACC-023 / reputation:** proposition typed
- [ ] **ACC-024 / reputation:** evidence provenance
- [ ] **ACC-025 / reputation:** audiences disagree
- [ ] **ACC-026 / reputation:** false supported
- [ ] **ACC-027 / reputation:** diffusion replayable
- [ ] **ACC-028 / reputation:** partial correction
- [ ] **ACC-029 / reputation:** no global default
- [ ] **ACC-030 / reputation:** standing not truth
- [ ] **ACC-031 / status:** formal informal
- [ ] **ACC-032 / status:** rank office prestige authority separate
- [ ] **ACC-033 / status:** jurisdiction explicit
- [ ] **ACC-034 / status:** claims disputed
- [ ] **ACC-035 / status:** recognition by audience
- [ ] **ACC-036 / status:** succession no personal prestige
- [ ] **ACC-037 / status:** source local contained
- [ ] **ACC-038 / status:** not moral worth
- [ ] **ACC-039 / membership:** membership allegiance separate
- [ ] **ACC-040 / membership:** membership loyalty separate
- [ ] **ACC-041 / membership:** formal informal
- [ ] **ACC-042 / membership:** secret supported
- [ ] **ACC-043 / membership:** overlap supported
- [ ] **ACC-044 / membership:** suspension expulsion defection separate
- [ ] **ACC-045 / membership:** rights duties AFQR09
- [ ] **ACC-046 / membership:** no cultural adoption
- [ ] **ACC-047 / membership:** model no inference
- [ ] **ACC-048 / culture_norms:** culture not ancestry personality
- [ ] **ACC-049 / culture_norms:** culture modular
- [ ] **ACC-050 / culture_norms:** multiple affiliations
- [ ] **ACC-051 / culture_norms:** competence identity separate
- [ ] **ACC-052 / culture_norms:** norm law value habit separate
- [ ] **ACC-053 / culture_norms:** awareness endorsement compliance enforcement
- [ ] **ACC-054 / culture_norms:** contestation
- [ ] **ACC-055 / culture_norms:** source local
- [ ] **ACC-056 / culture_norms:** stereotypes prohibited
- [ ] **ACC-057 / kinship_household:** kinship types separate
- [ ] **ACC-058 / kinship_household:** household separate
- [ ] **ACC-059 / kinship_household:** no affection authority
- [ ] **ACC-060 / kinship_household:** chosen family
- [ ] **ACC-061 / kinship_household:** copy claims disputed
- [ ] **ACC-062 / kinship_household:** guardianship inheritance handoffs
- [ ] **ACC-063 / kinship_household:** model no creator parent
- [ ] **ACC-064 / group_dynamics:** coalition institution separate
- [ ] **ACC-065 / group_dynamics:** clique faction separate
- [ ] **ACC-066 / group_dynamics:** cohesion profile
- [ ] **ACC-067 / group_dynamics:** schism explicit
- [ ] **ACC-068 / group_dynamics:** emergent not intention
- [ ] **ACC-069 / group_dynamics:** metrics derived
- [ ] **ACC-070 / group_dynamics:** centrality not authority
- [ ] **ACC-071 / group_dynamics:** hidden networks private
- [ ] **ACC-072 / group_dynamics:** aggregate vs individual
- [ ] **ACC-073 / continuity:** social not identity
- [ ] **ACC-074 / continuity:** copies no auto inheritance
- [ ] **ACC-075 / continuity:** reputation audience specific
- [ ] **ACC-076 / continuity:** office personal separate
- [ ] **ACC-077 / continuity:** fusion fission nary
- [ ] **ACC-078 / continuity:** resurrection profile
- [ ] **ACC-079 / continuity:** institutional continuity explicit
- [ ] **ACC-080 / continuity:** no auto transfer
- [ ] **ACC-081 / player_model:** player no mutation
- [ ] **ACC-082 / player_model:** dialogue no friendship
- [ ] **ACC-083 / player_model:** packets minimized
- [ ] **ACC-084 / player_model:** claims grounded
- [ ] **ACC-085 / player_model:** hidden protected
- [ ] **ACC-086 / player_model:** cross packet tested
- [ ] **ACC-087 / player_model:** hash unlinkable
- [ ] **ACC-088 / player_model:** model no social assignment
- [ ] **ACC-089 / player_model:** uncertainty explicit
- [ ] **ACC-090 / replay:** checkpoint retained
- [ ] **ACC-091 / replay:** trust evidence policy
- [ ] **ACC-092 / replay:** audience basis
- [ ] **ACC-093 / replay:** status membership times
- [ ] **ACC-094 / replay:** norm awareness applicability
- [ ] **ACC-095 / replay:** diffusion timing
- [ ] **ACC-096 / replay:** coalition history
- [ ] **ACC-097 / replay:** current policy no rewrite
- [ ] **ACC-098 / replay:** missing evaluator unverifiable
- [ ] **ACC-099 / conversion:** pressure IR
- [ ] **ACC-100 / conversion:** no universal scores
- [ ] **ACC-101 / conversion:** culture not personality
- [ ] **ACC-102 / conversion:** kinship source local
- [ ] **ACC-103 / conversion:** no campaign trust
- [ ] **ACC-104 / conversion:** no status membership
- [ ] **ACC-105 / conversion:** no hidden model state
- [ ] **ACC-106 / conversion:** lawful outcome
- [ ] **ACC-107 / runtime_containment:** descriptors fixture conversion
- [ ] **ACC-108 / runtime_containment:** actor not social subject
- [ ] **ACC-109 / runtime_containment:** model context not state
- [ ] **ACC-110 / runtime_containment:** relationship mutation blocked
- [ ] **ACC-111 / runtime_containment:** reputation propagation blocked
- [ ] **ACC-112 / runtime_containment:** norm enforcement blocked
- [ ] **ACC-113 / runtime_containment:** coalition simulation blocked
- [ ] **ACC-114 / runtime_containment:** dialogue portrayal only
- [ ] **ACC-115 / hardening:** graph reachability does not create relation
- [ ] **ACC-116 / hardening:** community detection does not create membership
- [ ] **ACC-117 / hardening:** audience count is nonleaking
- [ ] **ACC-118 / hardening:** translation provenance retained
- [ ] **ACC-119 / hardening:** rumor retraction does not erase history
- [ ] **ACC-120 / hardening:** trust condition expiry checked
- [ ] **ACC-121 / hardening:** status recognition can be partial
- [ ] **ACC-122 / hardening:** officeholder identity pinned
- [ ] **ACC-123 / hardening:** source local taboo handoff bounded
- [ ] **ACC-124 / hardening:** coalition cohesion may remain qualitative
- [ ] **ACC-125 / hardening:** simulation tier promotion preserves committed history
- [ ] **ACC-126 / hardening:** simulation tier demotion preserves reconstruction basis
- [ ] **ACC-127 / hardening:** network snapshots bind valid intervals
- [ ] **ACC-128 / hardening:** hyperrelations support more than two participants
- [ ] **ACC-129 / hardening:** relation dimensions can use unlike representations
- [ ] **ACC-130 / hardening:** public acknowledgment does not create reciprocity
- [ ] **ACC-131 / hardening:** institutional record does not create awareness
- [ ] **ACC-132 / hardening:** norm enforcement does not prove endorsement
- [ ] **ACC-133 / hardening:** sanction requires action and responsibility handoffs
- [ ] **ACC-134 / hardening:** trust evidence cannot read hidden truth without authorization
- [ ] **ACC-135 / hardening:** reputation aggregation resists duplicate identity claims
- [ ] **ACC-136 / hardening:** private digest cannot correlate across audiences
- [ ] **ACC-137 / hardening:** model timing is constant shaped
- [ ] **ACC-138 / hardening:** public projections omit policy identifiers
- [ ] **ACC-139 / hardening:** missing historical social evaluator returns unverifiable
- [ ] **ACC-140 / hardening:** administrative repair appends provenance
- [ ] **ACC-141 / hardening:** corrupt social state quarantines dependent transitions
- [ ] **ACC-142 / hardening:** membership ratification does not rewrite earlier authority
- [ ] **ACC-143 / hardening:** forgiveness does not erase harm event
- [ ] **ACC-144 / hardening:** reconciliation does not imply restored intimacy
- [ ] **ACC-145 / hardening:** culture exposure does not create identity
- [ ] **ACC-146 / hardening:** cultural self claim may differ from external recognition
- [ ] **ACC-147 / hardening:** prestige does not grant command authority
- [ ] **ACC-148 / hardening:** fear deference does not prove prestige
- [ ] **ACC-149 / hardening:** kinship does not create consent
- [ ] **ACC-150 / hardening:** chosen family can be one sided or disputed
- [ ] **ACC-151 / hardening:** collective efficacy does not imply legal capacity
- [ ] **ACC-152 / hardening:** cohesion metric names dimensions and basis
- [ ] **ACC-153 / hardening:** social impact profiles never mutate all dimensions by default
- [ ] **ACC-154 / hardening:** mass conversion cannot register executable social policy automatically

## Part XXVI — Residual uncertainty ledger

- **Final relationship mechanics:** profile formulas, intimacy, romance, attachment, and decay remain downstream.
- **Prejudice and discrimination:** require protected-subject, culture, norm, institution, and harm architecture; no universal mechanism is adopted.
- **Law and political legitimacy:** source/jurisdiction-specific owners remain necessary.
- **Economic exchange:** AFQR-07 handles quantities; social meaning and obligation require explicit bridges.
- **Crime and sanctions:** action, authority, evidence, responsibility, law, and consequence profiles remain downstream.
- **Cultural content generation:** AFQR-13 defines structure, not a universal culture generator.
- **Population sociology:** simulation-tier algorithms, calibration, error bounds, and performance remain open.
- **Propaganda and diplomacy:** require AFQR-14 communication and later political/institutional profiles.
- **Distributed performance:** temporal multiplex graph indexing, audience-scale reputation, private token rotation, and replay storage need benchmarks.
- **Training-model behavior:** portrayal reliability remains separate from backend social authority.

## Part XXVII — Roadmap conclusion

1. **Is AFQR-13 resolved sufficiently for ratification?** Yes.
2. **Is another broad research pass required?** No; narrow profile-specific research remains mandatory.
3. **Mandatory amendments:** registry/instance separation; directional participant bindings; audience ownership; explicit valid/recorded/logical time; non-equivalent trust/reputation/status/culture profiles; social simulation tiers; private commitments; security and hard-case certification.
4. **Immediate artifacts:** the pack accompanying this document.
5. **Smallest prototype:** the 50-case non-mutating dry run.
6. **Runtime work blocked:** all authoritative social mutation, propagation, enforcement, coalition execution, detailed network simulation, and model-authored social inference.
7. **Authoritative social-state mutation unlocked?** No. Only schemas, registries, evaluators, fixtures, and non-mutating candidates are unlocked.
8. **Bounded social dialogue portrayal unlocked?** Only after AFQR-14 plus grounding, claim validation, and isolation controls. AFQR-13 supplies the visible social-state input boundary.
9. **RT-002G:** may continue narrowly after AFQR-01–13 artifact ratification and social side-channel amendments; existing references gain no generalized social semantics.
10. **AFQR-14:** Communication, Language, Dialogue Acts, Conversation State, Interpretation, Persuasion, and Social Interaction Protocols.
11. **Exact next action:** Ratify and register AFQR-13, execute the 50-case non-mutating dry run and an RT-002A–RT-002F social-state/side-channel audit, permit only narrowly amended RT-002G fixture work, and open AFQR-14 as a read-only foundational investigation.

## Part XXVIII — Machine-readable decision block

```yaml
question_id: AFQR-13
question_title: Social Relationships Trust Reputation Status Norms Culture Affiliation and Group Dynamics
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: ratification_candidate
selected_architecture: Registered Multiplex Social-State Architecture with Domain-Scoped Trust, Audience-Relative Reputation,
  Modular Culture–Norm Profiles, and Bitemporal Network Continuity
selected_architecture_abbreviation: RMSSA-DT-ARR-MCNP-BNC
confidence: high
central_law: No encounter, communication, repeated contact, governed relation, graph edge, public record, audience claim,
  social metric, donor descriptor, or model portrayal creates authoritative relationship, trust, reputation, status, affiliation,
  culture, norm, kinship, coalition, or social continuity by itself. Every social result is a typed, purpose- and audience-scoped,
  version-pinned determination over frozen identity, epistemic, agency, behavioral, governed-relation, and event bases; every
  mutation is owner-prepared and committed through AFQR-01; graph metrics and aggregates remain derived observations; historical
  social state and later corrections are append-only.
accepted_dependencies:
  AFQR_01:
    accepted: true
    status: architectural_dependency
    title: Atomic Typed Transition Journal
  AFQR_02:
    accepted: true
    status: architectural_dependency
    title: Command and Attempt Lifecycle
  AFQR_03:
    accepted: true
    status: architectural_dependency
    title: Typed Action Gateway
  AFQR_04:
    accepted: true
    status: architectural_dependency
    title: Logical-Time Causal Scheduler
  AFQR_05:
    accepted: true
    status: architectural_dependency
    title: Registered Interface-and-Bridge Hypergraph
  AFQR_06:
    accepted: true
    status: architectural_dependency
    title: Typed Claim Arbitration
  AFQR_07:
    accepted: true
    status: architectural_dependency
    title: Typed Quantity and Settlement
  AFQR_08:
    accepted: true
    status: architectural_dependency
    title: Typed Identity and Continuity
  AFQR_09:
    accepted: true
    status: architectural_dependency
    title: Governed Relations and Dependency Consequences
  AFQR_10:
    accepted: true
    status: architectural_dependency
    title: Truth–Epistemic Provenance
  AFQR_11:
    accepted: true
    status: architectural_dependency
    title: Agency, Consent, Control, Action Origin, Responsibility
  AFQR_12:
    accepted: true
    status: architectural_dependency
    title: Motivational–Behavioral State
definitions:
  social relation: A registered typed social connection or social-position relation among one or more participant bindings;
    it does not imply affection, obligation, recognition, or reciprocity.
  relationship: A social-relation instance whose dimensions, participants, recognition, visibility, and lifecycle are explicit.
  relation dimension: One independently governed aspect of a multiplex relation, such as familiarity, affection, rivalry,
    dependence, cooperation, or source-local meaning.
  relation participant: An identity-scoped reference bound to a relation in a named role and direction.
  dyadic relation: A relation whose authoritative participant set contains exactly two bindings.
  asymmetric relation: A relation or relation dimension whose state from A toward B need not equal the state from B toward
    A.
  reciprocal relation: A relation whose certified profile requires compatible participant acknowledgments or directional states;
    reciprocity is determined, not presumed.
  multiplex relation: A relation carrying several separately typed dimensions without collapsing them into one score.
  group relation: A relation binding one or more subjects to a group, audience, household, coalition, culture, or institution.
  role relation: A relation attached to a role or office facet rather than automatically to the occupant as a person.
  formal relation: A relation recognized by a registered institution, procedure, jurisdiction, or governed-relation authority.
  informal relation: A social relation not dependent on formal institutional recognition.
  acknowledged relation: A relation or relation claim a named participant or audience explicitly recognizes.
  hidden relation: A committed relation whose existence or dimensions are restricted to authorized audiences.
  acquaintance: A familiarity-class relation with limited recognition and no implied trust or affection.
  friendship: A source/profile-qualified relation type; it may require recognition or reciprocity under its profile but never
    follows automatically from contact.
  rivalry: A competitive relation dimension that may coexist with respect, cooperation, affection, or trust in other domains.
  enmity: A hostile relation dimension or profile, not a universal action command.
  intimacy: A profile-scoped closeness or disclosure relation; it is not consent, ownership, or guaranteed affection.
  attachment: A behavioral or affective relation reference routed to AFQR-12 where motivational or emotional state is involved.
  dependency: A social or governed relation involving reliance on another subject or structure; it is not trust or authority
    by default.
  patronage: A typed relation involving support, sponsorship, access, or resource flow with explicit governed-relation handoffs.
  mentorship: A typed developmental or instructional relation that does not automatically grant authority, kinship, or loyalty.
  alliance: A formal or informal cooperative relation or governed agreement scoped to stated purposes.
  coalition: A multi-party temporary or persistent grouping organized around partly shared goals or procedures without requiring
    friendship, trust, or cultural unity.
  estrangement: A transition or state of reduced contact, recognition, or relation dimensions; not universal termination.
  trust: A directional, domain-specific determination that a subject is willing to accept a defined vulnerability or reliance
    under stated evidence and conditions.
  reliance: A decision or practical dependence on another subject or system, which may occur without personal trust.
  confidence: A profile-qualified degree or qualitative assessment of support for a trust, reputation, status, or other social
    determination.
  credibility: An audience- or trust-domain assessment of the reliability of a source or claim.
  predictability: An expectation of behavioral regularity, separable from benevolence, integrity, approval, or trust.
  benevolence expectation: A domain-specific expectation that another subject is disposed to protect or advance the trustor’s
    interests.
  competence trust: Trust scoped to another’s ability in a defined task or domain.
  discretion trust: Trust scoped to handling confidential or sensitive information.
  loyalty trust: Trust scoped to expected support or non-defection under stated conditions; distinct from actual allegiance
    or affection.
  distrust: A supported expectation of unreliability, harmfulness, deception, or adverse conduct in a domain; not merely low
    trust.
  suspicion: An uncertain adverse trust or credibility assessment that does not establish wrongdoing.
  trust domain: The explicit purpose, vulnerability, action family, or reliance context to which a trust determination applies.
  trust condition: A condition under which a trust determination or reliance basis remains applicable.
  trust violation: A profile-scoped event or evidence pattern inconsistent with an existing trust expectation.
  betrayal: A trust-violation or relationship-impact claim requiring a named profile, expectation, evidence basis, and determination.
  trust repair: A candidate or determination concerning restoration or recalibration of a trust domain after a violation.
  forgiveness: A behavioral, relational, cultural, or normative transition that does not automatically restore trust or erase
    responsibility.
  reconciliation: A profile-scoped process or transition toward renewed interaction or relation repair; no universal sequence
    is implied.
  reputation: An audience-owned, proposition-scoped epistemic-social state concerning a subject; it is not intrinsic truth
    or personality.
guarantees:
- typed multiplex relations
- directional domain-scoped trust
- audience-owned reputation
- jurisdiction-scoped status
- governed membership handoff
- modular culture and norms
- typed kinship/household
- derived network metrics
- family-specific continuity
- hidden-safe model-independent projections
non_guarantees:
- universal relationship score
- global trust
- global reputation
- one culture taxonomy
- one family model
- automatic friendship from interaction
- automatic norm enforcement
- automatic coalition intention
- model-authored social change
social_subject_model:
  eligible:
  - individual_actor
  - persona
  - office
  - institution
  - collective
  - faction
  - household
  - culture
  - swarm
  - artificial_agent
  - public_audience
  - community
  - source_local_entity
  separations:
  - social_subject
  - relationship_participant
  - epistemic_subject
  - audience
  - institution
  - collective
  - office
  - behavioral_subject
  - model_consumer
social_audience_model:
  typed: true
  membership_may_be_hidden: true
  audience_state_owner_separate: true
  common_knowledge_not_assumed: true
social_state_ownership:
  federated: true
  coordinator_non_mutating: true
  owners:
  - social_relation_owner
  - trust_owner
  - reputation_audience_owner
  - status_rank_owner
  - affiliation_membership_owner
  - culture_profile_owner
  - norm_owner
  - kinship_household_owner
  - coalition_group_dynamics_owner
  - social_network_projection_owner
  - social_projection_security_owner
social_relation_model:
  multiplex: true
  directional: true
  hyperrelations: true
  universal_dimensions: false
  formal_and_informal_components_separate: true
relation_dimension_model:
  registered_definitions: true
  unlike_representations_allowed: true
  silent_aggregation_prohibited: true
relation_recognition_model:
  authoritative_registration_separate:
  - participant_belief
  - public_acknowledgment
  - observer_inference
  - legal_recognition
  - self_description
  - model_portrayal
relation_transition_model:
  transitions:
  - formation
  - strengthening
  - weakening
  - dimension_change
  - suspension
  - estrangement
  - betrayal
  - reconciliation
  - transformation
  - termination
  - ambiguity
  - recognition_change
  automatic_from_event: false
relation_continuity_model:
  family_specific: true
  office_personal_split: true
  copy_fusion_fission_nary: true
trust_domain_model:
  directional: true
  purpose_specific: true
  qualitative_allowed: true
  global_scalar_prohibited: true
trust_evidence_model:
  AFQR_10_grounded: true
  hidden_evidence_private: true
  false_evidence_supported: true
trust_determination_model:
  trust_distrust_suspicion_separate: true
  reliance_separate: true
  affection_and_loyalty_separate: true
trust_violation_model:
  profile_scoped: true
  betrayal_claim_separate_from_determination: true
trust_repair_model:
  repair_candidate_then_determination: true
  forgiveness_separate: true
  reconciliation_separate: true
reputation_model:
  owner: audience_or_audience_state_owner
  subject_intrinsic: false
  proposition_scoped: true
  false_reputation_supported: true
reputation_audience_model:
  local_and_overlapping: true
  disagreement_supported: true
  boundary_dispute_supported: true
reputation_diffusion_model:
  scheduled: true
  provenance_preserving: true
  translation_transform_explicit: true
  simple_complex_profiles: true
reputation_correction_model:
  append_only: true
  partial_reach: true
  non_erasing: true
status_model:
  formal_informal_perceived_enacted_separate: true
  jurisdiction_scoped: true
  authority_separate: true
rank_model:
  versioned_structure: true
  occupancy_separate: true
  partial_order_allowed: true
prestige_model:
  deference_evidence_separate: true
  dominance_separate: true
  transfer_not_automatic: true
deference_model:
  observed_behavior_not_status_truth: true
  fear_and_strategic_compliance_distinguishable: true
membership_model:
  governed_relation_handoff: true
  lifecycle:
  - candidate
  - admitted
  - active
  - suspended
  - expelled
  - defected
  - disputed
  - terminated
  rights_duties_explicit: true
affiliation_model:
  formal_informal_self_claim_external_recognition_separate: true
  overlap_supported: true
  coerced_supported: true
admission_and_expulsion_model:
  procedure_and_authority_versioned: true
  notification_separate: true
  dispute_AFQR06: true
secret_affiliation_model:
  private_receipts: true
  visible_blockers_generic: true
  hidden_relation_no_public_hash: true
culture_model:
  modular_components:
  - practices
  - norms
  - symbols
  - institutions
  - narratives
  - interpretive_frameworks
  personality_package_prohibited: true
cultural_affiliation_model:
  exposure_competence_practice_identity_claim_recognition_separate: true
  multiple_affiliations: true
cultural_competence_model:
  domain_specific: true
  identity_not_implied: true
  learning_handoff_AFQR12: true
cultural_continuity_model:
  copy_fusion_fission_profiled: true
  migration_and_diaspora_supported: true
norm_model:
  existence_recognition_awareness_endorsement_applicability_compliance_enforcement_legitimacy_separate: true
  universal_morality: false
norm_awareness_model:
  AFQR_10_owned: true
  legal_notice_separate: true
norm_compliance_model:
  evidence_then_claim_then_determination: true
  strategic_compliance_supported: true
  unknown_violation_supported: true
norm_enforcement_handoff:
  AFQR_03_action: true
  AFQR_09_governed_relation: true
  AFQR_11_authority_responsibility: true
  AFQR_07_quantities: true
kinship_model:
  types:
  - biological
  - legal
  - adoptive
  - social
  - ritual
  - clan
  - lineage
  - chosen_family
  - spiritual
  - source_local
  no_auto_affection_authority_inheritance: true
household_model:
  membership_separate_from_kinship: true
  split_merge_transitions: true
lineage_handoff:
  AFQR_08_identity: true
  AFQR_09_inheritance_and_dependency: true
social_network_model:
  typed_edges: true
  multiplex_layers: true
  hyperedges: true
  temporal_snapshots: true
  metrics_derived: true
  missing_data_explicit: true
coalition_model:
  membership_not_trust: true
  partly_shared_goals: true
  procedure_or_emergent_formation: true
cohesion_model:
  profile_scoped: true
  dimensions_named: true
  single_scalar_not_required: true
schism_model:
  candidate_then_receipt: true
  boundary_dispute: true
  successor_membership_overlap: true
emergent_group_pattern_model:
  derived_not_intentional: true
  collective_agency_AFQR11_handoff: true
social_influence_handoff:
  information_AFQR10: true
  attention_and_motivation_AFQR12: true
  control_coercion_AFQR11: true
  no_auto_action: true
behavioral_handoff:
  relationship_may_bias_deliberation_only_through_registered_bridge: true
agency_handoff:
  group_action_requires_AFQR11: true
  membership_not_agency: true
epistemic_handoff:
  belief_recognition_reputation_rumor_awareness_AFQR10: true
governed_relation_handoff:
  formal_membership_office_duties_kinship_legal_components_AFQR09: true
resource_handoff:
  favor_prestige_honor_influence_not_universal_resources: true
  AFQR07_for_explicit_quantities: true
social_simulation_tier_model:
  tiers:
  - authored_static
  - aggregate_population
  - institutional_routine
  - network_summary
  - relationship_active
  - full_social_deliberative_fixture
social_materialization_policy:
  promotion_requires_certificate: true
  demotion_preserves_reconstruction_basis: true
  no_invented_history: true
hidden_social_state_policy:
  private_receipts: true
  audience_scoped_tokens: true
  projection_specific_digests: true
  constant_shape: true
visible_projection_policy:
  audience_minimized: true
  unknown_and_uncertain_explicit: true
  counts_topology_profile_names_hidden_by_default: true
model_context_policy:
  untrusted_model: true
  only_grounding_manifest_claims: true
  cross_packet_isolation: true
model_output_validation:
  claim_kind_allowlist: true
  source_refs_required: true
  mutation_language_rejected: true
  stereotype_inference_rejected: true
side_channel_protection:
  option_relation_audience_counts_suppressed: true
  timing_bounded: true
  hash_unlinkability: true
  cache_partitioning: true
historical_replay_policy:
  retain:
  - policy_versions
  - identity_facets
  - audience_basis
  - evidence
  - relation_dimensions
  - network_snapshot
  - effective_recorded_logical_times
  missing_evaluator: unverifiable
bitemporal_policy:
  valid_time: true
  recorded_time: true
  logical_time: true
  correction_append_only: true
owner_boundaries:
  backend_state_owner_not_in_world_authority: true
  audience_owns_reputation: true
  participants_own_private_trust_or_recognition: true
  institution_owns_formal_records: true
AFQR_handoffs:
  AFQR_01:
    required: true
  AFQR_02:
    required: true
  AFQR_03:
    required: true
  AFQR_04:
    required: true
  AFQR_05:
    required: true
  AFQR_06:
    required: true
  AFQR_07:
    required: true
  AFQR_08:
    required: true
  AFQR_09:
    required: true
  AFQR_10:
    required: true
  AFQR_11:
    required: true
  AFQR_12:
    required: true
persistent_rival_stress_case:
  subjects:
  - player_character
  - rival_persona
  - rival_office_or_faction_role
  - faction
  - public_audiences
  relation_dimensions:
  - rivalry
  - respect
  - fear
  - cooperation
  - attachment
  - enmity
  - familiarity
  trust_domains:
  - combat_competence_high
  - truthfulness_low_or_uncertain
  - cooperation_against_shared_threat_conditional
  reputation:
  - rival_spreads_partly_false_player_reputation
  - rival_gains_faction_status
  - audiences_diverge
  norms:
  - faction_norm_against_forgiveness
  - private_reconciliation_candidate
  decision: Keep every dimension directional and audience-specific. Cooperation does not create friendship; public enemy status
    does not erase private reconciliation; hidden motives remain AFQR-12 private state.
  handoffs:
  - AFQR-10 false attribution and rumor
  - AFQR-12 fear/resentment/attachment/goals
  - AFQR-11 action origin
  - AFQR-09 faction role and office
  - AFQR-01 commit
uplifted_dependent_stress_case:
  subjects:
  - uplifted_subject
  - former_guardian
  - new_community
  - chosen_family
  - legal_or_social_status_audiences
  relations:
  - care
  - teaching
  - dependency
  - possible_guardianship
  - claimed_parentage
  - chosen_family
  - community_affiliation
  conflicts:
  - creator/guardian/owner/parent/patron/exploiter/liberator audience narratives
  - private rejection of creation identity
  - resource dependency versus autonomous affiliation
  decision: Creation and nurture establish no universal parenthood or ownership. Kinship, care, guardianship, trust, dependence,
    status, cultural identity, and reputation are separately determined.
  handoffs:
  - AFQR-11 autonomy/consent/personhood
  - AFQR-12 values/loyalty/resentment
  - AFQR-09 guardianship/dependency
  - AFQR-10 audience narratives
familiar_network_stress_case:
  subjects:
  - original_familiar
  - ritual_derivative
  - signer
  - contract_administrator
  - religious_community
  - public_property_audience
  relations:
  - origin/derivative lineage
  - friendship with signer
  - fear of original
  - distrust of administrator
  - religious membership
  - independent reputation
  hidden:
  - religious affiliation
  - private goals
  - autonomy transition basis
  decision: Derivative reputation and relationships use its distinct identity reference. Public property classification remains
    source-local law/reputation, not core personhood or social truth. Autonomy does not erase prior ties or impose inherited
    obligations.
  handoffs:
  - AFQR-08 derivative identity
  - AFQR-09 contract obligations
  - AFQR-11 agency/status safeguards
  - AFQR-12 private goals
  - AFQR-10 hidden affiliation
coalition_stress_case:
  subjects:
  - multiple_factions
  - leaders
  - coalition
  - enemy
  - public_propaganda_audience
  state:
  - incompatible cultures
  - domain-specific distrust
  - false reputation
  - secret enemy alliance
  - partly overlapping goals
  - consensus norm
  - emergency authority
  - defection after misunderstanding
  - status-motivated retention
  decision: Coalition membership, trust, cultural identity, public unity claims, norm recognition, authority, cohesion, and
    institutional continuity remain separate. Defection and schism append transitions and do not retroactively erase coalition
    acts.
  handoffs:
  - AFQR-10 misinformation/rumor
  - AFQR-11 collective procedure/authority
  - AFQR-12 goals/behavior
  - AFQR-09 membership obligations
  - AFQR-04 timing
conversion_pipeline_handoff:
  candidate_only_IRs:
  - SocialRelationPressureIR
  - TrustPressureIR
  - ReliancePressureIR
  - LoyaltyPressureIR
  - AffectionPressureIR
  - RivalryPressureIR
  - ReputationPressureIR
  - PublicStandingPressureIR
  - StatusPressureIR
  - RankPressureIR
  - PrestigePressureIR
  - AffiliationPressureIR
  - MembershipPressureIR
  - CulturePressureIR
  - SubculturePressureIR
  - NormPressureIR
  - TabooPressureIR
  - CustomPressureIR
  - KinshipPressureIR
  - HouseholdPressureIR
  - CoalitionPressureIR
  - GroupDynamicsPressureIR
  - SocialNetworkPressureIR
  - ReconciliationPressureIR
  - SocialContinuityPressureIR
  - SourceLocalSocialOntologyPressureIR
  no_campaign_mutation: true
  lawful_outcomes:
  - direct
  - normalized
  - source_local
  - quarantined
  - escalated
model_authority_policy:
  relationship_trust_reputation_status_culture_membership_norm_group_dynamics_authority: false
  portray_committed_visible_state: true
current_runtime_disposition:
  exists:
  - backend authority doctrine
  - conversion and schema descriptors
  - state owner reference skeleton
  - narrow RT-002 fixture actor/NPC/faction-social reference
  - hidden-information projection boundaries
  fixture_only:
  - RT-002A-F actor/NPC/object/hazard/condition/hidden fact and command/event/audit path
  conversion_only:
  - relationship
  - bond
  - loyalty
  - reputation
  - rank
  - status
  - culture
  - faction
  - role
  - affiliation
  - norm
  - kinship
  - social tags
  narrative_only:
  - NPC social prose
  - faction attitudes
  - mission allies/enemies
  - dialogue examples
  missing:
  - all AFQR-13 runtime owners and evaluators
required_artifacts:
  immediate:
  - ADR
  - decision registry
  - terminology registry
  - contract catalog
  - operation grammar
  - 200-case adversarial pack
  - 50-case dry run
  - four stress graphs
  - research synthesis
  - side-channel threat model
  before_authoritative_relationships:
  - owner registry
  - relation definition registry
  - transition evaluator
  - AFQR-01 fragments
  - continuity archive
  before_trust_mutation:
  - trust domain registry
  - evidence/revision profiles
  - reliance handoff tests
  before_reputation_propagation:
  - audience registry
  - diffusion scheduler
  - aggregation attack tests
  - translation provenance
  before_status_membership:
  - jurisdiction/rank/affiliation registries
  - AFQR-09 transitions
  - AFQR-06 conflict domains
  before_culture_norm_execution:
  - culture/norm registries
  - awareness/applicability/compliance evaluators
  - sanction handoffs
  before_group_simulation:
  - network snapshot service
  - coalition/schism profiles
  - simulation tier certificates
  before_model_social_dialogue:
  - grounding manifest
  - claim registry
  - output validator
  - cross-packet isolation
  - noninterference suite
  before_mass_conversion:
  - pressure IR validator
  - donor-family fixtures
  - source-local namespace governance
  deferred:
  - romance mechanics
  - prejudice/discrimination
  - political legitimacy
  - economic exchange
  - crime/sanctions
  - population sociology
  - propaganda
  - diplomacy formulas
required_prototype:
  name: AFQR-13 Social Relations, Trust, Reputation, Status, Culture, and Group Dynamics Dry Run
  non_mutating: true
  case_count: 50
required_fixtures:
- one-sided friendship claim
- asymmetric familiarity
- rivalry with respect
- cooperation without affection
- domain-specific trust
- reliance without trust
- betrayal candidate
- forgiveness without trust repair
- trust-repair candidate
- local positive reputation
- conflicting audience reputation
- false reputation from rumor
- partial correction
- formal rank
- informal prestige
- status conflict
- formal membership
- secret membership
- dual affiliation
- defection
- cultural identification
- cultural competence without identity
- mixed cultural affiliation
- norm awareness
- norm rejection
- norm violation claim
- false norm-violation accusation
- biological and adoptive kinship
- chosen-family claim
- household split
- coalition formation
- coalition without trust
- clique formation
- schism
- network centrality projection
- hidden social network
- clone reputation dispute
- office social-continuity split
- resurrected membership
- familiar independent friendship
- uplifted subject rejecting creator-parent relation
- institutional alliance after leadership replacement
- persistent rival
- covert coalition member
- hidden-affiliation model projection
- audience-token unlinkability
- aggregate social simulation
- promotion to detailed simulation
- source-local social relation
- no lawful social determination
blocked_work:
- authoritative social relation mutation
- trust mutation
- reputation diffusion
- status/rank transitions
- membership admission/expulsion execution
- norm sanction execution
- coalition formation/schism execution
- full social network simulation
- model-authored social state
- unbounded social dialogue inference
work_unlocked:
- schema and registry implementation
- non-mutating determinators
- conversion pressure validation
- hard-case fixtures
- social projection security tests
- bounded portrayal packet design after validators
rejected_alternatives:
- single relationship score
- fixed universal tracks
- graph reachability as social truth
- reputation ledger as whole social model
- institutional role as whole social model
- unbounded agent-based simulation
- narrative tags as authoritative state
residual_risks:
- profile proliferation
- authoring burden
- audience scale
- temporal network performance
- social approximation error
- cultural stereotype leakage
- reputation attacks
- side-channel correlation
- continuity disputes
- small-model portrayal drift
RT_002G_status: May proceed only as a narrow fixture after AFQR-01–13 artifact ratification and social noninterference amendments;
  actor/faction references gain no generalized relationship, trust, reputation, status, culture, membership, or norm semantics.
next_foundational_question:
  question_id: AFQR-14
  title: Communication, Language, Dialogue Acts, Conversation State, Interpretation, Persuasion, and Social Interaction Protocols
  central_question: How should Astra represent, transmit, interpret, ground, sequence, dispute, conceal, project, and replay
    communicative acts and conversation state across languages, modalities, agents, institutions, cultures, and models without
    allowing freeform dialogue to create truth, consent, relationship, motive, authority, or state mutation?
exact_next_roadmap_action: Ratify and register AFQR-13, execute the 50-case non-mutating dry run and an RT-002A–RT-002F social-state/side-channel
  audit, permit only narrowly amended RT-002G fixture work, and open AFQR-14 as a read-only foundational investigation.
```
