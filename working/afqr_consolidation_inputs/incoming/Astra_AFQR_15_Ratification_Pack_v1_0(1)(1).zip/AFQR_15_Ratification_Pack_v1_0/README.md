# AFQR-15 Ratification Pack v1.0

Architecture: **Registered Federated Institutional–Jurisdictional Architecture with Relational Normative Positions, Versioned Rule Materials, Protocol-Governed Adjudication, Profiled Legitimacy, and Separated Enforcement Authorization and Execution** (`RFIJA-RNP-VRM-PGA-PL-SEA`)  
Repository: `928bb79ce00a2de749d127dcc5cb8299de788a15`  
Status: read-only ratification candidate.

Contains a 30-part master, corrected AFQR-14 dependency note, 50-question repo audit, 199 definitions, 181 contracts, 90 operations, 200 adversarial cases, 50 dry-run cases, four stress graphs, 184 acceptance tests, 29 conversion IR types, 18 research families, threat model, and corrected manifests. No repository modification or merge-ready implementation is included.