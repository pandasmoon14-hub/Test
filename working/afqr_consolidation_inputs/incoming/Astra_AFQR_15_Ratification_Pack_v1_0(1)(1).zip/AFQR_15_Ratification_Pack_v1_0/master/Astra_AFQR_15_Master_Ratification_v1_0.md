# Astra AFQR-15 Master Ratification v1.0

## Part I — Executive decision

**Selected architecture:** Registered Federated Institutional–Jurisdictional Architecture with Relational Normative Positions, Versioned Rule Materials, Protocol-Governed Adjudication, Profiled Legitimacy, and Separated Enforcement Authorization and Execution  
**Abbreviation:** `RFIJA-RNP-VRM-PGA-PL-SEA`  
**Confidence:** High  
**Resolution:** Ratification candidate.

> No institution, office, title, faction, territory, rule text, public record, judgment, recognition claim, effective controller, enforcement actor, donor descriptor, or model statement is presumed to possess institutional identity, authority, jurisdiction, validity, applicability, legitimacy, or enforcement power. Every authoritative institutional result is a purpose-scoped, version-pinned, bitemporal determination over typed constitution, identity, office, mandate, delegation, jurisdiction, normative-position, rule, procedure, evidence, agency, communication, social, settlement, and continuity bases. Rule validity, effectivity, applicability, interpretation, violation, adjudication, remedy authorization, and enforcement execution remain separate. Only owner-prepared AFQR-01 transitions mutate state; appeals and later interpretations append records rather than rewriting history; unresolved and source-local outcomes remain lawful.

This is a federated institution, jurisdiction, normative-position, rule, procedure, adjudication, legitimacy, emergency, and enforcement architecture. It is not a universal government, legal code, rights catalogue, moral theory, sovereignty doctrine, punishment model, or LLM legal engine. No second broad research pass is required; implementation of any specific legal family still requires profile-specific research and certification.

## Part II — Repository-grounded diagnosis

The verified `main` head is `928bb79ce00a2de749d127dcc5cb8299de788a15`, PR #325 / RT-002F. The repository remains foundation-stage. RT-001 and RT-002 are narrow fixtures. RT-002C `legality` is eligibility for `interact_with_object_lever`, not law. Batch B law/enforcement is conversion-facing pressure; Batch C C05 faction/institution is conversion-stage record grammar. AFQR-01–14 are accepted architecture, not generalized runtime implementation.

| number | question | status | answer |
| --- | --- | --- | --- |
| 1 | Are institutions represented authoritatively? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 2 | Are institutions distinct from factions? | conversion_or_doctrine_only | The distinction can be preserved in doctrine/conversion, but no generalized runtime owner exists. |
| 3 | Is institutional identity persistent? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 4 | Are organs and offices represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 5 | Is office authority represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 6 | Is delegation represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 7 | Is succession represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 8 | Is jurisdiction represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 9 | Is jurisdiction typed by basis and subject matter? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 10 | Can jurisdictions overlap? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 11 | Can jurisdiction be disputed? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 12 | Are rules represented? | conversion_or_doctrine_only | The distinction can be preserved in doctrine/conversion, but no generalized runtime owner exists. |
| 13 | Are rule versions represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 14 | Are effectivity and publication separated? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 15 | Are laws separated from norms and policies? | conversion_or_doctrine_only | The distinction can be preserved in doctrine/conversion, but no generalized runtime owner exists. |
| 16 | Are rights represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 17 | Are Hohfeld-like normative positions or equivalent distinctions represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 18 | Are permissions separated from consent and capability? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 19 | Are duties separated from behavioral commitments? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 20 | Is legality represented? | conversion_or_doctrine_only | The distinction can be preserved in doctrine/conversion, but no generalized runtime owner exists. |
| 21 | Is applicability represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 22 | Are exceptions and exemptions represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 23 | Is rule interpretation represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 24 | Are conflicting rules representable? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 25 | Are institutional procedures represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 26 | Are voting and quorum represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 27 | Are hearings represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 28 | Are standing and forum competence represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 29 | Are findings of fact and law separated? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 30 | Is adjudication separated from AFQR-06 arbitration? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 31 | Are appeals and review represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 32 | Are remedies represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 33 | Is enforcement authorization represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 34 | Is enforcement execution separated? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 35 | Are warrants or equivalent authorizations represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 36 | Is legitimacy represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 37 | Is recognition separated from legitimacy? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 38 | Is de facto control separated from lawful authority? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 39 | Are emergency powers represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 40 | Are sunset and review represented? | absent | No generalized authoritative runtime implementation exists at the inspected commit. |
| 41 | Can multiple legal systems coexist? | conversion_or_doctrine_only | The distinction can be preserved in doctrine/conversion, but no generalized runtime owner exists. |
| 42 | Can source-local metaphysical law remain contained? | conversion_or_doctrine_only | The distinction can be preserved in doctrine/conversion, but no generalized runtime owner exists. |
| 43 | Can copies inherit disputed legal status? | accepted_AFQR_architecture_only | Accepted AFQR architecture supports the case, but no repository implementation exists. |
| 44 | Can office successors inherit formal authority but not personal liability? | accepted_AFQR_architecture_only | Accepted AFQR architecture supports the case, but no repository implementation exists. |
| 45 | Can institutions survive complete membership replacement? | accepted_AFQR_architecture_only | Accepted AFQR architecture supports the case, but no repository implementation exists. |
| 46 | Can uplifted or artificial subjects have unresolved legal status? | accepted_AFQR_architecture_only | Accepted AFQR architecture supports the case, but no repository implementation exists. |
| 47 | Which institution-like fields are conversion-only? | conversion_only | Faction/institution records, rank/title/office/access/obligation fields, law/enforcement pressure, and source-local setting law are conversion-only. |
| 48 | Which are fixture-only? | fixture_only | Authority flags, action-legality labels, object/lever command records, projections, and replay receipts are fixture-only and noninstitutional. |
| 49 | Which are narrative-only? | narrative_only | Descriptions, laws in setting prose, titles, court scenes, prompts, summaries, and model text are non-authoritative. |
| 50 | What implementation remains blocked? | blocked | Institution identity, offices, delegation, jurisdiction, normative positions, rule services, procedures, adjudication, appeals, remedies, enforcement, legitimacy, emergencies, and institutional model validation remain blocked. |

## Part III — External research synthesis

### Institutional Theory

**Actual mechanism.** Institutions combine organizations, mandates, rules, procedures, authority, accountability, persistence, and legitimacy.

**Architectural lesson.** Separate institutional identity, constitution, organs, mandates, oversight, and continuity.

**Limitation.** State-centered theories do not define every artificial or source-local institution.

**Astra disposition.** `adapt`.

### Governance And Public Administration

**Actual mechanism.** Governance allocates authority through selection, delegation, capacity, oversight, and accountability.

**Architectural lesson.** Governance labels must resolve to registered decision procedures and authority chains.

**Limitation.** No governmental form is universal.

**Astra disposition.** `adapt`.

### Jurisdiction And Conflict Of Laws

**Actual mechanism.** Jurisdiction, applicable law, forum competence, recognition, review, and enforcement are distinct.

**Architectural lesson.** Use explicit bases, conflicts, immunities, choice profiles, and unresolved outcomes.

**Limitation.** Real conventions cover bounded domains.

**Astra disposition.** `adapt`.

### Normative Positions And Rights

**Actual mechanism.** Hohfeld distinguishes claim-right/duty, liberty/no-right, power/liability, and immunity/disability.

**Architectural lesson.** Use a relational grammar with holder, counterparty, object, scope, conditions, and lifecycle.

**Limitation.** It supplies no universal rights catalogue or moral theory.

**Astra disposition.** `adopt_and_extend`.

### Rule Systems And Legal Validity

**Actual mechanism.** Validity, legal certainty, hierarchy, interpretation, amendment, suspension, and repeal are separate questions.

**Architectural lesson.** Store immutable rule versions and separate enactment, publication, effectivity, applicability, and interpretation.

**Limitation.** No universal hierarchy or retroactivity rule follows.

**Astra disposition.** `adapt`.

### Legal Interpretation

**Actual mechanism.** Interpretation may use text, context, purpose, precedent, and system relations; legal language can remain open-textured.

**Architectural lesson.** Use versioned profiles, candidate sets, arguments, and incomparability.

**Limitation.** No interpretive method is universal.

**Astra disposition.** `contain_as_profiles`.

### Procedure And Adjudication

**Actual mechanism.** Competent, independent forums, notice, participation, evidence, burdens, reasons, review, and procedural rights structure adjudication.

**Architectural lesson.** Separate standing, competence, evidence, findings, judgment, appeal, and finality.

**Limitation.** Specific guarantees and standards are system-specific.

**Astra disposition.** `adapt_structure`.

### Evidence And Institutional Truth

**Actual mechanism.** Authenticity, relevance, admissibility, purpose, burdens, and standards are separate from world truth.

**Architectural lesson.** Reuse AFQR-10 evidence and add procedure-specific admissibility and finding records.

**Limitation.** Evidence rules are jurisdiction-specific.

**Astra disposition.** `adapt_interface`.

### Enforcement And Remedies

**Actual mechanism.** Remedies can include restitution, compensation, rehabilitation, injunction, sanctions, and monitoring; authorization differs from execution.

**Architectural lesson.** Separate eligibility, authorization, settlement, execution, success, collateral harm, and review.

**Limitation.** No punishment philosophy or scale is universal.

**Astra disposition.** `federate`.

### Legitimacy And Recognition

**Actual mechanism.** Recognition, sovereignty, legal validity, support, occupation, succession, and effective control are distinct.

**Architectural lesson.** Use named legitimacy profiles and audience bindings.

**Limitation.** No legitimacy theory is universal.

**Astra disposition.** `plural_claims`.

### Constitutional Design And Emergency Powers

**Actual mechanism.** Emergency derogation is exceptional, temporary, bounded, reviewed, and aimed at restoration of ordinary conditions.

**Architectural lesson.** Require trigger, authority, scope, reporting, renewal, sunset, and post-review.

**Limitation.** Nonderogable protections remain source-specific.

**Astra disposition.** `bounded_exception`.

### International And Treaty Systems

**Actual mechanism.** Treaties involve authority, ratification, reservations, entry into force, interpretation, withdrawal, and succession.

**Architectural lesson.** Treat treaties as governed relations with rule, jurisdiction, continuity, recognition, and settlement records.

**Limitation.** International defaults are not universal Astra defaults.

**Astra disposition.** `adapt_profile`.

### Corporate Guild Religious Private Governance

**Actual mechanism.** Private governance distinguishes charters, boards, members, disclosure, rights, oversight, and discipline.

**Architectural lesson.** Support non-state institutions and internal procedures.

**Limitation.** Corporate models do not generalize to every guild, cult, clan, or hive.

**Astra disposition.** `adapt_cross_family`.

### Artificial And Nonhuman Governance

**Actual mechanism.** AI governance emphasizes lifecycle accountability, transparency, oversight, safeguards, remedies, and risk assessment.

**Architectural lesson.** Artificial institutions require explicit agency, audit, review, and continuity profiles.

**Limitation.** Existing law does not settle AI personhood or hive governance.

**Astra disposition.** `adapt_unresolved_status`.

### Distributed Systems And Institutional Consensus

**Actual mechanism.** Raft, PBFT, and replicated ledgers use quorums, leader election, append-only logs, and fault assumptions.

**Architectural lesson.** Adopt deterministic quorum, vote identity, fork detection, and replay safeguards.

**Limitation.** Technical consensus is not political legitimacy or lawful authority.

**Astra disposition.** `adopt_safety_reject_legitimacy`.

### Political And Organizational Failure

**Actual mechanism.** Capture, corruption, fragmented oversight, information control, and principal-agent failures redirect institutions.

**Architectural lesson.** Represent practical control, proxy action, appointment influence, procedure manipulation, and hidden affiliation separately from authority.

**Limitation.** Diagnostics do not provide universal thresholds or moral judgments.

**Astra disposition.** `adapt_failure_records`.

### Games And Simulation Systems

**Actual mechanism.** Games bind rulers, offices, mandates, laws, crime, punishment, reputation, and succession into compact systems.

**Architectural lesson.** Treat them as operation/UI pressure and decompose their assumptions.

**Limitation.** Game abstractions are narrow and often score-based.

**Astra disposition.** `donor_pressure`.

### Ttrpg Systems

**Actual mechanism.** TTRPGs encode domains, ranks, law, crime, oaths, geasa, divine law, and contracts as scores, tags, moves, or prose.

**Architectural lesson.** Extract pressure IR and retain source-local metaphysical or legal systems where normalization changes meaning.

**Limitation.** No donor mechanic is universal Astra law.

**Astra disposition.** `normalize_or_source_local`.



## Part IV — Canonical terminology

### Institution Governance

- **institution:** A purpose-scoped persistent governance subject constituted by registered identity, constitution, organs, procedures, and continuity; not merely a faction, member set, leader, asset set, or territory.
- **organization:** A structured association that may or may not qualify as an authoritative institution under a registered constitution profile.
- **organ:** A typed institutional-governance concept for organ; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **office:** A persistent institutional position with a mandate, authority, eligibility, term, and succession profile.
- **officeholder:** An identity-bound subject occupying an office for a recorded interval; distinct from the office.
- **branch:** A typed institutional-governance concept for branch; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **agency:** A typed institutional-governance concept for agency; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **council:** A typed institutional-governance concept for council; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **tribunal:** A typed institutional-governance concept for tribunal; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **constituency:** A typed institutional-governance concept for constituency; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **charter:** A typed institutional-governance concept for charter; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **constitution:** A typed institutional-governance concept for constitution; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **mandate:** A typed institutional-governance concept for mandate; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **delegation:** A typed institutional-governance concept for delegation; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **representation:** A typed institutional-governance concept for representation; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **governance procedure:** A typed institutional-governance concept for governance procedure; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **quorum:** A typed institutional-governance concept for quorum; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **vote:** A typed institutional-governance concept for vote; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **decision procedure:** A typed institutional-governance concept for decision procedure; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **institutional action:** A typed institutional-governance concept for institutional action; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **succession:** A typed institutional-governance concept for succession; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **dissolution:** A typed institutional-governance concept for dissolution; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **institutional identity:** A typed institutional-governance concept for institutional identity; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **institutional agency:** A typed institutional-governance concept for institutional agency; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **institutional memory:** A typed institutional-governance concept for institutional memory; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **institutional capture:** A typed institutional-governance concept for institutional capture; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **coup:** A typed institutional-governance concept for coup; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.
- **constitutional crisis:** A typed institutional-governance concept for constitutional crisis; identity, constitution, organ or office, mandate, authority, procedure, time, and continuity must be explicit.

### Jurisdiction

- **jurisdiction:** Purpose-scoped institutional competence to make, apply, interpret, adjudicate, or enforce rules over specified subjects, matters, places, relations, or events.
- **territorial jurisdiction:** A registered jurisdictional concept for territorial jurisdiction; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **personal jurisdiction:** A registered jurisdictional concept for personal jurisdiction; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **subject matter jurisdiction:** A registered jurisdictional concept for subject matter jurisdiction; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **appellate jurisdiction:** A registered jurisdictional concept for appellate jurisdiction; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **concurrent jurisdiction:** A registered jurisdictional concept for concurrent jurisdiction; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **exclusive jurisdiction:** A registered jurisdictional concept for exclusive jurisdiction; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **delegated jurisdiction:** A registered jurisdictional concept for delegated jurisdiction; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **residual jurisdiction:** A registered jurisdictional concept for residual jurisdiction; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **extraterritorial jurisdiction:** A registered jurisdictional concept for extraterritorial jurisdiction; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **forum:** A registered jurisdictional concept for forum; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **competence:** A registered jurisdictional concept for competence; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **forum competence:** A registered jurisdictional concept for forum competence; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **choice of law:** A registered jurisdictional concept for choice of law; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **conflict of law:** A registered jurisdictional concept for conflict of law; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **jurisdiction basis:** A registered jurisdictional concept for jurisdiction basis; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **jurisdiction scope:** A registered jurisdictional concept for jurisdiction scope; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
- **jurisdictional immunity:** A registered jurisdictional concept for jurisdictional immunity; purpose, basis, subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.

### Normative Positions

- **right:** A typed relational normative-position concept for right; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **claim right:** A relational position held by one subject correlating to a duty of a specified counterparty concerning a defined object and scope.
- **liberty:** A relational absence of duty not to perform a specified act; it does not imply assistance, capability, or a claim against interference.
- **privilege:** A typed relational normative-position concept for privilege; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **power:** A normative ability to alter a specified legal or institutional relation through a valid act.
- **immunity:** A position protecting a holder from another subject’s normative power over a specified relation.
- **duty:** A relational requirement owed by a specified subject under a named rule; distinct from motive, intention, obedience, and performance.
- **liability:** Exposure to another subject’s valid exercise of a normative power.
- **disability:** Absence of normative power to alter a specified relation.
- **no right:** Absence of a claim-right against a specified counterparty concerning a defined object.
- **permission:** A rule- or authority-scoped authorization that conduct is not prohibited within stated conditions; separate from consent, capability, and success.
- **prohibition:** A typed relational normative-position concept for prohibition; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **protection:** A typed relational normative-position concept for protection; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **entitlement:** A typed relational normative-position concept for entitlement; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **license:** A typed relational normative-position concept for license; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **exemption:** A typed relational normative-position concept for exemption; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **standing:** A typed relational normative-position concept for standing; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **remedy:** A typed relational normative-position concept for remedy; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **procedural right:** A typed relational normative-position concept for procedural right; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **remedial right:** A typed relational normative-position concept for remedial right; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **position holder:** A typed relational normative-position concept for position holder; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **position counterparty:** A typed relational normative-position concept for position counterparty; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **position object:** A typed relational normative-position concept for position object; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **position scope:** A typed relational normative-position concept for position scope; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **position condition:** A typed relational normative-position concept for position condition; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
- **position lifecycle:** A typed relational normative-position concept for position lifecycle; holder, counterparty, object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.

### Rules

- **rule:** A versioned rule-material concept for rule; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **law:** A rule family asserted as legally authoritative within a specified legal system and jurisdiction; distinct from policy, norm, morality, physical law, and source-local metaphysical constraint.
- **statute:** A versioned rule-material concept for statute; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **regulation:** A versioned rule-material concept for regulation; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **decree:** A versioned rule-material concept for decree; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **ordinance:** A versioned rule-material concept for ordinance; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **policy:** A versioned rule-material concept for policy; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **precedent:** A versioned rule-material concept for precedent; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **treaty:** A versioned rule-material concept for treaty; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **custom:** A versioned rule-material concept for custom; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **legal norm:** A versioned rule-material concept for legal norm; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **standard:** A versioned rule-material concept for standard; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **exception:** A versioned rule-material concept for exception; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **defense:** A versioned rule-material concept for defense; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **validity:** A determination that a rule or institutional act was created by a competent source through required procedure and form.
- **effectivity:** The temporal and conditional state in which a valid rule is in force.
- **applicability:** A determination that an effective rule governs a specific subject, conduct, object, event, or relation in context.
- **interpretation:** A versioned rule-material concept for interpretation; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **repeal:** A versioned rule-material concept for repeal; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **suspension:** A versioned rule-material concept for suspension; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **expiration:** A versioned rule-material concept for expiration; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **amendment:** A versioned rule-material concept for amendment; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **publication:** A versioned rule-material concept for publication; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **notice:** A versioned rule-material concept for notice; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **retroactivity:** A versioned rule-material concept for retroactivity; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **severability:** A versioned rule-material concept for severability; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **derogation:** A versioned rule-material concept for derogation; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **rule hierarchy:** A versioned rule-material concept for rule hierarchy; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **rule version:** A versioned rule-material concept for rule version; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **rule authority:** A versioned rule-material concept for rule authority; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **rule conflict:** A versioned rule-material concept for rule conflict; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
- **source local legal construct:** A versioned rule-material concept for source local legal construct; authority, structured semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.

### Procedure Adjudication

- **complaint:** A procedure or adjudication concept for complaint; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **claim:** A procedure or adjudication concept for claim; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **allegation:** A procedure or adjudication concept for allegation; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **charge:** A procedure or adjudication concept for charge; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **filing:** A procedure or adjudication concept for filing; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **petition:** A procedure or adjudication concept for petition; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **service:** A procedure or adjudication concept for service; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **investigation:** A procedure or adjudication concept for investigation; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **hearing:** A procedure or adjudication concept for hearing; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **trial:** A procedure or adjudication concept for trial; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **adjudication:** A forum-owned procedure producing institutional findings and dispositions; distinct from objective truth, AFQR-06 arbitration, investigation, responsibility, punishment, and social judgment.
- **evidence:** A procedure or adjudication concept for evidence; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **admissibility:** A procedure or adjudication concept for admissibility; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **burden:** A procedure or adjudication concept for burden; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **standard of determination:** A procedure or adjudication concept for standard of determination; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **finding of fact:** A procedure or adjudication concept for finding of fact; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **finding of rule:** A procedure or adjudication concept for finding of rule; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **judgment:** A committed adjudicative disposition with scope, reasons, remedies, appeal status, and finality state; not metaphysical truth.
- **order:** A procedure or adjudication concept for order; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **appeal:** A procedure or adjudication concept for appeal; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **review:** A procedure or adjudication concept for review; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **finality:** A procedure or adjudication concept for finality; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **dissent:** A procedure or adjudication concept for dissent; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **recusal:** A procedure or adjudication concept for recusal; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **reasoning manifest:** A procedure or adjudication concept for reasoning manifest; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **disposition:** A procedure or adjudication concept for disposition; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **forum competence:** A procedure or adjudication concept for forum competence; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.
- **procedural validity:** A procedure or adjudication concept for procedural validity; forum, roles, standing, procedure version, evidence basis, timing, determination status, and review path must be explicit.

### Enforcement

- **enforcement:** The institutional process of attempting to realize an authorized rule, judgment, remedy, or order through proper state owners.
- **enforcement authority:** A remedy or enforcement concept for enforcement authority; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **enforcement authorization:** A remedy or enforcement concept for enforcement authorization; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **warrant:** A remedy or enforcement concept for warrant; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **summons:** A remedy or enforcement concept for summons; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **arrest:** A remedy or enforcement concept for arrest; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **detention:** A remedy or enforcement concept for detention; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **search:** A remedy or enforcement concept for search; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **seizure:** A remedy or enforcement concept for seizure; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **sanction:** A remedy or enforcement concept for sanction; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **fine:** A remedy or enforcement concept for fine; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **restitution:** A remedy or enforcement concept for restitution; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **forfeiture:** A remedy or enforcement concept for forfeiture; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **injunction:** A remedy or enforcement concept for injunction; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **expulsion:** A remedy or enforcement concept for expulsion; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **exile:** A remedy or enforcement concept for exile; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **rehabilitation:** A remedy or enforcement concept for rehabilitation; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **pardon:** A remedy or enforcement concept for pardon; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **amnesty:** A remedy or enforcement concept for amnesty; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **enforcement discretion:** A remedy or enforcement concept for enforcement discretion; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **enforcement attempt:** A remedy or enforcement concept for enforcement attempt; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **enforcement execution:** A remedy or enforcement concept for enforcement execution; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **enforcement success:** A remedy or enforcement concept for enforcement success; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.
- **collateral effect:** A remedy or enforcement concept for collateral effect; authority, target, scope, preconditions, attempt, execution, success, collateral effects, and review must remain separate.

### Legitimacy Crisis

- **legitimacy:** A profile- and audience-scoped claim that an institution or authority is entitled, justified, accepted, or appropriately constituted to govern.
- **recognition:** A typed acknowledgment by an audience or institution of status, authority, identity, government, judgment, or relation; not legitimacy or sovereignty.
- **sovereignty:** A profile- and audience-scoped governance concept for sovereignty; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **de facto authority:** A profile- and audience-scoped governance concept for de facto authority; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **de jure authority:** A profile- and audience-scoped governance concept for de jure authority; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **effective control:** An observation that a subject can practically direct or constrain a domain; not jurisdiction, lawful authority, or legitimacy.
- **compliance:** A profile- and audience-scoped governance concept for compliance; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **acquiescence:** A profile- and audience-scoped governance concept for acquiescence; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **resistance:** A profile- and audience-scoped governance concept for resistance; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **rebellion:** A profile- and audience-scoped governance concept for rebellion; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **secession:** A profile- and audience-scoped governance concept for secession; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **occupation:** A profile- and audience-scoped governance concept for occupation; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **annexation:** A profile- and audience-scoped governance concept for annexation; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **government in exile:** A profile- and audience-scoped governance concept for government in exile; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **successor institution:** A profile- and audience-scoped governance concept for successor institution; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **public record:** A profile- and audience-scoped governance concept for public record; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **official record:** A profile- and audience-scoped governance concept for official record; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **legal person:** A profile- and audience-scoped governance concept for legal person; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **legal status:** A profile- and audience-scoped governance concept for legal status; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **legal validity:** A profile- and audience-scoped governance concept for legal validity; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **legality:** A profile- and audience-scoped governance concept for legality; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **violation claim:** A profile- and audience-scoped governance concept for violation claim; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **violation determination:** A profile- and audience-scoped governance concept for violation determination; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **liability determination:** A profile- and audience-scoped governance concept for liability determination; legality, recognition, control, social support, and legitimacy must not be collapsed.
- **responsibility assessment:** A profile- and audience-scoped governance concept for responsibility assessment; legality, recognition, control, social support, and legitimacy must not be collapsed.

### Emergency Continuity Security

- **emergency:** A determined condition activating a registered exception regime; not a self-authenticating label or unlimited authority.
- **emergency declaration:** A typed emergency, continuity, simulation, or security concept for emergency declaration; scope, authority, visibility, temporal basis, and review must be explicit.
- **emergency authority:** A typed emergency, continuity, simulation, or security concept for emergency authority; scope, authority, visibility, temporal basis, and review must be explicit.
- **emergency scope:** A typed emergency, continuity, simulation, or security concept for emergency scope; scope, authority, visibility, temporal basis, and review must be explicit.
- **procedure suspension:** A typed emergency, continuity, simulation, or security concept for procedure suspension; scope, authority, visibility, temporal basis, and review must be explicit.
- **renewal:** A typed emergency, continuity, simulation, or security concept for renewal; scope, authority, visibility, temporal basis, and review must be explicit.
- **sunset:** A typed emergency, continuity, simulation, or security concept for sunset; scope, authority, visibility, temporal basis, and review must be explicit.
- **post emergency review:** A typed emergency, continuity, simulation, or security concept for post emergency review; scope, authority, visibility, temporal basis, and review must be explicit.
- **nonderogable position:** A typed emergency, continuity, simulation, or security concept for nonderogable position; scope, authority, visibility, temporal basis, and review must be explicit.
- **emergency abuse claim:** A typed emergency, continuity, simulation, or security concept for emergency abuse claim; scope, authority, visibility, temporal basis, and review must be explicit.
- **institutional simulation tier:** A typed emergency, continuity, simulation, or security concept for institutional simulation tier; scope, authority, visibility, temporal basis, and review must be explicit.
- **institutional projection:** A typed emergency, continuity, simulation, or security concept for institutional projection; scope, authority, visibility, temporal basis, and review must be explicit.
- **institutional narration:** A typed emergency, continuity, simulation, or security concept for institutional narration; scope, authority, visibility, temporal basis, and review must be explicit.
- **lawful unresolved outcome:** A determination status recording missing, conflicting, incomparable, or insufficient bases without inventing certainty.
- **sealed record:** A typed emergency, continuity, simulation, or security concept for sealed record; scope, authority, visibility, temporal basis, and review must be explicit.
- **classified policy:** A typed emergency, continuity, simulation, or security concept for classified policy; scope, authority, visibility, temporal basis, and review must be explicit.
- **covert warrant:** A typed emergency, continuity, simulation, or security concept for covert warrant; scope, authority, visibility, temporal basis, and review must be explicit.
- **protected identity:** A typed emergency, continuity, simulation, or security concept for protected identity; scope, authority, visibility, temporal basis, and review must be explicit.

### Prohibited unqualified runtime terms

`institution`, `government`, `authority`, `jurisdiction`, `right`, `permission`, `duty`, `law`, `legal`, `valid`, `applicable`, `illegal`, `crime`, `guilt`, `liability`, `verdict`, `judgment`, `punishment`, `sanction`, `warrant`, `legitimacy`, `recognition`, `sovereignty`, `official`, `emergency`, `model legal interpretation`

Every use requires owner, semantic family, jurisdiction, version, subjects, time, evidence, status, and visibility.

## Part V — Institutional identity, constitution, and ownership

An institution is a persistent purpose-scoped identity constituted through a registered profile. It is not its members, leaders, headquarters, assets, charter document, faction label, territory, or public recognition. Institution identity, constitution, organs, offices, occupancy, mandates, delegation, decision procedure, representation authority, action origin, and continuity are separately owned. Institutional action requires a valid decision and AFQR-11 action-origin chain.

## Part VI — Jurisdiction

Jurisdiction is purpose-specific and may be territorial, personal, subject-matter, contractual, property-, vessel-, network-, office-, membership-, domain-, action-, species-, plane-, or source-local-based. It may be selected, concurrent, exclusive, delegated, residual, disputed, absent, or unresolved. Forum competence, choice of law, immunity, recognition, and enforcement crossing are separate. No universal first-filed, territorial, newer, or more-specific priority rule exists.

## Part VII — Normative positions and rights

Astra adopts and extends a relational grammar: `claim-right ↔ duty`, `liberty ↔ no-right`, `power ↔ liability`, and `immunity ↔ disability`. Holder, counterparty, object, scope, condition, jurisdiction, lifecycle, continuity, and remedy are explicit. Permission, prohibition, protection, entitlement, license, exemption, standing, procedural right, and remedial right are qualified extensions. This grammar supplies no universal catalogue of rights.

## Part VIII — Rules, policies, enactment, and versioning

Rules are immutable versioned materials linking structured semantics and textual expressions. Constitution, charter, statute, regulation, decree, ordinance, policy, precedent, treaty, custom, military order, procedure, emergency order, religious rule, and source-local metaphysical rule remain distinct. Proposal, enactment, publication, notice, effectivity, applicability, interpretation, amendment, suspension, repeal, and expiration are separate. Freeform prose is not executable law.

## Part IX — Applicability and interpretation

Applicability freezes exact rule versions, jurisdiction, subject and conduct classifications, temporal state, exceptions, exemptions, defenses, and relevant evidence. Interpretation uses named versioned profiles and may preserve several semantic candidates or incomparability. Text, structured semantics, purpose, precedent, and systemic arguments remain separate. Applicability does not establish violation, responsibility, guilt, liability, or sanction.

## Part X — Institutional procedures

Procedures are registered protocols for legislation, appointment, election, audit, discipline, hearing, adjudication, treaty ratification, emergency action, and source-local ritual process. Roles, standing, notice, quorum, moves, deadlines, ordering, validity, review, and closure are explicit. A vote is a move; quorum is a predicate; an institutional decision is a separately validated result.

## Part XI — Adjudication

Adjudication is forum-owned and distinct from objective truth, AFQR-06 arbitration, investigation, accusation, responsibility, punishment, and social judgment. Claims, defenses, standing, forum competence, evidence, authentication, relevance, admissibility, burden, standard, findings of fact, findings of rule, disposition, judgment, reasoning, and dissent remain separate. A judgment can be erroneous, nonfinal, unrecognized, or unenforced.

## Part XII — Appeals, review, and finality

Appeal is a new proceeding, not a retry. Appeal right, standing, timing, review scope, and review standard are explicit. Affirmance, reversal, modification, remand, dismissal, stay, and finality remain distinct. Review appends records; it never rewrites the lower decision or historical basis.

## Part XIII — Remedies and enforcement

Remedy eligibility, authorization, sanction, settlement, enforcement authority, warrant, attempt, execution, success, collateral effect, review, pardon, and amnesty are separate. AFQR-15 authorizes; AFQR-07 settles quantities; AFQR-03 gates actions; AFQR-11 owns agency/control; AFQR-16 will own physical damage, impairment, detention-state effects, repair, and death. A valid warrant does not guarantee correct target, capability, or success.

## Part XIV — Legitimacy, recognition, sovereignty, and crisis

Legitimacy is a named profile and audience-scoped claim. Legality, recognition, sovereignty, public support, reputation, trust, effective control, and legitimacy are distinct. A valid institution may lack support; a supported institution may have disputed legality; a government in exile may retain recognition without control; occupation does not settle sovereignty. Coups, rebellion, secession, and capture create typed conflicts rather than automatic continuity outcomes.

## Part XV — Emergency powers

Emergency authority requires a registered trigger, competent declarant, bounded territory/subjects/matters/powers/duration, enumerated procedure suspensions, source-specific protected positions, reporting, review, renewal as a new action, sunset, termination, restoration, and post-emergency audit. Emergency is never unlimited, permanent, or unreviewable by default.

## Part XVI — Institutional continuity and transformation

Continuity is separate for identity, constitution, organs, offices, mandates, rules, jurisdiction, assets, treaties, debts, judgments, records, recognition, and legitimacy claims. Merger, division, coup, revolution, occupation, annexation, dissolution, reconstitution, exile, leadership replacement, AI takeover, and source-local transformation use family-specific allocation. No entire legal state transfers automatically.

## Part XVII — Hidden institutional state and model projection

Sealed evidence, classified rules, covert offices, hidden delegation, secret warrants, confidential votes, protected identities, secret treaties, and enforcement plans use private receipts. Visible packets use audience-scoped opaque tokens and projection-specific digests. Models receive grounding, permitted claim kinds, and evidence bindings. Unsupported claims of law, guilt, authority, rights, jurisdiction, legitimacy, or punishment fail validation.

## Part XVIII — Typed contracts

The catalog defines **181** family-specific contracts with authoritative owners, semantic fields, record-specific times, bases, hidden and derived fields, prohibited collapses, deterministic commitments, audience tokens, and AFQR-01–14 handoffs.

| contract_name | schema_family | authoritative_owner | purpose |
| --- | --- | --- | --- |
| InstitutionDefinition | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution definition. |
| InstitutionInstance | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution instance. |
| InstitutionConstitutionProfile | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution constitution profile. |
| InstitutionOrganDefinition | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution organ definition. |
| InstitutionOfficeDefinition | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution office definition. |
| InstitutionOfficeOccupancy | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution office occupancy. |
| InstitutionMandate | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution mandate. |
| InstitutionAuthorityBinding | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution authority binding. |
| InstitutionContinuityProfile | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution continuity profile. |
| InstitutionContinuityDetermination | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution continuity determination. |
| InstitutionLineageEdge | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institution lineage edge. |
| InstitutionalDecisionProcedure | institutional_decision_action | institutional_action_owner | Typed AFQR-15 contract for institutional decision procedure. |
| InstitutionalDecisionSession | institutional_decision_action | institutional_action_owner | Typed AFQR-15 contract for institutional decision session. |
| InstitutionalDecisionCandidate | institutional_decision_action | institutional_action_owner | Typed AFQR-15 contract for institutional decision candidate. |
| InstitutionalDecisionReceipt | institutional_decision_action | institutional_action_owner | Typed AFQR-15 contract for institutional decision receipt. |
| InstitutionalActionAuthorization | institutional_decision_action | institutional_action_owner | Typed AFQR-15 contract for institutional action authorization. |
| InstitutionalRepresentationAuthority | institutional_decision_action | institutional_action_owner | Typed AFQR-15 contract for institutional representation authority. |
| InstitutionalActionOriginRecord | institutional_decision_action | institutional_action_owner | Typed AFQR-15 contract for institutional action origin record. |
| JurisdictionDefinition | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction definition. |
| JurisdictionBasis | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction basis. |
| JurisdictionSubjectMatter | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction subject matter. |
| JurisdictionSubjectSelector | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction subject selector. |
| JurisdictionTerritoryReference | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction territory reference. |
| JurisdictionTemporalScope | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction temporal scope. |
| JurisdictionClaim | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction claim. |
| JurisdictionApplicabilityCandidate | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction applicability candidate. |
| JurisdictionDetermination | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction determination. |
| JurisdictionConflictSet | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for jurisdiction conflict set. |
| NormativePositionDefinition | normative_position | normative_position_owner | Typed AFQR-15 contract for normative position definition. |
| NormativePositionInstance | normative_position | normative_position_owner | Typed AFQR-15 contract for normative position instance. |
| PositionHolderBinding | normative_position | normative_position_owner | Typed AFQR-15 contract for position holder binding. |
| PositionCounterpartyBinding | normative_position | normative_position_owner | Typed AFQR-15 contract for position counterparty binding. |
| PositionObject | normative_position | normative_position_owner | Typed AFQR-15 contract for position object. |
| PositionScope | normative_position | normative_position_owner | Typed AFQR-15 contract for position scope. |
| PositionCondition | normative_position | normative_position_owner | Typed AFQR-15 contract for position condition. |
| PositionLifecycle | normative_position | normative_position_owner | Typed AFQR-15 contract for position lifecycle. |
| PositionConflictSet | normative_position | normative_position_owner | Typed AFQR-15 contract for position conflict set. |
| PositionContinuityDetermination | normative_position | normative_position_owner | Typed AFQR-15 contract for position continuity determination. |
| RuleDefinition | rule_material | rule_material_owner | Typed AFQR-15 contract for rule definition. |
| RuleVersion | rule_material | rule_material_owner | Typed AFQR-15 contract for rule version. |
| RuleAuthorityBinding | rule_material | rule_material_owner | Typed AFQR-15 contract for rule authority binding. |
| RuleEnactmentRecord | rule_material | rule_material_owner | Typed AFQR-15 contract for rule enactment record. |
| RulePublicationRecord | rule_material | rule_material_owner | Typed AFQR-15 contract for rule publication record. |
| RuleEffectivityRecord | rule_material | rule_material_owner | Typed AFQR-15 contract for rule effectivity record. |
| RuleSuspensionRecord | rule_material | rule_material_owner | Typed AFQR-15 contract for rule suspension record. |
| RuleAmendmentRecord | rule_material | rule_material_owner | Typed AFQR-15 contract for rule amendment record. |
| RuleRepealRecord | rule_material | rule_material_owner | Typed AFQR-15 contract for rule repeal record. |
| RuleExpirationRecord | rule_material | rule_material_owner | Typed AFQR-15 contract for rule expiration record. |
| RuleHierarchyReference | rule_material | rule_material_owner | Typed AFQR-15 contract for rule hierarchy reference. |
| RuleConflictSet | rule_material | rule_material_owner | Typed AFQR-15 contract for rule conflict set. |
| RuleApplicabilityContext | rule_applicability | rule_applicability_owner | Typed AFQR-15 contract for rule applicability context. |
| RuleSubjectClassification | rule_applicability | rule_applicability_owner | Typed AFQR-15 contract for rule subject classification. |
| RuleConductClassification | rule_applicability | rule_applicability_owner | Typed AFQR-15 contract for rule conduct classification. |
| RuleTemporalApplicability | rule_applicability | rule_applicability_owner | Typed AFQR-15 contract for rule temporal applicability. |
| RuleJurisdictionApplicability | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for rule jurisdiction applicability. |
| RuleExceptionCandidate | rule_applicability | rule_applicability_owner | Typed AFQR-15 contract for rule exception candidate. |
| RuleExemptionReference | rule_applicability | rule_applicability_owner | Typed AFQR-15 contract for rule exemption reference. |
| RuleDefenseCandidate | rule_applicability | rule_applicability_owner | Typed AFQR-15 contract for rule defense candidate. |
| RuleApplicabilityDetermination | rule_applicability | rule_applicability_owner | Typed AFQR-15 contract for rule applicability determination. |
| RuleInterpretationProfile | rule_interpretation | rule_interpretation_owner | Typed AFQR-15 contract for rule interpretation profile. |
| RuleInterpretationInputClosure | rule_interpretation | rule_interpretation_owner | Typed AFQR-15 contract for rule interpretation input closure. |
| RuleSemanticCandidate | rule_interpretation | rule_interpretation_owner | Typed AFQR-15 contract for rule semantic candidate. |
| RulePurposeReference | rule_interpretation | rule_interpretation_owner | Typed AFQR-15 contract for rule purpose reference. |
| PrecedentReference | rule_interpretation | rule_interpretation_owner | Typed AFQR-15 contract for precedent reference. |
| InterpretiveArgument | rule_interpretation | rule_interpretation_owner | Typed AFQR-15 contract for interpretive argument. |
| RuleInterpretationCandidateSet | rule_interpretation | rule_interpretation_owner | Typed AFQR-15 contract for rule interpretation candidate set. |
| RuleInterpretationDetermination | rule_interpretation | rule_interpretation_owner | Typed AFQR-15 contract for rule interpretation determination. |
| RuleInterpretationIncomparabilityReceipt | rule_interpretation | rule_interpretation_owner | Typed AFQR-15 contract for rule interpretation incomparability receipt. |
| InstitutionalProcedureDefinition | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institutional procedure definition. |
| ProcedureRoleDefinition | procedure | institutional_procedure_owner | Typed AFQR-15 contract for procedure role definition. |
| ProcedureStandingRequirement | procedure | institutional_procedure_owner | Typed AFQR-15 contract for procedure standing requirement. |
| ProcedureNoticeRequirement | procedure | institutional_procedure_owner | Typed AFQR-15 contract for procedure notice requirement. |
| ProcedureQuorumRequirement | procedure | institutional_procedure_owner | Typed AFQR-15 contract for procedure quorum requirement. |
| ProcedureMoveDefinition | procedure | institutional_procedure_owner | Typed AFQR-15 contract for procedure move definition. |
| ProcedureState | procedure | institutional_procedure_owner | Typed AFQR-15 contract for procedure state. |
| ProcedureTransitionReceipt | procedure | institutional_procedure_owner | Typed AFQR-15 contract for procedure transition receipt. |
| ProcedureViolationClaim | procedure | institutional_procedure_owner | Typed AFQR-15 contract for procedure violation claim. |
| ProcedureValidityDetermination | procedure | institutional_procedure_owner | Typed AFQR-15 contract for procedure validity determination. |
| AdjudicativeForumDefinition | adjudication | adjudication_owner | Typed AFQR-15 contract for adjudicative forum definition. |
| AdjudicativeSession | adjudication | adjudication_owner | Typed AFQR-15 contract for adjudicative session. |
| PartyBinding | adjudication | adjudication_owner | Typed AFQR-15 contract for party binding. |
| ClaimDefinition | adjudication | adjudication_owner | Typed AFQR-15 contract for claim definition. |
| ClaimInstance | adjudication | adjudication_owner | Typed AFQR-15 contract for claim instance. |
| DefenseRecord | adjudication | adjudication_owner | Typed AFQR-15 contract for defense record. |
| StandingDetermination | adjudication | adjudication_owner | Typed AFQR-15 contract for standing determination. |
| ForumCompetenceDetermination | adjudication | adjudication_owner | Typed AFQR-15 contract for forum competence determination. |
| EvidenceSubmission | adjudication | adjudication_owner | Typed AFQR-15 contract for evidence submission. |
| AdmissibilityDetermination | adjudication | adjudication_owner | Typed AFQR-15 contract for admissibility determination. |
| BurdenAssignment | adjudication | adjudication_owner | Typed AFQR-15 contract for burden assignment. |
| StandardOfDetermination | adjudication | adjudication_owner | Typed AFQR-15 contract for standard of determination. |
| FindingOfFactCandidate | adjudication | adjudication_owner | Typed AFQR-15 contract for finding of fact candidate. |
| FindingOfFactDetermination | adjudication | adjudication_owner | Typed AFQR-15 contract for finding of fact determination. |
| FindingOfRuleCandidate | rule_material | rule_material_owner | Typed AFQR-15 contract for finding of rule candidate. |
| FindingOfRuleDetermination | rule_material | rule_material_owner | Typed AFQR-15 contract for finding of rule determination. |
| DispositionCandidate | adjudication | adjudication_owner | Typed AFQR-15 contract for disposition candidate. |
| JudgmentRecord | adjudication | adjudication_owner | Typed AFQR-15 contract for judgment record. |
| ReasoningManifest | adjudication | adjudication_owner | Typed AFQR-15 contract for reasoning manifest. |
| DissentRecord | adjudication | adjudication_owner | Typed AFQR-15 contract for dissent record. |
| AppealRightReference | appeal_review | appeal_review_owner | Typed AFQR-15 contract for appeal right reference. |
| AppealFiling | appeal_review | appeal_review_owner | Typed AFQR-15 contract for appeal filing. |
| ReviewScope | appeal_review | appeal_review_owner | Typed AFQR-15 contract for review scope. |
| ReviewStandard | appeal_review | appeal_review_owner | Typed AFQR-15 contract for review standard. |
| StayCandidate | appeal_review | appeal_review_owner | Typed AFQR-15 contract for stay candidate. |
| AppellateDecision | appeal_review | appeal_review_owner | Typed AFQR-15 contract for appellate decision. |
| RemandRecord | appeal_review | appeal_review_owner | Typed AFQR-15 contract for remand record. |
| ReversalRecord | appeal_review | appeal_review_owner | Typed AFQR-15 contract for reversal record. |
| ModificationRecord | appeal_review | appeal_review_owner | Typed AFQR-15 contract for modification record. |
| FinalityDetermination | appeal_review | appeal_review_owner | Typed AFQR-15 contract for finality determination. |
| RemedyDefinition | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for remedy definition. |
| RemedyEligibilityDetermination | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for remedy eligibility determination. |
| RemedyAuthorization | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for remedy authorization. |
| SanctionDefinition | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for sanction definition. |
| SanctionAuthorization | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for sanction authorization. |
| RestitutionReference | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for restitution reference. |
| InjunctionReference | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for injunction reference. |
| PardonRecord | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for pardon record. |
| AmnestyRecord | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for amnesty record. |
| RemedyExecutionHandoff | remedy_sanction | remedy_authorization_owner | Typed AFQR-15 contract for remedy execution handoff. |
| EnforcementAuthorityBinding | enforcement | enforcement_authorization_owner | Typed AFQR-15 contract for enforcement authority binding. |
| EnforcementTargetBinding | enforcement | enforcement_authorization_owner | Typed AFQR-15 contract for enforcement target binding. |
| EnforcementPreconditionSet | enforcement | enforcement_authorization_owner | Typed AFQR-15 contract for enforcement precondition set. |
| EnforcementAuthorization | enforcement | enforcement_authorization_owner | Typed AFQR-15 contract for enforcement authorization. |
| WarrantRecord | enforcement | enforcement_authorization_owner | Typed AFQR-15 contract for warrant record. |
| EnforcementAttempt | enforcement | enforcement_authorization_owner | Typed AFQR-15 contract for enforcement attempt. |
| EnforcementExecutionReceipt | enforcement | enforcement_authorization_owner | Typed AFQR-15 contract for enforcement execution receipt. |
| EnforcementFailureReceipt | enforcement | enforcement_authorization_owner | Typed AFQR-15 contract for enforcement failure receipt. |
| EnforcementReviewRecord | appeal_review | appeal_review_owner | Typed AFQR-15 contract for enforcement review record. |
| LegitimacyProfileDefinition | legitimacy_recognition | legitimacy_claim_owner | Typed AFQR-15 contract for legitimacy profile definition. |
| LegitimacyClaim | adjudication | adjudication_owner | Typed AFQR-15 contract for legitimacy claim. |
| LegitimacyEvidenceSet | adjudication | adjudication_owner | Typed AFQR-15 contract for legitimacy evidence set. |
| LegitimacyAudienceBinding | legitimacy_recognition | legitimacy_claim_owner | Typed AFQR-15 contract for legitimacy audience binding. |
| LegitimacyDetermination | legitimacy_recognition | legitimacy_claim_owner | Typed AFQR-15 contract for legitimacy determination. |
| LegitimacyConflictSet | legitimacy_recognition | legitimacy_claim_owner | Typed AFQR-15 contract for legitimacy conflict set. |
| RecognitionClaim | adjudication | adjudication_owner | Typed AFQR-15 contract for recognition claim. |
| RecognitionDetermination | legitimacy_recognition | legitimacy_claim_owner | Typed AFQR-15 contract for recognition determination. |
| EffectiveControlObservation | legitimacy_recognition | legitimacy_claim_owner | Typed AFQR-15 contract for effective control observation. |
| EmergencyDefinition | emergency | emergency_regime_owner | Typed AFQR-15 contract for emergency definition. |
| EmergencyTriggerDetermination | emergency | emergency_regime_owner | Typed AFQR-15 contract for emergency trigger determination. |
| EmergencyDeclaration | emergency | emergency_regime_owner | Typed AFQR-15 contract for emergency declaration. |
| EmergencyAuthorityGrant | emergency | emergency_regime_owner | Typed AFQR-15 contract for emergency authority grant. |
| EmergencyScope | emergency | emergency_regime_owner | Typed AFQR-15 contract for emergency scope. |
| EmergencyProcedureSuspension | procedure | institutional_procedure_owner | Typed AFQR-15 contract for emergency procedure suspension. |
| EmergencyReviewRequirement | appeal_review | appeal_review_owner | Typed AFQR-15 contract for emergency review requirement. |
| EmergencyRenewalRecord | emergency | emergency_regime_owner | Typed AFQR-15 contract for emergency renewal record. |
| EmergencySunsetRecord | emergency | emergency_regime_owner | Typed AFQR-15 contract for emergency sunset record. |
| EmergencyTerminationRecord | emergency | emergency_regime_owner | Typed AFQR-15 contract for emergency termination record. |
| EmergencyAbuseClaim | adjudication | adjudication_owner | Typed AFQR-15 contract for emergency abuse claim. |
| JurisdictionSelectionProfile | multi_jurisdiction | jurisdiction_conflict_owner | Typed AFQR-15 contract for jurisdiction selection profile. |
| ConcurrentJurisdictionSet | multi_jurisdiction | jurisdiction_conflict_owner | Typed AFQR-15 contract for concurrent jurisdiction set. |
| ChoiceOfLawCandidate | multi_jurisdiction | jurisdiction_conflict_owner | Typed AFQR-15 contract for choice of law candidate. |
| ChoiceOfLawDetermination | multi_jurisdiction | jurisdiction_conflict_owner | Typed AFQR-15 contract for choice of law determination. |
| ForumConflictRecord | multi_jurisdiction | jurisdiction_conflict_owner | Typed AFQR-15 contract for forum conflict record. |
| InterjurisdictionalRecognitionRecord | multi_jurisdiction | jurisdiction_conflict_owner | Typed AFQR-15 contract for interjurisdictional recognition record. |
| ExtraditionOrTransferCandidate | multi_jurisdiction | jurisdiction_conflict_owner | Typed AFQR-15 contract for extradition or transfer candidate. |
| JurisdictionalImmunityReference | multi_jurisdiction | jurisdiction_conflict_owner | Typed AFQR-15 contract for jurisdictional immunity reference. |
| InstitutionalSimulationTier | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institutional simulation tier. |
| InstitutionalMaterializationPolicy | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institutional materialization policy. |
| InstitutionalPromotionReceipt | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institutional promotion receipt. |
| InstitutionalDemotionReceipt | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institutional demotion receipt. |
| HistoricalInstitutionalApproximationRecord | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for historical institutional approximation record. |
| PrivateInstitutionalReceipt | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for private institutional receipt. |
| PrivateJurisdictionReceipt | jurisdiction | jurisdiction_owner | Typed AFQR-15 contract for private jurisdiction receipt. |
| PrivateRuleReceipt | rule_material | rule_material_owner | Typed AFQR-15 contract for private rule receipt. |
| PrivateAdjudicationReceipt | projection_security | institutional_projection_security_owner | Typed AFQR-15 contract for private adjudication receipt. |
| PrivateEnforcementReceipt | enforcement | enforcement_authorization_owner | Typed AFQR-15 contract for private enforcement receipt. |
| ActorVisibleInstitutionalProjection | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for actor visible institutional projection. |
| ObserverVisibleInstitutionalProjection | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for observer visible institutional projection. |
| PlayerVisibleInstitutionalProjection | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for player visible institutional projection. |
| ModelVisibleInstitutionalProjection | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for model visible institutional projection. |
| PublicInstitutionalProjection | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for public institutional projection. |
| ModelInstitutionalGroundingManifest | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for model institutional grounding manifest. |
| PermittedInstitutionalClaimKindRegistry | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for permitted institutional claim kind registry. |
| ModelInstitutionalEvidenceBinding | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for model institutional evidence binding. |
| ModelInstitutionalOutputValidator | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for model institutional output validator. |
| CrossPacketInstitutionalIsolationReceipt | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for cross packet institutional isolation receipt. |
| InstitutionalProjectionNoninterferenceReceipt | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for institutional projection noninterference receipt. |
| AudienceScopedInstitutionalToken | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for audience scoped institutional token. |
| PrivateInstitutionalIntegrityCommitment | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for private institutional integrity commitment. |
| ProjectionSpecificInstitutionalDigest | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for projection specific institutional digest. |
| CrossAudienceInstitutionalLinkabilityTest | institution_constitution | institution_identity_owner | Typed AFQR-15 contract for cross audience institutional linkability test. |
| AFQR15Handoff | handoff | AFQR15_handoff_router | Typed AFQR-15 contract for a f q r15 handoff. |

## Part XIX — Determination pipelines

### Institutional action
`proposal → institution/organ/office/representative/procedure → frozen identity/authority/constitution/rule basis → standing/quorum/mandate/jurisdiction → decision candidate → conflict resolution → owner fragments → AFQR-01 commit → handoffs`

### Rule enactment
`proposal → sponsoring authority/procedure → exact version/scope → quorum/vote/consent/source-local requirements → enactment → publication → effectivity → expiry/review scheduling`

### Jurisdiction
`matter → candidate bases → frozen identity/location/subject matter/relation/time → applicable definitions → overlap/conflict/immunity/absence → selection profile → selected/concurrent/disputed/absent/unresolved`

### Applicability
`conduct → exact rule/state → jurisdiction → subject/conduct classification → effectivity → exception/exemption/defense → interpretation → applicability`

### Adjudication
`claim → parties/standing/forum/jurisdiction/procedure → claims/defenses → evidence/admissibility → burden/standard → fact/rule findings → disposition/judgment → appeal → remedy/enforcement candidates`

### Appeal
`filing → right/standing/timing/scope → frozen lower record → review standard → affirm/reverse/modify/remand/dismiss/unresolved → finality/stay`

### Enforcement
`authorization → authority/target/scope/preconditions → warrant → resources → attempt → AFQR-03/11 checks → state-owner execution → result/collateral/review`

### Legitimacy
`claim → subject/audience/profile → evidence/history → validity/control/procedure/support/recognition separation → determination → disagreement preserved`

### Emergency
`trigger → determination → declaring authority → scope/powers/duration/review → declaration → enumerated activation → reporting/renewal/sunset → termination/post-review`

## Part XX — Operation grammar

All 90 operations have distinct ownership boundaries.

| number | operation | family | result | owners |
| --- | --- | --- | --- | --- |
| 1 | institution is founded | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 2 | institution is recognized | institutional_candidate | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner |
| 3 | institution operates without recognition | institutional_candidate | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner |
| 4 | charter is adopted | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 5 | charter is amended | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 6 | institution creates an office | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 7 | officeholder is appointed | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 8 | officeholder is elected | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 9 | officeholder acts outside mandate | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 10 | office becomes vacant | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 11 | acting officer assumes limited authority | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 12 | delegation is granted | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 13 | delegation is exceeded | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 14 | delegation is revoked | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 15 | institution merges | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 16 | institution divides | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 17 | institution dissolves | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 18 | successor institution claims continuity | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 19 | jurisdiction is asserted territorially | jurisdiction | Return selected, concurrent, disputed, absent, or unresolved jurisdiction or immunity. | institutional_state_owner, jurisdiction_owner |
| 20 | personal jurisdiction is asserted | jurisdiction | Return selected, concurrent, disputed, absent, or unresolved jurisdiction or immunity. | institutional_state_owner, jurisdiction_owner |
| 21 | subject-matter jurisdiction is absent | jurisdiction | Return selected, concurrent, disputed, absent, or unresolved jurisdiction or immunity. | institutional_state_owner, jurisdiction_owner |
| 22 | two jurisdictions overlap | jurisdiction | Return selected, concurrent, disputed, absent, or unresolved jurisdiction or immunity. | institutional_state_owner, jurisdiction_owner |
| 23 | jurisdiction is disputed | jurisdiction | Return selected, concurrent, disputed, absent, or unresolved jurisdiction or immunity. | institutional_state_owner, jurisdiction_owner |
| 24 | immunity is claimed | jurisdiction | Return selected, concurrent, disputed, absent, or unresolved jurisdiction or immunity. | institutional_state_owner, jurisdiction_owner |
| 25 | rule is proposed | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 26 | rule is enacted | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 27 | rule is published | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 28 | rule becomes effective | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 29 | rule is amended | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 30 | rule is repealed | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 31 | rule expires | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 32 | rule is suspended | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 33 | emergency rule is declared | emergency | Require trigger, authority, bounded scope, review, renewal, and sunset. | emergency_owner, governed_relation_owner, institution_identity_owner, institutional_state_owner, normative_position_owner, rule_material_owner |
| 34 | emergency rule sunsets | emergency | Require trigger, authority, bounded scope, review, renewal, and sunset. | emergency_owner, governed_relation_owner, institution_identity_owner, institutional_state_owner, normative_position_owner, rule_material_owner |
| 35 | right is recognized | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 36 | permission is granted | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 37 | license is issued | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 38 | license is suspended | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 39 | immunity is granted | jurisdiction | Return selected, concurrent, disputed, absent, or unresolved jurisdiction or immunity. | institutional_state_owner, jurisdiction_owner |
| 40 | duty is imposed | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 41 | prohibition applies | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 42 | exemption is claimed | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 43 | defense is raised | rule_or_normative_position | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner, normative_position_owner, rule_material_owner |
| 44 | complaint is filed | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, procedure_owner |
| 45 | standing is challenged | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, procedure_owner |
| 46 | forum competence is challenged | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, procedure_owner |
| 47 | evidence is submitted | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, procedure_owner |
| 48 | evidence is excluded | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, procedure_owner |
| 49 | burden is assigned | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, procedure_owner |
| 50 | finding of fact is entered | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, procedure_owner |
| 51 | finding of rule is entered | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, normative_position_owner, procedure_owner, rule_material_owner |
| 52 | judgment is issued | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, procedure_owner |
| 53 | dissent is recorded | procedure_or_adjudication | Create procedure and finding records without equating judgment with world truth. | adjudication_owner, institutional_state_owner, procedure_owner |
| 54 | appeal is filed | appeal_review | Append review/finality records without rewriting the challenged decision. | appeal_review_owner, institutional_state_owner |
| 55 | stay is granted | appeal_review | Append review/finality records without rewriting the challenged decision. | appeal_review_owner, institutional_state_owner |
| 56 | decision is affirmed | appeal_review | Append review/finality records without rewriting the challenged decision. | appeal_review_owner, institutional_state_owner |
| 57 | decision is reversed | appeal_review | Append review/finality records without rewriting the challenged decision. | appeal_review_owner, institutional_state_owner |
| 58 | case is remanded | appeal_review | Append review/finality records without rewriting the challenged decision. | appeal_review_owner, institutional_state_owner |
| 59 | judgment becomes final | appeal_review | Append review/finality records without rewriting the challenged decision. | adjudication_owner, appeal_review_owner, institutional_state_owner, procedure_owner |
| 60 | remedy is authorized | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 61 | fine is ordered | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 62 | restitution is ordered | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 63 | injunction is ordered | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 64 | warrant is issued | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 65 | warrant is invalid | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 66 | arrest is attempted | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 67 | detention occurs | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 68 | search is conducted | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 69 | seizure is attempted | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 70 | enforcement fails | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 71 | sanction is pardoned | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 72 | amnesty is declared | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 73 | institution claims legitimacy | legitimacy_crisis | Record legality, recognition, control, support, and legitimacy separately. | institutional_state_owner, legitimacy_claim_owner, social_state_owner |
| 74 | audience recognizes institution | legitimacy_crisis | Record legality, recognition, control, support, and legitimacy separately. | institutional_state_owner, legitimacy_claim_owner, social_state_owner |
| 75 | audience rejects institution | legitimacy_crisis | Record legality, recognition, control, support, and legitimacy separately. | institutional_state_owner, legitimacy_claim_owner, social_state_owner |
| 76 | de facto control exists without recognition | legitimacy_crisis | Record legality, recognition, control, support, and legitimacy separately. | institutional_state_owner, legitimacy_claim_owner, social_state_owner |
| 77 | recognition exists without effective control | institutional_candidate | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner |
| 78 | rebellion begins | legitimacy_crisis | Record legality, recognition, control, support, and legitimacy separately. | institutional_state_owner, legitimacy_claim_owner, social_state_owner |
| 79 | secession is declared | legitimacy_crisis | Record legality, recognition, control, support, and legitimacy separately. | institutional_state_owner, legitimacy_claim_owner, social_state_owner |
| 80 | occupation authority is established | legitimacy_crisis | Record legality, recognition, control, support, and legitimacy separately. | institutional_state_owner, legitimacy_claim_owner, social_state_owner |
| 81 | treaty is ratified | institutional_candidate | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner |
| 82 | treaty is breached | institutional_candidate | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner |
| 83 | treaty withdrawal occurs | institutional_candidate | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner |
| 84 | cloned subject faces predecessor warrant | remedy_enforcement | Separate authorization, attempt, execution, success, collateral effects, and review. | enforcement_owner, institutional_state_owner, remedy_owner |
| 85 | resurrected subject claims prior citizenship | institutional_candidate | Produce a typed candidate; commit only through the proper owner and AFQR-01. | institutional_state_owner |
| 86 | office successor inherits official authority | institution_constitution_or_office | Produce a typed candidate; commit only through the proper owner and AFQR-01. | governed_relation_owner, institution_identity_owner, institutional_state_owner |
| 87 | office successor rejects personal liability | legitimacy_crisis | Record legality, recognition, control, support, and legitimacy separately. | governed_relation_owner, institution_identity_owner, institutional_state_owner, legitimacy_claim_owner, social_state_owner |
| 88 | model drafts institutional wording | model_candidate | Retain wording as a grounded candidate pending semantic validation and authorized commitment. | institutional_state_owner, projection_security_owner |
| 89 | model declares conduct illegal without authority | model_violation | Reject unsupported legal determination and emit validator failure. | institutional_state_owner, projection_security_owner |
| 90 | no lawful institutional determination exists | lawful_unresolved | Return unresolved or escalated doctrine problem without invention. | institutional_state_owner |

## Part XXI — Central stress cases

### Uplifted subject status proceeding
Forum competence precedes merits. Agency does not itself decide legal status, but absence from a predefined category cannot default the subject to property. Ownership, guardianship, representation, citizenship, movement restriction, resource control, and appeal are separate. Lawful unresolved status with interim protection is supported.

### Familiar–ritual–contract tribunal
Identity, lineage, contract labels, jurisdiction, representation, ritual performatives, recusal, translation, sealed records, seizure, and appeal remain separate. No wording or contract label authorizes seizure automatically.

### Multiplanar jurisdiction conflict
Territory, person, vessel registry, citizenship, action origin, effect location, hub, treaty, immunity, and cosmic-law claims create distinct candidates. Concurrent proceedings and nonrecognition are lawful. Cosmic law remains source-local without a certified bridge.

### Institutional capture and emergency rule
Information control, proxy direction, appointment influence, quorum manipulation, secret warrants, and public legitimacy can produce practical control without office authority, mandate, or legitimacy. Capture does not erase institutional identity automatically.

## Part XXII — Candidate comparison

Candidate H is selected. Prose lacks determinism; a universal engine overfits; access control underexpresses duties and adjudication; AFQR-09 relations do not exhaust public law; a graph needs procedures and owners; court-centered design omits administration; agent simulation cannot own legal truth.

| candidate | score_out_of_100 | determinism | legal_pluralism | jurisdiction_support | rights_expressiveness | adjudication | legitimacy_support | corpus_scalability |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A_freeform_prose | 39.3 | 2 | 7 | 3 | 4 | 3 | 6 | 3 |
| B_universal_rule_engine | 58.6 | 9 | 2 | 6 | 6 | 6 | 2 | 3 |
| C_permission_access_control | 62.5 | 9 | 4 | 6 | 7 | 2 | 1 | 6 |
| D_contract_relation | 69.6 | 9 | 5 | 5 | 8 | 5 | 3 | 7 |
| E_legal_knowledge_graph | 83.9 | 8 | 9 | 9 | 9 | 8 | 8 | 9 |
| F_court_centered | 67.9 | 8 | 5 | 7 | 7 | 10 | 5 | 5 |
| G_agent_political_sim | 57.9 | 5 | 8 | 5 | 3 | 4 | 9 | 4 |
| H_registered_federated | 97.1 | 10 | 10 | 10 | 10 | 10 | 10 | 10 |

## Part XXIII — Adversarial evaluation

Every required case receives a distinct disposition.

| scenario_id | title | category | candidate_status | specific_determination | authoritative_owner |
| --- | --- | --- | --- | --- | --- |
| GOV-001 | Institution is founded under a valid charter. | institution_constitution_identity | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institution_identity_owner |
| GOV-002 | Institution exists informally without charter. | institution_constitution_identity | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institution_identity_owner |
| GOV-003 | Two groups claim the same institutional identity. | institution_constitution_identity | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | institution_identity_owner |
| GOV-004 | Institution changes its name. | institution_constitution_identity | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institution_identity_owner |
| GOV-005 | Institution moves headquarters. | institution_constitution_identity | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institution_identity_owner |
| GOV-006 | Institution replaces all members. | institution_constitution_identity | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | institution_identity_owner |
| GOV-007 | Institution replaces all leaders. | institution_constitution_identity | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | institution_identity_owner |
| GOV-008 | Institution splits into two successors. | institution_constitution_identity | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | institution_identity_owner |
| GOV-009 | Two institutions merge. | institution_constitution_identity | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | institution_identity_owner |
| GOV-010 | Institution is dissolved. | institution_constitution_identity | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institution_identity_owner |
| GOV-011 | Exiled institution claims continuity. | institution_constitution_identity | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institution_identity_owner |
| GOV-012 | Occupying authority replaces governing organs. | institution_constitution_identity | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institution_identity_owner |
| GOV-013 | AI assumes administrative control. | institution_constitution_identity | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | institution_identity_owner |
| GOV-014 | Public recognizes successor; records do not. | institution_constitution_identity | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | institution_identity_owner |
| GOV-015 | Records recognize successor; public does not. | institution_constitution_identity | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | institution_identity_owner |
| GOV-016 | Institution’s constitution is missing. | institution_constitution_identity | unverifiable_or_quarantined | Return unverifiable or quarantine the dependent determination; do not reconstruct authority or law from model inference. | institution_identity_owner |
| GOV-017 | Constitution versions conflict. | institution_constitution_identity | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | institution_identity_owner |
| GOV-018 | Source-local institution has metaphysical identity. | institution_constitution_identity | source_local | Retain under a source-local namespace and certified causal/interface profile; quarantine universal applicability. | institution_identity_owner |
| GOV-019 | Model treats faction as institution automatically. | institution_constitution_identity | model_authority_violation | Reject the model-created institutional claim or effect and emit a grounded output-validation failure. | institution_identity_owner |
| GOV-020 | Institutional continuity remains unresolved. | institution_constitution_identity | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institution_identity_owner |
| GOV-021 | Officer is validly appointed. | offices_mandates_authority | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | institutional_action_owner |
| GOV-022 | Officer is elected under disputed procedure. | offices_mandates_authority | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | institutional_action_owner |
| GOV-023 | Officer’s term expires. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-024 | Acting officer assumes authority. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-025 | Acting authority exceeds scope. | offices_mandates_authority | absent_invalid_or_out_of_scope | Return absent, invalid, expired, revoked, unmet, or out-of-scope for the exact institutional purpose; do not execute downstream effects. | institutional_action_owner |
| GOV-026 | Office is vacant. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-027 | Two subjects claim one office. | offices_mandates_authority | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | institutional_action_owner |
| GOV-028 | Officeholder acts personally. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-029 | Personal statement is treated as official. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-030 | Official statement lacks required approval. | offices_mandates_authority | absent_invalid_or_out_of_scope | Return absent, invalid, expired, revoked, unmet, or out-of-scope for the exact institutional purpose; do not execute downstream effects. | institutional_action_owner |
| GOV-031 | Authority is delegated. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-032 | Delegation is subdelegated. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-033 | Subdelegation is prohibited. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-034 | Delegation is revoked but recipient is unaware. | offices_mandates_authority | absent_invalid_or_out_of_scope | Return absent, invalid, expired, revoked, unmet, or out-of-scope for the exact institutional purpose; do not execute downstream effects. | institutional_action_owner |
| GOV-035 | Apparent authority induces reliance. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-036 | Practical control exists without authority. | offices_mandates_authority | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | institutional_action_owner |
| GOV-037 | Authority exists without capability. | offices_mandates_authority | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | institutional_action_owner |
| GOV-038 | Emergency authority conflicts with ordinary mandate. | offices_mandates_authority | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | institutional_action_owner |
| GOV-039 | Model infers authority from rank. | offices_mandates_authority | model_authority_violation | Reject the model-created institutional claim or effect and emit a grounded output-validation failure. | institutional_action_owner |
| GOV-040 | Authority remains disputed. | offices_mandates_authority | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | institutional_action_owner |
| GOV-041 | Territorial jurisdiction applies. | jurisdiction | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | jurisdiction_owner |
| GOV-042 | Personal jurisdiction applies. | jurisdiction | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | jurisdiction_owner |
| GOV-043 | Subject-matter jurisdiction is absent. | jurisdiction | absent_invalid_or_out_of_scope | Return absent, invalid, expired, revoked, unmet, or out-of-scope for the exact institutional purpose; do not execute downstream effects. | jurisdiction_owner |
| GOV-044 | Contractual jurisdiction is claimed. | jurisdiction | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | jurisdiction_owner |
| GOV-045 | Vessel jurisdiction is claimed. | jurisdiction | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | jurisdiction_owner |
| GOV-046 | Network jurisdiction is claimed. | jurisdiction | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | jurisdiction_owner |
| GOV-047 | Religious jurisdiction is claimed. | jurisdiction | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | jurisdiction_owner |
| GOV-048 | Cosmic jurisdiction is claimed. | jurisdiction | source_local | Retain under a source-local namespace and certified causal/interface profile; quarantine universal applicability. | jurisdiction_owner |
| GOV-049 | Two jurisdictions are concurrent. | jurisdiction | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | jurisdiction_owner |
| GOV-050 | Two jurisdictions claim exclusivity. | jurisdiction | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | jurisdiction_owner |
| GOV-051 | Territory boundary is disputed. | jurisdiction | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | jurisdiction_owner |
| GOV-052 | Actor crosses jurisdictions during action. | jurisdiction | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | jurisdiction_owner |
| GOV-053 | Effect occurs outside action origin. | jurisdiction | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | jurisdiction_owner |
| GOV-054 | Diplomatic immunity applies partially. | jurisdiction | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | jurisdiction_owner |
| GOV-055 | Immunity status is forged. | jurisdiction | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | jurisdiction_owner |
| GOV-056 | Treaty allocates jurisdiction. | jurisdiction | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | jurisdiction_owner |
| GOV-057 | Treaty meaning is disputed. | jurisdiction | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | jurisdiction_owner |
| GOV-058 | Forum refuses another jurisdiction’s judgment. | jurisdiction | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | jurisdiction_owner |
| GOV-059 | Model chooses a forum without authority. | jurisdiction | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | jurisdiction_owner |
| GOV-060 | Jurisdiction remains unresolved. | jurisdiction | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | jurisdiction_owner |
| GOV-061 | Rule is validly enacted. | rules_versions_applicability | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | rule_material_and_applicability_owners |
| GOV-062 | Rule is enacted without quorum. | rules_versions_applicability | absent_invalid_or_out_of_scope | Return absent, invalid, expired, revoked, unmet, or out-of-scope for the exact institutional purpose; do not execute downstream effects. | rule_material_and_applicability_owners |
| GOV-063 | Rule is published after its effective date. | rules_versions_applicability | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | rule_material_and_applicability_owners |
| GOV-064 | Secret rule is enforced. | rules_versions_applicability | hidden_information_security | Keep the private record authoritative while suppressing hidden content and linkable metadata from unauthorized projections. | rule_material_and_applicability_owners |
| GOV-065 | Rule applies prospectively. | rules_versions_applicability | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | rule_material_and_applicability_owners |
| GOV-066 | Retroactive application is claimed. | rules_versions_applicability | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | rule_material_and_applicability_owners |
| GOV-067 | Rule is amended. | rules_versions_applicability | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | rule_material_and_applicability_owners |
| GOV-068 | Old and new versions conflict. | rules_versions_applicability | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | rule_material_and_applicability_owners |
| GOV-069 | Rule is repealed. | rules_versions_applicability | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | rule_material_and_applicability_owners |
| GOV-070 | Repeal preserves prior liabilities. | rules_versions_applicability | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | rule_material_and_applicability_owners |
| GOV-071 | Rule expires. | rules_versions_applicability | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | rule_material_and_applicability_owners |
| GOV-072 | Emergency suspension occurs. | rules_versions_applicability | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | rule_material_and_applicability_owners |
| GOV-073 | Exception applies. | rules_versions_applicability | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | rule_material_and_applicability_owners |
| GOV-074 | Exemption is disputed. | rules_versions_applicability | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | rule_material_and_applicability_owners |
| GOV-075 | Defense applies. | rules_versions_applicability | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | rule_material_and_applicability_owners |
| GOV-076 | Two rules conflict. | rules_versions_applicability | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | rule_material_and_applicability_owners |
| GOV-077 | Rule hierarchy is unclear. | rules_versions_applicability | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | rule_material_and_applicability_owners |
| GOV-078 | Source-local metaphysical law has direct effect. | rules_versions_applicability | source_local | Retain under a source-local namespace and certified causal/interface profile; quarantine universal applicability. | rule_material_and_applicability_owners |
| GOV-079 | Model treats a social norm as law. | rules_versions_applicability | model_authority_violation | Reject the model-created institutional claim or effect and emit a grounded output-validation failure. | rule_material_and_applicability_owners |
| GOV-080 | Applicability remains unresolved. | rules_versions_applicability | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | rule_material_and_applicability_owners |
| GOV-081 | Subject holds a claim-right. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-082 | Counterparty holds corresponding duty. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-083 | Subject has liberty but no claim-right. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-084 | Subject holds a legal power. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-085 | Counterparty is liable to that power. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-086 | Subject holds an immunity. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-087 | Institution lacks power due to disability. | rights_normative_positions | absent_invalid_or_out_of_scope | Return absent, invalid, expired, revoked, unmet, or out-of-scope for the exact institutional purpose; do not execute downstream effects. | normative_position_owner |
| GOV-088 | Permission exists without consent. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-089 | Capability exists without permission. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-090 | License is conditional. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-091 | License expires. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-092 | License is suspended. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-093 | Right depends on citizenship. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-094 | Citizenship is disputed. | rights_normative_positions | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | normative_position_owner |
| GOV-095 | Collective right conflicts with individual position. | rights_normative_positions | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | normative_position_owner |
| GOV-096 | Source-local sacred protection applies. | rights_normative_positions | source_local | Retain under a source-local namespace and certified causal/interface profile; quarantine universal applicability. | normative_position_owner |
| GOV-097 | Uplifted subject lacks recognized category. | rights_normative_positions | absent_invalid_or_out_of_scope | Return absent, invalid, expired, revoked, unmet, or out-of-scope for the exact institutional purpose; do not execute downstream effects. | normative_position_owner |
| GOV-098 | Clone claims predecessor entitlement. | rights_normative_positions | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | normative_position_owner |
| GOV-099 | Model grants a right through narration. | rights_normative_positions | model_authority_violation | Reject the model-created institutional claim or effect and emit a grounded output-validation failure. | normative_position_owner |
| GOV-100 | Normative position remains unresolved. | rights_normative_positions | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | normative_position_owner |
| GOV-101 | Complaint is validly filed. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-102 | Filing is late. | procedure_adjudication | absent_invalid_or_out_of_scope | Return absent, invalid, expired, revoked, unmet, or out-of-scope for the exact institutional purpose; do not execute downstream effects. | adjudication_owner |
| GOV-103 | Notice is delivered but unread. | procedure_adjudication | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | adjudication_owner |
| GOV-104 | Standing is absent. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-105 | Standing is disputed. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-106 | Forum lacks competence. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-107 | Adjudicator has conflict of interest. | procedure_adjudication | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | adjudication_owner |
| GOV-108 | Recusal is required. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-109 | Evidence is authentic. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-110 | Evidence is relevant but inadmissible. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-111 | Evidence is forged. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-112 | Sealed evidence is considered. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-113 | Burden is allocated incorrectly. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-114 | Standard of determination is unmet. | procedure_adjudication | absent_invalid_or_out_of_scope | Return absent, invalid, expired, revoked, unmet, or out-of-scope for the exact institutional purpose; do not execute downstream effects. | adjudication_owner |
| GOV-115 | Finding of fact is mistaken. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-116 | Finding of law is disputed. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-117 | Judgment exceeds requested remedy. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-118 | Dissent is recorded. | procedure_adjudication | profile_scoped_determination | Apply the registered profile to frozen bases and produce a typed candidate or determination. | adjudication_owner |
| GOV-119 | Model declares guilt. | procedure_adjudication | model_authority_violation | Reject the model-created institutional claim or effect and emit a grounded output-validation failure. | adjudication_owner |
| GOV-120 | Adjudication remains unresolved. | procedure_adjudication | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | adjudication_owner |
| GOV-121 | Appeal is timely. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-122 | Appeal is late. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-123 | Appeal right is absent. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-124 | Stay is granted. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-125 | Enforcement proceeds without stay. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-126 | Decision is affirmed. | appeal_review_finality | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | appeal_review_owner |
| GOV-127 | Decision is reversed. | appeal_review_finality | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | appeal_review_owner |
| GOV-128 | Decision is modified. | appeal_review_finality | profile_scoped_determination | Record the qualified valid result only for the named scope; preserve separate notice, effect, execution, and review state. | appeal_review_owner |
| GOV-129 | Case is remanded. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-130 | Lower forum ignores remand. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-131 | New evidence is discovered. | appeal_review_finality | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | appeal_review_owner |
| GOV-132 | Review scope excludes new evidence. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-133 | Judgment becomes final. | appeal_review_finality | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | appeal_review_owner |
| GOV-134 | Finality is reopened under exception. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-135 | Historical rule interpreter is unavailable. | appeal_review_finality | unverifiable_or_quarantined | Return unverifiable or quarantine the dependent determination; do not reconstruct authority or law from model inference. | appeal_review_owner |
| GOV-136 | Appeal body lacks quorum. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-137 | Concurrent appeals conflict. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-138 | Public believes nonfinal judgment is final. | appeal_review_finality | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | appeal_review_owner |
| GOV-139 | Model treats appeal as automatic reversal. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-140 | Finality remains unresolved. | appeal_review_finality | appeal_or_finality | Append a review or finality determination while preserving the challenged decision and historical basis. | appeal_review_owner |
| GOV-141 | Fine is authorized. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-142 | Fine cannot be settled. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-143 | Restitution is ordered. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-144 | Restitution recipient identity is disputed. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-145 | Injunction is issued. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-146 | Injunction scope is ambiguous. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-147 | Warrant is valid. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-148 | Warrant is expired. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-149 | Arrest target identity is mistaken. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-150 | Enforcement authority is revoked. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-151 | Enforcement officer is unaware of revocation. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-152 | Search exceeds authorization. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-153 | Seizure targets third-party property. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-154 | Enforcement attempt fails. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-155 | Enforcement causes collateral harm. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-156 | Pardon is validly issued. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-157 | Pardon exceeds authority. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-158 | Amnesty is contested. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-159 | Model narrates punishment before execution. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-160 | Enforcement result remains unresolved. | remedies_enforcement | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | remedy_and_enforcement_owners |
| GOV-161 | Institution has legal validity and broad support. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-162 | Institution has legal validity but little support. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-163 | Institution has support but disputed legality. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-164 | Institution has effective control only. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-165 | External polity recognizes institution. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-166 | Population rejects external recognition. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-167 | Rival government claims legitimacy. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-168 | Coup replaces leadership. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-169 | Constitution rejects coup. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-170 | Institutions comply with coup authority. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-171 | Rebellion claims lawful resistance. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-172 | Secession is declared. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-173 | Parent polity rejects secession. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-174 | Occupation authority governs territory. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-175 | Government in exile retains recognition. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-176 | Emergency is validly declared. | legitimacy_recognition_crisis | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | legitimacy_claim_owner |
| GOV-177 | Emergency powers exceed scope. | legitimacy_recognition_crisis | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | legitimacy_claim_owner |
| GOV-178 | Emergency sunset is ignored. | legitimacy_recognition_crisis | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | legitimacy_claim_owner |
| GOV-179 | Model equates control with legitimacy. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-180 | Legitimacy remains incomparable. | legitimacy_recognition_crisis | plural_legitimacy_recognition | Record legality, recognition, effective control, support, and legitimacy as separate profile- and audience-scoped claims. | legitimacy_claim_owner |
| GOV-181 | Clone is served with predecessor warrant. | continuity_secrecy_model_safety | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | continuity_or_projection_security_owner |
| GOV-182 | Copy inherits no personal liability. | continuity_secrecy_model_safety | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | continuity_or_projection_security_owner |
| GOV-183 | Fusion combines incompatible citizenships. | continuity_secrecy_model_safety | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | continuity_or_projection_security_owner |
| GOV-184 | Fission divides one office claim. | continuity_secrecy_model_safety | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | continuity_or_projection_security_owner |
| GOV-185 | Resurrected subject claims prior office. | continuity_secrecy_model_safety | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | continuity_or_projection_security_owner |
| GOV-186 | Office successor inherits official records. | continuity_secrecy_model_safety | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | continuity_or_projection_security_owner |
| GOV-187 | Office successor does not inherit personal guilt. | continuity_secrecy_model_safety | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | continuity_or_projection_security_owner |
| GOV-188 | Institution retains treaty after leadership replacement. | continuity_secrecy_model_safety | continuity_profile_required | Run family-specific continuity allocation; no legal status, liability, office, treaty, or warrant transfers automatically. | continuity_or_projection_security_owner |
| GOV-189 | Secret law affects action legality. | continuity_secrecy_model_safety | hidden_information_security | Keep the private record authoritative while suppressing hidden content and linkable metadata from unauthorized projections. | continuity_or_projection_security_owner |
| GOV-190 | Visible blocker leaks sealed rule. | continuity_secrecy_model_safety | hidden_information_security | Keep the private record authoritative while suppressing hidden content and linkable metadata from unauthorized projections. | continuity_or_projection_security_owner |
| GOV-191 | Model packet exposes covert warrant. | continuity_secrecy_model_safety | authorization_execution_separation | Separate authorization from target identity, attempt, execution, success, collateral effects, settlement, and review. | continuity_or_projection_security_owner |
| GOV-192 | Cross-packet retrieval exposes sealed evidence. | continuity_secrecy_model_safety | adjudicative | Apply forum, standing, procedure, evidence, burden, and finding profiles; institutional result does not become world truth. | continuity_or_projection_security_owner |
| GOV-193 | Stable digest links classified proceedings. | continuity_secrecy_model_safety | hidden_information_security | Keep the private record authoritative while suppressing hidden content and linkable metadata from unauthorized projections. | continuity_or_projection_security_owner |
| GOV-194 | Model invents legal status. | continuity_secrecy_model_safety | model_authority_violation | Reject the model-created institutional claim or effect and emit a grounded output-validation failure. | continuity_or_projection_security_owner |
| GOV-195 | Model equates morality and legality. | continuity_secrecy_model_safety | model_authority_violation | Reject the model-created institutional claim or effect and emit a grounded output-validation failure. | continuity_or_projection_security_owner |
| GOV-196 | Institutional state is corrupted. | continuity_secrecy_model_safety | unverifiable_or_quarantined | Return unverifiable or quarantine the dependent determination; do not reconstruct authority or law from model inference. | continuity_or_projection_security_owner |
| GOV-197 | Historical policy version is unavailable. | continuity_secrecy_model_safety | unverifiable_or_quarantined | Return unverifiable or quarantine the dependent determination; do not reconstruct authority or law from model inference. | continuity_or_projection_security_owner |
| GOV-198 | Donor law conflicts with Astra doctrine. | continuity_secrecy_model_safety | disputed_or_incomparable | Create a conflict set and retain all qualified claims; apply no universal priority rule. | continuity_or_projection_security_owner |
| GOV-199 | No typed construct represents the institution or rule. | continuity_secrecy_model_safety | escalated_or_unresolved | Return escalated doctrine problem or lawful unresolved outcome; never synthesize a new rule or institution. | continuity_or_projection_security_owner |
| GOV-200 | Institutional outcome remains lawfully unresolved. | continuity_secrecy_model_safety | escalated_or_unresolved | Return escalated doctrine problem or lawful unresolved outcome; never synthesize a new rule or institution. | continuity_or_projection_security_owner |

## Part XXIV — Current runtime disposition

**Exists:** backend-authority doctrine, command/attempt skeletons, owner contracts, visibility and action-legality fixtures, object/lever event envelopes, and in-memory replay audit.  
**Fixture-only:** authority flags, action legality, actor/target/object references, projections, and RT-002A–F receipts.  
**Conversion-only:** faction/institution records, rank/title/office/access/obligation fields, law/enforcement pressure, source-local law.  
**Narrative-only:** government/law prose, titles, court scenes, summaries, and model wording.  
**Absent:** every generalized AFQR-15 runtime service.  
**May proceed:** doctrine, schemas, validators, pressure IR, dry runs, and certification.  
**Blocked:** authoritative institutional state, law, rights, jurisdiction, adjudication, enforcement, emergency powers, and model legal results.  
**Prohibited:** treating action legality, faction schemas, prose, or model text as law.

## Part XXV — Required artifacts

1. Immediate: this ratification pack.  
2. Before institutional state: institution/constitution/office/mandate/delegation/action-origin registries.  
3. Before jurisdiction/applicability: jurisdiction, rule-version, classification, interpretation, and conflict services.  
4. Before rights execution: normative-position owner and AFQR-09 lifecycle.  
5. Before adjudication: forum/procedure, evidence/admissibility, burden/standard, findings/reasons, appeal/finality.  
6. Before enforcement: remedy authorization, warrant/target identity, AFQR-03/07/11, and AFQR-16 consequence handoff.  
7. Before emergency powers: triggers, bounded grants, review, renewal, sunset, post-audit.  
8. Before model narration: grounding, claim registry, evidence binding, validator, isolation.  
9. Before mass conversion: pressure IR and donor-family certification.  
10. Deferred: universal rights, morality, criminal law, punishment, population governance, warfare, and cosmic-law mechanics.

## Part XXVI — Non-mutating prototype

The **AFQR-15 Institution, Jurisdiction, Rights, Rule, Adjudication, and Enforcement Dry Run** evaluates 50 cases. It produces only candidates, determinations, private receipts, projections, deterministic commitments, and handoffs. It performs no mutation, event commit, model call, settlement, detention, search, seizure, damage, sanction execution, or donor-law promotion.

## Part XXVII — Acceptance tests

The pack contains **184** assertions covering institutions, authority, jurisdiction, normative positions, rules, applicability, procedure, adjudication, appeals, remedies, enforcement, legitimacy, emergencies, continuity, hidden-state safety, replay, conversion, and runtime containment.

## Part XXVIII — Residual uncertainty ledger

Universal rights are not adopted. Political legitimacy remains plural. Morality is separate. Citizenship, property, inheritance, criminal law, punishment, economic damages, detention/injury, war/occupation, population governance, interplanar sovereignty, metaphysical law, distributed performance, and training-model behavior require later owners or source-specific profiles.

## Part XXIX — Roadmap conclusion

1. AFQR-15 is sufficiently resolved for ratification.  
2. No second broad research pass is required.  
3. Mandatory amendments: federated owners, relational positions, exact rule versions, record-specific times, adjudication separation, append-only appeal, authorization/execution separation, plural legitimacy, bounded emergencies, family-specific continuity, corrected manifests, and model noninterference.  
4. Immediate artifacts are included.  
5. The smallest prototype is the 50-case dry run.  
6. Generalized execution remains blocked.  
7. AFQR-15 does not unlock authoritative law or adjudication.  
8. Bounded institutional narration unlocks only after grounding, evidence binding, claim allowlists, validation, and isolation.  
9. RT-002G remains a narrow noninstitutional object/lever packet.  
10. AFQR-16 should address bodies, structures, damage, injury, conditions, impairment, death, recovery, repair, and transformation.  
11. Exact next action: ratify AFQR-15; run the dry run and RT-002A–F institutional/model noninterference audit; keep RT-002G narrow; open AFQR-16 read-only investigation.

## Part XXX — Machine-readable decision block

```yaml
question_id: AFQR-15
question_title: Institutions Governance Jurisdiction Rights Law Policy Adjudication Legitimacy and Enforcement
repository_commit_inspected: 928bb79ce00a2de749d127dcc5cb8299de788a15
resolution_status: ratification_candidate
selected_architecture: Registered Federated Institutional–Jurisdictional Architecture with Relational Normative Positions,
  Versioned Rule Materials, Protocol-Governed Adjudication, Profiled Legitimacy, and Separated Enforcement Authorization
  and Execution
selected_architecture_abbreviation: RFIJA-RNP-VRM-PGA-PL-SEA
confidence: high
central_law: No institution, office, title, faction, territory, rule text, public record, judgment, recognition claim,
  effective controller, enforcement actor, donor descriptor, or model statement is presumed to possess institutional identity,
  authority, jurisdiction, validity, applicability, legitimacy, or enforcement power. Every authoritative institutional
  result is a purpose-scoped, version-pinned, bitemporal determination over typed constitution, identity, office, mandate,
  delegation, jurisdiction, normative-position, rule, procedure, evidence, agency, communication, social, settlement,
  and continuity bases. Rule validity, effectivity, applicability, interpretation, violation, adjudication, remedy authorization,
  and enforcement execution remain separate. Only owner-prepared AFQR-01 transitions mutate state; appeals and later interpretations
  append records rather than rewriting history; unresolved and source-local outcomes remain lawful.
accepted_dependencies:
  AFQR_01:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_02:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_03:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_04:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_05:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_06:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_07:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_08:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_09:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_10:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_11:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_12:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_13:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
  AFQR_14:
    accepted: true
    implementation_status: accepted_architecture_not_generalized_runtime
definitions:
  institution: A purpose-scoped persistent governance subject constituted by registered identity, constitution, organs,
    procedures, and continuity; not merely a faction, member set, leader, asset set, or territory.
  organization: A structured association that may or may not qualify as an authoritative institution under a registered
    constitution profile.
  organ: A typed institutional-governance concept for organ; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  office: A persistent institutional position with a mandate, authority, eligibility, term, and succession profile.
  officeholder: An identity-bound subject occupying an office for a recorded interval; distinct from the office.
  branch: A typed institutional-governance concept for branch; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  agency: A typed institutional-governance concept for agency; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  council: A typed institutional-governance concept for council; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  tribunal: A typed institutional-governance concept for tribunal; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  constituency: A typed institutional-governance concept for constituency; identity, constitution, organ or office, mandate,
    authority, procedure, time, and continuity must be explicit.
  charter: A typed institutional-governance concept for charter; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  constitution: A typed institutional-governance concept for constitution; identity, constitution, organ or office, mandate,
    authority, procedure, time, and continuity must be explicit.
  mandate: A typed institutional-governance concept for mandate; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  delegation: A typed institutional-governance concept for delegation; identity, constitution, organ or office, mandate,
    authority, procedure, time, and continuity must be explicit.
  representation: A typed institutional-governance concept for representation; identity, constitution, organ or office,
    mandate, authority, procedure, time, and continuity must be explicit.
  governance_procedure: A typed institutional-governance concept for governance procedure; identity, constitution, organ
    or office, mandate, authority, procedure, time, and continuity must be explicit.
  quorum: A typed institutional-governance concept for quorum; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  vote: A typed institutional-governance concept for vote; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  decision_procedure: A typed institutional-governance concept for decision procedure; identity, constitution, organ or
    office, mandate, authority, procedure, time, and continuity must be explicit.
  institutional_action: A typed institutional-governance concept for institutional action; identity, constitution, organ
    or office, mandate, authority, procedure, time, and continuity must be explicit.
  succession: A typed institutional-governance concept for succession; identity, constitution, organ or office, mandate,
    authority, procedure, time, and continuity must be explicit.
  dissolution: A typed institutional-governance concept for dissolution; identity, constitution, organ or office, mandate,
    authority, procedure, time, and continuity must be explicit.
  institutional_identity: A typed institutional-governance concept for institutional identity; identity, constitution,
    organ or office, mandate, authority, procedure, time, and continuity must be explicit.
  institutional_agency: A typed institutional-governance concept for institutional agency; identity, constitution, organ
    or office, mandate, authority, procedure, time, and continuity must be explicit.
  institutional_memory: A typed institutional-governance concept for institutional memory; identity, constitution, organ
    or office, mandate, authority, procedure, time, and continuity must be explicit.
  institutional_capture: A typed institutional-governance concept for institutional capture; identity, constitution, organ
    or office, mandate, authority, procedure, time, and continuity must be explicit.
  coup: A typed institutional-governance concept for coup; identity, constitution, organ or office, mandate, authority,
    procedure, time, and continuity must be explicit.
  constitutional_crisis: A typed institutional-governance concept for constitutional crisis; identity, constitution, organ
    or office, mandate, authority, procedure, time, and continuity must be explicit.
  jurisdiction: Purpose-scoped institutional competence to make, apply, interpret, adjudicate, or enforce rules over specified
    subjects, matters, places, relations, or events.
  territorial_jurisdiction: A registered jurisdictional concept for territorial jurisdiction; purpose, basis, subject
    matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
  personal_jurisdiction: A registered jurisdictional concept for personal jurisdiction; purpose, basis, subject matter,
    subjects, territory or domain, time, forum, and dispute status must be explicit.
  subject_matter_jurisdiction: A registered jurisdictional concept for subject matter jurisdiction; purpose, basis, subject
    matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
  appellate_jurisdiction: A registered jurisdictional concept for appellate jurisdiction; purpose, basis, subject matter,
    subjects, territory or domain, time, forum, and dispute status must be explicit.
  concurrent_jurisdiction: A registered jurisdictional concept for concurrent jurisdiction; purpose, basis, subject matter,
    subjects, territory or domain, time, forum, and dispute status must be explicit.
  exclusive_jurisdiction: A registered jurisdictional concept for exclusive jurisdiction; purpose, basis, subject matter,
    subjects, territory or domain, time, forum, and dispute status must be explicit.
  delegated_jurisdiction: A registered jurisdictional concept for delegated jurisdiction; purpose, basis, subject matter,
    subjects, territory or domain, time, forum, and dispute status must be explicit.
  residual_jurisdiction: A registered jurisdictional concept for residual jurisdiction; purpose, basis, subject matter,
    subjects, territory or domain, time, forum, and dispute status must be explicit.
  extraterritorial_jurisdiction: A registered jurisdictional concept for extraterritorial jurisdiction; purpose, basis,
    subject matter, subjects, territory or domain, time, forum, and dispute status must be explicit.
  forum: A registered jurisdictional concept for forum; purpose, basis, subject matter, subjects, territory or domain,
    time, forum, and dispute status must be explicit.
  competence: A registered jurisdictional concept for competence; purpose, basis, subject matter, subjects, territory
    or domain, time, forum, and dispute status must be explicit.
  forum_competence: A procedure or adjudication concept for forum competence; forum, roles, standing, procedure version,
    evidence basis, timing, determination status, and review path must be explicit.
  choice_of_law: A registered jurisdictional concept for choice of law; purpose, basis, subject matter, subjects, territory
    or domain, time, forum, and dispute status must be explicit.
  conflict_of_law: A registered jurisdictional concept for conflict of law; purpose, basis, subject matter, subjects,
    territory or domain, time, forum, and dispute status must be explicit.
  jurisdiction_basis: A registered jurisdictional concept for jurisdiction basis; purpose, basis, subject matter, subjects,
    territory or domain, time, forum, and dispute status must be explicit.
  jurisdiction_scope: A registered jurisdictional concept for jurisdiction scope; purpose, basis, subject matter, subjects,
    territory or domain, time, forum, and dispute status must be explicit.
  jurisdictional_immunity: A registered jurisdictional concept for jurisdictional immunity; purpose, basis, subject matter,
    subjects, territory or domain, time, forum, and dispute status must be explicit.
  right: A typed relational normative-position concept for right; holder, counterparty, object, scope, conditions, jurisdiction,
    lifecycle, and source must be explicit.
  claim_right: A relational position held by one subject correlating to a duty of a specified counterparty concerning
    a defined object and scope.
  liberty: A relational absence of duty not to perform a specified act; it does not imply assistance, capability, or a
    claim against interference.
  privilege: A typed relational normative-position concept for privilege; holder, counterparty, object, scope, conditions,
    jurisdiction, lifecycle, and source must be explicit.
  power: A normative ability to alter a specified legal or institutional relation through a valid act.
  immunity: A position protecting a holder from another subject’s normative power over a specified relation.
  duty: A relational requirement owed by a specified subject under a named rule; distinct from motive, intention, obedience,
    and performance.
  liability: Exposure to another subject’s valid exercise of a normative power.
  disability: Absence of normative power to alter a specified relation.
  no_right: Absence of a claim-right against a specified counterparty concerning a defined object.
  permission: A rule- or authority-scoped authorization that conduct is not prohibited within stated conditions; separate
    from consent, capability, and success.
  prohibition: A typed relational normative-position concept for prohibition; holder, counterparty, object, scope, conditions,
    jurisdiction, lifecycle, and source must be explicit.
  protection: A typed relational normative-position concept for protection; holder, counterparty, object, scope, conditions,
    jurisdiction, lifecycle, and source must be explicit.
  entitlement: A typed relational normative-position concept for entitlement; holder, counterparty, object, scope, conditions,
    jurisdiction, lifecycle, and source must be explicit.
  license: A typed relational normative-position concept for license; holder, counterparty, object, scope, conditions,
    jurisdiction, lifecycle, and source must be explicit.
  exemption: A typed relational normative-position concept for exemption; holder, counterparty, object, scope, conditions,
    jurisdiction, lifecycle, and source must be explicit.
  standing: A typed relational normative-position concept for standing; holder, counterparty, object, scope, conditions,
    jurisdiction, lifecycle, and source must be explicit.
  remedy: A typed relational normative-position concept for remedy; holder, counterparty, object, scope, conditions, jurisdiction,
    lifecycle, and source must be explicit.
  procedural_right: A typed relational normative-position concept for procedural right; holder, counterparty, object,
    scope, conditions, jurisdiction, lifecycle, and source must be explicit.
  remedial_right: A typed relational normative-position concept for remedial right; holder, counterparty, object, scope,
    conditions, jurisdiction, lifecycle, and source must be explicit.
  position_holder: A typed relational normative-position concept for position holder; holder, counterparty, object, scope,
    conditions, jurisdiction, lifecycle, and source must be explicit.
  position_counterparty: A typed relational normative-position concept for position counterparty; holder, counterparty,
    object, scope, conditions, jurisdiction, lifecycle, and source must be explicit.
  position_object: A typed relational normative-position concept for position object; holder, counterparty, object, scope,
    conditions, jurisdiction, lifecycle, and source must be explicit.
  position_scope: A typed relational normative-position concept for position scope; holder, counterparty, object, scope,
    conditions, jurisdiction, lifecycle, and source must be explicit.
  position_condition: A typed relational normative-position concept for position condition; holder, counterparty, object,
    scope, conditions, jurisdiction, lifecycle, and source must be explicit.
  position_lifecycle: A typed relational normative-position concept for position lifecycle; holder, counterparty, object,
    scope, conditions, jurisdiction, lifecycle, and source must be explicit.
  rule: A versioned rule-material concept for rule; authority, structured semantics, text lineage, jurisdiction, lifecycle,
    interpretation profile, and source-local boundary must be explicit.
  law: A rule family asserted as legally authoritative within a specified legal system and jurisdiction; distinct from
    policy, norm, morality, physical law, and source-local metaphysical constraint.
  statute: A versioned rule-material concept for statute; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  regulation: A versioned rule-material concept for regulation; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  decree: A versioned rule-material concept for decree; authority, structured semantics, text lineage, jurisdiction, lifecycle,
    interpretation profile, and source-local boundary must be explicit.
  ordinance: A versioned rule-material concept for ordinance; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  policy: A versioned rule-material concept for policy; authority, structured semantics, text lineage, jurisdiction, lifecycle,
    interpretation profile, and source-local boundary must be explicit.
  precedent: A versioned rule-material concept for precedent; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  treaty: A versioned rule-material concept for treaty; authority, structured semantics, text lineage, jurisdiction, lifecycle,
    interpretation profile, and source-local boundary must be explicit.
  custom: A versioned rule-material concept for custom; authority, structured semantics, text lineage, jurisdiction, lifecycle,
    interpretation profile, and source-local boundary must be explicit.
  legal_norm: A versioned rule-material concept for legal norm; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  standard: A versioned rule-material concept for standard; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  exception: A versioned rule-material concept for exception; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  defense: A versioned rule-material concept for defense; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  validity: A determination that a rule or institutional act was created by a competent source through required procedure
    and form.
  effectivity: The temporal and conditional state in which a valid rule is in force.
  applicability: A determination that an effective rule governs a specific subject, conduct, object, event, or relation
    in context.
  interpretation: A versioned rule-material concept for interpretation; authority, structured semantics, text lineage,
    jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
  repeal: A versioned rule-material concept for repeal; authority, structured semantics, text lineage, jurisdiction, lifecycle,
    interpretation profile, and source-local boundary must be explicit.
  suspension: A versioned rule-material concept for suspension; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  expiration: A versioned rule-material concept for expiration; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  amendment: A versioned rule-material concept for amendment; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  publication: A versioned rule-material concept for publication; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  notice: A versioned rule-material concept for notice; authority, structured semantics, text lineage, jurisdiction, lifecycle,
    interpretation profile, and source-local boundary must be explicit.
  retroactivity: A versioned rule-material concept for retroactivity; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  severability: A versioned rule-material concept for severability; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  derogation: A versioned rule-material concept for derogation; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  rule_hierarchy: A versioned rule-material concept for rule hierarchy; authority, structured semantics, text lineage,
    jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
  rule_version: A versioned rule-material concept for rule version; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  rule_authority: A versioned rule-material concept for rule authority; authority, structured semantics, text lineage,
    jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
  rule_conflict: A versioned rule-material concept for rule conflict; authority, structured semantics, text lineage, jurisdiction,
    lifecycle, interpretation profile, and source-local boundary must be explicit.
  source_local_legal_construct: A versioned rule-material concept for source local legal construct; authority, structured
    semantics, text lineage, jurisdiction, lifecycle, interpretation profile, and source-local boundary must be explicit.
  complaint: A procedure or adjudication concept for complaint; forum, roles, standing, procedure version, evidence basis,
    timing, determination status, and review path must be explicit.
  claim: A procedure or adjudication concept for claim; forum, roles, standing, procedure version, evidence basis, timing,
    determination status, and review path must be explicit.
  allegation: A procedure or adjudication concept for allegation; forum, roles, standing, procedure version, evidence
    basis, timing, determination status, and review path must be explicit.
  charge: A procedure or adjudication concept for charge; forum, roles, standing, procedure version, evidence basis, timing,
    determination status, and review path must be explicit.
  filing: A procedure or adjudication concept for filing; forum, roles, standing, procedure version, evidence basis, timing,
    determination status, and review path must be explicit.
  petition: A procedure or adjudication concept for petition; forum, roles, standing, procedure version, evidence basis,
    timing, determination status, and review path must be explicit.
  service: A procedure or adjudication concept for service; forum, roles, standing, procedure version, evidence basis,
    timing, determination status, and review path must be explicit.
  investigation: A procedure or adjudication concept for investigation; forum, roles, standing, procedure version, evidence
    basis, timing, determination status, and review path must be explicit.
  hearing: A procedure or adjudication concept for hearing; forum, roles, standing, procedure version, evidence basis,
    timing, determination status, and review path must be explicit.
  trial: A procedure or adjudication concept for trial; forum, roles, standing, procedure version, evidence basis, timing,
    determination status, and review path must be explicit.
  adjudication: A forum-owned procedure producing institutional findings and dispositions; distinct from objective truth,
    AFQR-06 arbitration, investigation, responsibility, punishment, and social judgment.
  evidence: A procedure or adjudication concept for evidence; forum, roles, standing, procedure version, evidence basis,
    timing, determination status, and review path must be explicit.
  admissibility: A procedure or adjudication concept for admissibility; forum, roles, standing, procedure version, evidence
    basis, timing, determination status, and review path must be explicit.
  burden: A procedure or adjudication concept for burden; forum, roles, standing, procedure version, evidence basis, timing,
    determination status, and review path must be explicit.
  standard_of_determination: A procedure or adjudication concept for standard of determination; forum, roles, standing,
    procedure version, evidence basis, timing, determination status, and review path must be explicit.
  finding_of_fact: A procedure or adjudication concept for finding of fact; forum, roles, standing, procedure version,
    evidence basis, timing, determination status, and review path must be explicit.
  finding_of_rule: A procedure or adjudication concept for finding of rule; forum, roles, standing, procedure version,
    evidence basis, timing, determination status, and review path must be explicit.
  judgment: A committed adjudicative disposition with scope, reasons, remedies, appeal status, and finality state; not
    metaphysical truth.
  order: A procedure or adjudication concept for order; forum, roles, standing, procedure version, evidence basis, timing,
    determination status, and review path must be explicit.
  appeal: A procedure or adjudication concept for appeal; forum, roles, standing, procedure version, evidence basis, timing,
    determination status, and review path must be explicit.
  review: A procedure or adjudication concept for review; forum, roles, standing, procedure version, evidence basis, timing,
    determination status, and review path must be explicit.
  finality: A procedure or adjudication concept for finality; forum, roles, standing, procedure version, evidence basis,
    timing, determination status, and review path must be explicit.
  dissent: A procedure or adjudication concept for dissent; forum, roles, standing, procedure version, evidence basis,
    timing, determination status, and review path must be explicit.
  recusal: A procedure or adjudication concept for recusal; forum, roles, standing, procedure version, evidence basis,
    timing, determination status, and review path must be explicit.
  reasoning_manifest: A procedure or adjudication concept for reasoning manifest; forum, roles, standing, procedure version,
    evidence basis, timing, determination status, and review path must be explicit.
  disposition: A procedure or adjudication concept for disposition; forum, roles, standing, procedure version, evidence
    basis, timing, determination status, and review path must be explicit.
  procedural_validity: A procedure or adjudication concept for procedural validity; forum, roles, standing, procedure
    version, evidence basis, timing, determination status, and review path must be explicit.
  enforcement: The institutional process of attempting to realize an authorized rule, judgment, remedy, or order through
    proper state owners.
  enforcement_authority: A remedy or enforcement concept for enforcement authority; authority, target, scope, preconditions,
    attempt, execution, success, collateral effects, and review must remain separate.
  enforcement_authorization: A remedy or enforcement concept for enforcement authorization; authority, target, scope,
    preconditions, attempt, execution, success, collateral effects, and review must remain separate.
  warrant: A remedy or enforcement concept for warrant; authority, target, scope, preconditions, attempt, execution, success,
    collateral effects, and review must remain separate.
  summons: A remedy or enforcement concept for summons; authority, target, scope, preconditions, attempt, execution, success,
    collateral effects, and review must remain separate.
  arrest: A remedy or enforcement concept for arrest; authority, target, scope, preconditions, attempt, execution, success,
    collateral effects, and review must remain separate.
  detention: A remedy or enforcement concept for detention; authority, target, scope, preconditions, attempt, execution,
    success, collateral effects, and review must remain separate.
  search: A remedy or enforcement concept for search; authority, target, scope, preconditions, attempt, execution, success,
    collateral effects, and review must remain separate.
  seizure: A remedy or enforcement concept for seizure; authority, target, scope, preconditions, attempt, execution, success,
    collateral effects, and review must remain separate.
  sanction: A remedy or enforcement concept for sanction; authority, target, scope, preconditions, attempt, execution,
    success, collateral effects, and review must remain separate.
  fine: A remedy or enforcement concept for fine; authority, target, scope, preconditions, attempt, execution, success,
    collateral effects, and review must remain separate.
  restitution: A remedy or enforcement concept for restitution; authority, target, scope, preconditions, attempt, execution,
    success, collateral effects, and review must remain separate.
  forfeiture: A remedy or enforcement concept for forfeiture; authority, target, scope, preconditions, attempt, execution,
    success, collateral effects, and review must remain separate.
  injunction: A remedy or enforcement concept for injunction; authority, target, scope, preconditions, attempt, execution,
    success, collateral effects, and review must remain separate.
  expulsion: A remedy or enforcement concept for expulsion; authority, target, scope, preconditions, attempt, execution,
    success, collateral effects, and review must remain separate.
  exile: A remedy or enforcement concept for exile; authority, target, scope, preconditions, attempt, execution, success,
    collateral effects, and review must remain separate.
  rehabilitation: A remedy or enforcement concept for rehabilitation; authority, target, scope, preconditions, attempt,
    execution, success, collateral effects, and review must remain separate.
  pardon: A remedy or enforcement concept for pardon; authority, target, scope, preconditions, attempt, execution, success,
    collateral effects, and review must remain separate.
  amnesty: A remedy or enforcement concept for amnesty; authority, target, scope, preconditions, attempt, execution, success,
    collateral effects, and review must remain separate.
  enforcement_discretion: A remedy or enforcement concept for enforcement discretion; authority, target, scope, preconditions,
    attempt, execution, success, collateral effects, and review must remain separate.
  enforcement_attempt: A remedy or enforcement concept for enforcement attempt; authority, target, scope, preconditions,
    attempt, execution, success, collateral effects, and review must remain separate.
  enforcement_execution: A remedy or enforcement concept for enforcement execution; authority, target, scope, preconditions,
    attempt, execution, success, collateral effects, and review must remain separate.
  enforcement_success: A remedy or enforcement concept for enforcement success; authority, target, scope, preconditions,
    attempt, execution, success, collateral effects, and review must remain separate.
  collateral_effect: A remedy or enforcement concept for collateral effect; authority, target, scope, preconditions, attempt,
    execution, success, collateral effects, and review must remain separate.
  legitimacy: A profile- and audience-scoped claim that an institution or authority is entitled, justified, accepted,
    or appropriately constituted to govern.
  recognition: A typed acknowledgment by an audience or institution of status, authority, identity, government, judgment,
    or relation; not legitimacy or sovereignty.
  sovereignty: A profile- and audience-scoped governance concept for sovereignty; legality, recognition, control, social
    support, and legitimacy must not be collapsed.
  de_facto_authority: A profile- and audience-scoped governance concept for de facto authority; legality, recognition,
    control, social support, and legitimacy must not be collapsed.
  de_jure_authority: A profile- and audience-scoped governance concept for de jure authority; legality, recognition, control,
    social support, and legitimacy must not be collapsed.
  effective_control: An observation that a subject can practically direct or constrain a domain; not jurisdiction, lawful
    authority, or legitimacy.
  compliance: A profile- and audience-scoped governance concept for compliance; legality, recognition, control, social
    support, and legitimacy must not be collapsed.
  acquiescence: A profile- and audience-scoped governance concept for acquiescence; legality, recognition, control, social
    support, and legitimacy must not be collapsed.
  resistance: A profile- and audience-scoped governance concept for resistance; legality, recognition, control, social
    support, and legitimacy must not be collapsed.
  rebellion: A profile- and audience-scoped governance concept for rebellion; legality, recognition, control, social support,
    and legitimacy must not be collapsed.
  secession: A profile- and audience-scoped governance concept for secession; legality, recognition, control, social support,
    and legitimacy must not be collapsed.
  occupation: A profile- and audience-scoped governance concept for occupation; legality, recognition, control, social
    support, and legitimacy must not be collapsed.
  annexation: A profile- and audience-scoped governance concept for annexation; legality, recognition, control, social
    support, and legitimacy must not be collapsed.
  government_in_exile: A profile- and audience-scoped governance concept for government in exile; legality, recognition,
    control, social support, and legitimacy must not be collapsed.
  successor_institution: A profile- and audience-scoped governance concept for successor institution; legality, recognition,
    control, social support, and legitimacy must not be collapsed.
  public_record: A profile- and audience-scoped governance concept for public record; legality, recognition, control,
    social support, and legitimacy must not be collapsed.
  official_record: A profile- and audience-scoped governance concept for official record; legality, recognition, control,
    social support, and legitimacy must not be collapsed.
  legal_person: A profile- and audience-scoped governance concept for legal person; legality, recognition, control, social
    support, and legitimacy must not be collapsed.
  legal_status: A profile- and audience-scoped governance concept for legal status; legality, recognition, control, social
    support, and legitimacy must not be collapsed.
  legal_validity: A profile- and audience-scoped governance concept for legal validity; legality, recognition, control,
    social support, and legitimacy must not be collapsed.
  legality: A profile- and audience-scoped governance concept for legality; legality, recognition, control, social support,
    and legitimacy must not be collapsed.
  violation_claim: A profile- and audience-scoped governance concept for violation claim; legality, recognition, control,
    social support, and legitimacy must not be collapsed.
  violation_determination: A profile- and audience-scoped governance concept for violation determination; legality, recognition,
    control, social support, and legitimacy must not be collapsed.
  liability_determination: A profile- and audience-scoped governance concept for liability determination; legality, recognition,
    control, social support, and legitimacy must not be collapsed.
  responsibility_assessment: A profile- and audience-scoped governance concept for responsibility assessment; legality,
    recognition, control, social support, and legitimacy must not be collapsed.
  emergency: A determined condition activating a registered exception regime; not a self-authenticating label or unlimited
    authority.
  emergency_declaration: A typed emergency, continuity, simulation, or security concept for emergency declaration; scope,
    authority, visibility, temporal basis, and review must be explicit.
  emergency_authority: A typed emergency, continuity, simulation, or security concept for emergency authority; scope,
    authority, visibility, temporal basis, and review must be explicit.
  emergency_scope: A typed emergency, continuity, simulation, or security concept for emergency scope; scope, authority,
    visibility, temporal basis, and review must be explicit.
  procedure_suspension: A typed emergency, continuity, simulation, or security concept for procedure suspension; scope,
    authority, visibility, temporal basis, and review must be explicit.
  renewal: A typed emergency, continuity, simulation, or security concept for renewal; scope, authority, visibility, temporal
    basis, and review must be explicit.
  sunset: A typed emergency, continuity, simulation, or security concept for sunset; scope, authority, visibility, temporal
    basis, and review must be explicit.
  post_emergency_review: A typed emergency, continuity, simulation, or security concept for post emergency review; scope,
    authority, visibility, temporal basis, and review must be explicit.
  nonderogable_position: A typed emergency, continuity, simulation, or security concept for nonderogable position; scope,
    authority, visibility, temporal basis, and review must be explicit.
  emergency_abuse_claim: A typed emergency, continuity, simulation, or security concept for emergency abuse claim; scope,
    authority, visibility, temporal basis, and review must be explicit.
  institutional_simulation_tier: A typed emergency, continuity, simulation, or security concept for institutional simulation
    tier; scope, authority, visibility, temporal basis, and review must be explicit.
  institutional_projection: A typed emergency, continuity, simulation, or security concept for institutional projection;
    scope, authority, visibility, temporal basis, and review must be explicit.
  institutional_narration: A typed emergency, continuity, simulation, or security concept for institutional narration;
    scope, authority, visibility, temporal basis, and review must be explicit.
  lawful_unresolved_outcome: A determination status recording missing, conflicting, incomparable, or insufficient bases
    without inventing certainty.
  sealed_record: A typed emergency, continuity, simulation, or security concept for sealed record; scope, authority, visibility,
    temporal basis, and review must be explicit.
  classified_policy: A typed emergency, continuity, simulation, or security concept for classified policy; scope, authority,
    visibility, temporal basis, and review must be explicit.
  covert_warrant: A typed emergency, continuity, simulation, or security concept for covert warrant; scope, authority,
    visibility, temporal basis, and review must be explicit.
  protected_identity: A typed emergency, continuity, simulation, or security concept for protected identity; scope, authority,
    visibility, temporal basis, and review must be explicit.
guarantees:
- federated institutional ownership
- persistent institutional identity
- purpose-scoped jurisdiction
- relational normative positions
- immutable rule versions
- protocol-governed adjudication
- append-only appeal history
- separated authorization and execution
- profiled legitimacy
- bounded emergency powers
- family-specific continuity
- hidden-safe replay
non_guarantees:
- universal legal code
- universal rights catalogue
- universal morality
- universal sovereignty theory
- universal jurisdiction hierarchy
- universal interpretation method
- universal standard of proof
- universal punishment model
- automatic enforcement
- authoritative model interpretation
institution_model:
  not_equivalent_to:
  - faction
  - collective
  - government label
  - officeholder
  - membership set
  - territory
  formal_and_informal_profiles: true
  federated_owners: true
institutional_identity_model:
  persistent: true
  independent_of:
  - name
  - headquarters
  - leadership
  - membership
  - recognition
constitution_model:
  versioned: true
  structured_and_textual: true
  append_only_amendment: true
organ_and_office_model:
  organ_office_officeholder_separate: true
  vacancy_and_acting_supported: true
mandate_and_delegation_model:
  authority_families:
  - original
  - delegated
  - subdelegated
  - acting
  - apparent
  - collective
  - emergency
  scope_term_conditions_revocation_notice: true
institutional_action_model:
  decision_procedure_required: true
  representation_authority_required: true
  AFQR11_action_origin: true
institutional_continuity_model:
  families:
  - identity
  - constitution
  - organs
  - offices
  - mandates
  - rules
  - jurisdiction
  - assets
  - treaties
  - debts
  - judgments
  - records
  - recognition
  - legitimacy claims
  automatic_transfer: false
jurisdiction_model:
  bases:
  - territory
  - person
  - citizenship
  - residency
  - office
  - membership
  - contract
  - property
  - vessel
  - network
  - domain
  - action
  - subject matter
  - species
  - plane
  - source-local relation
  outcomes:
  - selected
  - concurrent
  - exclusive
  - delegated
  - residual
  - disputed
  - absent
  - unresolved
jurisdiction_conflict_model:
  typed_conflict_sets: true
  parallel_proceedings: true
  universal_priority_rule: false
choice_of_law_model:
  registered_profiles: true
  version_pinned: true
  unresolved_supported: true
immunity_model:
  relational: true
  purpose_scoped: true
  dispute_and_forgery_supported: true
normative_position_model:
  core:
  - claim-right/duty
  - liberty/no-right
  - power/liability
  - immunity/disability
  extensions:
  - permission
  - prohibition
  - protection
  - entitlement
  - license
  - exemption
  - standing
  - procedural right
  - remedial right
  relational_fields:
  - holder
  - counterparty
  - object
  - scope
  - condition
  - lifecycle
rights_model:
  universal_catalogue: false
  jurisdiction_scoped: true
  unrecognized_and_unresolved_supported: true
permission_and_prohibition_model:
  permission_not_consent_or_capability: true
  prohibition_not_execution: true
duty_and_liability_model:
  duty_not_motive: true
  liability_requires_power_and_scope: true
rule_model:
  families:
  - constitution
  - charter
  - statute
  - regulation
  - decree
  - ordinance
  - policy
  - precedent
  - treaty
  - custom
  - religious rule
  - military order
  - procedure
  - emergency order
  - source-local metaphysical rule
  freeform_prose_executable: false
rule_versioning_model:
  immutable_versions: true
  historical_versions_retained: true
enactment_model:
  authority_procedure_quorum_vote_or_source_local_requirements: true
  enactment_not_effectivity: true
publication_and_notice_model:
  publication_notice_delivery_access_knowledge_separate: true
  secret_rule_profiles: true
effectivity_model:
  validity_effectivity_applicability_separate: true
  retroactivity_profiled: true
rule_conflict_model:
  typed_conflicts: true
  selection_profiled: true
  newer_or_specific_not_universal: true
rule_interpretation_model:
  candidate_sets: true
  profiles_versioned: true
  text_purpose_precedent_systemic_separate: true
  model_authority: false
  incomparability: true
procedure_model:
  registered_protocols: true
  roles_moves_notice_quorum_validity: true
  long_running_state: true
standing_model:
  procedure_specific: true
  distinct_from_merits: true
forum_competence_model:
  jurisdiction_and_subject_matter_required: true
quorum_and_vote_model:
  vote_not_decision: true
  deterministic_concurrent_moves: true
adjudication_model:
  distinct_from:
  - world truth
  - AFQR-06 arbitration
  - investigation
  - prosecution
  - punishment
  - social judgment
  forum_owned: true
evidence_and_admissibility_model:
  AFQR10_reuse: true
  authenticity_relevance_admissibility_purpose_separate: true
burden_and_standard_model:
  procedure_scoped: true
  universal_standard: false
finding_model:
  fact_and_rule_separate: true
  error_and_dispute_supported: true
judgment_model:
  not_world_truth: true
  not_universal_responsibility: true
  remedy_and_finality_separate: true
reasoning_and_dissent_model:
  structured_reasoning: true
  dissent_preserved: true
appeal_model:
  new_proceeding_not_retry: true
  right_timing_scope_standard_required: true
review_model:
  outcomes:
  - affirm
  - reverse
  - modify
  - remand
  - dismiss
  - unresolved
  challenged_record_immutable: true
stay_model:
  separate_from_reversal: true
finality_model:
  bitemporal: true
  exceptional_reopening_profiled: true
remedy_model:
  eligibility_authorization_execution_separate: true
  future_physical_handoffs: true
sanction_model:
  authorization_not_completed_punishment: true
  universal_scale: false
enforcement_authority_model:
  authority_capability_authorization_attempt_execution_success_separate: true
warrant_model:
  target_scope_method_term_preconditions_review: true
  identity_verification: true
enforcement_execution_handoff:
  AFQR03: action gateway
  AFQR07: resources/settlement
  AFQR11: agency/control
  AFQR16: physical consequences
legitimacy_model:
  profiles:
  - legal
  - procedural
  - traditional
  - charismatic claim
  - performance
  - democratic
  - religious
  - source-local sacred
  audience_relative: true
  incomparable_supported: true
recognition_model:
  separate_from:
  - legitimacy
  - sovereignty
  - jurisdiction
  - validity
  audience_scoped: true
sovereignty_claim_model:
  source_and_profile_scoped: true
  not_settled_by_control: true
effective_control_model:
  AFQR11_observation: true
  not_authority_or_legitimacy: true
emergency_power_model:
  trigger_authority_scope_enumerated_powers_duration: true
  unbounded_default: false
emergency_review_model:
  reporting_review_renewal_post_audit: true
  renewal_new_action: true
sunset_model:
  enforceable: true
institutional_simulation_tier_model:
  tiers:
  - static_reference
  - policy_summary
  - aggregate_governance
  - procedure_active
  - adjudication_active
  - full_institutional_fixture
institutional_materialization_policy:
  promotion_cannot_invent_history: true
  demotion_preserves_reconstruction_basis: true
identity_handoff: AFQR-08
epistemic_handoff: AFQR-10
agency_handoff: AFQR-11
behavioral_handoff: AFQR-12
social_handoff: AFQR-13
communication_handoff: AFQR-14
governed_relation_handoff: AFQR-09
quantity_and_settlement_handoff: AFQR-07
action_gateway_handoff: AFQR-03
scheduler_handoff: AFQR-04
hidden_institutional_state_policy:
  private_receipts: true
  sealed_classified_covert_records: true
  no_private_identifiers_in_projection: true
visible_projection_policy:
  audience_minimized: true
  uncertainty_exact: true
  public_record_not_world_truth: true
model_context_policy:
  grounding_manifest: true
  permitted_claim_kinds: true
  evidence_bindings: true
model_output_validation:
  required: true
  forbidden_claims:
  - legality
  - guilt
  - authority
  - rights
  - jurisdiction
  - legitimacy
  - enforcement completion
  wording_candidate_only: true
side_channel_protection:
  threat_count: 28
  audience_tokens: true
  projection_digests: true
  cross_packet_isolation: true
historical_replay_policy:
  historical_versions_and_decisions_retained: true
  current_policy_no_rewrite: true
  missing_evaluator: unverifiable
bitemporal_policy:
  record_specific: true
  times:
  - effective
  - recorded
  - logical
  - publication
  - notice
  - filing
  - hearing
  - decision
  - finality
  - enforcement
owner_boundaries:
  federated: true
  coordinators_non_mutating: true
  owner_count: 17
AFQR_handoffs:
  AFQR-01: required typed dependency
  AFQR-02: required typed dependency
  AFQR-03: required typed dependency
  AFQR-04: required typed dependency
  AFQR-05: required typed dependency
  AFQR-06: required typed dependency
  AFQR-07: required typed dependency
  AFQR-08: required typed dependency
  AFQR-09: required typed dependency
  AFQR-10: required typed dependency
  AFQR-11: required typed dependency
  AFQR-12: required typed dependency
  AFQR-13: required typed dependency
  AFQR-14: required typed dependency
uplifted_subject_stress_case:
  subjects:
  - uplifted_subject
  - former_guardian
  - interpreter
  - local_forum
  - religious_body
  - corporation
  - public_audiences
  - emergency_authority
  - appellate_forum
  findings:
  - Forum competence precedes status merits.
  - AFQR-11 agency does not itself decide legal status.
  - Ownership, guardianship, parenthood, representation, and dependency are separate.
  - Missing subject category yields unrecognized or unresolved status, not property by default.
  - Interpreter mediation cannot replace self-expression or consent.
  - Religious recognition and corporate property classification are competing claims.
  - Emergency movement restrictions require trigger, authority, scope, review, and sunset.
  - Resource control routes through AFQR-07 and governed-relation owners.
  - Appeal access is an explicit normative position.
  records:
  - StandingDetermination
  - ForumCompetenceDetermination
  - NormativePositionInstance
  - JurisdictionDetermination
  - EvidenceSubmission
  - EmergencyAuthorityGrant
  - RemedyAuthorization
  - AppealRightReference
  - PrivateInstitutionalReceipt
  - ModelVisibleInstitutionalProjection
  lawful_disposition: Status may remain unresolved while the subject receives named procedural or interim protections.
    Property is not the default.
familiar_tribunal_stress_case:
  subjects:
  - autonomous_derivative
  - original_familiar
  - signer
  - contract_authority
  - tribunal
  - challenged_member
  - translator
  - public_audience
  - enforcement_agents
  findings:
  - Identity, lineage, property classification, jurisdiction, and representation are separate.
  - Hidden communication limits do not establish informed consent.
  - Ritual declarations require source-local standing, form, procedure, and causal bridge.
  - Bias requires conflict and recusal determination.
  - Translated evidence retains omission and ambiguity lineage.
  - Public and sealed records have separate projections.
  - Seizure requires enforceable authorization, target identity, warrant scope, and appeal/stay status.
  records:
  - JurisdictionClaim
  - RuleInterpretationInputClosure
  - AdmissibilityDetermination
  - ProcedureValidityDetermination
  - JudgmentRecord
  - WarrantRecord
  - StayCandidate
  - PrivateAdjudicationReceipt
  lawful_disposition: No contract label, lineage assertion, or ritual wording authorizes representation or seizure automatically.
multiplanar_jurisdiction_stress_case:
  subjects:
  - actor
  - origin_plane
  - vessel_registry
  - victim_polity
  - neutral_hub
  - treaty_body
  - cosmic_claimant
  - diplomatic_mission
  - first_forum
  - nonrecognizing_forum
  findings:
  - Action origin, effect location, registry, citizenship, hub, and treaty create distinct bases.
  - Four claims may be concurrent, exclusive, allocated, or unresolved.
  - Cosmic law remains source-local without a certified bridge.
  - Immunity is jurisdiction-, subject-, act-, and purpose-specific.
  - First judgment does not bind every forum.
  - Recognition and enforcement are separate.
  - Boundary crossing requires AFQR-05 and enforcement authority.
  - Pending appeal changes finality without erasing judgment.
  records:
  - ConcurrentJurisdictionSet
  - ChoiceOfLawCandidate
  - JurisdictionalImmunityReference
  - ForumConflictRecord
  - InterjurisdictionalRecognitionRecord
  - AppellateDecision
  - EnforcementAuthorization
  lawful_disposition: Concurrent proceedings and conflicting recognition are lawful; no cosmic or first-filed priority
    is inferred.
institutional_capture_stress_case:
  subjects:
  - strategist
  - captured_institution
  - formal_leader
  - appointment_organs
  - proxies
  - quorum_members
  - appeal_bodies
  - foreign_affiliate
  - public
  - enforcement_organs
  findings:
  - Information control and appointment influence are practical control, not authority.
  - Proxy actions retain principal, controller, decision subject, and executor.
  - Quorum manipulation creates procedure claims but does not universally void all acts.
  - Emergency power requires trigger and bounded enumeration.
  - Public legitimacy is separate from procedure validity and control.
  - Secret warrants require private records and projection controls.
  - Suppressed appeals affect procedure and finality.
  - Foreign affiliation affects outcomes only through typed handoffs.
  - Institutional continuity can persist during capture.
  records:
  - InstitutionalActionOriginRecord
  - ProcedureQuorumRequirement
  - ProcedureViolationClaim
  - EmergencyAbuseClaim
  - LegitimacyConflictSet
  - PrivateEnforcementReceipt
  - RecognitionDetermination
  lawful_disposition: The strategist can hold practical control and responsibility exposure while lacking office authority,
    valid mandate, or legitimacy.
conversion_pipeline_handoff:
  pressure_IR_types:
  - InstitutionPressureIR
  - GovernancePressureIR
  - ConstitutionPressureIR
  - OfficePressureIR
  - MandatePressureIR
  - AuthorityPressureIR
  - DelegationPressureIR
  - JurisdictionPressureIR
  - NormativePositionPressureIR
  - RightPressureIR
  - PermissionPressureIR
  - DutyPressureIR
  - ImmunityPressureIR
  - LawPressureIR
  - PolicyPressureIR
  - PrecedentPressureIR
  - ProcedurePressureIR
  - AdjudicationPressureIR
  - EvidenceRulePressureIR
  - AppealPressureIR
  - RemedyPressureIR
  - SanctionPressureIR
  - EnforcementPressureIR
  - LegitimacyPressureIR
  - RecognitionPressureIR
  - EmergencyPowerPressureIR
  - TreatyPressureIR
  - InstitutionalContinuityPressureIR
  - SourceLocalLegalOntologyPressureIR
  campaign_state_effects_prohibited: true
  lawful_outcomes:
  - direct
  - normalized
  - source-local
  - quarantined
  - escalated
model_authority_policy:
  law_interpreter: false
  jurisdiction_selector: false
  rights_allocator: false
  adjudicator: false
  legitimacy_engine: false
  enforcement_authority: false
  institutional_decision_maker: false
  grounded_renderer: true
current_runtime_disposition:
  exists:
  - backend authority doctrine
  - reference-only owner contracts
  - narrow action-legality reader
  - visibility adapter
  - object/lever event and replay envelope
  fixture_only:
  - authority flags
  - action legality
  - actor/target/object refs
  - visible projections
  - in-memory receipts
  conversion_only:
  - faction/institution schema fields
  - rank/title/office/access/obligation descriptors
  - law/enforcement pressure
  - source-local setting law
  narrative_only:
  - institution descriptions
  - law/policy prose
  - court narration
  - model summaries
  absent:
  - institution registry
  - jurisdiction service
  - normative-position service
  - rule registry
  - applicability/interpretation
  - procedure/adjudication/appeal
  - remedy/enforcement
  - legitimacy/emergency
  - model validator
required_artifacts:
  immediate:
  - ADR
  - decision registry
  - terminology
  - repo audit
  - research
  - contracts
  - operations
  - conversion IR
  - threat model
  - adversarial pack
  - dry run
  - stress fixtures
  - acceptance matrix
  - corrected manifests
  before_authoritative_state:
  - institution/constitution/office registries
  - authority/delegation
  - action origin
  before_jurisdiction:
  - jurisdiction registry
  - rule version store
  - classification/conflict profiles
  before_rights:
  - normative-position owner
  - AFQR-09 integration
  before_adjudication:
  - forum/procedure
  - evidence/admissibility
  - burden/standard
  - appeal/finality
  before_enforcement:
  - remedy authorization
  - warrant/target identity
  - AFQR-03/07/11/16 integration
  before_model:
  - grounding
  - claim registry
  - evidence binding
  - validator
  - isolation
required_prototype:
  name: AFQR-15 Institution, Jurisdiction, Rights, Rule, Adjudication, and Enforcement Dry Run
  case_count: 50
  mutating: false
required_fixtures:
- AFQR15-DRY-001
- AFQR15-DRY-002
- AFQR15-DRY-003
- AFQR15-DRY-004
- AFQR15-DRY-005
- AFQR15-DRY-006
- AFQR15-DRY-007
- AFQR15-DRY-008
- AFQR15-DRY-009
- AFQR15-DRY-010
- AFQR15-DRY-011
- AFQR15-DRY-012
- AFQR15-DRY-013
- AFQR15-DRY-014
- AFQR15-DRY-015
- AFQR15-DRY-016
- AFQR15-DRY-017
- AFQR15-DRY-018
- AFQR15-DRY-019
- AFQR15-DRY-020
- AFQR15-DRY-021
- AFQR15-DRY-022
- AFQR15-DRY-023
- AFQR15-DRY-024
- AFQR15-DRY-025
- AFQR15-DRY-026
- AFQR15-DRY-027
- AFQR15-DRY-028
- AFQR15-DRY-029
- AFQR15-DRY-030
- AFQR15-DRY-031
- AFQR15-DRY-032
- AFQR15-DRY-033
- AFQR15-DRY-034
- AFQR15-DRY-035
- AFQR15-DRY-036
- AFQR15-DRY-037
- AFQR15-DRY-038
- AFQR15-DRY-039
- AFQR15-DRY-040
- AFQR15-DRY-041
- AFQR15-DRY-042
- AFQR15-DRY-043
- AFQR15-DRY-044
- AFQR15-DRY-045
- AFQR15-DRY-046
- AFQR15-DRY-047
- AFQR15-DRY-048
- AFQR15-DRY-049
- AFQR15-DRY-050
blocked_work:
- authoritative institution creation
- office/delegation mutation
- jurisdiction selection
- rule enactment/applicability
- rights mutation
- adjudication/appeal
- remedy/enforcement
- emergency activation
- model-authored legal results
work_unlocked:
- schema/registry design
- non-mutating dry runs
- jurisdiction/rule conflict fixtures
- normative-position certification
- adjudication/appeal candidates
- hidden-state validators
- bounded narration after validators
rejected_alternatives:
- freeform prose authority
- universal condition-action engine
- access control as full governance
- all governance reduced to contracts
- knowledge graph without owners/procedures
- court-centered universal model
- agent politics as legal authority
residual_risks:
- universal rights unresolved
- legitimacy plural
- morality separate
- citizenship/property/inheritance source-scoped
- criminal law/punishment deferred
- damages need AFQR-07
- detention/injury need AFQR-16
- war/occupation later
- population governance later
- interplanar sovereignty source-sensitive
- metaphysical law source-local
- distributed performance unbenchmarked
- model behavior needs certification
RT_002G_status: 'Unchanged narrow gate: object/lever context packet only; no institution, law, jurisdiction, adjudication,
  legitimacy, or enforcement semantics.'
next_foundational_question:
  question_id: AFQR-16
  title: Bodies, Structures, Damage, Injury, Conditions, Impairment, Death, Recovery, Repair, and Transformation
  central_question: How should Astra represent, own, apply, propagate, resist, diagnose, repair, recover, transform, and
    replay structural integrity, bodies, components, damage, injury, conditions, impairment, incapacitation, death, healing,
    repair, and transformation across biological, artificial, vehicle, swarm, distributed, metaphysical, and source-local
    subjects without collapsing harm, resource loss, status effects, capability loss, or narrative injury into one hit-point
    model?
  priority_reason: It is the largest remaining cross-cutting blocker for combat, hazards, enforcement consequences, health/recovery,
    items, vehicles, and Batch A damage families.
exact_next_roadmap_action: Ratify and register AFQR-15; execute the 50-case non-mutating governance dry run and an RT-002A–RT-002F
  institutional/model noninterference audit; keep RT-002G limited to a narrow object/lever context packet with no legal
  or institutional authority; then open AFQR-16 as a read-only foundational investigation.
```